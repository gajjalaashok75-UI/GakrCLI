import { i as _objectSpread2, o as _asyncToGenerator } from "./_plugin-vue_export-helper-BdaNZm_w.js";
import { _ as __vitePreload } from "./sidepanel-CNA6DX5t.js";
import { n as __name, t as __export } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import { h as setLogLevel, m as log } from "./src-C3sq9HJl.js";
//#region ../../node_modules/khroma/dist/utils/channel.js
var Channel = {
	min: {
		r: 0,
		g: 0,
		b: 0,
		s: 0,
		l: 0,
		a: 0
	},
	max: {
		r: 255,
		g: 255,
		b: 255,
		h: 360,
		s: 100,
		l: 100,
		a: 1
	},
	clamp: {
		r: (r) => r >= 255 ? 255 : r < 0 ? 0 : r,
		g: (g) => g >= 255 ? 255 : g < 0 ? 0 : g,
		b: (b) => b >= 255 ? 255 : b < 0 ? 0 : b,
		h: (h) => h % 360,
		s: (s) => s >= 100 ? 100 : s < 0 ? 0 : s,
		l: (l) => l >= 100 ? 100 : l < 0 ? 0 : l,
		a: (a) => a >= 1 ? 1 : a < 0 ? 0 : a
	},
	toLinear: (c) => {
		const n = c / 255;
		return c > .03928 ? Math.pow((n + .055) / 1.055, 2.4) : n / 12.92;
	},
	hue2rgb: (p, q, t) => {
		if (t < 0) t += 1;
		if (t > 1) t -= 1;
		if (t < 1 / 6) return p + (q - p) * 6 * t;
		if (t < 1 / 2) return q;
		if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
		return p;
	},
	hsl2rgb: ({ h, s, l }, channel) => {
		if (!s) return l * 2.55;
		h /= 360;
		s /= 100;
		l /= 100;
		const q = l < .5 ? l * (1 + s) : l + s - l * s;
		const p = 2 * l - q;
		switch (channel) {
			case "r": return Channel.hue2rgb(p, q, h + 1 / 3) * 255;
			case "g": return Channel.hue2rgb(p, q, h) * 255;
			case "b": return Channel.hue2rgb(p, q, h - 1 / 3) * 255;
		}
	},
	rgb2hsl: ({ r, g, b }, channel) => {
		r /= 255;
		g /= 255;
		b /= 255;
		const max = Math.max(r, g, b);
		const min = Math.min(r, g, b);
		const l = (max + min) / 2;
		if (channel === "l") return l * 100;
		if (max === min) return 0;
		const d = max - min;
		const s = l > .5 ? d / (2 - max - min) : d / (max + min);
		if (channel === "s") return s * 100;
		switch (max) {
			case r: return ((g - b) / d + (g < b ? 6 : 0)) * 60;
			case g: return ((b - r) / d + 2) * 60;
			case b: return ((r - g) / d + 4) * 60;
			default: return -1;
		}
	}
};
//#endregion
//#region ../../node_modules/khroma/dist/utils/index.js
var Utils = {
	channel: Channel,
	lang: {
		clamp: (number, lower, upper) => {
			if (lower > upper) return Math.min(lower, Math.max(upper, number));
			return Math.min(upper, Math.max(lower, number));
		},
		round: (number) => {
			return Math.round(number * 1e10) / 1e10;
		}
	},
	unit: { dec2hex: (dec) => {
		const hex = Math.round(dec).toString(16);
		return hex.length > 1 ? hex : `0${hex}`;
	} }
};
//#endregion
//#region ../../node_modules/khroma/dist/constants.js
var DEC2HEX = {};
for (let i = 0; i <= 255; i++) DEC2HEX[i] = Utils.unit.dec2hex(i);
var TYPE = {
	ALL: 0,
	RGB: 1,
	HSL: 2
};
//#endregion
//#region ../../node_modules/khroma/dist/channels/type.js
var Type = class {
	constructor() {
		this.type = TYPE.ALL;
	}
	get() {
		return this.type;
	}
	set(type) {
		if (this.type && this.type !== type) throw new Error("Cannot change both RGB and HSL channels at the same time");
		this.type = type;
	}
	reset() {
		this.type = TYPE.ALL;
	}
	is(type) {
		return this.type === type;
	}
};
//#endregion
//#region ../../node_modules/khroma/dist/channels/index.js
var Channels = class {
	constructor(data, color) {
		this.color = color;
		this.changed = false;
		this.data = data;
		this.type = new Type();
	}
	set(data, color) {
		this.color = color;
		this.changed = false;
		this.data = data;
		this.type.type = TYPE.ALL;
		return this;
	}
	_ensureHSL() {
		const data = this.data;
		const { h, s, l } = data;
		if (h === void 0) data.h = Utils.channel.rgb2hsl(data, "h");
		if (s === void 0) data.s = Utils.channel.rgb2hsl(data, "s");
		if (l === void 0) data.l = Utils.channel.rgb2hsl(data, "l");
	}
	_ensureRGB() {
		const data = this.data;
		const { r, g, b } = data;
		if (r === void 0) data.r = Utils.channel.hsl2rgb(data, "r");
		if (g === void 0) data.g = Utils.channel.hsl2rgb(data, "g");
		if (b === void 0) data.b = Utils.channel.hsl2rgb(data, "b");
	}
	get r() {
		const data = this.data;
		const r = data.r;
		if (!this.type.is(TYPE.HSL) && r !== void 0) return r;
		this._ensureHSL();
		return Utils.channel.hsl2rgb(data, "r");
	}
	get g() {
		const data = this.data;
		const g = data.g;
		if (!this.type.is(TYPE.HSL) && g !== void 0) return g;
		this._ensureHSL();
		return Utils.channel.hsl2rgb(data, "g");
	}
	get b() {
		const data = this.data;
		const b = data.b;
		if (!this.type.is(TYPE.HSL) && b !== void 0) return b;
		this._ensureHSL();
		return Utils.channel.hsl2rgb(data, "b");
	}
	get h() {
		const data = this.data;
		const h = data.h;
		if (!this.type.is(TYPE.RGB) && h !== void 0) return h;
		this._ensureRGB();
		return Utils.channel.rgb2hsl(data, "h");
	}
	get s() {
		const data = this.data;
		const s = data.s;
		if (!this.type.is(TYPE.RGB) && s !== void 0) return s;
		this._ensureRGB();
		return Utils.channel.rgb2hsl(data, "s");
	}
	get l() {
		const data = this.data;
		const l = data.l;
		if (!this.type.is(TYPE.RGB) && l !== void 0) return l;
		this._ensureRGB();
		return Utils.channel.rgb2hsl(data, "l");
	}
	get a() {
		return this.data.a;
	}
	set r(r) {
		this.type.set(TYPE.RGB);
		this.changed = true;
		this.data.r = r;
	}
	set g(g) {
		this.type.set(TYPE.RGB);
		this.changed = true;
		this.data.g = g;
	}
	set b(b) {
		this.type.set(TYPE.RGB);
		this.changed = true;
		this.data.b = b;
	}
	set h(h) {
		this.type.set(TYPE.HSL);
		this.changed = true;
		this.data.h = h;
	}
	set s(s) {
		this.type.set(TYPE.HSL);
		this.changed = true;
		this.data.s = s;
	}
	set l(l) {
		this.type.set(TYPE.HSL);
		this.changed = true;
		this.data.l = l;
	}
	set a(a) {
		this.changed = true;
		this.data.a = a;
	}
};
//#endregion
//#region ../../node_modules/khroma/dist/channels/reusable.js
var channels = new Channels({
	r: 0,
	g: 0,
	b: 0,
	a: 0
}, "transparent");
//#endregion
//#region ../../node_modules/khroma/dist/color/hex.js
var Hex = {
	re: /^#((?:[a-f0-9]{2}){2,4}|[a-f0-9]{3})$/i,
	parse: (color) => {
		if (color.charCodeAt(0) !== 35) return;
		const match = color.match(Hex.re);
		if (!match) return;
		const hex = match[1];
		const dec = parseInt(hex, 16);
		const length = hex.length;
		const hasAlpha = length % 4 === 0;
		const isFullLength = length > 4;
		const multiplier = isFullLength ? 1 : 17;
		const bits = isFullLength ? 8 : 4;
		const bitsOffset = hasAlpha ? 0 : -1;
		const mask = isFullLength ? 255 : 15;
		return channels.set({
			r: (dec >> bits * (bitsOffset + 3) & mask) * multiplier,
			g: (dec >> bits * (bitsOffset + 2) & mask) * multiplier,
			b: (dec >> bits * (bitsOffset + 1) & mask) * multiplier,
			a: hasAlpha ? (dec & mask) * multiplier / 255 : 1
		}, color);
	},
	stringify: (channels) => {
		const { r, g, b, a } = channels;
		if (a < 1) return `#${DEC2HEX[Math.round(r)]}${DEC2HEX[Math.round(g)]}${DEC2HEX[Math.round(b)]}${DEC2HEX[Math.round(a * 255)]}`;
		else return `#${DEC2HEX[Math.round(r)]}${DEC2HEX[Math.round(g)]}${DEC2HEX[Math.round(b)]}`;
	}
};
//#endregion
//#region ../../node_modules/khroma/dist/color/hsl.js
var HSL = {
	re: /^hsla?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(?:deg|grad|rad|turn)?)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(%)?))?\s*?\)$/i,
	hueRe: /^(.+?)(deg|grad|rad|turn)$/i,
	_hue2deg: (hue) => {
		const match = hue.match(HSL.hueRe);
		if (match) {
			const [, number, unit] = match;
			switch (unit) {
				case "grad": return Utils.channel.clamp.h(parseFloat(number) * .9);
				case "rad": return Utils.channel.clamp.h(parseFloat(number) * 180 / Math.PI);
				case "turn": return Utils.channel.clamp.h(parseFloat(number) * 360);
			}
		}
		return Utils.channel.clamp.h(parseFloat(hue));
	},
	parse: (color) => {
		const charCode = color.charCodeAt(0);
		if (charCode !== 104 && charCode !== 72) return;
		const match = color.match(HSL.re);
		if (!match) return;
		const [, h, s, l, a, isAlphaPercentage] = match;
		return channels.set({
			h: HSL._hue2deg(h),
			s: Utils.channel.clamp.s(parseFloat(s)),
			l: Utils.channel.clamp.l(parseFloat(l)),
			a: a ? Utils.channel.clamp.a(isAlphaPercentage ? parseFloat(a) / 100 : parseFloat(a)) : 1
		}, color);
	},
	stringify: (channels) => {
		const { h, s, l, a } = channels;
		if (a < 1) return `hsla(${Utils.lang.round(h)}, ${Utils.lang.round(s)}%, ${Utils.lang.round(l)}%, ${a})`;
		else return `hsl(${Utils.lang.round(h)}, ${Utils.lang.round(s)}%, ${Utils.lang.round(l)}%)`;
	}
};
//#endregion
//#region ../../node_modules/khroma/dist/color/keyword.js
var Keyword = {
	colors: {
		aliceblue: "#f0f8ff",
		antiquewhite: "#faebd7",
		aqua: "#00ffff",
		aquamarine: "#7fffd4",
		azure: "#f0ffff",
		beige: "#f5f5dc",
		bisque: "#ffe4c4",
		black: "#000000",
		blanchedalmond: "#ffebcd",
		blue: "#0000ff",
		blueviolet: "#8a2be2",
		brown: "#a52a2a",
		burlywood: "#deb887",
		cadetblue: "#5f9ea0",
		chartreuse: "#7fff00",
		chocolate: "#d2691e",
		coral: "#ff7f50",
		cornflowerblue: "#6495ed",
		cornsilk: "#fff8dc",
		crimson: "#dc143c",
		cyanaqua: "#00ffff",
		darkblue: "#00008b",
		darkcyan: "#008b8b",
		darkgoldenrod: "#b8860b",
		darkgray: "#a9a9a9",
		darkgreen: "#006400",
		darkgrey: "#a9a9a9",
		darkkhaki: "#bdb76b",
		darkmagenta: "#8b008b",
		darkolivegreen: "#556b2f",
		darkorange: "#ff8c00",
		darkorchid: "#9932cc",
		darkred: "#8b0000",
		darksalmon: "#e9967a",
		darkseagreen: "#8fbc8f",
		darkslateblue: "#483d8b",
		darkslategray: "#2f4f4f",
		darkslategrey: "#2f4f4f",
		darkturquoise: "#00ced1",
		darkviolet: "#9400d3",
		deeppink: "#ff1493",
		deepskyblue: "#00bfff",
		dimgray: "#696969",
		dimgrey: "#696969",
		dodgerblue: "#1e90ff",
		firebrick: "#b22222",
		floralwhite: "#fffaf0",
		forestgreen: "#228b22",
		fuchsia: "#ff00ff",
		gainsboro: "#dcdcdc",
		ghostwhite: "#f8f8ff",
		gold: "#ffd700",
		goldenrod: "#daa520",
		gray: "#808080",
		green: "#008000",
		greenyellow: "#adff2f",
		grey: "#808080",
		honeydew: "#f0fff0",
		hotpink: "#ff69b4",
		indianred: "#cd5c5c",
		indigo: "#4b0082",
		ivory: "#fffff0",
		khaki: "#f0e68c",
		lavender: "#e6e6fa",
		lavenderblush: "#fff0f5",
		lawngreen: "#7cfc00",
		lemonchiffon: "#fffacd",
		lightblue: "#add8e6",
		lightcoral: "#f08080",
		lightcyan: "#e0ffff",
		lightgoldenrodyellow: "#fafad2",
		lightgray: "#d3d3d3",
		lightgreen: "#90ee90",
		lightgrey: "#d3d3d3",
		lightpink: "#ffb6c1",
		lightsalmon: "#ffa07a",
		lightseagreen: "#20b2aa",
		lightskyblue: "#87cefa",
		lightslategray: "#778899",
		lightslategrey: "#778899",
		lightsteelblue: "#b0c4de",
		lightyellow: "#ffffe0",
		lime: "#00ff00",
		limegreen: "#32cd32",
		linen: "#faf0e6",
		magenta: "#ff00ff",
		maroon: "#800000",
		mediumaquamarine: "#66cdaa",
		mediumblue: "#0000cd",
		mediumorchid: "#ba55d3",
		mediumpurple: "#9370db",
		mediumseagreen: "#3cb371",
		mediumslateblue: "#7b68ee",
		mediumspringgreen: "#00fa9a",
		mediumturquoise: "#48d1cc",
		mediumvioletred: "#c71585",
		midnightblue: "#191970",
		mintcream: "#f5fffa",
		mistyrose: "#ffe4e1",
		moccasin: "#ffe4b5",
		navajowhite: "#ffdead",
		navy: "#000080",
		oldlace: "#fdf5e6",
		olive: "#808000",
		olivedrab: "#6b8e23",
		orange: "#ffa500",
		orangered: "#ff4500",
		orchid: "#da70d6",
		palegoldenrod: "#eee8aa",
		palegreen: "#98fb98",
		paleturquoise: "#afeeee",
		palevioletred: "#db7093",
		papayawhip: "#ffefd5",
		peachpuff: "#ffdab9",
		peru: "#cd853f",
		pink: "#ffc0cb",
		plum: "#dda0dd",
		powderblue: "#b0e0e6",
		purple: "#800080",
		rebeccapurple: "#663399",
		red: "#ff0000",
		rosybrown: "#bc8f8f",
		royalblue: "#4169e1",
		saddlebrown: "#8b4513",
		salmon: "#fa8072",
		sandybrown: "#f4a460",
		seagreen: "#2e8b57",
		seashell: "#fff5ee",
		sienna: "#a0522d",
		silver: "#c0c0c0",
		skyblue: "#87ceeb",
		slateblue: "#6a5acd",
		slategray: "#708090",
		slategrey: "#708090",
		snow: "#fffafa",
		springgreen: "#00ff7f",
		tan: "#d2b48c",
		teal: "#008080",
		thistle: "#d8bfd8",
		transparent: "#00000000",
		turquoise: "#40e0d0",
		violet: "#ee82ee",
		wheat: "#f5deb3",
		white: "#ffffff",
		whitesmoke: "#f5f5f5",
		yellow: "#ffff00",
		yellowgreen: "#9acd32"
	},
	parse: (color) => {
		color = color.toLowerCase();
		const hex = Keyword.colors[color];
		if (!hex) return;
		return Hex.parse(hex);
	},
	stringify: (channels) => {
		const hex = Hex.stringify(channels);
		for (const name in Keyword.colors) if (Keyword.colors[name] === hex) return name;
	}
};
//#endregion
//#region ../../node_modules/khroma/dist/color/rgb.js
var RGB = {
	re: /^rgba?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?)))?\s*?\)$/i,
	parse: (color) => {
		const charCode = color.charCodeAt(0);
		if (charCode !== 114 && charCode !== 82) return;
		const match = color.match(RGB.re);
		if (!match) return;
		const [, r, isRedPercentage, g, isGreenPercentage, b, isBluePercentage, a, isAlphaPercentage] = match;
		return channels.set({
			r: Utils.channel.clamp.r(isRedPercentage ? parseFloat(r) * 2.55 : parseFloat(r)),
			g: Utils.channel.clamp.g(isGreenPercentage ? parseFloat(g) * 2.55 : parseFloat(g)),
			b: Utils.channel.clamp.b(isBluePercentage ? parseFloat(b) * 2.55 : parseFloat(b)),
			a: a ? Utils.channel.clamp.a(isAlphaPercentage ? parseFloat(a) / 100 : parseFloat(a)) : 1
		}, color);
	},
	stringify: (channels) => {
		const { r, g, b, a } = channels;
		if (a < 1) return `rgba(${Utils.lang.round(r)}, ${Utils.lang.round(g)}, ${Utils.lang.round(b)}, ${Utils.lang.round(a)})`;
		else return `rgb(${Utils.lang.round(r)}, ${Utils.lang.round(g)}, ${Utils.lang.round(b)})`;
	}
};
//#endregion
//#region ../../node_modules/khroma/dist/color/index.js
var Color = {
	format: {
		keyword: Keyword,
		hex: Hex,
		rgb: RGB,
		rgba: RGB,
		hsl: HSL,
		hsla: HSL
	},
	parse: (color) => {
		if (typeof color !== "string") return color;
		const channels = Hex.parse(color) || RGB.parse(color) || HSL.parse(color) || Keyword.parse(color);
		if (channels) return channels;
		throw new Error(`Unsupported color format: "${color}"`);
	},
	stringify: (channels) => {
		if (!channels.changed && channels.color) return channels.color;
		if (channels.type.is(TYPE.HSL) || channels.data.r === void 0) return HSL.stringify(channels);
		else if (channels.a < 1 || !Number.isInteger(channels.r) || !Number.isInteger(channels.g) || !Number.isInteger(channels.b)) return RGB.stringify(channels);
		else return Hex.stringify(channels);
	}
};
//#endregion
//#region ../../node_modules/khroma/dist/methods/change.js
var change = (color, channels) => {
	const ch = Color.parse(color);
	for (const c in channels) ch[c] = Utils.channel.clamp[c](channels[c]);
	return Color.stringify(ch);
};
//#endregion
//#region ../../node_modules/khroma/dist/methods/rgba.js
var rgba = (r, g, b = 0, a = 1) => {
	if (typeof r !== "number") return change(r, { a: g });
	const channels$1 = channels.set({
		r: Utils.channel.clamp.r(r),
		g: Utils.channel.clamp.g(g),
		b: Utils.channel.clamp.b(b),
		a: Utils.channel.clamp.a(a)
	});
	return Color.stringify(channels$1);
};
//#endregion
//#region ../../node_modules/khroma/dist/methods/luminance.js
var luminance = (color) => {
	const { r, g, b } = Color.parse(color);
	const luminance = .2126 * Utils.channel.toLinear(r) + .7152 * Utils.channel.toLinear(g) + .0722 * Utils.channel.toLinear(b);
	return Utils.lang.round(luminance);
};
//#endregion
//#region ../../node_modules/khroma/dist/methods/is_light.js
var isLight = (color) => {
	return luminance(color) >= .5;
};
//#endregion
//#region ../../node_modules/khroma/dist/methods/is_dark.js
var isDark = (color) => {
	return !isLight(color);
};
//#endregion
//#region ../../node_modules/khroma/dist/methods/adjust_channel.js
var adjustChannel = (color, channel, amount) => {
	const channels = Color.parse(color);
	const amountCurrent = channels[channel];
	const amountNext = Utils.channel.clamp[channel](amountCurrent + amount);
	if (amountCurrent !== amountNext) channels[channel] = amountNext;
	return Color.stringify(channels);
};
//#endregion
//#region ../../node_modules/khroma/dist/methods/lighten.js
var lighten = (color, amount) => {
	return adjustChannel(color, "l", amount);
};
//#endregion
//#region ../../node_modules/khroma/dist/methods/darken.js
var darken = (color, amount) => {
	return adjustChannel(color, "l", -amount);
};
//#endregion
//#region ../../node_modules/khroma/dist/methods/adjust.js
var adjust = (color, channels) => {
	const ch = Color.parse(color);
	const changes = {};
	for (const c in channels) {
		if (!channels[c]) continue;
		changes[c] = ch[c] + channels[c];
	}
	return change(color, changes);
};
//#endregion
//#region ../../node_modules/khroma/dist/methods/mix.js
var mix = (color1, color2, weight = 50) => {
	const { r: r1, g: g1, b: b1, a: a1 } = Color.parse(color1);
	const { r: r2, g: g2, b: b2, a: a2 } = Color.parse(color2);
	const weightScale = weight / 100;
	const weightNormalized = weightScale * 2 - 1;
	const alphaDelta = a1 - a2;
	const weight1 = ((weightNormalized * alphaDelta === -1 ? weightNormalized : (weightNormalized + alphaDelta) / (1 + weightNormalized * alphaDelta)) + 1) / 2;
	const weight2 = 1 - weight1;
	return rgba(r1 * weight1 + r2 * weight2, g1 * weight1 + g2 * weight2, b1 * weight1 + b2 * weight2, a1 * weightScale + a2 * (1 - weightScale));
};
//#endregion
//#region ../../node_modules/khroma/dist/methods/invert.js
var invert = (color, weight = 100) => {
	const inverse = Color.parse(color);
	inverse.r = 255 - inverse.r;
	inverse.g = 255 - inverse.g;
	inverse.b = 255 - inverse.b;
	return mix(inverse, color, weight);
};
//#endregion
//#region ../../node_modules/dompurify/dist/purify.es.mjs
/*! @license DOMPurify 3.4.11 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.4.11/LICENSE */
function _arrayLikeToArray(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _arrayWithHoles(r) {
	if (Array.isArray(r)) return r;
}
function _iterableToArrayLimit(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = true, o = false;
		try {
			if (i = (t = t.call(r)).next, 0 === l);
			else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = true, n = r;
		} finally {
			try {
				if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _nonIterableRest() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _slicedToArray(r, e) {
	return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _unsupportedIterableToArray(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
	}
}
var entries = Object.entries, setPrototypeOf = Object.setPrototypeOf, isFrozen = Object.isFrozen, getPrototypeOf = Object.getPrototypeOf, getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var freeze = Object.freeze, seal = Object.seal, create = Object.create;
var _ref = typeof Reflect !== "undefined" && Reflect, apply = _ref.apply, construct = _ref.construct;
if (!freeze) freeze = function freeze(x) {
	return x;
};
if (!seal) seal = function seal(x) {
	return x;
};
if (!apply) apply = function apply(func, thisArg) {
	for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) args[_key - 2] = arguments[_key];
	return func.apply(thisArg, args);
};
if (!construct) construct = function construct(Func) {
	for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) args[_key2 - 1] = arguments[_key2];
	return new Func(...args);
};
var arrayForEach = unapply(Array.prototype.forEach);
var arrayLastIndexOf = unapply(Array.prototype.lastIndexOf);
var arrayPop = unapply(Array.prototype.pop);
var arrayPush = unapply(Array.prototype.push);
var arraySplice = unapply(Array.prototype.splice);
var arrayIsArray = Array.isArray;
var stringToLowerCase = unapply(String.prototype.toLowerCase);
var stringToString = unapply(String.prototype.toString);
var stringMatch = unapply(String.prototype.match);
var stringReplace = unapply(String.prototype.replace);
var stringIndexOf = unapply(String.prototype.indexOf);
var stringTrim = unapply(String.prototype.trim);
var numberToString = unapply(Number.prototype.toString);
var booleanToString = unapply(Boolean.prototype.toString);
var bigintToString = typeof BigInt === "undefined" ? null : unapply(BigInt.prototype.toString);
var symbolToString = typeof Symbol === "undefined" ? null : unapply(Symbol.prototype.toString);
var objectHasOwnProperty = unapply(Object.prototype.hasOwnProperty);
var objectToString = unapply(Object.prototype.toString);
var regExpTest = unapply(RegExp.prototype.test);
var typeErrorCreate = unconstruct(TypeError);
/**
* Creates a new function that calls the given function with a specified thisArg and arguments.
*
* @param func - The function to be wrapped and called.
* @returns A new function that calls the given function with a specified thisArg and arguments.
*/
function unapply(func) {
	return function(thisArg) {
		if (thisArg instanceof RegExp) thisArg.lastIndex = 0;
		for (var _len3 = arguments.length, args = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) args[_key3 - 1] = arguments[_key3];
		return apply(func, thisArg, args);
	};
}
/**
* Creates a new function that constructs an instance of the given constructor function with the provided arguments.
*
* @param func - The constructor function to be wrapped and called.
* @returns A new function that constructs an instance of the given constructor function with the provided arguments.
*/
function unconstruct(Func) {
	return function() {
		for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) args[_key4] = arguments[_key4];
		return construct(Func, args);
	};
}
/**
* Add properties to a lookup table
*
* @param set - The set to which elements will be added.
* @param array - The array containing elements to be added to the set.
* @param transformCaseFunc - An optional function to transform the case of each element before adding to the set.
* @returns The modified set with added elements.
*/
function addToSet(set, array) {
	let transformCaseFunc = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : stringToLowerCase;
	if (setPrototypeOf) setPrototypeOf(set, null);
	if (!arrayIsArray(array)) return set;
	let l = array.length;
	while (l--) {
		let element = array[l];
		if (typeof element === "string") {
			const lcElement = transformCaseFunc(element);
			if (lcElement !== element) {
				if (!isFrozen(array)) array[l] = lcElement;
				element = lcElement;
			}
		}
		set[element] = true;
	}
	return set;
}
/**
* Clean up an array to harden against CSPP
*
* @param array - The array to be cleaned.
* @returns The cleaned version of the array
*/
function cleanArray(array) {
	for (let index = 0; index < array.length; index++) if (!objectHasOwnProperty(array, index)) array[index] = null;
	return array;
}
/**
* Shallow clone an object
*
* @param object - The object to be cloned.
* @returns A new object that copies the original.
*/
function clone(object) {
	const newObject = create(null);
	for (const _ref2 of entries(object)) {
		var _ref3 = _slicedToArray(_ref2, 2);
		const property = _ref3[0];
		const value = _ref3[1];
		if (objectHasOwnProperty(object, property)) if (arrayIsArray(value)) newObject[property] = cleanArray(value);
		else if (value && typeof value === "object" && value.constructor === Object) newObject[property] = clone(value);
		else newObject[property] = value;
	}
	return newObject;
}
/**
* Convert non-node values into strings without depending on direct property access.
*
* @param value - The value to stringify.
* @returns A string representation of the provided value.
*/
function stringifyValue(value) {
	switch (typeof value) {
		case "string": return value;
		case "number": return numberToString(value);
		case "boolean": return booleanToString(value);
		case "bigint": return bigintToString ? bigintToString(value) : "0";
		case "symbol": return symbolToString ? symbolToString(value) : "Symbol()";
		case "undefined": return objectToString(value);
		case "function":
		case "object": {
			if (value === null) return objectToString(value);
			const valueAsRecord = value;
			const valueToString = lookupGetter(valueAsRecord, "toString");
			if (typeof valueToString === "function") {
				const stringified = valueToString(valueAsRecord);
				return typeof stringified === "string" ? stringified : objectToString(stringified);
			}
			return objectToString(value);
		}
		default: return objectToString(value);
	}
}
/**
* This method automatically checks if the prop is function or getter and behaves accordingly.
*
* @param object - The object to look up the getter function in its prototype chain.
* @param prop - The property name for which to find the getter function.
* @returns The getter function found in the prototype chain or a fallback function.
*/
function lookupGetter(object, prop) {
	while (object !== null) {
		const desc = getOwnPropertyDescriptor(object, prop);
		if (desc) {
			if (desc.get) return unapply(desc.get);
			if (typeof desc.value === "function") return unapply(desc.value);
		}
		object = getPrototypeOf(object);
	}
	function fallbackValue() {
		return null;
	}
	return fallbackValue;
}
function isRegex(value) {
	try {
		regExpTest(value, "");
		return true;
	} catch (_unused) {
		return false;
	}
}
var html$1 = freeze([
	"a",
	"abbr",
	"acronym",
	"address",
	"area",
	"article",
	"aside",
	"audio",
	"b",
	"bdi",
	"bdo",
	"big",
	"blink",
	"blockquote",
	"body",
	"br",
	"button",
	"canvas",
	"caption",
	"center",
	"cite",
	"code",
	"col",
	"colgroup",
	"content",
	"data",
	"datalist",
	"dd",
	"decorator",
	"del",
	"details",
	"dfn",
	"dialog",
	"dir",
	"div",
	"dl",
	"dt",
	"element",
	"em",
	"fieldset",
	"figcaption",
	"figure",
	"font",
	"footer",
	"form",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"head",
	"header",
	"hgroup",
	"hr",
	"html",
	"i",
	"img",
	"input",
	"ins",
	"kbd",
	"label",
	"legend",
	"li",
	"main",
	"map",
	"mark",
	"marquee",
	"menu",
	"menuitem",
	"meter",
	"nav",
	"nobr",
	"ol",
	"optgroup",
	"option",
	"output",
	"p",
	"picture",
	"pre",
	"progress",
	"q",
	"rp",
	"rt",
	"ruby",
	"s",
	"samp",
	"search",
	"section",
	"select",
	"shadow",
	"slot",
	"small",
	"source",
	"spacer",
	"span",
	"strike",
	"strong",
	"style",
	"sub",
	"summary",
	"sup",
	"table",
	"tbody",
	"td",
	"template",
	"textarea",
	"tfoot",
	"th",
	"thead",
	"time",
	"tr",
	"track",
	"tt",
	"u",
	"ul",
	"var",
	"video",
	"wbr"
]);
var svg$1 = freeze([
	"svg",
	"a",
	"altglyph",
	"altglyphdef",
	"altglyphitem",
	"animatecolor",
	"animatemotion",
	"animatetransform",
	"circle",
	"clippath",
	"defs",
	"desc",
	"ellipse",
	"enterkeyhint",
	"exportparts",
	"filter",
	"font",
	"g",
	"glyph",
	"glyphref",
	"hkern",
	"image",
	"inputmode",
	"line",
	"lineargradient",
	"marker",
	"mask",
	"metadata",
	"mpath",
	"part",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"radialgradient",
	"rect",
	"stop",
	"style",
	"switch",
	"symbol",
	"text",
	"textpath",
	"title",
	"tref",
	"tspan",
	"view",
	"vkern"
]);
var svgFilters = freeze([
	"feBlend",
	"feColorMatrix",
	"feComponentTransfer",
	"feComposite",
	"feConvolveMatrix",
	"feDiffuseLighting",
	"feDisplacementMap",
	"feDistantLight",
	"feDropShadow",
	"feFlood",
	"feFuncA",
	"feFuncB",
	"feFuncG",
	"feFuncR",
	"feGaussianBlur",
	"feImage",
	"feMerge",
	"feMergeNode",
	"feMorphology",
	"feOffset",
	"fePointLight",
	"feSpecularLighting",
	"feSpotLight",
	"feTile",
	"feTurbulence"
]);
var svgDisallowed = freeze([
	"animate",
	"color-profile",
	"cursor",
	"discard",
	"font-face",
	"font-face-format",
	"font-face-name",
	"font-face-src",
	"font-face-uri",
	"foreignobject",
	"hatch",
	"hatchpath",
	"mesh",
	"meshgradient",
	"meshpatch",
	"meshrow",
	"missing-glyph",
	"script",
	"set",
	"solidcolor",
	"unknown",
	"use"
]);
var mathMl$1 = freeze([
	"math",
	"menclose",
	"merror",
	"mfenced",
	"mfrac",
	"mglyph",
	"mi",
	"mlabeledtr",
	"mmultiscripts",
	"mn",
	"mo",
	"mover",
	"mpadded",
	"mphantom",
	"mroot",
	"mrow",
	"ms",
	"mspace",
	"msqrt",
	"mstyle",
	"msub",
	"msup",
	"msubsup",
	"mtable",
	"mtd",
	"mtext",
	"mtr",
	"munder",
	"munderover",
	"mprescripts"
]);
var mathMlDisallowed = freeze([
	"maction",
	"maligngroup",
	"malignmark",
	"mlongdiv",
	"mscarries",
	"mscarry",
	"msgroup",
	"mstack",
	"msline",
	"msrow",
	"semantics",
	"annotation",
	"annotation-xml",
	"mprescripts",
	"none"
]);
var text = freeze(["#text"]);
var html = freeze([
	"accept",
	"action",
	"align",
	"alt",
	"autocapitalize",
	"autocomplete",
	"autopictureinpicture",
	"autoplay",
	"background",
	"bgcolor",
	"border",
	"capture",
	"cellpadding",
	"cellspacing",
	"checked",
	"cite",
	"class",
	"clear",
	"color",
	"cols",
	"colspan",
	"command",
	"commandfor",
	"controls",
	"controlslist",
	"coords",
	"crossorigin",
	"datetime",
	"decoding",
	"default",
	"dir",
	"disabled",
	"disablepictureinpicture",
	"disableremoteplayback",
	"download",
	"draggable",
	"enctype",
	"enterkeyhint",
	"exportparts",
	"face",
	"for",
	"headers",
	"height",
	"hidden",
	"high",
	"href",
	"hreflang",
	"id",
	"inert",
	"inputmode",
	"integrity",
	"ismap",
	"kind",
	"label",
	"lang",
	"list",
	"loading",
	"loop",
	"low",
	"max",
	"maxlength",
	"media",
	"method",
	"min",
	"minlength",
	"multiple",
	"muted",
	"name",
	"nonce",
	"noshade",
	"novalidate",
	"nowrap",
	"open",
	"optimum",
	"part",
	"pattern",
	"placeholder",
	"playsinline",
	"popover",
	"popovertarget",
	"popovertargetaction",
	"poster",
	"preload",
	"pubdate",
	"radiogroup",
	"readonly",
	"rel",
	"required",
	"rev",
	"reversed",
	"role",
	"rows",
	"rowspan",
	"spellcheck",
	"scope",
	"selected",
	"shape",
	"size",
	"sizes",
	"slot",
	"span",
	"srclang",
	"start",
	"src",
	"srcset",
	"step",
	"style",
	"summary",
	"tabindex",
	"title",
	"translate",
	"type",
	"usemap",
	"valign",
	"value",
	"width",
	"wrap",
	"xmlns"
]);
var svg = freeze([
	"accent-height",
	"accumulate",
	"additive",
	"alignment-baseline",
	"amplitude",
	"ascent",
	"attributename",
	"attributetype",
	"azimuth",
	"basefrequency",
	"baseline-shift",
	"begin",
	"bias",
	"by",
	"class",
	"clip",
	"clippathunits",
	"clip-path",
	"clip-rule",
	"color",
	"color-interpolation",
	"color-interpolation-filters",
	"color-profile",
	"color-rendering",
	"cx",
	"cy",
	"d",
	"dx",
	"dy",
	"diffuseconstant",
	"direction",
	"display",
	"divisor",
	"dur",
	"edgemode",
	"elevation",
	"end",
	"exponent",
	"fill",
	"fill-opacity",
	"fill-rule",
	"filter",
	"filterunits",
	"flood-color",
	"flood-opacity",
	"font-family",
	"font-size",
	"font-size-adjust",
	"font-stretch",
	"font-style",
	"font-variant",
	"font-weight",
	"fx",
	"fy",
	"g1",
	"g2",
	"glyph-name",
	"glyphref",
	"gradientunits",
	"gradienttransform",
	"height",
	"href",
	"id",
	"image-rendering",
	"in",
	"in2",
	"intercept",
	"k",
	"k1",
	"k2",
	"k3",
	"k4",
	"kerning",
	"keypoints",
	"keysplines",
	"keytimes",
	"lang",
	"lengthadjust",
	"letter-spacing",
	"kernelmatrix",
	"kernelunitlength",
	"lighting-color",
	"local",
	"marker-end",
	"marker-mid",
	"marker-start",
	"markerheight",
	"markerunits",
	"markerwidth",
	"maskcontentunits",
	"maskunits",
	"max",
	"mask",
	"mask-type",
	"media",
	"method",
	"mode",
	"min",
	"name",
	"numoctaves",
	"offset",
	"operator",
	"opacity",
	"order",
	"orient",
	"orientation",
	"origin",
	"overflow",
	"paint-order",
	"path",
	"pathlength",
	"patterncontentunits",
	"patterntransform",
	"patternunits",
	"points",
	"preservealpha",
	"preserveaspectratio",
	"primitiveunits",
	"r",
	"rx",
	"ry",
	"radius",
	"refx",
	"refy",
	"repeatcount",
	"repeatdur",
	"restart",
	"result",
	"rotate",
	"scale",
	"seed",
	"shape-rendering",
	"slope",
	"specularconstant",
	"specularexponent",
	"spreadmethod",
	"startoffset",
	"stddeviation",
	"stitchtiles",
	"stop-color",
	"stop-opacity",
	"stroke-dasharray",
	"stroke-dashoffset",
	"stroke-linecap",
	"stroke-linejoin",
	"stroke-miterlimit",
	"stroke-opacity",
	"stroke",
	"stroke-width",
	"style",
	"surfacescale",
	"systemlanguage",
	"tabindex",
	"tablevalues",
	"targetx",
	"targety",
	"transform",
	"transform-origin",
	"text-anchor",
	"text-decoration",
	"text-rendering",
	"textlength",
	"type",
	"u1",
	"u2",
	"unicode",
	"values",
	"viewbox",
	"visibility",
	"version",
	"vert-adv-y",
	"vert-origin-x",
	"vert-origin-y",
	"width",
	"word-spacing",
	"wrap",
	"writing-mode",
	"xchannelselector",
	"ychannelselector",
	"x",
	"x1",
	"x2",
	"xmlns",
	"y",
	"y1",
	"y2",
	"z",
	"zoomandpan"
]);
var mathMl = freeze([
	"accent",
	"accentunder",
	"align",
	"bevelled",
	"close",
	"columnalign",
	"columnlines",
	"columnspacing",
	"columnspan",
	"denomalign",
	"depth",
	"dir",
	"display",
	"displaystyle",
	"encoding",
	"fence",
	"frame",
	"height",
	"href",
	"id",
	"largeop",
	"length",
	"linethickness",
	"lquote",
	"lspace",
	"mathbackground",
	"mathcolor",
	"mathsize",
	"mathvariant",
	"maxsize",
	"minsize",
	"movablelimits",
	"notation",
	"numalign",
	"open",
	"rowalign",
	"rowlines",
	"rowspacing",
	"rowspan",
	"rspace",
	"rquote",
	"scriptlevel",
	"scriptminsize",
	"scriptsizemultiplier",
	"selection",
	"separator",
	"separators",
	"stretchy",
	"subscriptshift",
	"supscriptshift",
	"symmetric",
	"voffset",
	"width",
	"xmlns"
]);
var xml = freeze([
	"xlink:href",
	"xml:id",
	"xlink:title",
	"xml:space",
	"xmlns:xlink"
]);
var MUSTACHE_EXPR = seal(/{{[\w\W]*|^[\w\W]*}}/g);
var ERB_EXPR = seal(/<%[\w\W]*|^[\w\W]*%>/g);
var TMPLIT_EXPR = seal(/\${[\w\W]*/g);
var DATA_ATTR = seal(/^data-[\-\w.\u00B7-\uFFFF]+$/);
var ARIA_ATTR = seal(/^aria-[\-\w]+$/);
var IS_ALLOWED_URI = seal(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i);
var IS_SCRIPT_OR_DATA = seal(/^(?:\w+script|data):/i);
var ATTR_WHITESPACE = seal(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g);
var DOCTYPE_NAME = seal(/^html$/i);
var CUSTOM_ELEMENT = seal(/^[a-z][.\w]*(-[.\w]+)+$/i);
var ELEMENT_MARKUP_PROBE = seal(/<[/\w!]/g);
var COMMENT_MARKUP_PROBE = seal(/<[/\w]/g);
var FALLBACK_TAG_CLOSE = seal(/<\/no(script|embed|frames)/i);
var SELF_CLOSING_TAG = seal(/\/>/i);
var NODE_TYPE = {
	element: 1,
	attribute: 2,
	text: 3,
	cdataSection: 4,
	entityReference: 5,
	entityNode: 6,
	processingInstruction: 7,
	comment: 8,
	document: 9,
	documentType: 10,
	documentFragment: 11,
	notation: 12
};
var getGlobal = function getGlobal() {
	return typeof window === "undefined" ? null : window;
};
/**
* Creates a no-op policy for internal use only.
* Don't export this function outside this module!
* @param trustedTypes The policy factory.
* @param purifyHostElement The Script element used to load DOMPurify (to determine policy name suffix).
* @return The policy created (or null, if Trusted Types
* are not supported or creating the policy failed).
*/
var _createTrustedTypesPolicy = function _createTrustedTypesPolicy(trustedTypes, purifyHostElement) {
	if (typeof trustedTypes !== "object" || typeof trustedTypes.createPolicy !== "function") return null;
	let suffix = null;
	const ATTR_NAME = "data-tt-policy-suffix";
	if (purifyHostElement && purifyHostElement.hasAttribute(ATTR_NAME)) suffix = purifyHostElement.getAttribute(ATTR_NAME);
	const policyName = "dompurify" + (suffix ? "#" + suffix : "");
	try {
		return trustedTypes.createPolicy(policyName, {
			createHTML(html) {
				return html;
			},
			createScriptURL(scriptUrl) {
				return scriptUrl;
			}
		});
	} catch (_) {
		console.warn("TrustedTypes policy " + policyName + " could not be created.");
		return null;
	}
};
var _createHooksMap = function _createHooksMap() {
	return {
		afterSanitizeAttributes: [],
		afterSanitizeElements: [],
		afterSanitizeShadowDOM: [],
		beforeSanitizeAttributes: [],
		beforeSanitizeElements: [],
		beforeSanitizeShadowDOM: [],
		uponSanitizeAttribute: [],
		uponSanitizeElement: [],
		uponSanitizeShadowNode: []
	};
};
/**
* Resolve a set-valued configuration option: a fresh set built from
* cfg[key] when it is an own array property (seeded with a clone of
* options.base when given, case-normalized via options.transform),
* the fallback set otherwise.
*
* @param cfg the cloned, prototype-free configuration object
* @param key the configuration property to read
* @param fallback the set to use when the option is absent or not an array
* @param options transform and optional base set to merge into
* @returns the resolved set
*/
var _resolveSetOption = function _resolveSetOption(cfg, key, fallback, options) {
	return objectHasOwnProperty(cfg, key) && arrayIsArray(cfg[key]) ? addToSet(options.base ? clone(options.base) : {}, cfg[key], options.transform) : fallback;
};
function createDOMPurify() {
	let window = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : getGlobal();
	const DOMPurify = (root) => createDOMPurify(root);
	DOMPurify.version = "3.4.11";
	DOMPurify.removed = [];
	if (!window || !window.document || window.document.nodeType !== NODE_TYPE.document || !window.Element) {
		DOMPurify.isSupported = false;
		return DOMPurify;
	}
	let document = window.document;
	const originalDocument = document;
	const currentScript = originalDocument.currentScript;
	window.DocumentFragment;
	const HTMLTemplateElement = window.HTMLTemplateElement, Node = window.Node, Element = window.Element, NodeFilter = window.NodeFilter;
	window.NamedNodeMap === void 0 && (window.NamedNodeMap || window.MozNamedAttrMap);
	window.HTMLFormElement;
	const DOMParser = window.DOMParser, trustedTypes = window.trustedTypes;
	const ElementPrototype = Element.prototype;
	const cloneNode = lookupGetter(ElementPrototype, "cloneNode");
	const remove = lookupGetter(ElementPrototype, "remove");
	const getNextSibling = lookupGetter(ElementPrototype, "nextSibling");
	const getChildNodes = lookupGetter(ElementPrototype, "childNodes");
	const getParentNode = lookupGetter(ElementPrototype, "parentNode");
	const getShadowRoot = lookupGetter(ElementPrototype, "shadowRoot");
	const getAttributes = lookupGetter(ElementPrototype, "attributes");
	const getNodeType = Node && Node.prototype ? lookupGetter(Node.prototype, "nodeType") : null;
	const getNodeName = Node && Node.prototype ? lookupGetter(Node.prototype, "nodeName") : null;
	if (typeof HTMLTemplateElement === "function") {
		const template = document.createElement("template");
		if (template.content && template.content.ownerDocument) document = template.content.ownerDocument;
	}
	let trustedTypesPolicy;
	let emptyHTML = "";
	let defaultTrustedTypesPolicy;
	let defaultTrustedTypesPolicyResolved = false;
	let IN_TRUSTED_TYPES_POLICY = 0;
	const _assertNotInTrustedTypesPolicy = function _assertNotInTrustedTypesPolicy() {
		if (IN_TRUSTED_TYPES_POLICY > 0) throw typeErrorCreate("A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the \"DOMPurify and Trusted Types\" section of the README.");
	};
	const _createTrustedHTML = function _createTrustedHTML(html) {
		_assertNotInTrustedTypesPolicy();
		IN_TRUSTED_TYPES_POLICY++;
		try {
			return trustedTypesPolicy.createHTML(html);
		} finally {
			IN_TRUSTED_TYPES_POLICY--;
		}
	};
	const _createTrustedScriptURL = function _createTrustedScriptURL(scriptUrl) {
		_assertNotInTrustedTypesPolicy();
		IN_TRUSTED_TYPES_POLICY++;
		try {
			return trustedTypesPolicy.createScriptURL(scriptUrl);
		} finally {
			IN_TRUSTED_TYPES_POLICY--;
		}
	};
	const _getDefaultTrustedTypesPolicy = function _getDefaultTrustedTypesPolicy() {
		if (!defaultTrustedTypesPolicyResolved) {
			defaultTrustedTypesPolicy = _createTrustedTypesPolicy(trustedTypes, currentScript);
			defaultTrustedTypesPolicyResolved = true;
		}
		return defaultTrustedTypesPolicy;
	};
	const _document = document, implementation = _document.implementation, createNodeIterator = _document.createNodeIterator, createDocumentFragment = _document.createDocumentFragment, getElementsByTagName = _document.getElementsByTagName;
	const importNode = originalDocument.importNode;
	let hooks = _createHooksMap();
	/**
	* Expose whether this browser supports running the full DOMPurify.
	*/
	DOMPurify.isSupported = typeof entries === "function" && typeof getParentNode === "function" && implementation && implementation.createHTMLDocument !== void 0;
	const MUSTACHE_EXPR$1 = MUSTACHE_EXPR, ERB_EXPR$1 = ERB_EXPR, TMPLIT_EXPR$1 = TMPLIT_EXPR, DATA_ATTR$1 = DATA_ATTR, ARIA_ATTR$1 = ARIA_ATTR, IS_SCRIPT_OR_DATA$1 = IS_SCRIPT_OR_DATA, ATTR_WHITESPACE$1 = ATTR_WHITESPACE, CUSTOM_ELEMENT$1 = CUSTOM_ELEMENT;
	let IS_ALLOWED_URI$1 = IS_ALLOWED_URI;
	/**
	* We consider the elements and attributes below to be safe. Ideally
	* don't add any new ones but feel free to remove unwanted ones.
	*/
	let ALLOWED_TAGS = null;
	const DEFAULT_ALLOWED_TAGS = addToSet({}, [
		...html$1,
		...svg$1,
		...svgFilters,
		...mathMl$1,
		...text
	]);
	let ALLOWED_ATTR = null;
	const DEFAULT_ALLOWED_ATTR = addToSet({}, [
		...html,
		...svg,
		...mathMl,
		...xml
	]);
	let CUSTOM_ELEMENT_HANDLING = Object.seal(create(null, {
		tagNameCheck: {
			writable: true,
			configurable: false,
			enumerable: true,
			value: null
		},
		attributeNameCheck: {
			writable: true,
			configurable: false,
			enumerable: true,
			value: null
		},
		allowCustomizedBuiltInElements: {
			writable: true,
			configurable: false,
			enumerable: true,
			value: false
		}
	}));
	let FORBID_TAGS = null;
	let FORBID_ATTR = null;
	const EXTRA_ELEMENT_HANDLING = Object.seal(create(null, {
		tagCheck: {
			writable: true,
			configurable: false,
			enumerable: true,
			value: null
		},
		attributeCheck: {
			writable: true,
			configurable: false,
			enumerable: true,
			value: null
		}
	}));
	let ALLOW_ARIA_ATTR = true;
	let ALLOW_DATA_ATTR = true;
	let ALLOW_UNKNOWN_PROTOCOLS = false;
	let ALLOW_SELF_CLOSE_IN_ATTR = true;
	let SAFE_FOR_TEMPLATES = false;
	let SAFE_FOR_XML = true;
	let WHOLE_DOCUMENT = false;
	let SET_CONFIG = false;
	let SET_CONFIG_ALLOWED_TAGS = null;
	let SET_CONFIG_ALLOWED_ATTR = null;
	let FORCE_BODY = false;
	let RETURN_DOM = false;
	let RETURN_DOM_FRAGMENT = false;
	let RETURN_TRUSTED_TYPE = false;
	let SANITIZE_DOM = true;
	let SANITIZE_NAMED_PROPS = false;
	const SANITIZE_NAMED_PROPS_PREFIX = "user-content-";
	let KEEP_CONTENT = true;
	let IN_PLACE = false;
	let USE_PROFILES = {};
	let FORBID_CONTENTS = null;
	const DEFAULT_FORBID_CONTENTS = addToSet({}, [
		"annotation-xml",
		"audio",
		"colgroup",
		"desc",
		"foreignobject",
		"head",
		"iframe",
		"math",
		"mi",
		"mn",
		"mo",
		"ms",
		"mtext",
		"noembed",
		"noframes",
		"noscript",
		"plaintext",
		"script",
		"selectedcontent",
		"style",
		"svg",
		"template",
		"thead",
		"title",
		"video",
		"xmp"
	]);
	let DATA_URI_TAGS = null;
	const DEFAULT_DATA_URI_TAGS = addToSet({}, [
		"audio",
		"video",
		"img",
		"source",
		"image",
		"track"
	]);
	let URI_SAFE_ATTRIBUTES = null;
	const DEFAULT_URI_SAFE_ATTRIBUTES = addToSet({}, [
		"alt",
		"class",
		"for",
		"id",
		"label",
		"name",
		"pattern",
		"placeholder",
		"role",
		"summary",
		"title",
		"value",
		"style",
		"xmlns"
	]);
	const MATHML_NAMESPACE = "http://www.w3.org/1998/Math/MathML";
	const SVG_NAMESPACE = "http://www.w3.org/2000/svg";
	const HTML_NAMESPACE = "http://www.w3.org/1999/xhtml";
	let NAMESPACE = HTML_NAMESPACE;
	let IS_EMPTY_INPUT = false;
	let ALLOWED_NAMESPACES = null;
	const DEFAULT_ALLOWED_NAMESPACES = addToSet({}, [
		MATHML_NAMESPACE,
		SVG_NAMESPACE,
		HTML_NAMESPACE
	], stringToString);
	const DEFAULT_MATHML_TEXT_INTEGRATION_POINTS = freeze([
		"mi",
		"mo",
		"mn",
		"ms",
		"mtext"
	]);
	let MATHML_TEXT_INTEGRATION_POINTS = addToSet({}, DEFAULT_MATHML_TEXT_INTEGRATION_POINTS);
	const DEFAULT_HTML_INTEGRATION_POINTS = freeze(["annotation-xml"]);
	let HTML_INTEGRATION_POINTS = addToSet({}, DEFAULT_HTML_INTEGRATION_POINTS);
	const COMMON_SVG_AND_HTML_ELEMENTS = addToSet({}, [
		"title",
		"style",
		"font",
		"a",
		"script"
	]);
	let PARSER_MEDIA_TYPE = null;
	const SUPPORTED_PARSER_MEDIA_TYPES = ["application/xhtml+xml", "text/html"];
	const DEFAULT_PARSER_MEDIA_TYPE = "text/html";
	let transformCaseFunc = null;
	let CONFIG = null;
	const formElement = document.createElement("form");
	const isRegexOrFunction = function isRegexOrFunction(testValue) {
		return testValue instanceof RegExp || testValue instanceof Function;
	};
	/**
	* _parseConfig
	*
	* @param cfg optional config literal
	*/
	const _parseConfig = function _parseConfig() {
		let cfg = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		if (CONFIG && CONFIG === cfg) return;
		if (!cfg || typeof cfg !== "object") cfg = {};
		cfg = clone(cfg);
		PARSER_MEDIA_TYPE = SUPPORTED_PARSER_MEDIA_TYPES.indexOf(cfg.PARSER_MEDIA_TYPE) === -1 ? DEFAULT_PARSER_MEDIA_TYPE : cfg.PARSER_MEDIA_TYPE;
		transformCaseFunc = PARSER_MEDIA_TYPE === "application/xhtml+xml" ? stringToString : stringToLowerCase;
		ALLOWED_TAGS = _resolveSetOption(cfg, "ALLOWED_TAGS", DEFAULT_ALLOWED_TAGS, { transform: transformCaseFunc });
		ALLOWED_ATTR = _resolveSetOption(cfg, "ALLOWED_ATTR", DEFAULT_ALLOWED_ATTR, { transform: transformCaseFunc });
		ALLOWED_NAMESPACES = _resolveSetOption(cfg, "ALLOWED_NAMESPACES", DEFAULT_ALLOWED_NAMESPACES, { transform: stringToString });
		URI_SAFE_ATTRIBUTES = _resolveSetOption(cfg, "ADD_URI_SAFE_ATTR", DEFAULT_URI_SAFE_ATTRIBUTES, {
			transform: transformCaseFunc,
			base: DEFAULT_URI_SAFE_ATTRIBUTES
		});
		DATA_URI_TAGS = _resolveSetOption(cfg, "ADD_DATA_URI_TAGS", DEFAULT_DATA_URI_TAGS, {
			transform: transformCaseFunc,
			base: DEFAULT_DATA_URI_TAGS
		});
		FORBID_CONTENTS = _resolveSetOption(cfg, "FORBID_CONTENTS", DEFAULT_FORBID_CONTENTS, { transform: transformCaseFunc });
		FORBID_TAGS = _resolveSetOption(cfg, "FORBID_TAGS", clone({}), { transform: transformCaseFunc });
		FORBID_ATTR = _resolveSetOption(cfg, "FORBID_ATTR", clone({}), { transform: transformCaseFunc });
		USE_PROFILES = objectHasOwnProperty(cfg, "USE_PROFILES") ? cfg.USE_PROFILES && typeof cfg.USE_PROFILES === "object" ? clone(cfg.USE_PROFILES) : cfg.USE_PROFILES : false;
		ALLOW_ARIA_ATTR = cfg.ALLOW_ARIA_ATTR !== false;
		ALLOW_DATA_ATTR = cfg.ALLOW_DATA_ATTR !== false;
		ALLOW_UNKNOWN_PROTOCOLS = cfg.ALLOW_UNKNOWN_PROTOCOLS || false;
		ALLOW_SELF_CLOSE_IN_ATTR = cfg.ALLOW_SELF_CLOSE_IN_ATTR !== false;
		SAFE_FOR_TEMPLATES = cfg.SAFE_FOR_TEMPLATES || false;
		SAFE_FOR_XML = cfg.SAFE_FOR_XML !== false;
		WHOLE_DOCUMENT = cfg.WHOLE_DOCUMENT || false;
		RETURN_DOM = cfg.RETURN_DOM || false;
		RETURN_DOM_FRAGMENT = cfg.RETURN_DOM_FRAGMENT || false;
		RETURN_TRUSTED_TYPE = cfg.RETURN_TRUSTED_TYPE || false;
		FORCE_BODY = cfg.FORCE_BODY || false;
		SANITIZE_DOM = cfg.SANITIZE_DOM !== false;
		SANITIZE_NAMED_PROPS = cfg.SANITIZE_NAMED_PROPS || false;
		KEEP_CONTENT = cfg.KEEP_CONTENT !== false;
		IN_PLACE = cfg.IN_PLACE || false;
		IS_ALLOWED_URI$1 = isRegex(cfg.ALLOWED_URI_REGEXP) ? cfg.ALLOWED_URI_REGEXP : IS_ALLOWED_URI;
		NAMESPACE = typeof cfg.NAMESPACE === "string" ? cfg.NAMESPACE : HTML_NAMESPACE;
		MATHML_TEXT_INTEGRATION_POINTS = objectHasOwnProperty(cfg, "MATHML_TEXT_INTEGRATION_POINTS") && cfg.MATHML_TEXT_INTEGRATION_POINTS && typeof cfg.MATHML_TEXT_INTEGRATION_POINTS === "object" ? clone(cfg.MATHML_TEXT_INTEGRATION_POINTS) : addToSet({}, DEFAULT_MATHML_TEXT_INTEGRATION_POINTS);
		HTML_INTEGRATION_POINTS = objectHasOwnProperty(cfg, "HTML_INTEGRATION_POINTS") && cfg.HTML_INTEGRATION_POINTS && typeof cfg.HTML_INTEGRATION_POINTS === "object" ? clone(cfg.HTML_INTEGRATION_POINTS) : addToSet({}, DEFAULT_HTML_INTEGRATION_POINTS);
		const customElementHandling = objectHasOwnProperty(cfg, "CUSTOM_ELEMENT_HANDLING") && cfg.CUSTOM_ELEMENT_HANDLING && typeof cfg.CUSTOM_ELEMENT_HANDLING === "object" ? clone(cfg.CUSTOM_ELEMENT_HANDLING) : create(null);
		CUSTOM_ELEMENT_HANDLING = create(null);
		if (objectHasOwnProperty(customElementHandling, "tagNameCheck") && isRegexOrFunction(customElementHandling.tagNameCheck)) CUSTOM_ELEMENT_HANDLING.tagNameCheck = customElementHandling.tagNameCheck;
		if (objectHasOwnProperty(customElementHandling, "attributeNameCheck") && isRegexOrFunction(customElementHandling.attributeNameCheck)) CUSTOM_ELEMENT_HANDLING.attributeNameCheck = customElementHandling.attributeNameCheck;
		if (objectHasOwnProperty(customElementHandling, "allowCustomizedBuiltInElements") && typeof customElementHandling.allowCustomizedBuiltInElements === "boolean") CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements = customElementHandling.allowCustomizedBuiltInElements;
		seal(CUSTOM_ELEMENT_HANDLING);
		if (SAFE_FOR_TEMPLATES) ALLOW_DATA_ATTR = false;
		if (RETURN_DOM_FRAGMENT) RETURN_DOM = true;
		if (USE_PROFILES) {
			ALLOWED_TAGS = addToSet({}, text);
			ALLOWED_ATTR = create(null);
			if (USE_PROFILES.html === true) {
				addToSet(ALLOWED_TAGS, html$1);
				addToSet(ALLOWED_ATTR, html);
			}
			if (USE_PROFILES.svg === true) {
				addToSet(ALLOWED_TAGS, svg$1);
				addToSet(ALLOWED_ATTR, svg);
				addToSet(ALLOWED_ATTR, xml);
			}
			if (USE_PROFILES.svgFilters === true) {
				addToSet(ALLOWED_TAGS, svgFilters);
				addToSet(ALLOWED_ATTR, svg);
				addToSet(ALLOWED_ATTR, xml);
			}
			if (USE_PROFILES.mathMl === true) {
				addToSet(ALLOWED_TAGS, mathMl$1);
				addToSet(ALLOWED_ATTR, mathMl);
				addToSet(ALLOWED_ATTR, xml);
			}
		}
		EXTRA_ELEMENT_HANDLING.tagCheck = null;
		EXTRA_ELEMENT_HANDLING.attributeCheck = null;
		if (objectHasOwnProperty(cfg, "ADD_TAGS")) {
			if (typeof cfg.ADD_TAGS === "function") EXTRA_ELEMENT_HANDLING.tagCheck = cfg.ADD_TAGS;
			else if (arrayIsArray(cfg.ADD_TAGS)) {
				if (ALLOWED_TAGS === DEFAULT_ALLOWED_TAGS) ALLOWED_TAGS = clone(ALLOWED_TAGS);
				addToSet(ALLOWED_TAGS, cfg.ADD_TAGS, transformCaseFunc);
			}
		}
		if (objectHasOwnProperty(cfg, "ADD_ATTR")) {
			if (typeof cfg.ADD_ATTR === "function") EXTRA_ELEMENT_HANDLING.attributeCheck = cfg.ADD_ATTR;
			else if (arrayIsArray(cfg.ADD_ATTR)) {
				if (ALLOWED_ATTR === DEFAULT_ALLOWED_ATTR) ALLOWED_ATTR = clone(ALLOWED_ATTR);
				addToSet(ALLOWED_ATTR, cfg.ADD_ATTR, transformCaseFunc);
			}
		}
		if (objectHasOwnProperty(cfg, "ADD_URI_SAFE_ATTR") && arrayIsArray(cfg.ADD_URI_SAFE_ATTR)) addToSet(URI_SAFE_ATTRIBUTES, cfg.ADD_URI_SAFE_ATTR, transformCaseFunc);
		if (objectHasOwnProperty(cfg, "FORBID_CONTENTS") && arrayIsArray(cfg.FORBID_CONTENTS)) {
			if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) FORBID_CONTENTS = clone(FORBID_CONTENTS);
			addToSet(FORBID_CONTENTS, cfg.FORBID_CONTENTS, transformCaseFunc);
		}
		if (objectHasOwnProperty(cfg, "ADD_FORBID_CONTENTS") && arrayIsArray(cfg.ADD_FORBID_CONTENTS)) {
			if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) FORBID_CONTENTS = clone(FORBID_CONTENTS);
			addToSet(FORBID_CONTENTS, cfg.ADD_FORBID_CONTENTS, transformCaseFunc);
		}
		if (KEEP_CONTENT) ALLOWED_TAGS["#text"] = true;
		if (WHOLE_DOCUMENT) addToSet(ALLOWED_TAGS, [
			"html",
			"head",
			"body"
		]);
		if (ALLOWED_TAGS.table) {
			addToSet(ALLOWED_TAGS, ["tbody"]);
			delete FORBID_TAGS.tbody;
		}
		if (cfg.TRUSTED_TYPES_POLICY) {
			if (typeof cfg.TRUSTED_TYPES_POLICY.createHTML !== "function") throw typeErrorCreate("TRUSTED_TYPES_POLICY configuration option must provide a \"createHTML\" hook.");
			if (typeof cfg.TRUSTED_TYPES_POLICY.createScriptURL !== "function") throw typeErrorCreate("TRUSTED_TYPES_POLICY configuration option must provide a \"createScriptURL\" hook.");
			const previousTrustedTypesPolicy = trustedTypesPolicy;
			trustedTypesPolicy = cfg.TRUSTED_TYPES_POLICY;
			try {
				emptyHTML = _createTrustedHTML("");
			} catch (error) {
				trustedTypesPolicy = previousTrustedTypesPolicy;
				throw error;
			}
		} else if (cfg.TRUSTED_TYPES_POLICY === null) {
			trustedTypesPolicy = void 0;
			emptyHTML = "";
		} else {
			if (trustedTypesPolicy === void 0) trustedTypesPolicy = _getDefaultTrustedTypesPolicy();
			if (trustedTypesPolicy && typeof emptyHTML === "string") emptyHTML = _createTrustedHTML("");
		}
		if (freeze) freeze(cfg);
		CONFIG = cfg;
	};
	const ALL_SVG_TAGS = addToSet({}, [
		...svg$1,
		...svgFilters,
		...svgDisallowed
	]);
	const ALL_MATHML_TAGS = addToSet({}, [...mathMl$1, ...mathMlDisallowed]);
	/**
	* Namespace rules for an element in the SVG namespace.
	*
	* @param tagName the element's lowercase tag name
	* @param parent the (possibly simulated) parent node
	* @param parentTagName the parent's lowercase tag name
	* @returns true if a spec-compliant parser could produce this element
	*/
	const _checkSvgNamespace = function _checkSvgNamespace(tagName, parent, parentTagName) {
		if (parent.namespaceURI === HTML_NAMESPACE) return tagName === "svg";
		if (parent.namespaceURI === MATHML_NAMESPACE) return tagName === "svg" && (parentTagName === "annotation-xml" || MATHML_TEXT_INTEGRATION_POINTS[parentTagName]);
		return Boolean(ALL_SVG_TAGS[tagName]);
	};
	/**
	* Namespace rules for an element in the MathML namespace.
	*
	* @param tagName the element's lowercase tag name
	* @param parent the (possibly simulated) parent node
	* @param parentTagName the parent's lowercase tag name
	* @returns true if a spec-compliant parser could produce this element
	*/
	const _checkMathMlNamespace = function _checkMathMlNamespace(tagName, parent, parentTagName) {
		if (parent.namespaceURI === HTML_NAMESPACE) return tagName === "math";
		if (parent.namespaceURI === SVG_NAMESPACE) return tagName === "math" && HTML_INTEGRATION_POINTS[parentTagName];
		return Boolean(ALL_MATHML_TAGS[tagName]);
	};
	/**
	* Namespace rules for an element in the HTML namespace.
	*
	* @param tagName the element's lowercase tag name
	* @param parent the (possibly simulated) parent node
	* @param parentTagName the parent's lowercase tag name
	* @returns true if a spec-compliant parser could produce this element
	*/
	const _checkHtmlNamespace = function _checkHtmlNamespace(tagName, parent, parentTagName) {
		if (parent.namespaceURI === SVG_NAMESPACE && !HTML_INTEGRATION_POINTS[parentTagName]) return false;
		if (parent.namespaceURI === MATHML_NAMESPACE && !MATHML_TEXT_INTEGRATION_POINTS[parentTagName]) return false;
		return !ALL_MATHML_TAGS[tagName] && (COMMON_SVG_AND_HTML_ELEMENTS[tagName] || !ALL_SVG_TAGS[tagName]);
	};
	/**
	* @param element a DOM element whose namespace is being checked
	* @returns Return false if the element has a
	*  namespace that a spec-compliant parser would never
	*  return. Return true otherwise.
	*/
	const _checkValidNamespace = function _checkValidNamespace(element) {
		let parent = getParentNode(element);
		if (!parent || !parent.tagName) parent = {
			namespaceURI: NAMESPACE,
			tagName: "template"
		};
		const tagName = stringToLowerCase(element.tagName);
		const parentTagName = stringToLowerCase(parent.tagName);
		if (!ALLOWED_NAMESPACES[element.namespaceURI]) return false;
		if (element.namespaceURI === SVG_NAMESPACE) return _checkSvgNamespace(tagName, parent, parentTagName);
		if (element.namespaceURI === MATHML_NAMESPACE) return _checkMathMlNamespace(tagName, parent, parentTagName);
		if (element.namespaceURI === HTML_NAMESPACE) return _checkHtmlNamespace(tagName, parent, parentTagName);
		if (PARSER_MEDIA_TYPE === "application/xhtml+xml" && ALLOWED_NAMESPACES[element.namespaceURI]) return true;
		return false;
	};
	/**
	* _forceRemove
	*
	* @param node a DOM node
	*/
	const _forceRemove = function _forceRemove(node) {
		arrayPush(DOMPurify.removed, { element: node });
		try {
			getParentNode(node).removeChild(node);
		} catch (_) {
			remove(node);
			if (!getParentNode(node)) throw typeErrorCreate("a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place");
		}
	};
	/**
	* _neutralizeRoot
	*
	* Fail-closed teardown of an in-place root after the sanitize walk aborts
	* (campaign-3 F2). An internal throw mid-walk — e.g. a page-registered
	* custom element's reaction detaches a node so `_forceRemove`'s deliberate
	* parentless guard throws, or any other re-entrant engine mutation — would
	* otherwise leave the caller's *live* tree half-sanitized, with everything
	* after the abort point still carrying its handlers. There is no safe way
	* to resume the walk (the tree mutated under us), so we strip the root bare:
	* remove every child and every attribute, then let the caller's catch see
	* the original error. Clobber-safe (cached `remove`/`childNodes`/`attributes`
	* getters; the root was already clobber-pre-flighted at the IN_PLACE entry).
	*
	* @param root the in-place root to empty
	*/
	const _neutralizeRoot = function _neutralizeRoot(root) {
		const childNodes = getChildNodes(root);
		if (childNodes) {
			const snapshot = [];
			arrayForEach(childNodes, (child) => {
				arrayPush(snapshot, child);
			});
			arrayForEach(snapshot, (child) => {
				try {
					remove(child);
				} catch (_) {}
			});
		}
		const attributes = getAttributes(root);
		if (attributes) for (let i = attributes.length - 1; i >= 0; --i) {
			const attribute = attributes[i];
			const name = attribute && attribute.name;
			if (typeof name === "string") try {
				root.removeAttribute(name);
			} catch (_) {}
		}
	};
	/**
	* _removeAttribute
	*
	* @param name an Attribute name
	* @param element a DOM node
	*/
	const _removeAttribute = function _removeAttribute(name, element) {
		try {
			arrayPush(DOMPurify.removed, {
				attribute: element.getAttributeNode(name),
				from: element
			});
		} catch (_) {
			arrayPush(DOMPurify.removed, {
				attribute: null,
				from: element
			});
		}
		element.removeAttribute(name);
		if (name === "is") if (RETURN_DOM || RETURN_DOM_FRAGMENT) try {
			_forceRemove(element);
		} catch (_) {}
		else try {
			element.setAttribute(name, "");
		} catch (_) {}
	};
	/**
	* _stripDisallowedAttributes
	*
	* Removes every attribute the active configuration does not allow from a
	* single element, using the same allowlist as the main attribute pass (so
	* `on*` handlers go, but no `/^on/` blocklist is introduced). Used only to
	* neutralise nodes that are being discarded from an in-place tree.
	*
	* @param element the element to strip
	*/
	const _stripDisallowedAttributes = function _stripDisallowedAttributes(element) {
		const attributes = getAttributes(element);
		if (!attributes) return;
		for (let i = attributes.length - 1; i >= 0; --i) {
			const attribute = attributes[i];
			const name = attribute && attribute.name;
			if (typeof name !== "string" || ALLOWED_ATTR[transformCaseFunc(name)]) continue;
			try {
				element.removeAttribute(name);
			} catch (_) {}
		}
	};
	/**
	* _neutralizeSubtree
	*
	* Completes the audit-5 F1 fix across every removal path. The KEEP_CONTENT
	* move-hoist neutralises only disallowed-tag removals; clobber, mXSS-canary,
	* namespace, comment, processing-instruction and KEEP_CONTENT:false removals
	* all drop their subtree wholesale via `_forceRemove`. On the IN_PLACE path
	* those dropped nodes are detached from the caller's LIVE tree but a
	* handler-bearing original among them (an `<img onerror>`/`<video>` that was
	* loading) keeps its queued resource event, which fires in page scope after
	* sanitize returns. This walks a removed subtree and strips every attribute
	* the active configuration does not allow — so `on*` handlers are cancelled
	* through the SAME allowlist that governs kept nodes, not a separate `/^on/`
	* blocklist. Run synchronously before sanitize returns, i.e. before any
	* queued event can fire. Hook-free by design: these nodes leave the output,
	* so firing attribute hooks for them would be surprising. Clobber-safe reads;
	* a doomed clobbered node may shadow `removeAttribute` (its own attributes are
	* irrelevant — it is discarded — while its non-clobbered descendants, e.g.
	* the `<img>`, are reached and scrubbed).
	*
	* @param root the root of a removed subtree to neutralise
	*/
	const _neutralizeSubtree = function _neutralizeSubtree(root) {
		const stack = [root];
		while (stack.length > 0) {
			const node = stack.pop();
			if ((getNodeType ? getNodeType(node) : node.nodeType) === NODE_TYPE.element) _stripDisallowedAttributes(node);
			const childNodes = getChildNodes(node);
			if (childNodes) for (let i = childNodes.length - 1; i >= 0; --i) stack.push(childNodes[i]);
		}
	};
	/**
	* _initDocument
	*
	* @param dirty - a string of dirty markup
	* @return a DOM, filled with the dirty markup
	*/
	const _initDocument = function _initDocument(dirty) {
		let doc = null;
		let leadingWhitespace = null;
		if (FORCE_BODY) dirty = "<remove></remove>" + dirty;
		else {
			const matches = stringMatch(dirty, /^[\r\n\t ]+/);
			leadingWhitespace = matches && matches[0];
		}
		if (PARSER_MEDIA_TYPE === "application/xhtml+xml" && NAMESPACE === HTML_NAMESPACE) dirty = "<html xmlns=\"http://www.w3.org/1999/xhtml\"><head></head><body>" + dirty + "</body></html>";
		const dirtyPayload = trustedTypesPolicy ? _createTrustedHTML(dirty) : dirty;
		if (NAMESPACE === HTML_NAMESPACE) try {
			doc = new DOMParser().parseFromString(dirtyPayload, PARSER_MEDIA_TYPE);
		} catch (_) {}
		if (!doc || !doc.documentElement) {
			doc = implementation.createDocument(NAMESPACE, "template", null);
			try {
				doc.documentElement.innerHTML = IS_EMPTY_INPUT ? emptyHTML : dirtyPayload;
			} catch (_) {}
		}
		const body = doc.body || doc.documentElement;
		if (dirty && leadingWhitespace) body.insertBefore(document.createTextNode(leadingWhitespace), body.childNodes[0] || null);
		if (NAMESPACE === HTML_NAMESPACE) return getElementsByTagName.call(doc, WHOLE_DOCUMENT ? "html" : "body")[0];
		return WHOLE_DOCUMENT ? doc.documentElement : body;
	};
	/**
	* Creates a NodeIterator object that you can use to traverse filtered lists of nodes or elements in a document.
	*
	* @param root The root element or node to start traversing on.
	* @return The created NodeIterator
	*/
	const _createNodeIterator = function _createNodeIterator(root) {
		return createNodeIterator.call(root.ownerDocument || root, root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_TEXT | NodeFilter.SHOW_PROCESSING_INSTRUCTION | NodeFilter.SHOW_CDATA_SECTION, null);
	};
	/**
	* Replace template expression syntax (mustache, ERB, template
	* literal) with a space; shared by all SAFE_FOR_TEMPLATES scrub
	* sites. Order matters: mustache, then ERB, then template literal.
	*
	* @param value the string to scrub
	* @returns the scrubbed string
	*/
	const _stripTemplateExpressions = function _stripTemplateExpressions(value) {
		value = stringReplace(value, MUSTACHE_EXPR$1, " ");
		value = stringReplace(value, ERB_EXPR$1, " ");
		value = stringReplace(value, TMPLIT_EXPR$1, " ");
		return value;
	};
	/**
	* Strip template-engine expressions ({{...}}, ${...}, <%...%>) from the
	* character data of an element subtree. Used as the final safety net for
	* SAFE_FOR_TEMPLATES on every DOM-returning code path so that expressions
	* which only form after text-node normalization (e.g. fragments split across
	* stripped elements) cannot survive into a template-evaluating framework.
	*
	* Walks text/comment/CDATA/processing-instruction nodes and mutates `.data`
	* in place rather than round-tripping through innerHTML. This preserves
	* descendant node references (important for IN_PLACE callers), avoids a
	* serialize/reparse cycle, and reads literal character data — which means
	* `<%...%>` in text content matches the ERB regex against its real bytes
	* instead of the HTML-entity-escaped form innerHTML would produce.
	*
	* Attribute values are not visited here; SAFE_FOR_TEMPLATES handling for
	* attributes is performed during the per-node `_sanitizeAttributes` pass.
	*
	* @param node The root element whose character data should be scrubbed.
	*/
	const _scrubTemplateExpressions2 = function _scrubTemplateExpressions(node) {
		var _node$querySelectorAl;
		node.normalize();
		const walker = createNodeIterator.call(node.ownerDocument || node, node, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_CDATA_SECTION | NodeFilter.SHOW_PROCESSING_INSTRUCTION, null);
		let currentNode = walker.nextNode();
		while (currentNode) {
			currentNode.data = _stripTemplateExpressions(currentNode.data);
			currentNode = walker.nextNode();
		}
		const templates = (_node$querySelectorAl = node.querySelectorAll) === null || _node$querySelectorAl === void 0 ? void 0 : _node$querySelectorAl.call(node, "template");
		if (templates) arrayForEach(templates, (tmpl) => {
			if (_isDocumentFragment(tmpl.content)) _scrubTemplateExpressions2(tmpl.content);
		});
	};
	/**
	* _isClobbered
	*
	* Detect DOM-clobbering on HTMLFormElement nodes. Form is the only HTML
	* interface with [LegacyOverrideBuiltIns]; a descendant element with a
	* `name` attribute matching a prototype property shadows that property
	* on direct reads. We use this check at the IN_PLACE entry-point and
	* during attribute sanitization to refuse clobbered forms.
	*
	* @param element element to check for clobbering attacks
	* @return true if clobbered, false if safe
	*/
	const _isClobbered = function _isClobbered(element) {
		const realTagName = getNodeName ? getNodeName(element) : null;
		if (typeof realTagName !== "string") return false;
		if (transformCaseFunc(realTagName) !== "form") return false;
		return typeof element.nodeName !== "string" || typeof element.textContent !== "string" || typeof element.removeChild !== "function" || element.attributes !== getAttributes(element) || typeof element.removeAttribute !== "function" || typeof element.setAttribute !== "function" || typeof element.namespaceURI !== "string" || typeof element.insertBefore !== "function" || typeof element.hasChildNodes !== "function" || element.nodeType !== getNodeType(element) || element.childNodes !== getChildNodes(element);
	};
	/**
	* Checks whether the given value is a DocumentFragment from any realm.
	*
	* The realm-independent replacement reads `nodeType` through the cached
	* Node.prototype getter and compares to the DOCUMENT_FRAGMENT_NODE
	* constant (11). nodeType is a numeric value resolved from the node's
	* internal slot, identical across realms for the same kind of node.
	*
	* @param value object to check
	* @return true if value is a DocumentFragment-shaped node from any realm
	*/
	const _isDocumentFragment = function _isDocumentFragment(value) {
		if (!getNodeType || typeof value !== "object" || value === null) return false;
		try {
			return getNodeType(value) === NODE_TYPE.documentFragment;
		} catch (_) {
			return false;
		}
	};
	/**
	* Checks whether the given object is a DOM node, including nodes that
	* originate from a different window/realm (e.g. an iframe's
	* contentDocument). The previous `value instanceof Node` check was
	* realm-bound: nodes from a different window failed it, causing
	* sanitize() to silently stringify them and reset IN_PLACE to false,
	* returning the original node unsanitized. See GHSA-4w3q-35jp-p934.
	*
	* @param value object to check whether it's a DOM node
	* @return true if value is a DOM node from any realm
	*/
	const _isNode = function _isNode(value) {
		if (!getNodeType || typeof value !== "object" || value === null) return false;
		try {
			return typeof getNodeType(value) === "number";
		} catch (_) {
			return false;
		}
	};
	function _executeHooks(hooks, currentNode, data) {
		if (hooks.length === 0) return;
		arrayForEach(hooks, (hook) => {
			hook.call(DOMPurify, currentNode, data, CONFIG);
		});
	}
	/**
	* Structural-threat checks that condemn a node regardless of the
	* allowlists: mXSS via namespace confusion, risky CSS construction,
	* processing instructions, markup-bearing comments. Pure predicate;
	* the caller removes. Check order is load-bearing.
	*
	* @param currentNode the node to inspect
	* @param tagName the node's transformCaseFunc'd tag name
	* @return true if the node must be removed
	*/
	const _isUnsafeNode = function _isUnsafeNode(currentNode, tagName) {
		if (SAFE_FOR_XML && currentNode.hasChildNodes() && !_isNode(currentNode.firstElementChild) && regExpTest(ELEMENT_MARKUP_PROBE, currentNode.textContent) && regExpTest(ELEMENT_MARKUP_PROBE, currentNode.innerHTML)) return true;
		if (SAFE_FOR_XML && currentNode.namespaceURI === HTML_NAMESPACE && tagName === "style" && _isNode(currentNode.firstElementChild)) return true;
		if (currentNode.nodeType === NODE_TYPE.processingInstruction) return true;
		if (SAFE_FOR_XML && currentNode.nodeType === NODE_TYPE.comment && regExpTest(COMMENT_MARKUP_PROBE, currentNode.data)) return true;
		return false;
	};
	/**
	* Handle a node whose tag is forbidden or not allowlisted: keep
	* allowed custom elements (false return exits _sanitizeElements
	* early - namespace/fallback checks and the afterSanitizeElements
	* hook are intentionally skipped for kept custom elements), else
	* hoist content per KEEP_CONTENT and remove.
	*
	* @param currentNode the disallowed node
	* @param tagName the node's transformCaseFunc'd tag name
	* @return true if the node was removed, false if kept
	*/
	const _sanitizeDisallowedNode = function _sanitizeDisallowedNode(currentNode, tagName) {
		if (!FORBID_TAGS[tagName] && _isBasicCustomElement(tagName)) {
			if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, tagName)) return false;
			if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(tagName)) return false;
		}
		if (KEEP_CONTENT && !FORBID_CONTENTS[tagName]) {
			const parentNode = getParentNode(currentNode);
			const childNodes = getChildNodes(currentNode);
			if (childNodes && parentNode) {
				const childCount = childNodes.length;
				for (let i = childCount - 1; i >= 0; --i) {
					const hoisted = IN_PLACE ? childNodes[i] : cloneNode(childNodes[i], true);
					parentNode.insertBefore(hoisted, getNextSibling(currentNode));
				}
			}
		}
		_forceRemove(currentNode);
		return true;
	};
	/**
	* _sanitizeElements
	*
	* @protect nodeName
	* @protect textContent
	* @protect removeChild
	* @param currentNode to check for permission to exist
	* @return true if node was killed, false if left alive
	*/
	const _sanitizeElements = function _sanitizeElements(currentNode) {
		_executeHooks(hooks.beforeSanitizeElements, currentNode, null);
		if (_isClobbered(currentNode)) {
			_forceRemove(currentNode);
			return true;
		}
		const tagName = transformCaseFunc(getNodeName ? getNodeName(currentNode) : currentNode.nodeName);
		_executeHooks(hooks.uponSanitizeElement, currentNode, {
			tagName,
			allowedTags: ALLOWED_TAGS
		});
		if (_isUnsafeNode(currentNode, tagName)) {
			_forceRemove(currentNode);
			return true;
		}
		if (FORBID_TAGS[tagName] || !(EXTRA_ELEMENT_HANDLING.tagCheck instanceof Function && EXTRA_ELEMENT_HANDLING.tagCheck(tagName)) && !ALLOWED_TAGS[tagName]) return _sanitizeDisallowedNode(currentNode, tagName);
		if ((getNodeType ? getNodeType(currentNode) : currentNode.nodeType) === NODE_TYPE.element && !_checkValidNamespace(currentNode)) {
			_forceRemove(currentNode);
			return true;
		}
		if ((tagName === "noscript" || tagName === "noembed" || tagName === "noframes") && regExpTest(FALLBACK_TAG_CLOSE, currentNode.innerHTML)) {
			_forceRemove(currentNode);
			return true;
		}
		if (SAFE_FOR_TEMPLATES && currentNode.nodeType === NODE_TYPE.text) {
			const content = _stripTemplateExpressions(currentNode.textContent);
			if (currentNode.textContent !== content) {
				arrayPush(DOMPurify.removed, { element: currentNode.cloneNode() });
				currentNode.textContent = content;
			}
		}
		_executeHooks(hooks.afterSanitizeElements, currentNode, null);
		return false;
	};
	/**
	* _isValidAttribute
	*
	* @param lcTag Lowercase tag name of containing element.
	* @param lcName Lowercase attribute name.
	* @param value Attribute value.
	* @return Returns true if `value` is valid, otherwise false.
	*/
	const _isValidAttribute = function _isValidAttribute(lcTag, lcName, value) {
		if (FORBID_ATTR[lcName]) return false;
		if (SANITIZE_DOM && (lcName === "id" || lcName === "name") && (value in document || value in formElement)) return false;
		const nameIsPermitted = ALLOWED_ATTR[lcName] || EXTRA_ELEMENT_HANDLING.attributeCheck instanceof Function && EXTRA_ELEMENT_HANDLING.attributeCheck(lcName, lcTag);
		if (ALLOW_DATA_ATTR && regExpTest(DATA_ATTR$1, lcName));
		else if (ALLOW_ARIA_ATTR && regExpTest(ARIA_ATTR$1, lcName));
		else if (!nameIsPermitted) if (_isBasicCustomElement(lcTag) && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, lcTag) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(lcTag)) && (CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.attributeNameCheck, lcName) || CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.attributeNameCheck(lcName, lcTag)) || lcName === "is" && CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, value) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(value)));
		else return false;
		else if (URI_SAFE_ATTRIBUTES[lcName]);
		else if (regExpTest(IS_ALLOWED_URI$1, stringReplace(value, ATTR_WHITESPACE$1, "")));
		else if ((lcName === "src" || lcName === "xlink:href" || lcName === "href") && lcTag !== "script" && stringIndexOf(value, "data:") === 0 && DATA_URI_TAGS[lcTag]);
		else if (ALLOW_UNKNOWN_PROTOCOLS && !regExpTest(IS_SCRIPT_OR_DATA$1, stringReplace(value, ATTR_WHITESPACE$1, "")));
		else if (value) return false;
		return true;
	};
	const RESERVED_CUSTOM_ELEMENT_NAMES = addToSet({}, [
		"annotation-xml",
		"color-profile",
		"font-face",
		"font-face-format",
		"font-face-name",
		"font-face-src",
		"font-face-uri",
		"missing-glyph"
	]);
	/**
	* _isBasicCustomElement
	* checks if at least one dash is included in tagName, and it's not the first char
	* for more sophisticated checking see https://github.com/sindresorhus/validate-element-name
	*
	* @param tagName name of the tag of the node to sanitize
	* @returns Returns true if the tag name meets the basic criteria for a custom element, otherwise false.
	*/
	const _isBasicCustomElement = function _isBasicCustomElement(tagName) {
		return !RESERVED_CUSTOM_ELEMENT_NAMES[stringToLowerCase(tagName)] && regExpTest(CUSTOM_ELEMENT$1, tagName);
	};
	/**
	* Wrap an attribute value in the matching Trusted Types object when
	* the active policy requires it. Namespaced attributes pass through
	* unchanged (no TT support yet, see
	* https://bugs.chromium.org/p/chromium/issues/detail?id=1305293).
	*
	* @param lcTag lowercase tag name of the containing element
	* @param lcName lowercase attribute name
	* @param namespaceURI the attribute's namespace, if any
	* @param value the attribute value to wrap
	* @return the value, wrapped when Trusted Types demand it
	*/
	const _applyTrustedTypesToAttribute = function _applyTrustedTypesToAttribute(lcTag, lcName, namespaceURI, value) {
		if (trustedTypesPolicy && typeof trustedTypes === "object" && typeof trustedTypes.getAttributeType === "function" && !namespaceURI) switch (trustedTypes.getAttributeType(lcTag, lcName)) {
			case "TrustedHTML": return _createTrustedHTML(value);
			case "TrustedScriptURL": return _createTrustedScriptURL(value);
		}
		return value;
	};
	/**
	* Write a modified attribute value back onto the element. On
	* success, re-probe for clobbering introduced by the new value and
	* remove the element when found; otherwise pop the removal entry
	* recorded by the earlier _removeAttribute (long-standing pairing
	* with the SANITIZE_NAMED_PROPS path - do not "fix" casually). On
	* failure, remove the attribute instead.
	*
	* @param currentNode the element carrying the attribute
	* @param name the attribute name as present on the element
	* @param namespaceURI the attribute's namespace, if any
	* @param value the new attribute value
	*/
	const _setAttributeValue = function _setAttributeValue(currentNode, name, namespaceURI, value) {
		try {
			if (namespaceURI) currentNode.setAttributeNS(namespaceURI, name, value);
			else currentNode.setAttribute(name, value);
			if (_isClobbered(currentNode)) _forceRemove(currentNode);
			else arrayPop(DOMPurify.removed);
		} catch (_) {
			_removeAttribute(name, currentNode);
		}
	};
	/**
	* _sanitizeAttributes
	*
	* @protect attributes
	* @protect nodeName
	* @protect removeAttribute
	* @protect setAttribute
	*
	* @param currentNode to sanitize
	*/
	const _sanitizeAttributes = function _sanitizeAttributes(currentNode) {
		_executeHooks(hooks.beforeSanitizeAttributes, currentNode, null);
		const attributes = currentNode.attributes;
		if (!attributes || _isClobbered(currentNode)) return;
		const hookEvent = {
			attrName: "",
			attrValue: "",
			keepAttr: true,
			allowedAttributes: ALLOWED_ATTR,
			forceKeepAttr: void 0
		};
		let l = attributes.length;
		const lcTag = transformCaseFunc(currentNode.nodeName);
		while (l--) {
			const attr = attributes[l];
			const name = attr.name, namespaceURI = attr.namespaceURI, attrValue = attr.value;
			const lcName = transformCaseFunc(name);
			const initValue = attrValue;
			let value = name === "value" ? initValue : stringTrim(initValue);
			hookEvent.attrName = lcName;
			hookEvent.attrValue = value;
			hookEvent.keepAttr = true;
			hookEvent.forceKeepAttr = void 0;
			_executeHooks(hooks.uponSanitizeAttribute, currentNode, hookEvent);
			value = hookEvent.attrValue;
			if (SANITIZE_NAMED_PROPS && (lcName === "id" || lcName === "name") && stringIndexOf(value, SANITIZE_NAMED_PROPS_PREFIX) !== 0) {
				_removeAttribute(name, currentNode);
				value = SANITIZE_NAMED_PROPS_PREFIX + value;
			}
			if (SAFE_FOR_XML && regExpTest(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i, value)) {
				_removeAttribute(name, currentNode);
				continue;
			}
			if (lcName === "attributename" && stringMatch(value, "href")) {
				_removeAttribute(name, currentNode);
				continue;
			}
			if (hookEvent.forceKeepAttr) continue;
			if (!hookEvent.keepAttr) {
				_removeAttribute(name, currentNode);
				continue;
			}
			if (!ALLOW_SELF_CLOSE_IN_ATTR && regExpTest(SELF_CLOSING_TAG, value)) {
				_removeAttribute(name, currentNode);
				continue;
			}
			if (SAFE_FOR_TEMPLATES) value = _stripTemplateExpressions(value);
			if (!_isValidAttribute(lcTag, lcName, value)) {
				_removeAttribute(name, currentNode);
				continue;
			}
			value = _applyTrustedTypesToAttribute(lcTag, lcName, namespaceURI, value);
			if (value !== initValue) _setAttributeValue(currentNode, name, namespaceURI, value);
		}
		_executeHooks(hooks.afterSanitizeAttributes, currentNode, null);
	};
	/**
	* _sanitizeShadowDOM
	*
	* @param fragment to iterate over recursively
	*/
	const _sanitizeShadowDOM2 = function _sanitizeShadowDOM(fragment) {
		let shadowNode = null;
		const shadowIterator = _createNodeIterator(fragment);
		_executeHooks(hooks.beforeSanitizeShadowDOM, fragment, null);
		while (shadowNode = shadowIterator.nextNode()) {
			_executeHooks(hooks.uponSanitizeShadowNode, shadowNode, null);
			_sanitizeElements(shadowNode);
			_sanitizeAttributes(shadowNode);
			if (_isDocumentFragment(shadowNode.content)) _sanitizeShadowDOM2(shadowNode.content);
			if ((getNodeType ? getNodeType(shadowNode) : shadowNode.nodeType) === NODE_TYPE.element) {
				const innerSr = getShadowRoot(shadowNode);
				if (_isDocumentFragment(innerSr)) {
					_sanitizeAttachedShadowRoots(innerSr);
					_sanitizeShadowDOM2(innerSr);
				}
			}
		}
		_executeHooks(hooks.afterSanitizeShadowDOM, fragment, null);
	};
	/**
	* _sanitizeAttachedShadowRoots
	*
	* Walks `root` and feeds every attached shadow root we encounter into
	* the existing _sanitizeShadowDOM pipeline. The default node iterator
	* does not descend into shadow trees, so nodes inside an attached
	* shadow root would otherwise be skipped entirely.
	*
	* Two real input paths put attached shadow roots in front of us:
	*   1. IN_PLACE on a DOM node that already has shadow roots attached.
	*   2. DOM-node input where importNode(dirty, true) deep-clones the
	*      shadow root because it was created with `clonable: true`.
	*
	* This pass runs once, up front, so the main iteration loop (and the
	* existing _sanitizeShadowDOM template-content recursion) stay
	* untouched — string-input paths are not affected.
	*
	* @param root the subtree root to walk for attached shadow roots
	*/
	const _sanitizeAttachedShadowRoots = function _sanitizeAttachedShadowRoots(root) {
		const stack = [{
			node: root,
			shadow: null
		}];
		while (stack.length > 0) {
			const item = stack.pop();
			if (item.shadow) {
				_sanitizeShadowDOM2(item.shadow);
				continue;
			}
			const node = item.node;
			const isElement = (getNodeType ? getNodeType(node) : node.nodeType) === NODE_TYPE.element;
			const childNodes = getChildNodes(node);
			if (childNodes) for (let i = childNodes.length - 1; i >= 0; --i) stack.push({
				node: childNodes[i],
				shadow: null
			});
			if (isElement) {
				const rootName = getNodeName ? getNodeName(node) : null;
				if (typeof rootName === "string" && transformCaseFunc(rootName) === "template") {
					const content = node.content;
					if (_isDocumentFragment(content)) stack.push({
						node: content,
						shadow: null
					});
				}
			}
			if (isElement) {
				const sr = getShadowRoot(node);
				if (_isDocumentFragment(sr)) stack.push({
					node: null,
					shadow: sr
				}, {
					node: sr,
					shadow: null
				});
			}
		}
	};
	DOMPurify.sanitize = function(dirty) {
		let cfg = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		let body = null;
		let importedNode = null;
		let currentNode = null;
		let returnNode = null;
		IS_EMPTY_INPUT = !dirty;
		if (IS_EMPTY_INPUT) dirty = "<!-->";
		if (typeof dirty !== "string" && !_isNode(dirty)) {
			dirty = stringifyValue(dirty);
			if (typeof dirty !== "string") throw typeErrorCreate("dirty is not a string, aborting");
		}
		if (!DOMPurify.isSupported) return dirty;
		if (SET_CONFIG) {
			ALLOWED_TAGS = SET_CONFIG_ALLOWED_TAGS;
			ALLOWED_ATTR = SET_CONFIG_ALLOWED_ATTR;
		} else _parseConfig(cfg);
		if (hooks.uponSanitizeElement.length > 0 || hooks.uponSanitizeAttribute.length > 0) ALLOWED_TAGS = clone(ALLOWED_TAGS);
		if (hooks.uponSanitizeAttribute.length > 0) ALLOWED_ATTR = clone(ALLOWED_ATTR);
		DOMPurify.removed = [];
		const inPlace = IN_PLACE && typeof dirty !== "string" && _isNode(dirty);
		if (inPlace) {
			const nn = getNodeName ? getNodeName(dirty) : dirty.nodeName;
			if (typeof nn === "string") {
				const tagName = transformCaseFunc(nn);
				if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) throw typeErrorCreate("root node is forbidden and cannot be sanitized in-place");
			}
			if (_isClobbered(dirty)) throw typeErrorCreate("root node is clobbered and cannot be sanitized in-place");
			try {
				_sanitizeAttachedShadowRoots(dirty);
			} catch (error) {
				_neutralizeRoot(dirty);
				throw error;
			}
		} else if (_isNode(dirty)) {
			body = _initDocument("<!---->");
			importedNode = body.ownerDocument.importNode(dirty, true);
			if (importedNode.nodeType === NODE_TYPE.element && importedNode.nodeName === "BODY") body = importedNode;
			else if (importedNode.nodeName === "HTML") body = importedNode;
			else body.appendChild(importedNode);
			_sanitizeAttachedShadowRoots(importedNode);
		} else {
			if (!RETURN_DOM && !SAFE_FOR_TEMPLATES && !WHOLE_DOCUMENT && dirty.indexOf("<") === -1) return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? _createTrustedHTML(dirty) : dirty;
			body = _initDocument(dirty);
			if (!body) return RETURN_DOM ? null : RETURN_TRUSTED_TYPE ? emptyHTML : "";
		}
		if (body && FORCE_BODY) _forceRemove(body.firstChild);
		const nodeIterator = _createNodeIterator(inPlace ? dirty : body);
		try {
			while (currentNode = nodeIterator.nextNode()) {
				_sanitizeElements(currentNode);
				_sanitizeAttributes(currentNode);
				if (_isDocumentFragment(currentNode.content)) _sanitizeShadowDOM2(currentNode.content);
			}
		} catch (error) {
			if (inPlace) _neutralizeRoot(dirty);
			throw error;
		}
		if (inPlace) {
			arrayForEach(DOMPurify.removed, (entry) => {
				if (entry.element) _neutralizeSubtree(entry.element);
			});
			if (SAFE_FOR_TEMPLATES) _scrubTemplateExpressions2(dirty);
			return dirty;
		}
		if (RETURN_DOM) {
			if (SAFE_FOR_TEMPLATES) _scrubTemplateExpressions2(body);
			if (RETURN_DOM_FRAGMENT) {
				returnNode = createDocumentFragment.call(body.ownerDocument);
				while (body.firstChild) returnNode.appendChild(body.firstChild);
			} else returnNode = body;
			if (ALLOWED_ATTR.shadowroot || ALLOWED_ATTR.shadowrootmode) returnNode = importNode.call(originalDocument, returnNode, true);
			return returnNode;
		}
		let serializedHTML = WHOLE_DOCUMENT ? body.outerHTML : body.innerHTML;
		if (WHOLE_DOCUMENT && ALLOWED_TAGS["!doctype"] && body.ownerDocument && body.ownerDocument.doctype && body.ownerDocument.doctype.name && regExpTest(DOCTYPE_NAME, body.ownerDocument.doctype.name)) serializedHTML = "<!DOCTYPE " + body.ownerDocument.doctype.name + ">\n" + serializedHTML;
		if (SAFE_FOR_TEMPLATES) serializedHTML = _stripTemplateExpressions(serializedHTML);
		return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? _createTrustedHTML(serializedHTML) : serializedHTML;
	};
	DOMPurify.setConfig = function() {
		_parseConfig(arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {});
		SET_CONFIG = true;
		SET_CONFIG_ALLOWED_TAGS = ALLOWED_TAGS;
		SET_CONFIG_ALLOWED_ATTR = ALLOWED_ATTR;
	};
	DOMPurify.clearConfig = function() {
		CONFIG = null;
		SET_CONFIG = false;
		SET_CONFIG_ALLOWED_TAGS = null;
		SET_CONFIG_ALLOWED_ATTR = null;
		trustedTypesPolicy = defaultTrustedTypesPolicy;
		emptyHTML = "";
	};
	DOMPurify.isValidAttribute = function(tag, attr, value) {
		if (!CONFIG) _parseConfig({});
		return _isValidAttribute(transformCaseFunc(tag), transformCaseFunc(attr), value);
	};
	DOMPurify.addHook = function(entryPoint, hookFunction) {
		if (typeof hookFunction !== "function") return;
		if (!objectHasOwnProperty(hooks, entryPoint)) return;
		arrayPush(hooks[entryPoint], hookFunction);
	};
	DOMPurify.removeHook = function(entryPoint, hookFunction) {
		if (!objectHasOwnProperty(hooks, entryPoint)) return;
		if (hookFunction !== void 0) {
			const index = arrayLastIndexOf(hooks[entryPoint], hookFunction);
			return index === -1 ? void 0 : arraySplice(hooks[entryPoint], index, 1)[0];
		}
		return arrayPop(hooks[entryPoint]);
	};
	DOMPurify.removeHooks = function(entryPoint) {
		if (!objectHasOwnProperty(hooks, entryPoint)) return;
		hooks[entryPoint] = [];
	};
	DOMPurify.removeAllHooks = function() {
		hooks = _createHooksMap();
	};
	return DOMPurify;
}
var purify = createDOMPurify();
//#endregion
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/chunk-WYO6CB5R.mjs
var _Class, _Class2, _Class3, _Class4, _Class5, _Class6, _Class7, _Class8, _Class9, _Class10, _Class11, _Class12, _Class13;
var assignWithDepth = /* @__PURE__ */ __name((dst, src, { depth = 2, clobber = false } = {}) => {
	const config2 = {
		depth,
		clobber
	};
	if (Array.isArray(src) && !Array.isArray(dst)) {
		src.forEach((s) => assignWithDepth(dst, s, config2));
		return dst;
	} else if (Array.isArray(src) && Array.isArray(dst)) {
		src.forEach((s) => {
			if (!dst.includes(s)) dst.push(s);
		});
		return dst;
	}
	if (dst === void 0 || depth <= 0) if (dst !== void 0 && dst !== null && typeof dst === "object" && typeof src === "object") return Object.assign(dst, src);
	else return src;
	if (src !== void 0 && typeof dst === "object" && typeof src === "object") Object.keys(src).forEach((key) => {
		if (typeof src[key] === "object" && src[key] !== null && (dst[key] === void 0 || typeof dst[key] === "object")) {
			if (dst[key] === void 0) dst[key] = Array.isArray(src[key]) ? [] : {};
			dst[key] = assignWithDepth(dst[key], src[key], {
				depth: depth - 1,
				clobber
			});
		} else if (clobber || typeof dst[key] !== "object" && typeof src[key] !== "object") dst[key] = src[key];
	});
	return dst;
}, "assignWithDepth");
var assignWithDepth_default = assignWithDepth;
var oldAttributeBackgroundColorOdd = "#ffffff";
var oldAttributeBackgroundColorEven = "#f2f2f2";
var mkBorder = /* @__PURE__ */ __name((col, darkMode) => darkMode ? adjust(col, {
	s: -40,
	l: 10
}) : adjust(col, {
	s: -40,
	l: -10
}), "mkBorder");
var Theme = (_Class = class {
	constructor() {
		this.background = "#f4f4f4";
		this.primaryColor = "#fff4dd";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "#333";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 5;
		this.strokeWidth = 1;
		this.fontFamily = "\"trebuchet ms\", verdana, arial, sans-serif";
		this.fontSize = "16px";
		this.useGradient = true;
		this.dropShadow = "drop-shadow( 1px 2px 2px rgba(185,185,185,1))";
	}
	updateColors() {
		var _this$venn, _this$venn2, _this$venn3, _this$venn4, _this$venn5, _this$venn6, _this$venn7, _this$venn8, _this$vennTitleTextCo, _this$vennSetTextColo, _this$cynefin, _this$cynefin2, _this$cynefin3, _this$cynefin4, _this$cynefin5, _this$cynefin6, _this$cynefin7, _this$cynefin8, _this$cynefin9, _this$cynefin10, _this$cynefin11, _this$cynefin12, _this$cynefin13, _this$cynefin14, _this$cynefin15, _this$radar, _this$radar2, _this$radar3, _this$radar4, _this$radar5, _this$radar6, _this$radar7, _this$radar8, _this$radar9, _this$radar10, _this$wardley, _this$wardley2, _this$wardley3, _this$wardley4, _this$wardley5, _this$wardley6, _this$wardley7, _this$wardley8, _this$wardley9, _this$wardley10, _this$wardley11, _this$wardley12, _this$xyChart, _this$xyChart2, _this$xyChart3, _this$xyChart4, _this$xyChart5, _this$xyChart6, _this$xyChart7, _this$xyChart8, _this$xyChart9, _this$xyChart10, _this$xyChart11, _this$xyChart12;
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#333";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.primaryBorderColor;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		this.rectBkgColor = this.rectBkgColor || this.tertiaryColor;
		this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || this.primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(this.primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.vertLineColor = this.vertLineColor || "navy";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.noteFontWeight = this.noteFontWeight || "normal";
		this.fontWeight = this.fontWeight || "normal";
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		if (this.darkMode) {
			this.rowOdd = this.rowOdd || darken(this.mainBkg, 5) || "#ffffff";
			this.rowEven = this.rowEven || darken(this.mainBkg, 10);
		} else {
			this.rowOdd = this.rowOdd || lighten(this.mainBkg, 75) || "#ffffff";
			this.rowEven = this.rowEven || lighten(this.mainBkg, 5);
		}
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || this.tertiaryColor;
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, {
			h: 210,
			l: 150
		});
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		if (this.darkMode) for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 75);
		else for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 25);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || this.primaryColor;
		this.fillType1 = this.fillType1 || this.secondaryColor;
		this.fillType2 = this.fillType2 || adjust(this.primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(this.primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(this.primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || this.tertiaryColor;
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.venn1 = (_this$venn = this.venn1) !== null && _this$venn !== void 0 ? _this$venn : adjust(this.primaryColor, { l: -30 });
		this.venn2 = (_this$venn2 = this.venn2) !== null && _this$venn2 !== void 0 ? _this$venn2 : adjust(this.secondaryColor, { l: -30 });
		this.venn3 = (_this$venn3 = this.venn3) !== null && _this$venn3 !== void 0 ? _this$venn3 : adjust(this.tertiaryColor, { l: -30 });
		this.venn4 = (_this$venn4 = this.venn4) !== null && _this$venn4 !== void 0 ? _this$venn4 : adjust(this.primaryColor, {
			h: 60,
			l: -30
		});
		this.venn5 = (_this$venn5 = this.venn5) !== null && _this$venn5 !== void 0 ? _this$venn5 : adjust(this.primaryColor, {
			h: -60,
			l: -30
		});
		this.venn6 = (_this$venn6 = this.venn6) !== null && _this$venn6 !== void 0 ? _this$venn6 : adjust(this.secondaryColor, {
			h: 60,
			l: -30
		});
		this.venn7 = (_this$venn7 = this.venn7) !== null && _this$venn7 !== void 0 ? _this$venn7 : adjust(this.primaryColor, {
			h: 120,
			l: -30
		});
		this.venn8 = (_this$venn8 = this.venn8) !== null && _this$venn8 !== void 0 ? _this$venn8 : adjust(this.secondaryColor, {
			h: 120,
			l: -30
		});
		this.vennTitleTextColor = (_this$vennTitleTextCo = this.vennTitleTextColor) !== null && _this$vennTitleTextCo !== void 0 ? _this$vennTitleTextCo : this.titleColor;
		this.vennSetTextColor = (_this$vennSetTextColo = this.vennSetTextColor) !== null && _this$vennSetTextColo !== void 0 ? _this$vennSetTextColo : this.textColor;
		this.cynefin = {
			domainFontSize: ((_this$cynefin = this.cynefin) === null || _this$cynefin === void 0 ? void 0 : _this$cynefin.domainFontSize) || 16,
			itemFontSize: ((_this$cynefin2 = this.cynefin) === null || _this$cynefin2 === void 0 ? void 0 : _this$cynefin2.itemFontSize) || 12,
			boundaryColor: ((_this$cynefin3 = this.cynefin) === null || _this$cynefin3 === void 0 ? void 0 : _this$cynefin3.boundaryColor) || this.lineColor,
			boundaryWidth: ((_this$cynefin4 = this.cynefin) === null || _this$cynefin4 === void 0 ? void 0 : _this$cynefin4.boundaryWidth) || 2,
			cliffColor: ((_this$cynefin5 = this.cynefin) === null || _this$cynefin5 === void 0 ? void 0 : _this$cynefin5.cliffColor) || "#8B0000",
			cliffWidth: ((_this$cynefin6 = this.cynefin) === null || _this$cynefin6 === void 0 ? void 0 : _this$cynefin6.cliffWidth) || 4,
			arrowColor: ((_this$cynefin7 = this.cynefin) === null || _this$cynefin7 === void 0 ? void 0 : _this$cynefin7.arrowColor) || this.lineColor,
			arrowWidth: ((_this$cynefin8 = this.cynefin) === null || _this$cynefin8 === void 0 ? void 0 : _this$cynefin8.arrowWidth) || 2,
			complexBg: ((_this$cynefin9 = this.cynefin) === null || _this$cynefin9 === void 0 ? void 0 : _this$cynefin9.complexBg) || "#E8F5E9",
			complicatedBg: ((_this$cynefin10 = this.cynefin) === null || _this$cynefin10 === void 0 ? void 0 : _this$cynefin10.complicatedBg) || "#E3F2FD",
			chaoticBg: ((_this$cynefin11 = this.cynefin) === null || _this$cynefin11 === void 0 ? void 0 : _this$cynefin11.chaoticBg) || "#FBE9E7",
			clearBg: ((_this$cynefin12 = this.cynefin) === null || _this$cynefin12 === void 0 ? void 0 : _this$cynefin12.clearBg) || "#FFF8E1",
			confusionBg: ((_this$cynefin13 = this.cynefin) === null || _this$cynefin13 === void 0 ? void 0 : _this$cynefin13.confusionBg) || "#F3E5F5",
			textColor: ((_this$cynefin14 = this.cynefin) === null || _this$cynefin14 === void 0 ? void 0 : _this$cynefin14.textColor) || this.textColor,
			labelColor: ((_this$cynefin15 = this.cynefin) === null || _this$cynefin15 === void 0 ? void 0 : _this$cynefin15.labelColor) || this.primaryTextColor
		};
		this.radar = {
			axisColor: ((_this$radar = this.radar) === null || _this$radar === void 0 ? void 0 : _this$radar.axisColor) || this.lineColor,
			axisStrokeWidth: ((_this$radar2 = this.radar) === null || _this$radar2 === void 0 ? void 0 : _this$radar2.axisStrokeWidth) || 2,
			axisLabelFontSize: ((_this$radar3 = this.radar) === null || _this$radar3 === void 0 ? void 0 : _this$radar3.axisLabelFontSize) || 12,
			curveOpacity: ((_this$radar4 = this.radar) === null || _this$radar4 === void 0 ? void 0 : _this$radar4.curveOpacity) || .5,
			curveStrokeWidth: ((_this$radar5 = this.radar) === null || _this$radar5 === void 0 ? void 0 : _this$radar5.curveStrokeWidth) || 2,
			graticuleColor: ((_this$radar6 = this.radar) === null || _this$radar6 === void 0 ? void 0 : _this$radar6.graticuleColor) || "#DEDEDE",
			graticuleStrokeWidth: ((_this$radar7 = this.radar) === null || _this$radar7 === void 0 ? void 0 : _this$radar7.graticuleStrokeWidth) || 1,
			graticuleOpacity: ((_this$radar8 = this.radar) === null || _this$radar8 === void 0 ? void 0 : _this$radar8.graticuleOpacity) || .3,
			legendBoxSize: ((_this$radar9 = this.radar) === null || _this$radar9 === void 0 ? void 0 : _this$radar9.legendBoxSize) || 12,
			legendFontSize: ((_this$radar10 = this.radar) === null || _this$radar10 === void 0 ? void 0 : _this$radar10.legendFontSize) || 12
		};
		this.wardleyEvolutionColor = this.wardleyEvolutionColor || "#dc3545";
		this.wardley = {
			backgroundColor: ((_this$wardley = this.wardley) === null || _this$wardley === void 0 ? void 0 : _this$wardley.backgroundColor) || this.background,
			axisColor: ((_this$wardley2 = this.wardley) === null || _this$wardley2 === void 0 ? void 0 : _this$wardley2.axisColor) || this.lineColor,
			axisTextColor: ((_this$wardley3 = this.wardley) === null || _this$wardley3 === void 0 ? void 0 : _this$wardley3.axisTextColor) || this.primaryTextColor,
			gridColor: ((_this$wardley4 = this.wardley) === null || _this$wardley4 === void 0 ? void 0 : _this$wardley4.gridColor) || this.gridColor,
			componentFill: ((_this$wardley5 = this.wardley) === null || _this$wardley5 === void 0 ? void 0 : _this$wardley5.componentFill) || this.background,
			componentStroke: ((_this$wardley6 = this.wardley) === null || _this$wardley6 === void 0 ? void 0 : _this$wardley6.componentStroke) || this.lineColor,
			componentLabelColor: ((_this$wardley7 = this.wardley) === null || _this$wardley7 === void 0 ? void 0 : _this$wardley7.componentLabelColor) || this.primaryTextColor,
			linkStroke: ((_this$wardley8 = this.wardley) === null || _this$wardley8 === void 0 ? void 0 : _this$wardley8.linkStroke) || this.lineColor,
			evolutionStroke: ((_this$wardley9 = this.wardley) === null || _this$wardley9 === void 0 ? void 0 : _this$wardley9.evolutionStroke) || this.wardleyEvolutionColor,
			annotationStroke: ((_this$wardley10 = this.wardley) === null || _this$wardley10 === void 0 ? void 0 : _this$wardley10.annotationStroke) || this.lineColor,
			annotationTextColor: ((_this$wardley11 = this.wardley) === null || _this$wardley11 === void 0 ? void 0 : _this$wardley11.annotationTextColor) || this.primaryTextColor,
			annotationFill: ((_this$wardley12 = this.wardley) === null || _this$wardley12 === void 0 ? void 0 : _this$wardley12.annotationFill) || this.background
		};
		this.archEdgeColor = this.archEdgeColor || "#777";
		this.archEdgeArrowColor = this.archEdgeArrowColor || "#777";
		this.archEdgeWidth = this.archEdgeWidth || "3";
		this.archGroupBorderColor = this.archGroupBorderColor || "#000";
		this.archGroupBorderWidth = this.archGroupBorderWidth || "2px";
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: ((_this$xyChart = this.xyChart) === null || _this$xyChart === void 0 ? void 0 : _this$xyChart.backgroundColor) || this.background,
			titleColor: ((_this$xyChart2 = this.xyChart) === null || _this$xyChart2 === void 0 ? void 0 : _this$xyChart2.titleColor) || this.primaryTextColor,
			dataLabelColor: ((_this$xyChart3 = this.xyChart) === null || _this$xyChart3 === void 0 ? void 0 : _this$xyChart3.dataLabelColor) || this.primaryTextColor,
			xAxisTitleColor: ((_this$xyChart4 = this.xyChart) === null || _this$xyChart4 === void 0 ? void 0 : _this$xyChart4.xAxisTitleColor) || this.primaryTextColor,
			xAxisLabelColor: ((_this$xyChart5 = this.xyChart) === null || _this$xyChart5 === void 0 ? void 0 : _this$xyChart5.xAxisLabelColor) || this.primaryTextColor,
			xAxisTickColor: ((_this$xyChart6 = this.xyChart) === null || _this$xyChart6 === void 0 ? void 0 : _this$xyChart6.xAxisTickColor) || this.primaryTextColor,
			xAxisLineColor: ((_this$xyChart7 = this.xyChart) === null || _this$xyChart7 === void 0 ? void 0 : _this$xyChart7.xAxisLineColor) || this.primaryTextColor,
			yAxisTitleColor: ((_this$xyChart8 = this.xyChart) === null || _this$xyChart8 === void 0 ? void 0 : _this$xyChart8.yAxisTitleColor) || this.primaryTextColor,
			yAxisLabelColor: ((_this$xyChart9 = this.xyChart) === null || _this$xyChart9 === void 0 ? void 0 : _this$xyChart9.yAxisLabelColor) || this.primaryTextColor,
			yAxisTickColor: ((_this$xyChart10 = this.xyChart) === null || _this$xyChart10 === void 0 ? void 0 : _this$xyChart10.yAxisTickColor) || this.primaryTextColor,
			yAxisLineColor: ((_this$xyChart11 = this.xyChart) === null || _this$xyChart11 === void 0 ? void 0 : _this$xyChart11.yAxisLineColor) || this.primaryTextColor,
			plotColorPalette: ((_this$xyChart12 = this.xyChart) === null || _this$xyChart12 === void 0 ? void 0 : _this$xyChart12.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || this.primaryColor;
		this.git1 = this.git1 || this.secondaryColor;
		this.git2 = this.git2 || this.tertiaryColor;
		this.git3 = this.git3 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(this.primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.emUiFill = this.emUiFill || "white";
		this.emUiStroke = this.emUiStroke || "#dbdada";
		this.emProcessorFill = this.emProcessorFill || "#edb3f6";
		this.emProcessorStroke = this.emProcessorStroke || "#b88cbf";
		this.emReadModelFill = this.emReadModelFill || "#d3f1a2";
		this.emReadModelStroke = this.emReadModelStroke || "#a3b732";
		this.emCommandFill = this.emCommandFill || "#bcd6fe";
		this.emCommandStroke = this.emCommandStroke || "#679ac3";
		this.emEventFill = this.emEventFill || "#ffb778";
		this.emEventStroke = this.emEventStroke || "#c19a0f";
		this.emSwimlaneBackgroundOdd = this.emSwimlaneBackgroundOdd || "rgb(250,250,250)";
		this.emSwimlaneBackgroundStroke = this.emSwimlaneBackgroundStroke || "rgb(240,240,240)";
		this.emArrowhead = this.emArrowhead || this.lineColor;
		this.emRelationStroke = this.emRelationStroke || this.lineColor;
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
		this.gradientStart = this.primaryBorderColor;
		this.gradientStop = this.secondaryBorderColor;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
}, __name(_Class, "Theme"), _Class);
var getThemeVariables = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme2 = (_Class2 = class {
	constructor() {
		this.background = "#333";
		this.primaryColor = "#1f2020";
		this.secondaryColor = lighten(this.primaryColor, 16);
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = invert(this.background);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.lineColor = invert(this.background);
		this.textColor = invert(this.background);
		this.mainBkg = "#1f2020";
		this.secondBkg = "calculated";
		this.mainContrastColor = "lightgrey";
		this.darkTextColor = lighten(invert("#323D47"), 10);
		this.lineColor = "calculated";
		this.border1 = "#ccc";
		this.border2 = rgba(255, 255, 255, .25);
		this.arrowheadColor = "calculated";
		this.fontFamily = "\"trebuchet ms\", verdana, arial, sans-serif";
		this.fontSize = "16px";
		this.labelBackground = "#181818";
		this.textColor = "#ccc";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 5;
		this.strokeWidth = 1;
		this.nodeBkg = "calculated";
		this.nodeBorder = "calculated";
		this.clusterBkg = "calculated";
		this.clusterBorder = "calculated";
		this.defaultLinkColor = "calculated";
		this.titleColor = "#F9FFFE";
		this.edgeLabelBackground = "calculated";
		this.actorBorder = "calculated";
		this.actorBkg = "calculated";
		this.actorTextColor = "calculated";
		this.actorLineColor = "calculated";
		this.signalColor = "calculated";
		this.signalTextColor = "calculated";
		this.labelBoxBkgColor = "calculated";
		this.labelBoxBorderColor = "calculated";
		this.labelTextColor = "calculated";
		this.loopTextColor = "calculated";
		this.noteBorderColor = "calculated";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "calculated";
		this.activationBorderColor = "calculated";
		this.activationBkgColor = "calculated";
		this.sequenceNumberColor = "black";
		this.clusterBkg = "#302F3D";
		this.sectionBkgColor = darken("#EAE8D9", 30);
		this.altSectionBkgColor = "calculated";
		this.sectionBkgColor2 = "#EAE8D9";
		this.excludeBkgColor = darken(this.sectionBkgColor, 10);
		this.taskBorderColor = rgba(255, 255, 255, 70);
		this.taskBkgColor = "calculated";
		this.taskTextColor = "calculated";
		this.taskTextLightColor = "calculated";
		this.taskTextOutsideColor = "calculated";
		this.taskTextClickableColor = "#003163";
		this.activeTaskBorderColor = rgba(255, 255, 255, 50);
		this.activeTaskBkgColor = "#81B1DB";
		this.gridColor = "calculated";
		this.doneTaskBkgColor = "calculated";
		this.doneTaskBorderColor = "grey";
		this.critBorderColor = "#E83737";
		this.critBkgColor = "#E83737";
		this.taskTextDarkColor = "calculated";
		this.todayLineColor = "#DB5757";
		this.vertLineColor = "#00BFFF";
		this.personBorder = this.primaryBorderColor;
		this.personBkg = this.mainBkg;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.rowOdd = this.rowOdd || lighten(this.mainBkg, 5) || "#ffffff";
		this.rowEven = this.rowEven || darken(this.mainBkg, 10);
		this.labelColor = "calculated";
		this.errorBkgColor = "#a44141";
		this.errorTextColor = "#ddd";
		this.useGradient = true;
		this.gradientStart = this.primaryBorderColor;
		this.gradientStop = this.secondaryBorderColor;
		this.dropShadow = "drop-shadow( 1px 2px 2px rgba(185,185,185,1))";
		this.noteFontWeight = this.noteFontWeight || "normal";
		this.fontWeight = this.fontWeight || "normal";
	}
	updateColors() {
		var _this$vennTitleTextCo2, _this$vennSetTextColo2, _this$cynefin16, _this$cynefin17, _this$cynefin18, _this$cynefin19, _this$cynefin20, _this$cynefin21, _this$cynefin22, _this$cynefin23, _this$cynefin24, _this$cynefin25, _this$cynefin26, _this$cynefin27, _this$cynefin28, _this$cynefin29, _this$cynefin30, _this$xyChart13, _this$xyChart14, _this$xyChart15, _this$xyChart16, _this$xyChart17, _this$xyChart18, _this$xyChart19, _this$xyChart20, _this$xyChart21, _this$xyChart22, _this$xyChart23, _this$xyChart24, _this$radar11, _this$radar12, _this$radar13, _this$radar14, _this$radar15, _this$radar16, _this$radar17, _this$radar18, _this$radar19, _this$radar20, _this$wardley13, _this$wardley14, _this$wardley15, _this$wardley16, _this$wardley17, _this$wardley18, _this$wardley19, _this$wardley20, _this$wardley21, _this$wardley22, _this$wardley23, _this$wardley24;
		this.secondBkg = lighten(this.mainBkg, 16);
		this.lineColor = this.mainContrastColor;
		this.arrowheadColor = this.mainContrastColor;
		this.nodeBkg = this.mainBkg;
		this.nodeBorder = this.border1;
		this.clusterBkg = this.secondBkg;
		this.clusterBorder = this.border2;
		this.defaultLinkColor = this.lineColor;
		this.edgeLabelBackground = lighten(this.labelBackground, 25);
		this.actorBorder = this.border1;
		this.actorBkg = this.mainBkg;
		this.actorTextColor = this.mainContrastColor;
		this.actorLineColor = this.actorBorder;
		this.signalColor = this.mainContrastColor;
		this.signalTextColor = this.mainContrastColor;
		this.labelBoxBkgColor = this.actorBkg;
		this.labelBoxBorderColor = this.actorBorder;
		this.labelTextColor = this.mainContrastColor;
		this.loopTextColor = this.mainContrastColor;
		this.noteBorderColor = this.secondaryBorderColor;
		this.noteBkgColor = this.secondBkg;
		this.noteTextColor = this.secondaryTextColor;
		this.activationBorderColor = this.border1;
		this.activationBkgColor = this.secondBkg;
		this.rectBkgColor = this.rectBkgColor || this.tertiaryColor;
		this.altSectionBkgColor = this.background;
		this.taskBkgColor = lighten(this.mainBkg, 23);
		this.taskTextColor = this.darkTextColor;
		this.taskTextLightColor = this.mainContrastColor;
		this.taskTextOutsideColor = this.taskTextLightColor;
		this.gridColor = this.mainContrastColor;
		this.doneTaskBkgColor = this.mainContrastColor;
		this.taskTextDarkColor = invert(this.doneTaskBkgColor);
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#555";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.primaryBorderColor;
		this.specialStateColor = "#f4f4f4";
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.fillType0 = this.primaryColor;
		this.fillType1 = this.secondaryColor;
		this.fillType2 = adjust(this.primaryColor, { h: 64 });
		this.fillType3 = adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = adjust(this.primaryColor, { h: -64 });
		this.fillType5 = adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = adjust(this.primaryColor, { h: 128 });
		this.fillType7 = adjust(this.secondaryColor, { h: 128 });
		this.cScale1 = this.cScale1 || "#0b0000";
		this.cScale2 = this.cScale2 || "#4d1037";
		this.cScale3 = this.cScale3 || "#3f5258";
		this.cScale4 = this.cScale4 || "#4f2f1b";
		this.cScale5 = this.cScale5 || "#6e0a0a";
		this.cScale6 = this.cScale6 || "#3b0048";
		this.cScale7 = this.cScale7 || "#995a01";
		this.cScale8 = this.cScale8 || "#154706";
		this.cScale9 = this.cScale9 || "#161722";
		this.cScale10 = this.cScale10 || "#00296f";
		this.cScale11 = this.cScale11 || "#01629c";
		this.cScale12 = this.cScale12 || "#010029";
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, { h: 210 });
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 30,
				s: -30,
				l: -(-10 + i * 4)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 30,
				s: -30,
				l: -(-7 + i * 4)
			});
		}
		this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["pie" + i] = this["cScale" + i];
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.mainContrastColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.mainContrastColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		for (let i = 0; i < 8; i++) {
			var _this;
			this["venn" + (i + 1)] = (_this = this["venn" + (i + 1)]) !== null && _this !== void 0 ? _this : lighten(this["cScale" + i], 30);
		}
		this.vennTitleTextColor = (_this$vennTitleTextCo2 = this.vennTitleTextColor) !== null && _this$vennTitleTextCo2 !== void 0 ? _this$vennTitleTextCo2 : this.titleColor;
		this.vennSetTextColor = (_this$vennSetTextColo2 = this.vennSetTextColor) !== null && _this$vennSetTextColo2 !== void 0 ? _this$vennSetTextColo2 : this.textColor;
		this.cynefin = {
			domainFontSize: ((_this$cynefin16 = this.cynefin) === null || _this$cynefin16 === void 0 ? void 0 : _this$cynefin16.domainFontSize) || 16,
			itemFontSize: ((_this$cynefin17 = this.cynefin) === null || _this$cynefin17 === void 0 ? void 0 : _this$cynefin17.itemFontSize) || 12,
			boundaryColor: ((_this$cynefin18 = this.cynefin) === null || _this$cynefin18 === void 0 ? void 0 : _this$cynefin18.boundaryColor) || this.lineColor,
			boundaryWidth: ((_this$cynefin19 = this.cynefin) === null || _this$cynefin19 === void 0 ? void 0 : _this$cynefin19.boundaryWidth) || 2,
			cliffColor: ((_this$cynefin20 = this.cynefin) === null || _this$cynefin20 === void 0 ? void 0 : _this$cynefin20.cliffColor) || "#FF6B6B",
			cliffWidth: ((_this$cynefin21 = this.cynefin) === null || _this$cynefin21 === void 0 ? void 0 : _this$cynefin21.cliffWidth) || 4,
			arrowColor: ((_this$cynefin22 = this.cynefin) === null || _this$cynefin22 === void 0 ? void 0 : _this$cynefin22.arrowColor) || this.lineColor,
			arrowWidth: ((_this$cynefin23 = this.cynefin) === null || _this$cynefin23 === void 0 ? void 0 : _this$cynefin23.arrowWidth) || 2,
			complexBg: ((_this$cynefin24 = this.cynefin) === null || _this$cynefin24 === void 0 ? void 0 : _this$cynefin24.complexBg) || "#1B5E20",
			complicatedBg: ((_this$cynefin25 = this.cynefin) === null || _this$cynefin25 === void 0 ? void 0 : _this$cynefin25.complicatedBg) || "#0D47A1",
			chaoticBg: ((_this$cynefin26 = this.cynefin) === null || _this$cynefin26 === void 0 ? void 0 : _this$cynefin26.chaoticBg) || "#BF360C",
			clearBg: ((_this$cynefin27 = this.cynefin) === null || _this$cynefin27 === void 0 ? void 0 : _this$cynefin27.clearBg) || "#F57F17",
			confusionBg: ((_this$cynefin28 = this.cynefin) === null || _this$cynefin28 === void 0 ? void 0 : _this$cynefin28.confusionBg) || "#4A148C",
			textColor: ((_this$cynefin29 = this.cynefin) === null || _this$cynefin29 === void 0 ? void 0 : _this$cynefin29.textColor) || this.textColor,
			labelColor: ((_this$cynefin30 = this.cynefin) === null || _this$cynefin30 === void 0 ? void 0 : _this$cynefin30.labelColor) || this.primaryTextColor
		};
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: ((_this$xyChart13 = this.xyChart) === null || _this$xyChart13 === void 0 ? void 0 : _this$xyChart13.backgroundColor) || this.background,
			titleColor: ((_this$xyChart14 = this.xyChart) === null || _this$xyChart14 === void 0 ? void 0 : _this$xyChart14.titleColor) || this.primaryTextColor,
			dataLabelColor: ((_this$xyChart15 = this.xyChart) === null || _this$xyChart15 === void 0 ? void 0 : _this$xyChart15.dataLabelColor) || this.primaryTextColor,
			xAxisTitleColor: ((_this$xyChart16 = this.xyChart) === null || _this$xyChart16 === void 0 ? void 0 : _this$xyChart16.xAxisTitleColor) || this.primaryTextColor,
			xAxisLabelColor: ((_this$xyChart17 = this.xyChart) === null || _this$xyChart17 === void 0 ? void 0 : _this$xyChart17.xAxisLabelColor) || this.primaryTextColor,
			xAxisTickColor: ((_this$xyChart18 = this.xyChart) === null || _this$xyChart18 === void 0 ? void 0 : _this$xyChart18.xAxisTickColor) || this.primaryTextColor,
			xAxisLineColor: ((_this$xyChart19 = this.xyChart) === null || _this$xyChart19 === void 0 ? void 0 : _this$xyChart19.xAxisLineColor) || this.primaryTextColor,
			yAxisTitleColor: ((_this$xyChart20 = this.xyChart) === null || _this$xyChart20 === void 0 ? void 0 : _this$xyChart20.yAxisTitleColor) || this.primaryTextColor,
			yAxisLabelColor: ((_this$xyChart21 = this.xyChart) === null || _this$xyChart21 === void 0 ? void 0 : _this$xyChart21.yAxisLabelColor) || this.primaryTextColor,
			yAxisTickColor: ((_this$xyChart22 = this.xyChart) === null || _this$xyChart22 === void 0 ? void 0 : _this$xyChart22.yAxisTickColor) || this.primaryTextColor,
			yAxisLineColor: ((_this$xyChart23 = this.xyChart) === null || _this$xyChart23 === void 0 ? void 0 : _this$xyChart23.yAxisLineColor) || this.primaryTextColor,
			plotColorPalette: ((_this$xyChart24 = this.xyChart) === null || _this$xyChart24 === void 0 ? void 0 : _this$xyChart24.plotColorPalette) || "#3498db,#2ecc71,#e74c3c,#f1c40f,#bdc3c7,#ffffff,#34495e,#9b59b6,#1abc9c,#e67e22"
		};
		this.packet = {
			startByteColor: this.primaryTextColor,
			endByteColor: this.primaryTextColor,
			labelColor: this.primaryTextColor,
			titleColor: this.primaryTextColor,
			blockStrokeColor: this.primaryTextColor,
			blockFillColor: this.background
		};
		this.radar = {
			axisColor: ((_this$radar11 = this.radar) === null || _this$radar11 === void 0 ? void 0 : _this$radar11.axisColor) || this.lineColor,
			axisStrokeWidth: ((_this$radar12 = this.radar) === null || _this$radar12 === void 0 ? void 0 : _this$radar12.axisStrokeWidth) || 2,
			axisLabelFontSize: ((_this$radar13 = this.radar) === null || _this$radar13 === void 0 ? void 0 : _this$radar13.axisLabelFontSize) || 12,
			curveOpacity: ((_this$radar14 = this.radar) === null || _this$radar14 === void 0 ? void 0 : _this$radar14.curveOpacity) || .5,
			curveStrokeWidth: ((_this$radar15 = this.radar) === null || _this$radar15 === void 0 ? void 0 : _this$radar15.curveStrokeWidth) || 2,
			graticuleColor: ((_this$radar16 = this.radar) === null || _this$radar16 === void 0 ? void 0 : _this$radar16.graticuleColor) || "#DEDEDE",
			graticuleStrokeWidth: ((_this$radar17 = this.radar) === null || _this$radar17 === void 0 ? void 0 : _this$radar17.graticuleStrokeWidth) || 1,
			graticuleOpacity: ((_this$radar18 = this.radar) === null || _this$radar18 === void 0 ? void 0 : _this$radar18.graticuleOpacity) || .3,
			legendBoxSize: ((_this$radar19 = this.radar) === null || _this$radar19 === void 0 ? void 0 : _this$radar19.legendBoxSize) || 12,
			legendFontSize: ((_this$radar20 = this.radar) === null || _this$radar20 === void 0 ? void 0 : _this$radar20.legendFontSize) || 12
		};
		this.wardleyEvolutionColor = this.wardleyEvolutionColor || "#ff6b6b";
		this.wardley = {
			backgroundColor: ((_this$wardley13 = this.wardley) === null || _this$wardley13 === void 0 ? void 0 : _this$wardley13.backgroundColor) || this.background,
			axisColor: ((_this$wardley14 = this.wardley) === null || _this$wardley14 === void 0 ? void 0 : _this$wardley14.axisColor) || this.lineColor,
			axisTextColor: ((_this$wardley15 = this.wardley) === null || _this$wardley15 === void 0 ? void 0 : _this$wardley15.axisTextColor) || this.primaryTextColor,
			gridColor: ((_this$wardley16 = this.wardley) === null || _this$wardley16 === void 0 ? void 0 : _this$wardley16.gridColor) || this.gridColor,
			componentFill: ((_this$wardley17 = this.wardley) === null || _this$wardley17 === void 0 ? void 0 : _this$wardley17.componentFill) || this.mainBkg,
			componentStroke: ((_this$wardley18 = this.wardley) === null || _this$wardley18 === void 0 ? void 0 : _this$wardley18.componentStroke) || this.lineColor,
			componentLabelColor: ((_this$wardley19 = this.wardley) === null || _this$wardley19 === void 0 ? void 0 : _this$wardley19.componentLabelColor) || this.primaryTextColor,
			linkStroke: ((_this$wardley20 = this.wardley) === null || _this$wardley20 === void 0 ? void 0 : _this$wardley20.linkStroke) || this.lineColor,
			evolutionStroke: ((_this$wardley21 = this.wardley) === null || _this$wardley21 === void 0 ? void 0 : _this$wardley21.evolutionStroke) || this.wardleyEvolutionColor,
			annotationStroke: ((_this$wardley22 = this.wardley) === null || _this$wardley22 === void 0 ? void 0 : _this$wardley22.annotationStroke) || this.lineColor,
			annotationTextColor: ((_this$wardley23 = this.wardley) === null || _this$wardley23 === void 0 ? void 0 : _this$wardley23.annotationTextColor) || this.primaryTextColor,
			annotationFill: ((_this$wardley24 = this.wardley) === null || _this$wardley24 === void 0 ? void 0 : _this$wardley24.annotationFill) || this.mainBkg
		};
		this.classText = this.primaryTextColor;
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = lighten(this.secondaryColor, 20);
		this.git1 = lighten(this.pie2 || this.secondaryColor, 20);
		this.git2 = lighten(this.pie3 || this.tertiaryColor, 20);
		this.git3 = lighten(this.pie4 || adjust(this.primaryColor, { h: -30 }), 20);
		this.git4 = lighten(this.pie5 || adjust(this.primaryColor, { h: -60 }), 20);
		this.git5 = lighten(this.pie6 || adjust(this.primaryColor, { h: -90 }), 10);
		this.git6 = lighten(this.pie7 || adjust(this.primaryColor, { h: 60 }), 10);
		this.git7 = lighten(this.pie8 || adjust(this.primaryColor, { h: 120 }), 20);
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.gitBranchLabel0 = this.gitBranchLabel0 || invert(this.labelTextColor);
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || invert(this.labelTextColor);
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.emUiFill = this.emUiFill || "#2d2d2d";
		this.emUiStroke = this.emUiStroke || "#555";
		this.emProcessorFill = this.emProcessorFill || lighten("#5a3d5c", 10);
		this.emProcessorStroke = this.emProcessorStroke || "#8a6d8c";
		this.emReadModelFill = this.emReadModelFill || lighten("#3d5a2d", 10);
		this.emReadModelStroke = this.emReadModelStroke || "#6d8c5c";
		this.emCommandFill = this.emCommandFill || lighten("#2d3d5a", 10);
		this.emCommandStroke = this.emCommandStroke || "#5c6d8c";
		this.emEventFill = this.emEventFill || lighten("#5a452d", 10);
		this.emEventStroke = this.emEventStroke || "#8c755c";
		this.emSwimlaneBackgroundOdd = this.emSwimlaneBackgroundOdd || lighten(this.background, 5);
		this.emSwimlaneBackgroundStroke = this.emSwimlaneBackgroundStroke || lighten(this.background, 12);
		this.emArrowhead = this.emArrowhead || this.lineColor;
		this.emRelationStroke = this.emRelationStroke || this.lineColor;
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || lighten(this.background, 12);
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || lighten(this.background, 2);
		this.nodeBorder = this.nodeBorder || "#999";
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
}, __name(_Class2, "Theme"), _Class2);
var getThemeVariables2 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme2();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme3 = (_Class3 = class {
	constructor() {
		this.background = "#f4f4f4";
		this.primaryColor = "#ECECFF";
		this.secondaryColor = adjust(this.primaryColor, { h: 120 });
		this.secondaryColor = "#ffffde";
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.lineColor = invert(this.background);
		this.textColor = invert(this.background);
		this.background = "white";
		this.mainBkg = "#ECECFF";
		this.secondBkg = "#ffffde";
		this.lineColor = "#333333";
		this.border1 = "#9370DB";
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.border2 = "#aaaa33";
		this.arrowheadColor = "#333333";
		this.fontFamily = "\"trebuchet ms\", verdana, arial, sans-serif";
		this.fontSize = "16px";
		this.labelBackground = "rgba(232,232,232, 0.8)";
		this.textColor = "#333";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 5;
		this.strokeWidth = 1;
		this.nodeBkg = "calculated";
		this.nodeBorder = "calculated";
		this.clusterBkg = "calculated";
		this.clusterBorder = "calculated";
		this.defaultLinkColor = "calculated";
		this.titleColor = "calculated";
		this.edgeLabelBackground = "calculated";
		this.actorBorder = "calculated";
		this.actorBkg = "calculated";
		this.actorTextColor = "black";
		this.actorLineColor = "calculated";
		this.signalColor = "calculated";
		this.signalTextColor = "calculated";
		this.labelBoxBkgColor = "calculated";
		this.labelBoxBorderColor = "calculated";
		this.labelTextColor = "calculated";
		this.loopTextColor = "calculated";
		this.noteBorderColor = "calculated";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "calculated";
		this.activationBorderColor = "#666";
		this.activationBkgColor = "#f4f4f4";
		this.sequenceNumberColor = "white";
		this.clusterBkg = "#FBFBFF";
		this.sectionBkgColor = "calculated";
		this.altSectionBkgColor = "calculated";
		this.sectionBkgColor2 = "calculated";
		this.excludeBkgColor = "#eeeeee";
		this.taskBorderColor = "calculated";
		this.taskBkgColor = "calculated";
		this.taskTextLightColor = "calculated";
		this.taskTextColor = this.taskTextLightColor;
		this.taskTextDarkColor = "calculated";
		this.taskTextOutsideColor = this.taskTextDarkColor;
		this.taskTextClickableColor = "calculated";
		this.activeTaskBorderColor = "calculated";
		this.activeTaskBkgColor = "calculated";
		this.gridColor = "calculated";
		this.doneTaskBkgColor = "calculated";
		this.doneTaskBorderColor = "calculated";
		this.critBorderColor = "calculated";
		this.critBkgColor = "calculated";
		this.todayLineColor = "calculated";
		this.vertLineColor = "calculated";
		this.sectionBkgColor = rgba(102, 102, 255, .49);
		this.altSectionBkgColor = "white";
		this.sectionBkgColor2 = "#fff400";
		this.taskBorderColor = "#534fbc";
		this.taskBkgColor = "#8a90dd";
		this.taskTextLightColor = "white";
		this.taskTextColor = "calculated";
		this.taskTextDarkColor = "black";
		this.taskTextOutsideColor = "calculated";
		this.taskTextClickableColor = "#003163";
		this.activeTaskBorderColor = "#534fbc";
		this.activeTaskBkgColor = "#bfc7ff";
		this.gridColor = "lightgrey";
		this.doneTaskBkgColor = "lightgrey";
		this.doneTaskBorderColor = "grey";
		this.critBorderColor = "#ff8888";
		this.critBkgColor = "red";
		this.todayLineColor = "red";
		this.vertLineColor = "navy";
		this.noteFontWeight = this.noteFontWeight || "normal";
		this.fontWeight = this.fontWeight || "normal";
		this.personBorder = this.primaryBorderColor;
		this.personBkg = this.mainBkg;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.rowOdd = "calculated";
		this.rowEven = "calculated";
		this.labelColor = "black";
		this.errorBkgColor = "#552222";
		this.errorTextColor = "#552222";
		this.useGradient = false;
		this.gradientStart = this.primaryBorderColor;
		this.gradientStop = this.secondaryBorderColor;
		this.dropShadow = "drop-shadow(1px 2px 2px rgba(185, 185, 185, 1))";
		this.updateColors();
	}
	updateColors() {
		var _this$venn9, _this$venn10, _this$venn11, _this$venn12, _this$venn13, _this$venn14, _this$venn15, _this$venn16, _this$vennTitleTextCo3, _this$vennSetTextColo3, _this$cynefin31, _this$cynefin32, _this$cynefin33, _this$cynefin34, _this$cynefin35, _this$cynefin36, _this$cynefin37, _this$cynefin38, _this$cynefin39, _this$cynefin40, _this$cynefin41, _this$cynefin42, _this$cynefin43, _this$cynefin44, _this$cynefin45, _this$radar21, _this$radar22, _this$radar23, _this$radar24, _this$radar25, _this$radar26, _this$radar27, _this$radar28, _this$radar29, _this$radar30, _this$wardley25, _this$wardley26, _this$wardley27, _this$wardley28, _this$wardley29, _this$wardley30, _this$wardley31, _this$wardley32, _this$wardley33, _this$wardley34, _this$wardley35, _this$wardley36, _this$xyChart25, _this$xyChart26, _this$xyChart27, _this$xyChart28, _this$xyChart29, _this$xyChart30, _this$xyChart31, _this$xyChart32, _this$xyChart33, _this$xyChart34, _this$xyChart35, _this$xyChart36;
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, { h: 210 });
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		this["cScalePeer1"] = this["cScalePeer1"] || darken(this.secondaryColor, 45);
		this["cScalePeer2"] = this["cScalePeer2"] || darken(this.tertiaryColor, 40);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) {
			this["cScale" + i] = darken(this["cScale" + i], 10);
			this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 25);
		}
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || adjust(this["cScale" + i], { h: 180 });
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 30,
				l: -(5 + i * 5)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 30,
				l: -(7 + i * 5)
			});
		}
		this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor;
		if (this.labelTextColor !== "calculated") {
			this.cScaleLabel0 = this.cScaleLabel0 || invert(this.labelTextColor);
			this.cScaleLabel3 = this.cScaleLabel3 || invert(this.labelTextColor);
			for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.labelTextColor;
		}
		this.nodeBkg = this.mainBkg;
		this.nodeBorder = this.border1;
		this.clusterBkg = this.secondBkg;
		this.clusterBorder = this.border2;
		this.defaultLinkColor = this.lineColor;
		this.titleColor = this.textColor;
		this.edgeLabelBackground = this.labelBackground;
		this.actorBorder = this.border1;
		this.actorBkg = this.mainBkg;
		this.labelBoxBkgColor = this.actorBkg;
		this.signalColor = this.textColor;
		this.signalTextColor = this.textColor;
		this.labelBoxBorderColor = this.actorBorder;
		this.labelTextColor = this.actorTextColor;
		this.loopTextColor = this.actorTextColor;
		this.noteBorderColor = this.border2;
		this.noteTextColor = this.actorTextColor;
		this.actorLineColor = this.actorBorder;
		this.rectBkgColor = this.rectBkgColor || this.tertiaryColor;
		this.taskTextColor = this.taskTextLightColor;
		this.taskTextOutsideColor = this.taskTextDarkColor;
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.rowOdd = this.rowOdd || lighten(this.primaryColor, 75) || "#ffffff";
		this.rowEven = this.rowEven || lighten(this.primaryColor, 1);
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.specialStateColor = this.lineColor;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.classText = this.primaryTextColor;
		this.fillType0 = this.primaryColor;
		this.fillType1 = this.secondaryColor;
		this.fillType2 = adjust(this.primaryColor, { h: 64 });
		this.fillType3 = adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = adjust(this.primaryColor, { h: -64 });
		this.fillType5 = adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = adjust(this.primaryColor, { h: 128 });
		this.fillType7 = adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || adjust(this.tertiaryColor, { l: -40 });
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -30 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, { l: -20 });
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -20
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -40
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: -40
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -40
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -90,
			l: -40
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -30
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.venn1 = (_this$venn9 = this.venn1) !== null && _this$venn9 !== void 0 ? _this$venn9 : adjust(this.primaryColor, { l: -30 });
		this.venn2 = (_this$venn10 = this.venn2) !== null && _this$venn10 !== void 0 ? _this$venn10 : adjust(this.secondaryColor, { l: -30 });
		this.venn3 = (_this$venn11 = this.venn3) !== null && _this$venn11 !== void 0 ? _this$venn11 : adjust(this.tertiaryColor, { l: -40 });
		this.venn4 = (_this$venn12 = this.venn4) !== null && _this$venn12 !== void 0 ? _this$venn12 : adjust(this.primaryColor, {
			h: 60,
			l: -30
		});
		this.venn5 = (_this$venn13 = this.venn5) !== null && _this$venn13 !== void 0 ? _this$venn13 : adjust(this.primaryColor, {
			h: -60,
			l: -30
		});
		this.venn6 = (_this$venn14 = this.venn6) !== null && _this$venn14 !== void 0 ? _this$venn14 : adjust(this.secondaryColor, {
			h: 60,
			l: -30
		});
		this.venn7 = (_this$venn15 = this.venn7) !== null && _this$venn15 !== void 0 ? _this$venn15 : adjust(this.primaryColor, {
			h: 120,
			l: -30
		});
		this.venn8 = (_this$venn16 = this.venn8) !== null && _this$venn16 !== void 0 ? _this$venn16 : adjust(this.secondaryColor, {
			h: 120,
			l: -30
		});
		this.vennTitleTextColor = (_this$vennTitleTextCo3 = this.vennTitleTextColor) !== null && _this$vennTitleTextCo3 !== void 0 ? _this$vennTitleTextCo3 : this.titleColor;
		this.vennSetTextColor = (_this$vennSetTextColo3 = this.vennSetTextColor) !== null && _this$vennSetTextColo3 !== void 0 ? _this$vennSetTextColo3 : this.textColor;
		this.cynefin = {
			domainFontSize: ((_this$cynefin31 = this.cynefin) === null || _this$cynefin31 === void 0 ? void 0 : _this$cynefin31.domainFontSize) || 16,
			itemFontSize: ((_this$cynefin32 = this.cynefin) === null || _this$cynefin32 === void 0 ? void 0 : _this$cynefin32.itemFontSize) || 12,
			boundaryColor: ((_this$cynefin33 = this.cynefin) === null || _this$cynefin33 === void 0 ? void 0 : _this$cynefin33.boundaryColor) || this.lineColor,
			boundaryWidth: ((_this$cynefin34 = this.cynefin) === null || _this$cynefin34 === void 0 ? void 0 : _this$cynefin34.boundaryWidth) || 2,
			cliffColor: ((_this$cynefin35 = this.cynefin) === null || _this$cynefin35 === void 0 ? void 0 : _this$cynefin35.cliffColor) || "#8B0000",
			cliffWidth: ((_this$cynefin36 = this.cynefin) === null || _this$cynefin36 === void 0 ? void 0 : _this$cynefin36.cliffWidth) || 4,
			arrowColor: ((_this$cynefin37 = this.cynefin) === null || _this$cynefin37 === void 0 ? void 0 : _this$cynefin37.arrowColor) || this.lineColor,
			arrowWidth: ((_this$cynefin38 = this.cynefin) === null || _this$cynefin38 === void 0 ? void 0 : _this$cynefin38.arrowWidth) || 2,
			complexBg: ((_this$cynefin39 = this.cynefin) === null || _this$cynefin39 === void 0 ? void 0 : _this$cynefin39.complexBg) || "#E8F5E9",
			complicatedBg: ((_this$cynefin40 = this.cynefin) === null || _this$cynefin40 === void 0 ? void 0 : _this$cynefin40.complicatedBg) || "#E3F2FD",
			chaoticBg: ((_this$cynefin41 = this.cynefin) === null || _this$cynefin41 === void 0 ? void 0 : _this$cynefin41.chaoticBg) || "#FBE9E7",
			clearBg: ((_this$cynefin42 = this.cynefin) === null || _this$cynefin42 === void 0 ? void 0 : _this$cynefin42.clearBg) || "#FFF8E1",
			confusionBg: ((_this$cynefin43 = this.cynefin) === null || _this$cynefin43 === void 0 ? void 0 : _this$cynefin43.confusionBg) || "#F3E5F5",
			textColor: ((_this$cynefin44 = this.cynefin) === null || _this$cynefin44 === void 0 ? void 0 : _this$cynefin44.textColor) || this.textColor,
			labelColor: ((_this$cynefin45 = this.cynefin) === null || _this$cynefin45 === void 0 ? void 0 : _this$cynefin45.labelColor) || this.primaryTextColor
		};
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.radar = {
			axisColor: ((_this$radar21 = this.radar) === null || _this$radar21 === void 0 ? void 0 : _this$radar21.axisColor) || this.lineColor,
			axisStrokeWidth: ((_this$radar22 = this.radar) === null || _this$radar22 === void 0 ? void 0 : _this$radar22.axisStrokeWidth) || 2,
			axisLabelFontSize: ((_this$radar23 = this.radar) === null || _this$radar23 === void 0 ? void 0 : _this$radar23.axisLabelFontSize) || 12,
			curveOpacity: ((_this$radar24 = this.radar) === null || _this$radar24 === void 0 ? void 0 : _this$radar24.curveOpacity) || .5,
			curveStrokeWidth: ((_this$radar25 = this.radar) === null || _this$radar25 === void 0 ? void 0 : _this$radar25.curveStrokeWidth) || 2,
			graticuleColor: ((_this$radar26 = this.radar) === null || _this$radar26 === void 0 ? void 0 : _this$radar26.graticuleColor) || "#DEDEDE",
			graticuleStrokeWidth: ((_this$radar27 = this.radar) === null || _this$radar27 === void 0 ? void 0 : _this$radar27.graticuleStrokeWidth) || 1,
			graticuleOpacity: ((_this$radar28 = this.radar) === null || _this$radar28 === void 0 ? void 0 : _this$radar28.graticuleOpacity) || .3,
			legendBoxSize: ((_this$radar29 = this.radar) === null || _this$radar29 === void 0 ? void 0 : _this$radar29.legendBoxSize) || 12,
			legendFontSize: ((_this$radar30 = this.radar) === null || _this$radar30 === void 0 ? void 0 : _this$radar30.legendFontSize) || 12
		};
		this.wardleyEvolutionColor = this.wardleyEvolutionColor || "#dc3545";
		this.wardley = {
			backgroundColor: ((_this$wardley25 = this.wardley) === null || _this$wardley25 === void 0 ? void 0 : _this$wardley25.backgroundColor) || this.background,
			axisColor: ((_this$wardley26 = this.wardley) === null || _this$wardley26 === void 0 ? void 0 : _this$wardley26.axisColor) || this.lineColor,
			axisTextColor: ((_this$wardley27 = this.wardley) === null || _this$wardley27 === void 0 ? void 0 : _this$wardley27.axisTextColor) || this.primaryTextColor,
			gridColor: ((_this$wardley28 = this.wardley) === null || _this$wardley28 === void 0 ? void 0 : _this$wardley28.gridColor) || this.gridColor,
			componentFill: ((_this$wardley29 = this.wardley) === null || _this$wardley29 === void 0 ? void 0 : _this$wardley29.componentFill) || this.background,
			componentStroke: ((_this$wardley30 = this.wardley) === null || _this$wardley30 === void 0 ? void 0 : _this$wardley30.componentStroke) || this.lineColor,
			componentLabelColor: ((_this$wardley31 = this.wardley) === null || _this$wardley31 === void 0 ? void 0 : _this$wardley31.componentLabelColor) || this.primaryTextColor,
			linkStroke: ((_this$wardley32 = this.wardley) === null || _this$wardley32 === void 0 ? void 0 : _this$wardley32.linkStroke) || this.lineColor,
			evolutionStroke: ((_this$wardley33 = this.wardley) === null || _this$wardley33 === void 0 ? void 0 : _this$wardley33.evolutionStroke) || this.wardleyEvolutionColor,
			annotationStroke: ((_this$wardley34 = this.wardley) === null || _this$wardley34 === void 0 ? void 0 : _this$wardley34.annotationStroke) || this.lineColor,
			annotationTextColor: ((_this$wardley35 = this.wardley) === null || _this$wardley35 === void 0 ? void 0 : _this$wardley35.annotationTextColor) || this.primaryTextColor,
			annotationFill: ((_this$wardley36 = this.wardley) === null || _this$wardley36 === void 0 ? void 0 : _this$wardley36.annotationFill) || this.background
		};
		this.xyChart = {
			backgroundColor: ((_this$xyChart25 = this.xyChart) === null || _this$xyChart25 === void 0 ? void 0 : _this$xyChart25.backgroundColor) || this.background,
			titleColor: ((_this$xyChart26 = this.xyChart) === null || _this$xyChart26 === void 0 ? void 0 : _this$xyChart26.titleColor) || this.primaryTextColor,
			dataLabelColor: ((_this$xyChart27 = this.xyChart) === null || _this$xyChart27 === void 0 ? void 0 : _this$xyChart27.dataLabelColor) || this.primaryTextColor,
			xAxisTitleColor: ((_this$xyChart28 = this.xyChart) === null || _this$xyChart28 === void 0 ? void 0 : _this$xyChart28.xAxisTitleColor) || this.primaryTextColor,
			xAxisLabelColor: ((_this$xyChart29 = this.xyChart) === null || _this$xyChart29 === void 0 ? void 0 : _this$xyChart29.xAxisLabelColor) || this.primaryTextColor,
			xAxisTickColor: ((_this$xyChart30 = this.xyChart) === null || _this$xyChart30 === void 0 ? void 0 : _this$xyChart30.xAxisTickColor) || this.primaryTextColor,
			xAxisLineColor: ((_this$xyChart31 = this.xyChart) === null || _this$xyChart31 === void 0 ? void 0 : _this$xyChart31.xAxisLineColor) || this.primaryTextColor,
			yAxisTitleColor: ((_this$xyChart32 = this.xyChart) === null || _this$xyChart32 === void 0 ? void 0 : _this$xyChart32.yAxisTitleColor) || this.primaryTextColor,
			yAxisLabelColor: ((_this$xyChart33 = this.xyChart) === null || _this$xyChart33 === void 0 ? void 0 : _this$xyChart33.yAxisLabelColor) || this.primaryTextColor,
			yAxisTickColor: ((_this$xyChart34 = this.xyChart) === null || _this$xyChart34 === void 0 ? void 0 : _this$xyChart34.yAxisTickColor) || this.primaryTextColor,
			yAxisLineColor: ((_this$xyChart35 = this.xyChart) === null || _this$xyChart35 === void 0 ? void 0 : _this$xyChart35.yAxisLineColor) || this.primaryTextColor,
			plotColorPalette: ((_this$xyChart36 = this.xyChart) === null || _this$xyChart36 === void 0 ? void 0 : _this$xyChart36.plotColorPalette) || "#ECECFF,#8493A6,#FFC3A0,#DCDDE1,#B8E994,#D1A36F,#C3CDE6,#FFB6C1,#496078,#F8F3E3"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || this.labelBackground;
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || this.primaryColor;
		this.git1 = this.git1 || this.secondaryColor;
		this.git2 = this.git2 || this.tertiaryColor;
		this.git3 = this.git3 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(this.primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || darken(invert(this.git0), 25);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.gitBranchLabel0 = this.gitBranchLabel0 || invert(this.labelTextColor);
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || invert(this.labelTextColor);
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.emUiFill = this.emUiFill || "white";
		this.emUiStroke = this.emUiStroke || "#dbdada";
		this.emProcessorFill = this.emProcessorFill || "#edb3f6";
		this.emProcessorStroke = this.emProcessorStroke || "#b88cbf";
		this.emReadModelFill = this.emReadModelFill || "#d3f1a2";
		this.emReadModelStroke = this.emReadModelStroke || "#a3b732";
		this.emCommandFill = this.emCommandFill || "#bcd6fe";
		this.emCommandStroke = this.emCommandStroke || "#679ac3";
		this.emEventFill = this.emEventFill || "#ffb778";
		this.emEventStroke = this.emEventStroke || "#c19a0f";
		this.emSwimlaneBackgroundOdd = this.emSwimlaneBackgroundOdd || "rgb(250,250,250)";
		this.emSwimlaneBackgroundStroke = this.emSwimlaneBackgroundStroke || "rgb(240,240,240)";
		this.emArrowhead = this.emArrowhead || this.lineColor;
		this.emRelationStroke = this.emRelationStroke || this.lineColor;
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		Object.keys(this).forEach((k) => {
			if (this[k] === "calculated") this[k] = void 0;
		});
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
}, __name(_Class3, "Theme"), _Class3);
var getThemeVariables3 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme3();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme4 = (_Class4 = class {
	constructor() {
		this.background = "#f4f4f4";
		this.primaryColor = "#cde498";
		this.secondaryColor = "#cdffb2";
		this.background = "white";
		this.mainBkg = "#cde498";
		this.secondBkg = "#cdffb2";
		this.lineColor = "green";
		this.border1 = "#13540c";
		this.border2 = "#6eaa49";
		this.arrowheadColor = "green";
		this.fontFamily = "\"trebuchet ms\", verdana, arial, sans-serif";
		this.fontSize = "16px";
		this.tertiaryColor = lighten("#cde498", 10);
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.primaryColor);
		this.lineColor = invert(this.background);
		this.textColor = invert(this.background);
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 5;
		this.strokeWidth = 1;
		this.nodeBkg = "calculated";
		this.nodeBorder = "calculated";
		this.clusterBkg = "calculated";
		this.clusterBorder = "calculated";
		this.defaultLinkColor = "calculated";
		this.titleColor = "#333";
		this.edgeLabelBackground = "#e8e8e8";
		this.actorBorder = "calculated";
		this.actorBkg = "calculated";
		this.actorTextColor = "black";
		this.actorLineColor = "calculated";
		this.signalColor = "#333";
		this.signalTextColor = "#333";
		this.labelBoxBkgColor = "calculated";
		this.labelBoxBorderColor = "#326932";
		this.labelTextColor = "calculated";
		this.loopTextColor = "calculated";
		this.noteBorderColor = "calculated";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "calculated";
		this.activationBorderColor = "#666";
		this.activationBkgColor = "#f4f4f4";
		this.sequenceNumberColor = "white";
		this.sectionBkgColor = "#6eaa49";
		this.altSectionBkgColor = "white";
		this.sectionBkgColor2 = "#6eaa49";
		this.excludeBkgColor = "#eeeeee";
		this.taskBorderColor = "calculated";
		this.taskBkgColor = "#487e3a";
		this.taskTextLightColor = "white";
		this.taskTextColor = "calculated";
		this.taskTextDarkColor = "black";
		this.taskTextOutsideColor = "calculated";
		this.taskTextClickableColor = "#003163";
		this.activeTaskBorderColor = "calculated";
		this.activeTaskBkgColor = "calculated";
		this.gridColor = "lightgrey";
		this.doneTaskBkgColor = "lightgrey";
		this.doneTaskBorderColor = "grey";
		this.critBorderColor = "#ff8888";
		this.critBkgColor = "red";
		this.todayLineColor = "red";
		this.vertLineColor = "#00BFFF";
		this.personBorder = this.primaryBorderColor;
		this.personBkg = this.mainBkg;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.noteFontWeight = "normal";
		this.fontWeight = "normal";
		this.labelColor = "black";
		this.errorBkgColor = "#552222";
		this.errorTextColor = "#552222";
		this.useGradient = true;
		this.gradientStart = this.primaryBorderColor;
		this.gradientStop = this.secondaryBorderColor;
		this.dropShadow = "drop-shadow( 1px 2px 2px rgba(185,185,185,0.5))";
	}
	updateColors() {
		var _this$venn17, _this$venn18, _this$venn19, _this$venn20, _this$venn21, _this$venn22, _this$venn23, _this$venn24, _this$vennTitleTextCo4, _this$vennSetTextColo4, _this$cynefin46, _this$cynefin47, _this$cynefin48, _this$cynefin49, _this$cynefin50, _this$cynefin51, _this$cynefin52, _this$cynefin53, _this$cynefin54, _this$cynefin55, _this$cynefin56, _this$cynefin57, _this$cynefin58, _this$cynefin59, _this$cynefin60, _this$radar31, _this$radar32, _this$radar33, _this$radar34, _this$radar35, _this$radar36, _this$radar37, _this$radar38, _this$radar39, _this$radar40, _this$wardley37, _this$wardley38, _this$wardley39, _this$wardley40, _this$wardley41, _this$wardley42, _this$wardley43, _this$wardley44, _this$wardley45, _this$wardley46, _this$wardley47, _this$wardley48, _this$xyChart37, _this$xyChart38, _this$xyChart39, _this$xyChart40, _this$xyChart41, _this$xyChart42, _this$xyChart43, _this$xyChart44, _this$xyChart45, _this$xyChart46, _this$xyChart47, _this$xyChart48;
		this.actorBorder = darken(this.mainBkg, 20);
		this.actorBkg = this.mainBkg;
		this.labelBoxBkgColor = this.actorBkg;
		this.labelTextColor = this.actorTextColor;
		this.loopTextColor = this.actorTextColor;
		this.noteBorderColor = this.border2;
		this.noteTextColor = this.actorTextColor;
		this.actorLineColor = this.actorBorder;
		this.rectBkgColor = this.rectBkgColor || this.tertiaryColor;
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, { h: 210 });
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		this["cScalePeer1"] = this["cScalePeer1"] || darken(this.secondaryColor, 45);
		this["cScalePeer2"] = this["cScalePeer2"] || darken(this.tertiaryColor, 40);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) {
			this["cScale" + i] = darken(this["cScale" + i], 10);
			this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 25);
		}
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || adjust(this["cScale" + i], { h: 180 });
		this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 30,
				s: -30,
				l: -(5 + i * 5)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 30,
				s: -30,
				l: -(8 + i * 5)
			});
		}
		this.nodeBkg = this.mainBkg;
		this.nodeBorder = this.border1;
		this.clusterBkg = this.secondBkg;
		this.clusterBorder = this.border2;
		this.defaultLinkColor = this.lineColor;
		this.taskBorderColor = this.border1;
		this.taskTextColor = this.taskTextLightColor;
		this.taskTextOutsideColor = this.taskTextDarkColor;
		this.activeTaskBorderColor = this.taskBorderColor;
		this.activeTaskBkgColor = this.mainBkg;
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.rowOdd = this.rowOdd || lighten(this.mainBkg, 75) || "#ffffff";
		this.rowEven = this.rowEven || lighten(this.mainBkg, 20);
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.primaryBorderColor;
		this.specialStateColor = this.lineColor;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.classText = this.primaryTextColor;
		this.fillType0 = this.primaryColor;
		this.fillType1 = this.secondaryColor;
		this.fillType2 = adjust(this.primaryColor, { h: 64 });
		this.fillType3 = adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = adjust(this.primaryColor, { h: -64 });
		this.fillType5 = adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = adjust(this.primaryColor, { h: 128 });
		this.fillType7 = adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || this.tertiaryColor;
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -30 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -30 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, {
			h: 40,
			l: -40
		});
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -50
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -60,
			l: -50
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -50
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.venn1 = (_this$venn17 = this.venn1) !== null && _this$venn17 !== void 0 ? _this$venn17 : adjust(this.primaryColor, { l: -30 });
		this.venn2 = (_this$venn18 = this.venn2) !== null && _this$venn18 !== void 0 ? _this$venn18 : adjust(this.secondaryColor, { l: -30 });
		this.venn3 = (_this$venn19 = this.venn3) !== null && _this$venn19 !== void 0 ? _this$venn19 : adjust(this.tertiaryColor, { l: -30 });
		this.venn4 = (_this$venn20 = this.venn4) !== null && _this$venn20 !== void 0 ? _this$venn20 : adjust(this.primaryColor, {
			h: 60,
			l: -30
		});
		this.venn5 = (_this$venn21 = this.venn5) !== null && _this$venn21 !== void 0 ? _this$venn21 : adjust(this.primaryColor, {
			h: -60,
			l: -30
		});
		this.venn6 = (_this$venn22 = this.venn6) !== null && _this$venn22 !== void 0 ? _this$venn22 : adjust(this.secondaryColor, {
			h: 60,
			l: -30
		});
		this.venn7 = (_this$venn23 = this.venn7) !== null && _this$venn23 !== void 0 ? _this$venn23 : adjust(this.primaryColor, {
			h: 120,
			l: -30
		});
		this.venn8 = (_this$venn24 = this.venn8) !== null && _this$venn24 !== void 0 ? _this$venn24 : adjust(this.secondaryColor, {
			h: 120,
			l: -30
		});
		this.vennTitleTextColor = (_this$vennTitleTextCo4 = this.vennTitleTextColor) !== null && _this$vennTitleTextCo4 !== void 0 ? _this$vennTitleTextCo4 : this.titleColor;
		this.vennSetTextColor = (_this$vennSetTextColo4 = this.vennSetTextColor) !== null && _this$vennSetTextColo4 !== void 0 ? _this$vennSetTextColo4 : this.textColor;
		this.cynefin = {
			domainFontSize: ((_this$cynefin46 = this.cynefin) === null || _this$cynefin46 === void 0 ? void 0 : _this$cynefin46.domainFontSize) || 16,
			itemFontSize: ((_this$cynefin47 = this.cynefin) === null || _this$cynefin47 === void 0 ? void 0 : _this$cynefin47.itemFontSize) || 12,
			boundaryColor: ((_this$cynefin48 = this.cynefin) === null || _this$cynefin48 === void 0 ? void 0 : _this$cynefin48.boundaryColor) || this.lineColor,
			boundaryWidth: ((_this$cynefin49 = this.cynefin) === null || _this$cynefin49 === void 0 ? void 0 : _this$cynefin49.boundaryWidth) || 2,
			cliffColor: ((_this$cynefin50 = this.cynefin) === null || _this$cynefin50 === void 0 ? void 0 : _this$cynefin50.cliffColor) || "#8B4513",
			cliffWidth: ((_this$cynefin51 = this.cynefin) === null || _this$cynefin51 === void 0 ? void 0 : _this$cynefin51.cliffWidth) || 4,
			arrowColor: ((_this$cynefin52 = this.cynefin) === null || _this$cynefin52 === void 0 ? void 0 : _this$cynefin52.arrowColor) || this.lineColor,
			arrowWidth: ((_this$cynefin53 = this.cynefin) === null || _this$cynefin53 === void 0 ? void 0 : _this$cynefin53.arrowWidth) || 2,
			complexBg: ((_this$cynefin54 = this.cynefin) === null || _this$cynefin54 === void 0 ? void 0 : _this$cynefin54.complexBg) || "#C8E6C9",
			complicatedBg: ((_this$cynefin55 = this.cynefin) === null || _this$cynefin55 === void 0 ? void 0 : _this$cynefin55.complicatedBg) || "#DCEDC8",
			chaoticBg: ((_this$cynefin56 = this.cynefin) === null || _this$cynefin56 === void 0 ? void 0 : _this$cynefin56.chaoticBg) || "#FFE0B2",
			clearBg: ((_this$cynefin57 = this.cynefin) === null || _this$cynefin57 === void 0 ? void 0 : _this$cynefin57.clearBg) || "#FFF9C4",
			confusionBg: ((_this$cynefin58 = this.cynefin) === null || _this$cynefin58 === void 0 ? void 0 : _this$cynefin58.confusionBg) || "#D7CCC8",
			textColor: ((_this$cynefin59 = this.cynefin) === null || _this$cynefin59 === void 0 ? void 0 : _this$cynefin59.textColor) || this.textColor,
			labelColor: ((_this$cynefin60 = this.cynefin) === null || _this$cynefin60 === void 0 ? void 0 : _this$cynefin60.labelColor) || this.primaryTextColor
		};
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.packet = {
			startByteColor: this.primaryTextColor,
			endByteColor: this.primaryTextColor,
			labelColor: this.primaryTextColor,
			titleColor: this.primaryTextColor,
			blockStrokeColor: this.primaryTextColor,
			blockFillColor: this.mainBkg
		};
		this.radar = {
			axisColor: ((_this$radar31 = this.radar) === null || _this$radar31 === void 0 ? void 0 : _this$radar31.axisColor) || this.lineColor,
			axisStrokeWidth: ((_this$radar32 = this.radar) === null || _this$radar32 === void 0 ? void 0 : _this$radar32.axisStrokeWidth) || 2,
			axisLabelFontSize: ((_this$radar33 = this.radar) === null || _this$radar33 === void 0 ? void 0 : _this$radar33.axisLabelFontSize) || 12,
			curveOpacity: ((_this$radar34 = this.radar) === null || _this$radar34 === void 0 ? void 0 : _this$radar34.curveOpacity) || .5,
			curveStrokeWidth: ((_this$radar35 = this.radar) === null || _this$radar35 === void 0 ? void 0 : _this$radar35.curveStrokeWidth) || 2,
			graticuleColor: ((_this$radar36 = this.radar) === null || _this$radar36 === void 0 ? void 0 : _this$radar36.graticuleColor) || "#DEDEDE",
			graticuleStrokeWidth: ((_this$radar37 = this.radar) === null || _this$radar37 === void 0 ? void 0 : _this$radar37.graticuleStrokeWidth) || 1,
			graticuleOpacity: ((_this$radar38 = this.radar) === null || _this$radar38 === void 0 ? void 0 : _this$radar38.graticuleOpacity) || .3,
			legendBoxSize: ((_this$radar39 = this.radar) === null || _this$radar39 === void 0 ? void 0 : _this$radar39.legendBoxSize) || 12,
			legendFontSize: ((_this$radar40 = this.radar) === null || _this$radar40 === void 0 ? void 0 : _this$radar40.legendFontSize) || 12
		};
		this.wardleyEvolutionColor = this.wardleyEvolutionColor || "#dc3545";
		this.wardley = {
			backgroundColor: ((_this$wardley37 = this.wardley) === null || _this$wardley37 === void 0 ? void 0 : _this$wardley37.backgroundColor) || this.background,
			axisColor: ((_this$wardley38 = this.wardley) === null || _this$wardley38 === void 0 ? void 0 : _this$wardley38.axisColor) || this.lineColor,
			axisTextColor: ((_this$wardley39 = this.wardley) === null || _this$wardley39 === void 0 ? void 0 : _this$wardley39.axisTextColor) || this.primaryTextColor,
			gridColor: ((_this$wardley40 = this.wardley) === null || _this$wardley40 === void 0 ? void 0 : _this$wardley40.gridColor) || this.gridColor,
			componentFill: ((_this$wardley41 = this.wardley) === null || _this$wardley41 === void 0 ? void 0 : _this$wardley41.componentFill) || this.background,
			componentStroke: ((_this$wardley42 = this.wardley) === null || _this$wardley42 === void 0 ? void 0 : _this$wardley42.componentStroke) || this.lineColor,
			componentLabelColor: ((_this$wardley43 = this.wardley) === null || _this$wardley43 === void 0 ? void 0 : _this$wardley43.componentLabelColor) || this.primaryTextColor,
			linkStroke: ((_this$wardley44 = this.wardley) === null || _this$wardley44 === void 0 ? void 0 : _this$wardley44.linkStroke) || this.lineColor,
			evolutionStroke: ((_this$wardley45 = this.wardley) === null || _this$wardley45 === void 0 ? void 0 : _this$wardley45.evolutionStroke) || this.wardleyEvolutionColor,
			annotationStroke: ((_this$wardley46 = this.wardley) === null || _this$wardley46 === void 0 ? void 0 : _this$wardley46.annotationStroke) || this.lineColor,
			annotationTextColor: ((_this$wardley47 = this.wardley) === null || _this$wardley47 === void 0 ? void 0 : _this$wardley47.annotationTextColor) || this.primaryTextColor,
			annotationFill: ((_this$wardley48 = this.wardley) === null || _this$wardley48 === void 0 ? void 0 : _this$wardley48.annotationFill) || this.background
		};
		this.xyChart = {
			backgroundColor: ((_this$xyChart37 = this.xyChart) === null || _this$xyChart37 === void 0 ? void 0 : _this$xyChart37.backgroundColor) || this.background,
			titleColor: ((_this$xyChart38 = this.xyChart) === null || _this$xyChart38 === void 0 ? void 0 : _this$xyChart38.titleColor) || this.primaryTextColor,
			dataLabelColor: ((_this$xyChart39 = this.xyChart) === null || _this$xyChart39 === void 0 ? void 0 : _this$xyChart39.dataLabelColor) || this.primaryTextColor,
			xAxisTitleColor: ((_this$xyChart40 = this.xyChart) === null || _this$xyChart40 === void 0 ? void 0 : _this$xyChart40.xAxisTitleColor) || this.primaryTextColor,
			xAxisLabelColor: ((_this$xyChart41 = this.xyChart) === null || _this$xyChart41 === void 0 ? void 0 : _this$xyChart41.xAxisLabelColor) || this.primaryTextColor,
			xAxisTickColor: ((_this$xyChart42 = this.xyChart) === null || _this$xyChart42 === void 0 ? void 0 : _this$xyChart42.xAxisTickColor) || this.primaryTextColor,
			xAxisLineColor: ((_this$xyChart43 = this.xyChart) === null || _this$xyChart43 === void 0 ? void 0 : _this$xyChart43.xAxisLineColor) || this.primaryTextColor,
			yAxisTitleColor: ((_this$xyChart44 = this.xyChart) === null || _this$xyChart44 === void 0 ? void 0 : _this$xyChart44.yAxisTitleColor) || this.primaryTextColor,
			yAxisLabelColor: ((_this$xyChart45 = this.xyChart) === null || _this$xyChart45 === void 0 ? void 0 : _this$xyChart45.yAxisLabelColor) || this.primaryTextColor,
			yAxisTickColor: ((_this$xyChart46 = this.xyChart) === null || _this$xyChart46 === void 0 ? void 0 : _this$xyChart46.yAxisTickColor) || this.primaryTextColor,
			yAxisLineColor: ((_this$xyChart47 = this.xyChart) === null || _this$xyChart47 === void 0 ? void 0 : _this$xyChart47.yAxisLineColor) || this.primaryTextColor,
			plotColorPalette: ((_this$xyChart48 = this.xyChart) === null || _this$xyChart48 === void 0 ? void 0 : _this$xyChart48.plotColorPalette) || "#CDE498,#FF6B6B,#A0D2DB,#D7BDE2,#F0F0F0,#FFC3A0,#7FD8BE,#FF9A8B,#FAF3E0,#FFF176"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground;
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || this.primaryColor;
		this.git1 = this.git1 || this.secondaryColor;
		this.git2 = this.git2 || this.tertiaryColor;
		this.git3 = this.git3 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(this.primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.gitBranchLabel0 = this.gitBranchLabel0 || invert(this.labelTextColor);
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || invert(this.labelTextColor);
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.emUiFill = this.emUiFill || "white";
		this.emUiStroke = this.emUiStroke || "#dbdada";
		this.emProcessorFill = this.emProcessorFill || "#edb3f6";
		this.emProcessorStroke = this.emProcessorStroke || "#b88cbf";
		this.emReadModelFill = this.emReadModelFill || "#d3f1a2";
		this.emReadModelStroke = this.emReadModelStroke || "#a3b732";
		this.emCommandFill = this.emCommandFill || "#bcd6fe";
		this.emCommandStroke = this.emCommandStroke || "#679ac3";
		this.emEventFill = this.emEventFill || "#ffb778";
		this.emEventStroke = this.emEventStroke || "#c19a0f";
		this.emSwimlaneBackgroundOdd = this.emSwimlaneBackgroundOdd || "rgb(250,250,250)";
		this.emSwimlaneBackgroundStroke = this.emSwimlaneBackgroundStroke || "rgb(240,240,240)";
		this.emArrowhead = this.emArrowhead || this.lineColor;
		this.emRelationStroke = this.emRelationStroke || this.lineColor;
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
}, __name(_Class4, "Theme"), _Class4);
var getThemeVariables4 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme4();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme5 = (_Class5 = class {
	constructor() {
		this.primaryColor = "#eee";
		this.contrast = "#707070";
		this.secondaryColor = lighten(this.contrast, 55);
		this.background = "#ffffff";
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.lineColor = invert(this.background);
		this.textColor = invert(this.background);
		this.mainBkg = "#eee";
		this.secondBkg = "calculated";
		this.lineColor = "#666";
		this.border1 = "#999";
		this.border2 = "calculated";
		this.note = "#ffa";
		this.text = "#333";
		this.critical = "#d42";
		this.done = "#bbb";
		this.arrowheadColor = "#333333";
		this.fontFamily = "\"trebuchet ms\", verdana, arial, sans-serif";
		this.fontSize = "16px";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 5;
		this.strokeWidth = 1;
		this.nodeBkg = "calculated";
		this.nodeBorder = "calculated";
		this.clusterBkg = "calculated";
		this.clusterBorder = "calculated";
		this.defaultLinkColor = "calculated";
		this.titleColor = "calculated";
		this.edgeLabelBackground = "white";
		this.actorBorder = "calculated";
		this.actorBkg = "calculated";
		this.actorTextColor = "calculated";
		this.actorLineColor = this.actorBorder;
		this.signalColor = "calculated";
		this.signalTextColor = "calculated";
		this.labelBoxBkgColor = "calculated";
		this.labelBoxBorderColor = "calculated";
		this.labelTextColor = "calculated";
		this.loopTextColor = "calculated";
		this.noteBorderColor = "calculated";
		this.noteBkgColor = "calculated";
		this.noteTextColor = "calculated";
		this.activationBorderColor = "#666";
		this.activationBkgColor = "#f4f4f4";
		this.sequenceNumberColor = "white";
		this.sectionBkgColor = "calculated";
		this.altSectionBkgColor = "white";
		this.sectionBkgColor2 = "calculated";
		this.excludeBkgColor = "#eeeeee";
		this.taskBorderColor = "calculated";
		this.taskBkgColor = "calculated";
		this.taskTextLightColor = "white";
		this.taskTextColor = "calculated";
		this.taskTextDarkColor = "calculated";
		this.taskTextOutsideColor = "calculated";
		this.taskTextClickableColor = "#003163";
		this.activeTaskBorderColor = "calculated";
		this.activeTaskBkgColor = "calculated";
		this.gridColor = "calculated";
		this.doneTaskBkgColor = "calculated";
		this.doneTaskBorderColor = "calculated";
		this.critBkgColor = "calculated";
		this.critBorderColor = "calculated";
		this.todayLineColor = "calculated";
		this.vertLineColor = "calculated";
		this.personBorder = this.primaryBorderColor;
		this.personBkg = this.mainBkg;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.noteFontWeight = "normal";
		this.fontWeight = "normal";
		this.rowOdd = this.rowOdd || lighten(this.mainBkg, 75) || "#ffffff";
		this.rowEven = this.rowEven || "#f4f4f4";
		this.labelColor = "black";
		this.errorBkgColor = "#552222";
		this.errorTextColor = "#552222";
		this.useGradient = true;
		this.gradientStart = this.primaryBorderColor;
		this.gradientStop = this.secondaryBorderColor;
		this.dropShadow = "drop-shadow( 1px 2px 2px rgba(185,185,185,1))";
	}
	updateColors() {
		var _this$vennTitleTextCo5, _this$vennSetTextColo5, _this$cynefin61, _this$cynefin62, _this$cynefin63, _this$cynefin64, _this$cynefin65, _this$cynefin66, _this$cynefin67, _this$cynefin68, _this$cynefin69, _this$cynefin70, _this$cynefin71, _this$cynefin72, _this$cynefin73, _this$cynefin74, _this$cynefin75, _this$xyChart49, _this$xyChart50, _this$xyChart51, _this$xyChart52, _this$xyChart53, _this$xyChart54, _this$xyChart55, _this$xyChart56, _this$xyChart57, _this$xyChart58, _this$xyChart59, _this$xyChart60, _this$radar41, _this$radar42, _this$radar43, _this$radar44, _this$radar45, _this$radar46, _this$radar47, _this$radar48, _this$radar49, _this$radar50, _this$wardley49, _this$wardley50, _this$wardley51, _this$wardley52, _this$wardley53, _this$wardley54, _this$wardley55, _this$wardley56, _this$wardley57, _this$wardley58, _this$wardley59, _this$wardley60;
		this.secondBkg = lighten(this.contrast, 55);
		this.border2 = this.contrast;
		this.actorBorder = lighten(this.border1, 23);
		this.actorBkg = this.mainBkg;
		this.actorTextColor = this.text;
		this.actorLineColor = this.actorBorder;
		this.rectBkgColor = this.rectBkgColor || this.tertiaryColor;
		this.signalColor = this.text;
		this.signalTextColor = this.text;
		this.labelBoxBkgColor = this.actorBkg;
		this.labelBoxBorderColor = this.actorBorder;
		this.labelTextColor = this.text;
		this.loopTextColor = this.text;
		this.noteBorderColor = "#999";
		this.noteBkgColor = "#666";
		this.noteTextColor = "#fff";
		this.cScale0 = this.cScale0 || "#555";
		this.cScale1 = this.cScale1 || "#F4F4F4";
		this.cScale2 = this.cScale2 || "#555";
		this.cScale3 = this.cScale3 || "#BBB";
		this.cScale4 = this.cScale4 || "#777";
		this.cScale5 = this.cScale5 || "#999";
		this.cScale6 = this.cScale6 || "#DDD";
		this.cScale7 = this.cScale7 || "#FFF";
		this.cScale8 = this.cScale8 || "#DDD";
		this.cScale9 = this.cScale9 || "#BBB";
		this.cScale10 = this.cScale10 || "#999";
		this.cScale11 = this.cScale11 || "#777";
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.cScaleLabel0 = this.cScaleLabel0 || this.cScale1;
		this.cScaleLabel2 = this.cScaleLabel2 || this.cScale1;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, { l: -(5 + i * 5) });
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, { l: -(8 + i * 5) });
		}
		this.nodeBkg = this.mainBkg;
		this.nodeBorder = this.border1;
		this.clusterBkg = this.secondBkg;
		this.clusterBorder = this.border2;
		this.defaultLinkColor = this.lineColor;
		this.titleColor = this.text;
		this.sectionBkgColor = lighten(this.contrast, 30);
		this.sectionBkgColor2 = lighten(this.contrast, 30);
		this.taskBorderColor = darken(this.contrast, 10);
		this.taskBkgColor = this.contrast;
		this.taskTextColor = this.taskTextLightColor;
		this.taskTextDarkColor = this.text;
		this.taskTextOutsideColor = this.taskTextDarkColor;
		this.activeTaskBorderColor = this.taskBorderColor;
		this.activeTaskBkgColor = this.mainBkg;
		this.gridColor = lighten(this.border1, 30);
		this.doneTaskBkgColor = this.done;
		this.doneTaskBorderColor = this.lineColor;
		this.critBkgColor = this.critical;
		this.critBorderColor = darken(this.critBkgColor, 10);
		this.todayLineColor = this.critBkgColor;
		this.vertLineColor = this.critBkgColor;
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.transitionColor = this.transitionColor || "#000";
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f4f4f4";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.stateBorder = this.stateBorder || "#000";
		this.innerEndBackground = this.primaryBorderColor;
		this.specialStateColor = "#222";
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.classText = this.primaryTextColor;
		this.fillType0 = this.primaryColor;
		this.fillType1 = this.secondaryColor;
		this.fillType2 = adjust(this.primaryColor, { h: 64 });
		this.fillType3 = adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = adjust(this.primaryColor, { h: -64 });
		this.fillType5 = adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = adjust(this.primaryColor, { h: 128 });
		this.fillType7 = adjust(this.secondaryColor, { h: 128 });
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["pie" + i] = this["cScale" + i];
		this.pie12 = this.pie0;
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		for (let i = 0; i < 8; i++) {
			var _this2;
			this["venn" + (i + 1)] = (_this2 = this["venn" + (i + 1)]) !== null && _this2 !== void 0 ? _this2 : this["cScale" + i];
		}
		this.vennTitleTextColor = (_this$vennTitleTextCo5 = this.vennTitleTextColor) !== null && _this$vennTitleTextCo5 !== void 0 ? _this$vennTitleTextCo5 : this.titleColor;
		this.vennSetTextColor = (_this$vennSetTextColo5 = this.vennSetTextColor) !== null && _this$vennSetTextColo5 !== void 0 ? _this$vennSetTextColo5 : this.textColor;
		this.cynefin = {
			domainFontSize: ((_this$cynefin61 = this.cynefin) === null || _this$cynefin61 === void 0 ? void 0 : _this$cynefin61.domainFontSize) || 16,
			itemFontSize: ((_this$cynefin62 = this.cynefin) === null || _this$cynefin62 === void 0 ? void 0 : _this$cynefin62.itemFontSize) || 12,
			boundaryColor: ((_this$cynefin63 = this.cynefin) === null || _this$cynefin63 === void 0 ? void 0 : _this$cynefin63.boundaryColor) || this.lineColor,
			boundaryWidth: ((_this$cynefin64 = this.cynefin) === null || _this$cynefin64 === void 0 ? void 0 : _this$cynefin64.boundaryWidth) || 2,
			cliffColor: ((_this$cynefin65 = this.cynefin) === null || _this$cynefin65 === void 0 ? void 0 : _this$cynefin65.cliffColor) || "#8B0000",
			cliffWidth: ((_this$cynefin66 = this.cynefin) === null || _this$cynefin66 === void 0 ? void 0 : _this$cynefin66.cliffWidth) || 4,
			arrowColor: ((_this$cynefin67 = this.cynefin) === null || _this$cynefin67 === void 0 ? void 0 : _this$cynefin67.arrowColor) || this.lineColor,
			arrowWidth: ((_this$cynefin68 = this.cynefin) === null || _this$cynefin68 === void 0 ? void 0 : _this$cynefin68.arrowWidth) || 2,
			complexBg: ((_this$cynefin69 = this.cynefin) === null || _this$cynefin69 === void 0 ? void 0 : _this$cynefin69.complexBg) || "#E8F5E9",
			complicatedBg: ((_this$cynefin70 = this.cynefin) === null || _this$cynefin70 === void 0 ? void 0 : _this$cynefin70.complicatedBg) || "#E3F2FD",
			chaoticBg: ((_this$cynefin71 = this.cynefin) === null || _this$cynefin71 === void 0 ? void 0 : _this$cynefin71.chaoticBg) || "#FBE9E7",
			clearBg: ((_this$cynefin72 = this.cynefin) === null || _this$cynefin72 === void 0 ? void 0 : _this$cynefin72.clearBg) || "#FFF8E1",
			confusionBg: ((_this$cynefin73 = this.cynefin) === null || _this$cynefin73 === void 0 ? void 0 : _this$cynefin73.confusionBg) || "#F3E5F5",
			textColor: ((_this$cynefin74 = this.cynefin) === null || _this$cynefin74 === void 0 ? void 0 : _this$cynefin74.textColor) || this.textColor,
			labelColor: ((_this$cynefin75 = this.cynefin) === null || _this$cynefin75 === void 0 ? void 0 : _this$cynefin75.labelColor) || this.primaryTextColor
		};
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: ((_this$xyChart49 = this.xyChart) === null || _this$xyChart49 === void 0 ? void 0 : _this$xyChart49.backgroundColor) || this.background,
			titleColor: ((_this$xyChart50 = this.xyChart) === null || _this$xyChart50 === void 0 ? void 0 : _this$xyChart50.titleColor) || this.primaryTextColor,
			dataLabelColor: ((_this$xyChart51 = this.xyChart) === null || _this$xyChart51 === void 0 ? void 0 : _this$xyChart51.dataLabelColor) || this.primaryTextColor,
			xAxisTitleColor: ((_this$xyChart52 = this.xyChart) === null || _this$xyChart52 === void 0 ? void 0 : _this$xyChart52.xAxisTitleColor) || this.primaryTextColor,
			xAxisLabelColor: ((_this$xyChart53 = this.xyChart) === null || _this$xyChart53 === void 0 ? void 0 : _this$xyChart53.xAxisLabelColor) || this.primaryTextColor,
			xAxisTickColor: ((_this$xyChart54 = this.xyChart) === null || _this$xyChart54 === void 0 ? void 0 : _this$xyChart54.xAxisTickColor) || this.primaryTextColor,
			xAxisLineColor: ((_this$xyChart55 = this.xyChart) === null || _this$xyChart55 === void 0 ? void 0 : _this$xyChart55.xAxisLineColor) || this.primaryTextColor,
			yAxisTitleColor: ((_this$xyChart56 = this.xyChart) === null || _this$xyChart56 === void 0 ? void 0 : _this$xyChart56.yAxisTitleColor) || this.primaryTextColor,
			yAxisLabelColor: ((_this$xyChart57 = this.xyChart) === null || _this$xyChart57 === void 0 ? void 0 : _this$xyChart57.yAxisLabelColor) || this.primaryTextColor,
			yAxisTickColor: ((_this$xyChart58 = this.xyChart) === null || _this$xyChart58 === void 0 ? void 0 : _this$xyChart58.yAxisTickColor) || this.primaryTextColor,
			yAxisLineColor: ((_this$xyChart59 = this.xyChart) === null || _this$xyChart59 === void 0 ? void 0 : _this$xyChart59.yAxisLineColor) || this.primaryTextColor,
			plotColorPalette: ((_this$xyChart60 = this.xyChart) === null || _this$xyChart60 === void 0 ? void 0 : _this$xyChart60.plotColorPalette) || "#EEE,#6BB8E4,#8ACB88,#C7ACD6,#E8DCC2,#FFB2A8,#FFF380,#7E8D91,#FFD8B1,#FAF3E0"
		};
		this.radar = {
			axisColor: ((_this$radar41 = this.radar) === null || _this$radar41 === void 0 ? void 0 : _this$radar41.axisColor) || this.lineColor,
			axisStrokeWidth: ((_this$radar42 = this.radar) === null || _this$radar42 === void 0 ? void 0 : _this$radar42.axisStrokeWidth) || 2,
			axisLabelFontSize: ((_this$radar43 = this.radar) === null || _this$radar43 === void 0 ? void 0 : _this$radar43.axisLabelFontSize) || 12,
			curveOpacity: ((_this$radar44 = this.radar) === null || _this$radar44 === void 0 ? void 0 : _this$radar44.curveOpacity) || .5,
			curveStrokeWidth: ((_this$radar45 = this.radar) === null || _this$radar45 === void 0 ? void 0 : _this$radar45.curveStrokeWidth) || 2,
			graticuleColor: ((_this$radar46 = this.radar) === null || _this$radar46 === void 0 ? void 0 : _this$radar46.graticuleColor) || "#DEDEDE",
			graticuleStrokeWidth: ((_this$radar47 = this.radar) === null || _this$radar47 === void 0 ? void 0 : _this$radar47.graticuleStrokeWidth) || 1,
			graticuleOpacity: ((_this$radar48 = this.radar) === null || _this$radar48 === void 0 ? void 0 : _this$radar48.graticuleOpacity) || .3,
			legendBoxSize: ((_this$radar49 = this.radar) === null || _this$radar49 === void 0 ? void 0 : _this$radar49.legendBoxSize) || 12,
			legendFontSize: ((_this$radar50 = this.radar) === null || _this$radar50 === void 0 ? void 0 : _this$radar50.legendFontSize) || 12
		};
		this.wardleyEvolutionColor = this.wardleyEvolutionColor || "#dc3545";
		this.wardley = {
			backgroundColor: ((_this$wardley49 = this.wardley) === null || _this$wardley49 === void 0 ? void 0 : _this$wardley49.backgroundColor) || this.background,
			axisColor: ((_this$wardley50 = this.wardley) === null || _this$wardley50 === void 0 ? void 0 : _this$wardley50.axisColor) || this.lineColor,
			axisTextColor: ((_this$wardley51 = this.wardley) === null || _this$wardley51 === void 0 ? void 0 : _this$wardley51.axisTextColor) || this.primaryTextColor,
			gridColor: ((_this$wardley52 = this.wardley) === null || _this$wardley52 === void 0 ? void 0 : _this$wardley52.gridColor) || this.gridColor,
			componentFill: ((_this$wardley53 = this.wardley) === null || _this$wardley53 === void 0 ? void 0 : _this$wardley53.componentFill) || this.background,
			componentStroke: ((_this$wardley54 = this.wardley) === null || _this$wardley54 === void 0 ? void 0 : _this$wardley54.componentStroke) || this.lineColor,
			componentLabelColor: ((_this$wardley55 = this.wardley) === null || _this$wardley55 === void 0 ? void 0 : _this$wardley55.componentLabelColor) || this.primaryTextColor,
			linkStroke: ((_this$wardley56 = this.wardley) === null || _this$wardley56 === void 0 ? void 0 : _this$wardley56.linkStroke) || this.lineColor,
			evolutionStroke: ((_this$wardley57 = this.wardley) === null || _this$wardley57 === void 0 ? void 0 : _this$wardley57.evolutionStroke) || this.wardleyEvolutionColor,
			annotationStroke: ((_this$wardley58 = this.wardley) === null || _this$wardley58 === void 0 ? void 0 : _this$wardley58.annotationStroke) || this.lineColor,
			annotationTextColor: ((_this$wardley59 = this.wardley) === null || _this$wardley59 === void 0 ? void 0 : _this$wardley59.annotationTextColor) || this.primaryTextColor,
			annotationFill: ((_this$wardley60 = this.wardley) === null || _this$wardley60 === void 0 ? void 0 : _this$wardley60.annotationFill) || this.background
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground;
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = darken(this.pie1, 25) || this.primaryColor;
		this.git1 = this.pie2 || this.secondaryColor;
		this.git2 = this.pie3 || this.tertiaryColor;
		this.git3 = this.pie4 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.pie5 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.pie6 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.pie7 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.pie8 || adjust(this.primaryColor, { h: 120 });
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || this.labelTextColor;
		this.gitBranchLabel0 = this.branchLabelColor;
		this.gitBranchLabel1 = "white";
		this.gitBranchLabel2 = this.branchLabelColor;
		this.gitBranchLabel3 = "white";
		this.gitBranchLabel4 = this.branchLabelColor;
		this.gitBranchLabel5 = this.branchLabelColor;
		this.gitBranchLabel6 = this.branchLabelColor;
		this.gitBranchLabel7 = this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.emUiFill = this.emUiFill || "white";
		this.emUiStroke = this.emUiStroke || "#dbdada";
		this.emProcessorFill = this.emProcessorFill || "#edb3f6";
		this.emProcessorStroke = this.emProcessorStroke || "#b88cbf";
		this.emReadModelFill = this.emReadModelFill || "#d3f1a2";
		this.emReadModelStroke = this.emReadModelStroke || "#a3b732";
		this.emCommandFill = this.emCommandFill || "#bcd6fe";
		this.emCommandStroke = this.emCommandStroke || "#679ac3";
		this.emEventFill = this.emEventFill || "#ffb778";
		this.emEventStroke = this.emEventStroke || "#c19a0f";
		this.emSwimlaneBackgroundOdd = this.emSwimlaneBackgroundOdd || "rgb(250,250,250)";
		this.emSwimlaneBackgroundStroke = this.emSwimlaneBackgroundStroke || "rgb(240,240,240)";
		this.emArrowhead = this.emArrowhead || this.lineColor;
		this.emRelationStroke = this.emRelationStroke || this.lineColor;
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
}, __name(_Class5, "Theme"), _Class5);
var getThemeVariables5 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme5();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme6 = (_Class6 = class {
	constructor() {
		this.background = "#ffffff";
		this.primaryColor = "#cccccc";
		this.mainBkg = "#ffffff";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "#333";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 3;
		this.strokeWidth = 2;
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.fontFamily = "arial, sans-serif";
		this.fontSize = "14px";
		this.nodeBorder = "#000000";
		this.stateBorder = "#000000";
		this.useGradient = true;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "drop-shadow( 0px 1px 2px rgba(0, 0, 0, 0.25));";
		this.tertiaryColor = "#ffffff";
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.noteFontWeight = "normal";
		this.fontWeight = "normal";
	}
	updateColors() {
		var _this$vennTitleTextCo6, _this$vennSetTextColo6, _this$xyChart61, _this$xyChart62, _this$xyChart63, _this$xyChart64, _this$xyChart65, _this$xyChart66, _this$xyChart67, _this$xyChart68, _this$xyChart69, _this$xyChart70, _this$xyChart71;
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#333";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.primaryBorderColor;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		this.rectBkgColor = this.rectBkgColor || this.tertiaryColor;
		const primaryColor = "#ECECFE";
		const secondaryColor = "#E9E9F1";
		const tertiaryColor = adjust(primaryColor, {
			h: 180,
			l: 5
		});
		this.sectionBkgColor = this.sectionBkgColor || tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || primaryColor;
		this.cScale1 = this.cScale1 || secondaryColor;
		this.cScale2 = this.cScale2 || tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(primaryColor, {
			h: 210,
			l: 150
		});
		this.cScale9 = this.cScale9 || adjust(primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(primaryColor, { h: 330 });
		if (this.darkMode) for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 75);
		else for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 25);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || primaryColor;
		this.fillType1 = this.fillType1 || secondaryColor;
		this.fillType2 = this.fillType2 || adjust(primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || primaryColor;
		this.pie2 = this.pie2 || secondaryColor;
		this.pie3 = this.pie3 || tertiaryColor;
		this.pie4 = this.pie4 || adjust(primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = (_this$vennTitleTextCo6 = this.vennTitleTextColor) !== null && _this$vennTitleTextCo6 !== void 0 ? _this$vennTitleTextCo6 : this.titleColor;
		this.vennSetTextColor = (_this$vennSetTextColo6 = this.vennSetTextColor) !== null && _this$vennSetTextColo6 !== void 0 ? _this$vennSetTextColo6 : this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: ((_this$xyChart61 = this.xyChart) === null || _this$xyChart61 === void 0 ? void 0 : _this$xyChart61.backgroundColor) || this.background,
			titleColor: ((_this$xyChart62 = this.xyChart) === null || _this$xyChart62 === void 0 ? void 0 : _this$xyChart62.titleColor) || this.primaryTextColor,
			xAxisTitleColor: ((_this$xyChart63 = this.xyChart) === null || _this$xyChart63 === void 0 ? void 0 : _this$xyChart63.xAxisTitleColor) || this.primaryTextColor,
			xAxisLabelColor: ((_this$xyChart64 = this.xyChart) === null || _this$xyChart64 === void 0 ? void 0 : _this$xyChart64.xAxisLabelColor) || this.primaryTextColor,
			xAxisTickColor: ((_this$xyChart65 = this.xyChart) === null || _this$xyChart65 === void 0 ? void 0 : _this$xyChart65.xAxisTickColor) || this.primaryTextColor,
			xAxisLineColor: ((_this$xyChart66 = this.xyChart) === null || _this$xyChart66 === void 0 ? void 0 : _this$xyChart66.xAxisLineColor) || this.primaryTextColor,
			yAxisTitleColor: ((_this$xyChart67 = this.xyChart) === null || _this$xyChart67 === void 0 ? void 0 : _this$xyChart67.yAxisTitleColor) || this.primaryTextColor,
			yAxisLabelColor: ((_this$xyChart68 = this.xyChart) === null || _this$xyChart68 === void 0 ? void 0 : _this$xyChart68.yAxisLabelColor) || this.primaryTextColor,
			yAxisTickColor: ((_this$xyChart69 = this.xyChart) === null || _this$xyChart69 === void 0 ? void 0 : _this$xyChart69.yAxisTickColor) || this.primaryTextColor,
			yAxisLineColor: ((_this$xyChart70 = this.xyChart) === null || _this$xyChart70 === void 0 ? void 0 : _this$xyChart70.yAxisLineColor) || this.primaryTextColor,
			plotColorPalette: ((_this$xyChart71 = this.xyChart) === null || _this$xyChart71 === void 0 ? void 0 : _this$xyChart71.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || primaryColor;
		this.git1 = this.git1 || secondaryColor;
		this.git2 = this.git2 || tertiaryColor;
		this.git3 = this.git3 || adjust(primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
}, __name(_Class6, "Theme"), _Class6);
var getThemeVariables6 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme6();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme7 = (_Class7 = class {
	constructor() {
		this.background = "#333";
		this.primaryColor = "#1f2020";
		this.secondaryColor = lighten(this.primaryColor, 16);
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = invert(this.background);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.mainBkg = "#2a2020";
		this.secondBkg = "calculated";
		this.mainContrastColor = "lightgrey";
		this.darkTextColor = lighten(invert("#323D47"), 10);
		this.border1 = "#ccc";
		this.border2 = rgba(255, 255, 255, .25);
		this.arrowheadColor = invert(this.background);
		this.fontFamily = "arial, sans-serif";
		this.fontSize = "14px";
		this.labelBackground = "#181818";
		this.textColor = "#ccc";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 3;
		this.strokeWidth = 1;
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "#333";
		this.THEME_COLOR_LIMIT = 12;
		this.fontFamily = "arial, sans-serif";
		this.fontSize = "14px";
		this.useGradient = true;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "drop-shadow( 1px 2px 2px rgba(185,185,185,0.2))";
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.noteFontWeight = "normal";
		this.fontWeight = "normal";
	}
	updateColors() {
		var _this$vennTitleTextCo7, _this$vennSetTextColo7, _this$xyChart72, _this$xyChart73, _this$xyChart74, _this$xyChart75, _this$xyChart76, _this$xyChart77, _this$xyChart78, _this$xyChart79, _this$xyChart80, _this$xyChart81, _this$xyChart82;
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#333";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.border1;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		this.rectBkgColor = this.rectBkgColor || this.tertiaryColor;
		this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || this.primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(this.primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, {
			h: 210,
			l: 150
		});
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		if (this.darkMode) for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 75);
		else for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 25);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || this.primaryColor;
		this.fillType1 = this.fillType1 || this.secondaryColor;
		this.fillType2 = this.fillType2 || adjust(this.primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(this.primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(this.primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || this.tertiaryColor;
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = (_this$vennTitleTextCo7 = this.vennTitleTextColor) !== null && _this$vennTitleTextCo7 !== void 0 ? _this$vennTitleTextCo7 : this.titleColor;
		this.vennSetTextColor = (_this$vennSetTextColo7 = this.vennSetTextColor) !== null && _this$vennSetTextColo7 !== void 0 ? _this$vennSetTextColo7 : this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: ((_this$xyChart72 = this.xyChart) === null || _this$xyChart72 === void 0 ? void 0 : _this$xyChart72.backgroundColor) || this.background,
			titleColor: ((_this$xyChart73 = this.xyChart) === null || _this$xyChart73 === void 0 ? void 0 : _this$xyChart73.titleColor) || this.primaryTextColor,
			xAxisTitleColor: ((_this$xyChart74 = this.xyChart) === null || _this$xyChart74 === void 0 ? void 0 : _this$xyChart74.xAxisTitleColor) || this.primaryTextColor,
			xAxisLabelColor: ((_this$xyChart75 = this.xyChart) === null || _this$xyChart75 === void 0 ? void 0 : _this$xyChart75.xAxisLabelColor) || this.primaryTextColor,
			xAxisTickColor: ((_this$xyChart76 = this.xyChart) === null || _this$xyChart76 === void 0 ? void 0 : _this$xyChart76.xAxisTickColor) || this.primaryTextColor,
			xAxisLineColor: ((_this$xyChart77 = this.xyChart) === null || _this$xyChart77 === void 0 ? void 0 : _this$xyChart77.xAxisLineColor) || this.primaryTextColor,
			yAxisTitleColor: ((_this$xyChart78 = this.xyChart) === null || _this$xyChart78 === void 0 ? void 0 : _this$xyChart78.yAxisTitleColor) || this.primaryTextColor,
			yAxisLabelColor: ((_this$xyChart79 = this.xyChart) === null || _this$xyChart79 === void 0 ? void 0 : _this$xyChart79.yAxisLabelColor) || this.primaryTextColor,
			yAxisTickColor: ((_this$xyChart80 = this.xyChart) === null || _this$xyChart80 === void 0 ? void 0 : _this$xyChart80.yAxisTickColor) || this.primaryTextColor,
			yAxisLineColor: ((_this$xyChart81 = this.xyChart) === null || _this$xyChart81 === void 0 ? void 0 : _this$xyChart81.yAxisLineColor) || this.primaryTextColor,
			plotColorPalette: ((_this$xyChart82 = this.xyChart) === null || _this$xyChart82 === void 0 ? void 0 : _this$xyChart82.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || "#0b0000";
		this.git1 = this.git1 || "#4d1037";
		this.git2 = this.git2 || "#3f5258";
		this.git3 = this.git3 || "#4f2f1b";
		this.git4 = this.git4 || "#6e0a0a";
		this.git5 = this.git5 || "#3b0048";
		this.git6 = this.git6 || "#995a01";
		this.git7 = this.git7 || "#154706";
		this.gitDarkMode = true;
		if (this.gitDarkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
}, __name(_Class7, "Theme"), _Class7);
var getThemeVariables7 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme7();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme8 = (_Class8 = class {
	constructor() {
		this.background = "#ffffff";
		this.primaryColor = "#cccccc";
		this.mainBkg = "#ffffff";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "#28253D";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 12;
		this.strokeWidth = 2;
		this.primaryBorderColor = mkBorder("#28253D", this.darkMode);
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.nodeBorder = "#28253D";
		this.stateBorder = "#28253D";
		this.useGradient = false;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "url(#drop-shadow)";
		this.nodeShadow = true;
		this.tertiaryColor = "#ffffff";
		this.clusterBkg = "#F9F9FB";
		this.clusterBorder = "#BDBCCC";
		this.noteBorderColor = "#FACC15";
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.actorBorder = "#28253D";
		this.filterColor = "#000000";
	}
	updateColors() {
		var _this$vennTitleTextCo8, _this$vennSetTextColo8, _this$xyChart83, _this$xyChart84, _this$xyChart85, _this$xyChart86, _this$xyChart87, _this$xyChart88, _this$xyChart89, _this$xyChart90, _this$xyChart91, _this$xyChart92, _this$xyChart93, _this$commitLineColor;
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#28253D");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#FEF9C3";
		this.noteTextColor = this.noteTextColor || "#28253D";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.primaryBorderColor;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.noteFontWeight = 600;
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		this.rectBkgColor = this.rectBkgColor || this.tertiaryColor;
		const primaryColor = "#ECECFE";
		const secondaryColor = "#E9E9F1";
		const tertiaryColor = adjust(primaryColor, {
			h: 180,
			l: 5
		});
		this.sectionBkgColor = this.sectionBkgColor || tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.compositeTitleBackground = "#F9F9FB";
		this.altBackground = "#F9F9FB";
		this.stateEdgeLabelBackground = "#FFFFFF";
		this.fontWeight = 600;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = this.mainBkg;
		if (this.darkMode) for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 75);
		else for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 25);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || primaryColor;
		this.fillType1 = this.fillType1 || secondaryColor;
		this.fillType2 = this.fillType2 || adjust(primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || primaryColor;
		this.pie2 = this.pie2 || secondaryColor;
		this.pie3 = this.pie3 || tertiaryColor;
		this.pie4 = this.pie4 || adjust(primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = (_this$vennTitleTextCo8 = this.vennTitleTextColor) !== null && _this$vennTitleTextCo8 !== void 0 ? _this$vennTitleTextCo8 : this.titleColor;
		this.vennSetTextColor = (_this$vennSetTextColo8 = this.vennSetTextColor) !== null && _this$vennSetTextColo8 !== void 0 ? _this$vennSetTextColo8 : this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: ((_this$xyChart83 = this.xyChart) === null || _this$xyChart83 === void 0 ? void 0 : _this$xyChart83.backgroundColor) || this.background,
			titleColor: ((_this$xyChart84 = this.xyChart) === null || _this$xyChart84 === void 0 ? void 0 : _this$xyChart84.titleColor) || this.primaryTextColor,
			xAxisTitleColor: ((_this$xyChart85 = this.xyChart) === null || _this$xyChart85 === void 0 ? void 0 : _this$xyChart85.xAxisTitleColor) || this.primaryTextColor,
			xAxisLabelColor: ((_this$xyChart86 = this.xyChart) === null || _this$xyChart86 === void 0 ? void 0 : _this$xyChart86.xAxisLabelColor) || this.primaryTextColor,
			xAxisTickColor: ((_this$xyChart87 = this.xyChart) === null || _this$xyChart87 === void 0 ? void 0 : _this$xyChart87.xAxisTickColor) || this.primaryTextColor,
			xAxisLineColor: ((_this$xyChart88 = this.xyChart) === null || _this$xyChart88 === void 0 ? void 0 : _this$xyChart88.xAxisLineColor) || this.primaryTextColor,
			yAxisTitleColor: ((_this$xyChart89 = this.xyChart) === null || _this$xyChart89 === void 0 ? void 0 : _this$xyChart89.yAxisTitleColor) || this.primaryTextColor,
			yAxisLabelColor: ((_this$xyChart90 = this.xyChart) === null || _this$xyChart90 === void 0 ? void 0 : _this$xyChart90.yAxisLabelColor) || this.primaryTextColor,
			yAxisTickColor: ((_this$xyChart91 = this.xyChart) === null || _this$xyChart91 === void 0 ? void 0 : _this$xyChart91.yAxisTickColor) || this.primaryTextColor,
			yAxisLineColor: ((_this$xyChart92 = this.xyChart) === null || _this$xyChart92 === void 0 ? void 0 : _this$xyChart92.yAxisLineColor) || this.primaryTextColor,
			plotColorPalette: ((_this$xyChart93 = this.xyChart) === null || _this$xyChart93 === void 0 ? void 0 : _this$xyChart93.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.requirementEdgeLabelBackground = "#FFFFFF";
		this.git0 = this.git0 || primaryColor;
		this.git1 = this.git1 || secondaryColor;
		this.git2 = this.git2 || tertiaryColor;
		this.git3 = this.git3 || adjust(primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.commitLineColor = (_this$commitLineColor = this.commitLineColor) !== null && _this$commitLineColor !== void 0 ? _this$commitLineColor : "#BDBCCC";
		this.erEdgeLabelBackground = "#FFFFFF";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
}, __name(_Class8, "Theme"), _Class8);
var getThemeVariables8 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme8();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme9 = (_Class9 = class {
	constructor() {
		var _this$noteBkgColor, _this$noteTextColor;
		this.background = "#333";
		this.primaryColor = "#1f2020";
		this.secondaryColor = lighten(this.primaryColor, 16);
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = invert(this.background);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.mainBkg = "#111113";
		this.secondBkg = "calculated";
		this.mainContrastColor = "lightgrey";
		this.darkTextColor = lighten(invert("#323D47"), 10);
		this.border1 = "#ccc";
		this.border2 = rgba(255, 255, 255, .25);
		this.arrowheadColor = invert(this.background);
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.labelBackground = "#111113";
		this.textColor = "#ccc";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 12;
		this.strokeWidth = 2;
		this.noteBkgColor = (_this$noteBkgColor = this.noteBkgColor) !== null && _this$noteBkgColor !== void 0 ? _this$noteBkgColor : "#FEF9C3";
		this.noteTextColor = (_this$noteTextColor = this.noteTextColor) !== null && _this$noteTextColor !== void 0 ? _this$noteTextColor : "#28253D";
		this.THEME_COLOR_LIMIT = 12;
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.nodeBorder = "#FFFFFF";
		this.stateBorder = "#FFFFFF";
		this.useGradient = false;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "url(#drop-shadow)";
		this.nodeShadow = true;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.clusterBkg = "#1E1A2E";
		this.clusterBorder = "#BDBCCC";
		this.noteBorderColor = "#FACC15";
		this.noteFontWeight = 600;
		this.filterColor = "#FFFFFF";
	}
	updateColors() {
		var _this$vennTitleTextCo9, _this$vennSetTextColo9, _this$xyChart94, _this$xyChart95, _this$xyChart96, _this$xyChart97, _this$xyChart98, _this$xyChart99, _this$xyChart100, _this$xyChart101, _this$xyChart102, _this$xyChart103, _this$xyChart104, _this$commitLineColor2;
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#FFFFFF");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#FFFFFF";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.border1;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = "#FFFFFF";
		this.signalColor = "#FFFFFF";
		this.labelBoxBorderColor = "#BDBCCC";
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		this.rectBkgColor = this.rectBkgColor || this.tertiaryColor;
		this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || this.primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(this.primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.compositeBackground = "#16141F";
		this.altBackground = "#16141F";
		this.compositeTitleBackground = "#16141F";
		this.stateEdgeLabelBackground = "#16141F";
		this.fontWeight = 600;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || this.primaryColor;
		this.cScale1 = this.cScale1 || this.secondaryColor;
		this.cScale2 = this.cScale2 || this.tertiaryColor;
		this.cScale3 = this.cScale3 || adjust(this.primaryColor, { h: 30 });
		this.cScale4 = this.cScale4 || adjust(this.primaryColor, { h: 60 });
		this.cScale5 = this.cScale5 || adjust(this.primaryColor, { h: 90 });
		this.cScale6 = this.cScale6 || adjust(this.primaryColor, { h: 120 });
		this.cScale7 = this.cScale7 || adjust(this.primaryColor, { h: 150 });
		this.cScale8 = this.cScale8 || adjust(this.primaryColor, {
			h: 210,
			l: 150
		});
		this.cScale9 = this.cScale9 || adjust(this.primaryColor, { h: 270 });
		this.cScale10 = this.cScale10 || adjust(this.primaryColor, { h: 300 });
		this.cScale11 = this.cScale11 || adjust(this.primaryColor, { h: 330 });
		if (this.darkMode) for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 75);
		else for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScale" + i] = darken(this["cScale" + i], 25);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || this.primaryColor;
		this.fillType1 = this.fillType1 || this.secondaryColor;
		this.fillType2 = this.fillType2 || adjust(this.primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(this.primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(this.primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || this.tertiaryColor;
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = (_this$vennTitleTextCo9 = this.vennTitleTextColor) !== null && _this$vennTitleTextCo9 !== void 0 ? _this$vennTitleTextCo9 : this.titleColor;
		this.vennSetTextColor = (_this$vennSetTextColo9 = this.vennSetTextColor) !== null && _this$vennSetTextColo9 !== void 0 ? _this$vennSetTextColo9 : this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: ((_this$xyChart94 = this.xyChart) === null || _this$xyChart94 === void 0 ? void 0 : _this$xyChart94.backgroundColor) || this.background,
			titleColor: ((_this$xyChart95 = this.xyChart) === null || _this$xyChart95 === void 0 ? void 0 : _this$xyChart95.titleColor) || this.primaryTextColor,
			xAxisTitleColor: ((_this$xyChart96 = this.xyChart) === null || _this$xyChart96 === void 0 ? void 0 : _this$xyChart96.xAxisTitleColor) || this.primaryTextColor,
			xAxisLabelColor: ((_this$xyChart97 = this.xyChart) === null || _this$xyChart97 === void 0 ? void 0 : _this$xyChart97.xAxisLabelColor) || this.primaryTextColor,
			xAxisTickColor: ((_this$xyChart98 = this.xyChart) === null || _this$xyChart98 === void 0 ? void 0 : _this$xyChart98.xAxisTickColor) || this.primaryTextColor,
			xAxisLineColor: ((_this$xyChart99 = this.xyChart) === null || _this$xyChart99 === void 0 ? void 0 : _this$xyChart99.xAxisLineColor) || this.primaryTextColor,
			yAxisTitleColor: ((_this$xyChart100 = this.xyChart) === null || _this$xyChart100 === void 0 ? void 0 : _this$xyChart100.yAxisTitleColor) || this.primaryTextColor,
			yAxisLabelColor: ((_this$xyChart101 = this.xyChart) === null || _this$xyChart101 === void 0 ? void 0 : _this$xyChart101.yAxisLabelColor) || this.primaryTextColor,
			yAxisTickColor: ((_this$xyChart102 = this.xyChart) === null || _this$xyChart102 === void 0 ? void 0 : _this$xyChart102.yAxisTickColor) || this.primaryTextColor,
			yAxisLineColor: ((_this$xyChart103 = this.xyChart) === null || _this$xyChart103 === void 0 ? void 0 : _this$xyChart103.yAxisLineColor) || this.primaryTextColor,
			plotColorPalette: ((_this$xyChart104 = this.xyChart) === null || _this$xyChart104 === void 0 ? void 0 : _this$xyChart104.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.requirementEdgeLabelBackground = "#16141F";
		this.git0 = this.git0 || this.primaryColor;
		this.git1 = this.git1 || this.secondaryColor;
		this.git2 = this.git2 || this.tertiaryColor;
		this.git3 = this.git3 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(this.primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.commitLineColor = (_this$commitLineColor2 = this.commitLineColor) !== null && _this$commitLineColor2 !== void 0 ? _this$commitLineColor2 : "#BDBCCC";
		this.erEdgeLabelBackground = "#16141F";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
}, __name(_Class9, "Theme"), _Class9);
var getThemeVariables9 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme9();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme10 = (_Class10 = class {
	constructor() {
		this.background = "#ffffff";
		this.primaryColor = "#cccccc";
		this.mainBkg = "#ffffff";
		this.noteBkgColor = "#fff5ad";
		this.noteTextColor = "#28253D";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 12;
		this.strokeWidth = 2;
		this.primaryBorderColor = mkBorder(this.primaryColor, this.darkMode);
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.nodeBorder = "#28253D";
		this.stateBorder = "#28253D";
		this.useGradient = false;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "url(#drop-shadow)";
		this.nodeShadow = true;
		this.tertiaryColor = "#ffffff";
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.actorBorder = "#28253D";
		this.noteBorderColor = "#FACC15";
		this.noteFontWeight = 600;
		this.borderColorArray = [
			"#E879F9",
			"#2DD4BF",
			"#FB923C",
			"#22D3EE",
			"#4ADE80",
			"#A78BFA",
			"#F87171",
			"#FACC15",
			"#818CF8",
			"#A3E635 ",
			"#38BDF8",
			"#FB7185"
		];
		this.bkgColorArray = [
			"#FDF4FF",
			"#F0FDFA",
			"#FFF7ED",
			"#ECFEFF",
			"#F0FDF4",
			"#F5F3FF",
			"#FEF2F2",
			"#FEFCE8",
			"#EEF2FF",
			"#F7FEE7",
			"#F0F9FF",
			"#FFF1F2"
		];
		this.filterColor = "#000000";
	}
	updateColors() {
		var _this$vennTitleTextCo10, _this$vennSetTextColo10, _this$xyChart105, _this$xyChart106, _this$xyChart107, _this$xyChart108, _this$xyChart109, _this$xyChart110, _this$xyChart111, _this$xyChart112, _this$xyChart113, _this$xyChart114, _this$xyChart115, _this$commitLineColor3;
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#28253D");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#28253D";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.primaryBorderColor;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		this.rectBkgColor = this.rectBkgColor || this.tertiaryColor;
		const primaryColor = "#ECECFE";
		const secondaryColor = "#E9E9F1";
		const tertiaryColor = adjust(primaryColor, {
			h: 180,
			l: 5
		});
		this.sectionBkgColor = this.sectionBkgColor || tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || "#f4a8ff";
		this.cScale1 = this.cScale1 || "#46ecd5";
		this.cScale2 = this.cScale2 || "#ffb86a";
		this.cScale3 = this.cScale3 || "#dab2ff";
		this.cScale4 = this.cScale4 || "#7bf1a8";
		this.cScale5 = this.cScale5 || "#c4b4ff";
		this.cScale6 = this.cScale6 || "#ffa2a2";
		this.cScale7 = this.cScale7 || "#ffdf20";
		this.cScale8 = this.cScale8 || "#a3b3ff";
		this.cScale9 = this.cScale9 || "#bbf451";
		this.cScale10 = this.cScale10 || "#74d4ff";
		this.cScale11 = this.cScale11 || "#ffa1ad";
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = this["cScaleLabel" + i] || this.scaleLabelColor;
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || primaryColor;
		this.fillType1 = this.fillType1 || secondaryColor;
		this.fillType2 = this.fillType2 || adjust(primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || primaryColor;
		this.pie2 = this.pie2 || secondaryColor;
		this.pie3 = this.pie3 || tertiaryColor;
		this.pie4 = this.pie4 || adjust(primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = (_this$vennTitleTextCo10 = this.vennTitleTextColor) !== null && _this$vennTitleTextCo10 !== void 0 ? _this$vennTitleTextCo10 : this.titleColor;
		this.vennSetTextColor = (_this$vennSetTextColo10 = this.vennSetTextColor) !== null && _this$vennSetTextColo10 !== void 0 ? _this$vennSetTextColo10 : this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: ((_this$xyChart105 = this.xyChart) === null || _this$xyChart105 === void 0 ? void 0 : _this$xyChart105.backgroundColor) || this.background,
			titleColor: ((_this$xyChart106 = this.xyChart) === null || _this$xyChart106 === void 0 ? void 0 : _this$xyChart106.titleColor) || this.primaryTextColor,
			xAxisTitleColor: ((_this$xyChart107 = this.xyChart) === null || _this$xyChart107 === void 0 ? void 0 : _this$xyChart107.xAxisTitleColor) || this.primaryTextColor,
			xAxisLabelColor: ((_this$xyChart108 = this.xyChart) === null || _this$xyChart108 === void 0 ? void 0 : _this$xyChart108.xAxisLabelColor) || this.primaryTextColor,
			xAxisTickColor: ((_this$xyChart109 = this.xyChart) === null || _this$xyChart109 === void 0 ? void 0 : _this$xyChart109.xAxisTickColor) || this.primaryTextColor,
			xAxisLineColor: ((_this$xyChart110 = this.xyChart) === null || _this$xyChart110 === void 0 ? void 0 : _this$xyChart110.xAxisLineColor) || this.primaryTextColor,
			yAxisTitleColor: ((_this$xyChart111 = this.xyChart) === null || _this$xyChart111 === void 0 ? void 0 : _this$xyChart111.yAxisTitleColor) || this.primaryTextColor,
			yAxisLabelColor: ((_this$xyChart112 = this.xyChart) === null || _this$xyChart112 === void 0 ? void 0 : _this$xyChart112.yAxisLabelColor) || this.primaryTextColor,
			yAxisTickColor: ((_this$xyChart113 = this.xyChart) === null || _this$xyChart113 === void 0 ? void 0 : _this$xyChart113.yAxisTickColor) || this.primaryTextColor,
			yAxisLineColor: ((_this$xyChart114 = this.xyChart) === null || _this$xyChart114 === void 0 ? void 0 : _this$xyChart114.yAxisLineColor) || this.primaryTextColor,
			plotColorPalette: ((_this$xyChart115 = this.xyChart) === null || _this$xyChart115 === void 0 ? void 0 : _this$xyChart115.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || primaryColor;
		this.git1 = this.git1 || secondaryColor;
		this.git2 = this.git2 || tertiaryColor;
		this.git3 = this.git3 || adjust(primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLineColor = (_this$commitLineColor3 = this.commitLineColor) !== null && _this$commitLineColor3 !== void 0 ? _this$commitLineColor3 : "#BDBCCC";
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.fontWeight = 600;
		this.erEdgeLabelBackground = "#FFFFFF";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
}, __name(_Class10, "Theme"), _Class10);
var getThemeVariables10 = /* @__PURE__ */ __name((userOverrides) => {
	const theme = new Theme10();
	theme.calculate(userOverrides);
	return theme;
}, "getThemeVariables");
var Theme11 = (_Class11 = class {
	constructor() {
		var _this$noteBkgColor2, _this$noteTextColor2;
		this.background = "#333";
		this.primaryColor = "#1f2020";
		this.secondaryColor = lighten(this.primaryColor, 16);
		this.tertiaryColor = adjust(this.primaryColor, { h: -160 });
		this.primaryBorderColor = invert(this.background);
		this.secondaryBorderColor = mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = mkBorder(this.tertiaryColor, this.darkMode);
		this.primaryTextColor = invert(this.primaryColor);
		this.secondaryTextColor = invert(this.secondaryColor);
		this.tertiaryTextColor = invert(this.tertiaryColor);
		this.mainBkg = "#111113";
		this.secondBkg = "calculated";
		this.mainContrastColor = "lightgrey";
		this.darkTextColor = lighten(invert("#323D47"), 10);
		this.border1 = "#ccc";
		this.border2 = rgba(255, 255, 255, .25);
		this.arrowheadColor = invert(this.background);
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.labelBackground = "#111113";
		this.textColor = "#ccc";
		this.THEME_COLOR_LIMIT = 12;
		this.radius = 12;
		this.strokeWidth = 2;
		this.noteBkgColor = (_this$noteBkgColor2 = this.noteBkgColor) !== null && _this$noteBkgColor2 !== void 0 ? _this$noteBkgColor2 : "#FEF9C3";
		this.noteTextColor = (_this$noteTextColor2 = this.noteTextColor) !== null && _this$noteTextColor2 !== void 0 ? _this$noteTextColor2 : "#28253D";
		this.THEME_COLOR_LIMIT = 12;
		this.fontFamily = "\"Recursive Variable\", arial, sans-serif";
		this.fontSize = "14px";
		this.nodeBorder = "#FFFFFF";
		this.stateBorder = "#FFFFFF";
		this.useGradient = false;
		this.gradientStart = "#0042eb";
		this.gradientStop = "#eb0042";
		this.dropShadow = "url(#drop-shadow)";
		this.nodeShadow = true;
		this.archEdgeColor = "calculated";
		this.archEdgeArrowColor = "calculated";
		this.archEdgeWidth = "3";
		this.archGroupBorderColor = this.primaryBorderColor;
		this.archGroupBorderWidth = "2px";
		this.clusterBkg = "#1E1A2E";
		this.clusterBorder = "#BDBCCC";
		this.noteBorderColor = "#FACC15";
		this.noteFontWeight = 600;
		this.borderColorArray = [
			"#E879F9",
			"#2DD4BF",
			"#FB923C",
			"#22D3EE",
			"#4ADE80",
			"#A78BFA",
			"#F87171",
			"#FACC15",
			"#818CF8",
			"#A3E635 ",
			"#38BDF8",
			"#FB7185"
		];
		this.bkgColorArray = [];
		this.filterColor = "#FFFFFF";
	}
	updateColors() {
		var _this$vennTitleTextCo11, _this$vennSetTextColo11, _this$xyChart116, _this$xyChart117, _this$xyChart118, _this$xyChart119, _this$xyChart120, _this$xyChart121, _this$xyChart122, _this$xyChart123, _this$xyChart124, _this$xyChart125, _this$xyChart126, _this$commitLineColor4;
		this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#FFFFFF");
		this.secondaryColor = this.secondaryColor || adjust(this.primaryColor, { h: -120 });
		this.tertiaryColor = this.tertiaryColor || adjust(this.primaryColor, {
			h: 180,
			l: 5
		});
		this.primaryBorderColor = this.primaryBorderColor || mkBorder(this.primaryColor, this.darkMode);
		this.secondaryBorderColor = this.secondaryBorderColor || mkBorder(this.secondaryColor, this.darkMode);
		this.tertiaryBorderColor = this.tertiaryBorderColor || mkBorder(this.tertiaryColor, this.darkMode);
		this.noteBorderColor = this.noteBorderColor || mkBorder(this.noteBkgColor, this.darkMode);
		this.noteBkgColor = this.noteBkgColor || "#fff5ad";
		this.noteTextColor = this.noteTextColor || "#FFFFFF";
		this.secondaryTextColor = this.secondaryTextColor || invert(this.secondaryColor);
		this.tertiaryTextColor = this.tertiaryTextColor || invert(this.tertiaryColor);
		this.lineColor = this.lineColor || invert(this.background);
		this.arrowheadColor = this.arrowheadColor || invert(this.background);
		this.textColor = this.textColor || this.primaryTextColor;
		this.border2 = this.border2 || this.tertiaryBorderColor;
		this.nodeBkg = this.nodeBkg || this.primaryColor;
		this.mainBkg = this.mainBkg || this.primaryColor;
		this.nodeBorder = this.nodeBorder || this.border1;
		this.clusterBkg = this.clusterBkg || this.tertiaryColor;
		this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor;
		this.defaultLinkColor = this.defaultLinkColor || this.lineColor;
		this.titleColor = this.titleColor || this.tertiaryTextColor;
		this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.nodeTextColor = this.nodeTextColor || this.primaryTextColor;
		this.actorBorder = "#FFFFFF";
		this.signalColor = "#FFFFFF";
		this.labelBoxBorderColor = "#BDBCCC";
		this.actorBorder = this.actorBorder || this.primaryBorderColor;
		this.actorBkg = this.actorBkg || this.mainBkg;
		this.actorTextColor = this.actorTextColor || this.primaryTextColor;
		this.actorLineColor = this.actorLineColor || this.actorBorder;
		this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg;
		this.signalColor = this.signalColor || this.textColor;
		this.signalTextColor = this.signalTextColor || this.textColor;
		this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder;
		this.labelTextColor = this.labelTextColor || this.actorTextColor;
		this.loopTextColor = this.loopTextColor || this.actorTextColor;
		this.activationBorderColor = this.activationBorderColor || darken(this.secondaryColor, 10);
		this.activationBkgColor = this.activationBkgColor || this.secondaryColor;
		this.sequenceNumberColor = this.sequenceNumberColor || invert(this.lineColor);
		this.rectBkgColor = this.rectBkgColor || this.tertiaryColor;
		this.rootLabelColor = "#FFFFFF";
		this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor;
		this.altSectionBkgColor = this.altSectionBkgColor || "white";
		this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor;
		this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor;
		this.excludeBkgColor = this.excludeBkgColor || "#eeeeee";
		this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor;
		this.taskBkgColor = this.taskBkgColor || this.primaryColor;
		this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor;
		this.activeTaskBkgColor = this.activeTaskBkgColor || lighten(this.primaryColor, 23);
		this.gridColor = this.gridColor || "lightgrey";
		this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey";
		this.doneTaskBorderColor = this.doneTaskBorderColor || "grey";
		this.critBorderColor = this.critBorderColor || "#ff8888";
		this.critBkgColor = this.critBkgColor || "red";
		this.todayLineColor = this.todayLineColor || "red";
		this.taskTextColor = this.taskTextColor || this.textColor;
		this.vertLineColor = this.vertLineColor || this.primaryBorderColor;
		this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor;
		this.taskTextLightColor = this.taskTextLightColor || this.textColor;
		this.taskTextColor = this.taskTextColor || this.primaryTextColor;
		this.taskTextDarkColor = this.taskTextDarkColor || this.textColor;
		this.taskTextClickableColor = this.taskTextClickableColor || "#003163";
		this.archEdgeColor = this.lineColor;
		this.archEdgeArrowColor = this.lineColor;
		this.personBorder = this.personBorder || this.primaryBorderColor;
		this.personBkg = this.personBkg || this.mainBkg;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.transitionLabelColor = this.transitionLabelColor || this.textColor;
		this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor;
		this.stateBkg = this.stateBkg || this.mainBkg;
		this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg;
		this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor;
		this.altBackground = this.altBackground || "#f0f0f0";
		this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg;
		this.compositeBorder = this.compositeBorder || this.nodeBorder;
		this.innerEndBackground = this.nodeBorder;
		this.errorBkgColor = this.errorBkgColor || this.tertiaryColor;
		this.errorTextColor = this.errorTextColor || this.tertiaryTextColor;
		this.transitionColor = this.transitionColor || this.lineColor;
		this.specialStateColor = this.lineColor;
		this.cScale0 = this.cScale0 || "#f4a8ff";
		this.cScale1 = this.cScale1 || "#46ecd5";
		this.cScale2 = this.cScale2 || "#ffb86a";
		this.cScale3 = this.cScale3 || "#dab2ff";
		this.cScale4 = this.cScale4 || "#7bf1a8";
		this.cScale5 = this.cScale5 || "#c4b4ff";
		this.cScale6 = this.cScale6 || "#ffa2a2";
		this.cScale7 = this.cScale7 || "#ffdf20";
		this.cScale8 = this.cScale8 || "#a3b3ff";
		this.cScale9 = this.cScale9 || "#bbf451";
		this.cScale10 = this.cScale10 || "#74d4ff";
		this.cScale11 = this.cScale11 || "#ffa1ad";
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleInv" + i] = this["cScaleInv" + i] || invert(this["cScale" + i]);
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) if (this.darkMode) this["cScalePeer" + i] = this["cScalePeer" + i] || lighten(this["cScale" + i], 10);
		else this["cScalePeer" + i] = this["cScalePeer" + i] || darken(this["cScale" + i], 10);
		this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
		for (let i = 0; i < this.THEME_COLOR_LIMIT; i++) this["cScaleLabel" + i] = darken(this["cScale" + i], 75);
		const multiplier = this.darkMode ? -4 : -1;
		for (let i = 0; i < 5; i++) {
			this["surface" + i] = this["surface" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (5 + i * 3)
			});
			this["surfacePeer" + i] = this["surfacePeer" + i] || adjust(this.mainBkg, {
				h: 180,
				s: -15,
				l: multiplier * (8 + i * 3)
			});
		}
		this.classText = this.classText || this.textColor;
		this.fillType0 = this.fillType0 || this.primaryColor;
		this.fillType1 = this.fillType1 || this.secondaryColor;
		this.fillType2 = this.fillType2 || adjust(this.primaryColor, { h: 64 });
		this.fillType3 = this.fillType3 || adjust(this.secondaryColor, { h: 64 });
		this.fillType4 = this.fillType4 || adjust(this.primaryColor, { h: -64 });
		this.fillType5 = this.fillType5 || adjust(this.secondaryColor, { h: -64 });
		this.fillType6 = this.fillType6 || adjust(this.primaryColor, { h: 128 });
		this.fillType7 = this.fillType7 || adjust(this.secondaryColor, { h: 128 });
		this.pie1 = this.pie1 || this.primaryColor;
		this.pie2 = this.pie2 || this.secondaryColor;
		this.pie3 = this.pie3 || this.tertiaryColor;
		this.pie4 = this.pie4 || adjust(this.primaryColor, { l: -10 });
		this.pie5 = this.pie5 || adjust(this.secondaryColor, { l: -10 });
		this.pie6 = this.pie6 || adjust(this.tertiaryColor, { l: -10 });
		this.pie7 = this.pie7 || adjust(this.primaryColor, {
			h: 60,
			l: -10
		});
		this.pie8 = this.pie8 || adjust(this.primaryColor, {
			h: -60,
			l: -10
		});
		this.pie9 = this.pie9 || adjust(this.primaryColor, {
			h: 120,
			l: 0
		});
		this.pie10 = this.pie10 || adjust(this.primaryColor, {
			h: 60,
			l: -20
		});
		this.pie11 = this.pie11 || adjust(this.primaryColor, {
			h: -60,
			l: -20
		});
		this.pie12 = this.pie12 || adjust(this.primaryColor, {
			h: 120,
			l: -10
		});
		this.pieTitleTextSize = this.pieTitleTextSize || "25px";
		this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor;
		this.pieSectionTextSize = this.pieSectionTextSize || "17px";
		this.pieSectionTextColor = this.pieSectionTextColor || this.textColor;
		this.pieLegendTextSize = this.pieLegendTextSize || "17px";
		this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor;
		this.pieStrokeColor = this.pieStrokeColor || "black";
		this.pieStrokeWidth = this.pieStrokeWidth || "2px";
		this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px";
		this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black";
		this.pieOpacity = this.pieOpacity || "0.7";
		this.vennTitleTextColor = (_this$vennTitleTextCo11 = this.vennTitleTextColor) !== null && _this$vennTitleTextCo11 !== void 0 ? _this$vennTitleTextCo11 : this.titleColor;
		this.vennSetTextColor = (_this$vennSetTextColo11 = this.vennSetTextColor) !== null && _this$vennSetTextColo11 !== void 0 ? _this$vennSetTextColo11 : this.textColor;
		this.quadrant1Fill = this.quadrant1Fill || this.primaryColor;
		this.quadrant2Fill = this.quadrant2Fill || adjust(this.primaryColor, {
			r: 5,
			g: 5,
			b: 5
		});
		this.quadrant3Fill = this.quadrant3Fill || adjust(this.primaryColor, {
			r: 10,
			g: 10,
			b: 10
		});
		this.quadrant4Fill = this.quadrant4Fill || adjust(this.primaryColor, {
			r: 15,
			g: 15,
			b: 15
		});
		this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor;
		this.quadrant2TextFill = this.quadrant2TextFill || adjust(this.primaryTextColor, {
			r: -5,
			g: -5,
			b: -5
		});
		this.quadrant3TextFill = this.quadrant3TextFill || adjust(this.primaryTextColor, {
			r: -10,
			g: -10,
			b: -10
		});
		this.quadrant4TextFill = this.quadrant4TextFill || adjust(this.primaryTextColor, {
			r: -15,
			g: -15,
			b: -15
		});
		this.quadrantPointFill = this.quadrantPointFill || isDark(this.quadrant1Fill) ? lighten(this.quadrant1Fill) : darken(this.quadrant1Fill);
		this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor;
		this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor;
		this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor;
		this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor;
		this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor;
		this.xyChart = {
			backgroundColor: ((_this$xyChart116 = this.xyChart) === null || _this$xyChart116 === void 0 ? void 0 : _this$xyChart116.backgroundColor) || this.background,
			titleColor: ((_this$xyChart117 = this.xyChart) === null || _this$xyChart117 === void 0 ? void 0 : _this$xyChart117.titleColor) || this.primaryTextColor,
			xAxisTitleColor: ((_this$xyChart118 = this.xyChart) === null || _this$xyChart118 === void 0 ? void 0 : _this$xyChart118.xAxisTitleColor) || this.primaryTextColor,
			xAxisLabelColor: ((_this$xyChart119 = this.xyChart) === null || _this$xyChart119 === void 0 ? void 0 : _this$xyChart119.xAxisLabelColor) || this.primaryTextColor,
			xAxisTickColor: ((_this$xyChart120 = this.xyChart) === null || _this$xyChart120 === void 0 ? void 0 : _this$xyChart120.xAxisTickColor) || this.primaryTextColor,
			xAxisLineColor: ((_this$xyChart121 = this.xyChart) === null || _this$xyChart121 === void 0 ? void 0 : _this$xyChart121.xAxisLineColor) || this.primaryTextColor,
			yAxisTitleColor: ((_this$xyChart122 = this.xyChart) === null || _this$xyChart122 === void 0 ? void 0 : _this$xyChart122.yAxisTitleColor) || this.primaryTextColor,
			yAxisLabelColor: ((_this$xyChart123 = this.xyChart) === null || _this$xyChart123 === void 0 ? void 0 : _this$xyChart123.yAxisLabelColor) || this.primaryTextColor,
			yAxisTickColor: ((_this$xyChart124 = this.xyChart) === null || _this$xyChart124 === void 0 ? void 0 : _this$xyChart124.yAxisTickColor) || this.primaryTextColor,
			yAxisLineColor: ((_this$xyChart125 = this.xyChart) === null || _this$xyChart125 === void 0 ? void 0 : _this$xyChart125.yAxisLineColor) || this.primaryTextColor,
			plotColorPalette: ((_this$xyChart126 = this.xyChart) === null || _this$xyChart126 === void 0 ? void 0 : _this$xyChart126.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
		};
		this.requirementBackground = this.requirementBackground || this.primaryColor;
		this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor;
		this.requirementBorderSize = this.requirementBorderSize || "1";
		this.requirementTextColor = this.requirementTextColor || this.primaryTextColor;
		this.relationColor = this.relationColor || this.lineColor;
		this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? darken(this.secondaryColor, 30) : this.secondaryColor);
		this.relationLabelColor = this.relationLabelColor || this.actorTextColor;
		this.git0 = this.git0 || this.primaryColor;
		this.git1 = this.git1 || this.secondaryColor;
		this.git2 = this.git2 || this.tertiaryColor;
		this.git3 = this.git3 || adjust(this.primaryColor, { h: -30 });
		this.git4 = this.git4 || adjust(this.primaryColor, { h: -60 });
		this.git5 = this.git5 || adjust(this.primaryColor, { h: -90 });
		this.git6 = this.git6 || adjust(this.primaryColor, { h: 60 });
		this.git7 = this.git7 || adjust(this.primaryColor, { h: 120 });
		if (this.darkMode) {
			this.git0 = lighten(this.git0, 25);
			this.git1 = lighten(this.git1, 25);
			this.git2 = lighten(this.git2, 25);
			this.git3 = lighten(this.git3, 25);
			this.git4 = lighten(this.git4, 25);
			this.git5 = lighten(this.git5, 25);
			this.git6 = lighten(this.git6, 25);
			this.git7 = lighten(this.git7, 25);
		} else {
			this.git0 = darken(this.git0, 25);
			this.git1 = darken(this.git1, 25);
			this.git2 = darken(this.git2, 25);
			this.git3 = darken(this.git3, 25);
			this.git4 = darken(this.git4, 25);
			this.git5 = darken(this.git5, 25);
			this.git6 = darken(this.git6, 25);
			this.git7 = darken(this.git7, 25);
		}
		this.gitInv0 = this.gitInv0 || invert(this.git0);
		this.gitInv1 = this.gitInv1 || invert(this.git1);
		this.gitInv2 = this.gitInv2 || invert(this.git2);
		this.gitInv3 = this.gitInv3 || invert(this.git3);
		this.gitInv4 = this.gitInv4 || invert(this.git4);
		this.gitInv5 = this.gitInv5 || invert(this.git5);
		this.gitInv6 = this.gitInv6 || invert(this.git6);
		this.gitInv7 = this.gitInv7 || invert(this.git7);
		this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor);
		this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor;
		this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor;
		this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor;
		this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor;
		this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor;
		this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor;
		this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor;
		this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor;
		this.tagLabelColor = this.tagLabelColor || this.primaryTextColor;
		this.tagLabelBackground = this.tagLabelBackground || this.primaryColor;
		this.tagLabelBorder = this.tagBorder || this.primaryBorderColor;
		this.tagLabelFontSize = this.tagLabelFontSize || "10px";
		this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor;
		this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor;
		this.commitLabelFontSize = this.commitLabelFontSize || "10px";
		this.commitLineColor = (_this$commitLineColor4 = this.commitLineColor) !== null && _this$commitLineColor4 !== void 0 ? _this$commitLineColor4 : "#BDBCCC";
		this.fontWeight = 600;
		this.erEdgeLabelBackground = "#16141F";
		this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || oldAttributeBackgroundColorOdd;
		this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || oldAttributeBackgroundColorEven;
	}
	calculate(overrides) {
		if (typeof overrides !== "object") {
			this.updateColors();
			return;
		}
		const keys = Object.keys(overrides);
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
		this.updateColors();
		keys.forEach((k) => {
			this[k] = overrides[k];
		});
	}
}, __name(_Class11, "Theme"), _Class11);
var themes_default = {
	base: { getThemeVariables },
	dark: { getThemeVariables: getThemeVariables2 },
	default: { getThemeVariables: getThemeVariables3 },
	forest: { getThemeVariables: getThemeVariables4 },
	neutral: { getThemeVariables: getThemeVariables5 },
	neo: { getThemeVariables: getThemeVariables6 },
	"neo-dark": { getThemeVariables: getThemeVariables7 },
	redux: { getThemeVariables: getThemeVariables8 },
	"redux-dark": { getThemeVariables: getThemeVariables9 },
	"redux-color": { getThemeVariables: getThemeVariables10 },
	"redux-dark-color": { getThemeVariables: /* @__PURE__ */ __name((userOverrides) => {
		const theme = new Theme11();
		theme.calculate(userOverrides);
		return theme;
	}, "getThemeVariables") }
};
var config_schema_default = {
	"flowchart": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"subGraphTitleMargin": {
			"top": 0,
			"bottom": 0
		},
		"diagramPadding": 8,
		"htmlLabels": null,
		"nodeSpacing": 50,
		"rankSpacing": 50,
		"curve": "basis",
		"padding": 15,
		"defaultRenderer": "dagre-wrapper",
		"wrappingWidth": 200,
		"inheritDir": false
	},
	"swimlane": {
		"useMaxWidth": true,
		"lineHops": "arc",
		"ignoreCrossLaneEdges": true,
		"optimizeRanksByCrossings": true,
		"automaticLaneOrdering": false
	},
	"sequence": {
		"useMaxWidth": true,
		"hideUnusedParticipants": false,
		"activationWidth": 10,
		"diagramMarginX": 50,
		"diagramMarginY": 10,
		"actorMargin": 50,
		"width": 150,
		"height": 65,
		"boxMargin": 10,
		"boxTextMargin": 5,
		"noteMargin": 10,
		"messageMargin": 35,
		"messageAlign": "center",
		"mirrorActors": true,
		"forceMenus": false,
		"bottomMarginAdj": 1,
		"rightAngles": false,
		"showSequenceNumbers": false,
		"actorFontSize": 14,
		"actorFontFamily": "\"Open Sans\", sans-serif",
		"actorFontWeight": 400,
		"noteFontSize": 14,
		"noteFontFamily": "\"trebuchet ms\", verdana, arial, sans-serif",
		"noteFontWeight": 400,
		"noteAlign": "center",
		"messageFontSize": 16,
		"messageFontFamily": "\"trebuchet ms\", verdana, arial, sans-serif",
		"messageFontWeight": 400,
		"wrap": false,
		"wrapPadding": 10,
		"labelBoxWidth": 50,
		"labelBoxHeight": 20
	},
	"gantt": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"barHeight": 20,
		"barGap": 4,
		"topPadding": 50,
		"rightPadding": 75,
		"leftPadding": 75,
		"gridLineStartPadding": 35,
		"fontSize": 11,
		"sectionFontSize": 11,
		"numberSectionStyles": 4,
		"axisFormat": "%Y-%m-%d",
		"topAxis": false,
		"displayMode": "",
		"weekday": "sunday"
	},
	"journey": {
		"useMaxWidth": true,
		"diagramMarginX": 50,
		"diagramMarginY": 10,
		"leftMargin": 150,
		"maxLabelWidth": 360,
		"width": 150,
		"height": 50,
		"boxMargin": 10,
		"boxTextMargin": 5,
		"noteMargin": 10,
		"messageMargin": 35,
		"messageAlign": "center",
		"bottomMarginAdj": 1,
		"rightAngles": false,
		"taskFontSize": 14,
		"taskFontFamily": "\"Open Sans\", sans-serif",
		"taskMargin": 50,
		"activationWidth": 10,
		"textPlacement": "fo",
		"actorColours": [
			"#8FBC8F",
			"#7CFC00",
			"#00FFFF",
			"#20B2AA",
			"#B0E0E6",
			"#FFFFE0"
		],
		"sectionFills": [
			"#191970",
			"#8B008B",
			"#4B0082",
			"#2F4F4F",
			"#800000",
			"#8B4513",
			"#00008B"
		],
		"sectionColours": ["#fff"],
		"titleColor": "",
		"titleFontFamily": "\"trebuchet ms\", verdana, arial, sans-serif",
		"titleFontSize": "4ex"
	},
	"class": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"arrowMarkerAbsolute": false,
		"dividerMargin": 10,
		"padding": 5,
		"textHeight": 10,
		"defaultRenderer": "dagre-wrapper",
		"htmlLabels": false,
		"hideEmptyMembersBox": false,
		"hierarchicalNamespaces": true
	},
	"state": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"dividerMargin": 10,
		"sizeUnit": 5,
		"padding": 8,
		"textHeight": 10,
		"titleShift": -15,
		"noteMargin": 10,
		"forkWidth": 70,
		"forkHeight": 7,
		"miniPadding": 2,
		"fontSizeFactor": 5.02,
		"fontSize": 24,
		"labelHeight": 16,
		"edgeLengthFactor": "20",
		"compositTitleSize": 35,
		"radius": 5,
		"defaultRenderer": "dagre-wrapper"
	},
	"er": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"diagramPadding": 20,
		"layoutDirection": "TB",
		"minEntityWidth": 100,
		"minEntityHeight": 75,
		"entityPadding": 15,
		"nodeSpacing": 140,
		"rankSpacing": 80,
		"stroke": "gray",
		"fill": "honeydew",
		"fontSize": 12
	},
	"pie": {
		"useMaxWidth": true,
		"textPosition": .75,
		"donutHole": 0,
		"legendPosition": "right",
		"highlightSlice": ""
	},
	"quadrantChart": {
		"useMaxWidth": true,
		"chartWidth": 500,
		"chartHeight": 500,
		"titleFontSize": 20,
		"titlePadding": 10,
		"quadrantPadding": 5,
		"xAxisLabelPadding": 5,
		"yAxisLabelPadding": 5,
		"xAxisLabelFontSize": 16,
		"yAxisLabelFontSize": 16,
		"quadrantLabelFontSize": 16,
		"quadrantTextTopPadding": 5,
		"pointTextPadding": 5,
		"pointLabelFontSize": 12,
		"pointRadius": 5,
		"xAxisPosition": "top",
		"yAxisPosition": "left",
		"quadrantInternalBorderStrokeWidth": 1,
		"quadrantExternalBorderStrokeWidth": 2
	},
	"xyChart": {
		"useMaxWidth": true,
		"width": 700,
		"height": 500,
		"titleFontSize": 20,
		"titlePadding": 10,
		"showDataLabel": false,
		"showDataLabelOutsideBar": false,
		"showTitle": true,
		"xAxis": {
			"$ref": "#/$defs/XYChartAxisConfig",
			"showLabel": true,
			"labelFontSize": 14,
			"labelPadding": 5,
			"showTitle": true,
			"titleFontSize": 16,
			"titlePadding": 5,
			"showTick": true,
			"tickLength": 5,
			"tickWidth": 2,
			"showAxisLine": true,
			"axisLineWidth": 2,
			"labelRotation": 0
		},
		"yAxis": {
			"$ref": "#/$defs/XYChartAxisConfig",
			"showLabel": true,
			"labelFontSize": 14,
			"labelPadding": 5,
			"showTitle": true,
			"titleFontSize": 16,
			"titlePadding": 5,
			"showTick": true,
			"tickLength": 5,
			"tickWidth": 2,
			"showAxisLine": true,
			"axisLineWidth": 2,
			"labelRotation": 0
		},
		"chartOrientation": "vertical",
		"plotReservedSpacePercent": 50
	},
	"requirement": {
		"useMaxWidth": true,
		"rect_fill": "#f9f9f9",
		"text_color": "#333",
		"rect_border_size": "0.5px",
		"rect_border_color": "#bbb",
		"rect_min_width": 200,
		"rect_min_height": 200,
		"fontSize": 14,
		"rect_padding": 10,
		"line_height": 20
	},
	"mindmap": {
		"useMaxWidth": true,
		"padding": 10,
		"maxNodeWidth": 200,
		"layoutAlgorithm": "cose-bilkent"
	},
	"ishikawa": {
		"useMaxWidth": true,
		"diagramPadding": 20
	},
	"kanban": {
		"useMaxWidth": true,
		"padding": 8,
		"sectionWidth": 200,
		"ticketBaseUrl": ""
	},
	"timeline": {
		"useMaxWidth": true,
		"diagramMarginX": 50,
		"diagramMarginY": 10,
		"leftMargin": 150,
		"width": 150,
		"height": 50,
		"boxMargin": 10,
		"boxTextMargin": 5,
		"noteMargin": 10,
		"messageMargin": 35,
		"messageAlign": "center",
		"bottomMarginAdj": 1,
		"rightAngles": false,
		"taskFontSize": 14,
		"taskFontFamily": "\"Open Sans\", sans-serif",
		"taskMargin": 50,
		"activationWidth": 10,
		"textPlacement": "fo",
		"actorColours": [
			"#8FBC8F",
			"#7CFC00",
			"#00FFFF",
			"#20B2AA",
			"#B0E0E6",
			"#FFFFE0"
		],
		"sectionFills": [
			"#191970",
			"#8B008B",
			"#4B0082",
			"#2F4F4F",
			"#800000",
			"#8B4513",
			"#00008B"
		],
		"sectionColours": ["#fff"],
		"disableMulticolor": false
	},
	"gitGraph": {
		"useMaxWidth": true,
		"titleTopMargin": 25,
		"diagramPadding": 8,
		"nodeLabel": {
			"width": 75,
			"height": 100,
			"x": -25,
			"y": 0
		},
		"mainBranchName": "main",
		"mainBranchOrder": 0,
		"showCommitLabel": true,
		"showBranches": true,
		"rotateCommitLabel": true,
		"parallelCommits": false,
		"arrowMarkerAbsolute": false
	},
	"c4": {
		"useMaxWidth": true,
		"diagramMarginX": 50,
		"diagramMarginY": 10,
		"c4ShapeMargin": 50,
		"c4ShapePadding": 20,
		"width": 216,
		"height": 60,
		"boxMargin": 10,
		"c4ShapeInRow": 4,
		"nextLinePaddingX": 0,
		"c4BoundaryInRow": 2,
		"personFontSize": 14,
		"personFontFamily": "\"Open Sans\", sans-serif",
		"personFontWeight": "normal",
		"external_personFontSize": 14,
		"external_personFontFamily": "\"Open Sans\", sans-serif",
		"external_personFontWeight": "normal",
		"systemFontSize": 14,
		"systemFontFamily": "\"Open Sans\", sans-serif",
		"systemFontWeight": "normal",
		"external_systemFontSize": 14,
		"external_systemFontFamily": "\"Open Sans\", sans-serif",
		"external_systemFontWeight": "normal",
		"system_dbFontSize": 14,
		"system_dbFontFamily": "\"Open Sans\", sans-serif",
		"system_dbFontWeight": "normal",
		"external_system_dbFontSize": 14,
		"external_system_dbFontFamily": "\"Open Sans\", sans-serif",
		"external_system_dbFontWeight": "normal",
		"system_queueFontSize": 14,
		"system_queueFontFamily": "\"Open Sans\", sans-serif",
		"system_queueFontWeight": "normal",
		"external_system_queueFontSize": 14,
		"external_system_queueFontFamily": "\"Open Sans\", sans-serif",
		"external_system_queueFontWeight": "normal",
		"boundaryFontSize": 14,
		"boundaryFontFamily": "\"Open Sans\", sans-serif",
		"boundaryFontWeight": "normal",
		"messageFontSize": 12,
		"messageFontFamily": "\"Open Sans\", sans-serif",
		"messageFontWeight": "normal",
		"containerFontSize": 14,
		"containerFontFamily": "\"Open Sans\", sans-serif",
		"containerFontWeight": "normal",
		"external_containerFontSize": 14,
		"external_containerFontFamily": "\"Open Sans\", sans-serif",
		"external_containerFontWeight": "normal",
		"container_dbFontSize": 14,
		"container_dbFontFamily": "\"Open Sans\", sans-serif",
		"container_dbFontWeight": "normal",
		"external_container_dbFontSize": 14,
		"external_container_dbFontFamily": "\"Open Sans\", sans-serif",
		"external_container_dbFontWeight": "normal",
		"container_queueFontSize": 14,
		"container_queueFontFamily": "\"Open Sans\", sans-serif",
		"container_queueFontWeight": "normal",
		"external_container_queueFontSize": 14,
		"external_container_queueFontFamily": "\"Open Sans\", sans-serif",
		"external_container_queueFontWeight": "normal",
		"componentFontSize": 14,
		"componentFontFamily": "\"Open Sans\", sans-serif",
		"componentFontWeight": "normal",
		"external_componentFontSize": 14,
		"external_componentFontFamily": "\"Open Sans\", sans-serif",
		"external_componentFontWeight": "normal",
		"component_dbFontSize": 14,
		"component_dbFontFamily": "\"Open Sans\", sans-serif",
		"component_dbFontWeight": "normal",
		"external_component_dbFontSize": 14,
		"external_component_dbFontFamily": "\"Open Sans\", sans-serif",
		"external_component_dbFontWeight": "normal",
		"component_queueFontSize": 14,
		"component_queueFontFamily": "\"Open Sans\", sans-serif",
		"component_queueFontWeight": "normal",
		"external_component_queueFontSize": 14,
		"external_component_queueFontFamily": "\"Open Sans\", sans-serif",
		"external_component_queueFontWeight": "normal",
		"wrap": true,
		"wrapPadding": 10,
		"person_bg_color": "#08427B",
		"person_border_color": "#073B6F",
		"external_person_bg_color": "#686868",
		"external_person_border_color": "#8A8A8A",
		"system_bg_color": "#1168BD",
		"system_border_color": "#3C7FC0",
		"system_db_bg_color": "#1168BD",
		"system_db_border_color": "#3C7FC0",
		"system_queue_bg_color": "#1168BD",
		"system_queue_border_color": "#3C7FC0",
		"external_system_bg_color": "#999999",
		"external_system_border_color": "#8A8A8A",
		"external_system_db_bg_color": "#999999",
		"external_system_db_border_color": "#8A8A8A",
		"external_system_queue_bg_color": "#999999",
		"external_system_queue_border_color": "#8A8A8A",
		"container_bg_color": "#438DD5",
		"container_border_color": "#3C7FC0",
		"container_db_bg_color": "#438DD5",
		"container_db_border_color": "#3C7FC0",
		"container_queue_bg_color": "#438DD5",
		"container_queue_border_color": "#3C7FC0",
		"external_container_bg_color": "#B3B3B3",
		"external_container_border_color": "#A6A6A6",
		"external_container_db_bg_color": "#B3B3B3",
		"external_container_db_border_color": "#A6A6A6",
		"external_container_queue_bg_color": "#B3B3B3",
		"external_container_queue_border_color": "#A6A6A6",
		"component_bg_color": "#85BBF0",
		"component_border_color": "#78A8D8",
		"component_db_bg_color": "#85BBF0",
		"component_db_border_color": "#78A8D8",
		"component_queue_bg_color": "#85BBF0",
		"component_queue_border_color": "#78A8D8",
		"external_component_bg_color": "#CCCCCC",
		"external_component_border_color": "#BFBFBF",
		"external_component_db_bg_color": "#CCCCCC",
		"external_component_db_border_color": "#BFBFBF",
		"external_component_queue_bg_color": "#CCCCCC",
		"external_component_queue_border_color": "#BFBFBF"
	},
	"sankey": {
		"useMaxWidth": true,
		"width": 600,
		"height": 400,
		"linkColor": "gradient",
		"nodeAlignment": "justify",
		"showValues": true,
		"prefix": "",
		"suffix": "",
		"nodeWidth": 10,
		"nodePadding": 12,
		"labelStyle": "legacy"
	},
	"block": {
		"useMaxWidth": true,
		"padding": 8
	},
	"packet": {
		"useMaxWidth": true,
		"rowHeight": 32,
		"bitWidth": 32,
		"bitsPerRow": 32,
		"showBits": true,
		"paddingX": 5,
		"paddingY": 5
	},
	"treeView": {
		"useMaxWidth": true,
		"rowIndent": 10,
		"paddingX": 5,
		"paddingY": 5,
		"lineThickness": 1,
		"showIcons": false,
		"defaultIconPack": "",
		"filenameIcons": {},
		"extensionIcons": {}
	},
	"architecture": {
		"useMaxWidth": true,
		"padding": 40,
		"iconSize": 80,
		"fontSize": 16,
		"randomize": false,
		"nodeSeparation": 75,
		"idealEdgeLengthMultiplier": 1.5,
		"edgeElasticity": .45,
		"numIter": 2500,
		"seed": 1
	},
	"eventmodeling": {
		"useMaxWidth": true,
		"padding": 30,
		"rowHeight": 32
	},
	"radar": {
		"useMaxWidth": true,
		"width": 600,
		"height": 600,
		"marginTop": 50,
		"marginRight": 50,
		"marginBottom": 50,
		"marginLeft": 50,
		"axisScaleFactor": 1,
		"axisLabelFactor": 1.05,
		"curveTension": .17
	},
	"venn": {
		"useMaxWidth": true,
		"width": 800,
		"height": 450,
		"padding": 8,
		"useDebugLayout": false
	},
	"cynefin": {
		"useMaxWidth": true,
		"width": 800,
		"height": 600,
		"padding": 40,
		"showDomainDescriptions": true,
		"boundaryAmplitude": 8,
		"seed": 0
	},
	"theme": "default",
	"look": "classic",
	"handDrawnSeed": 0,
	"layout": "dagre",
	"maxTextSize": 5e4,
	"maxEdges": 500,
	"darkMode": false,
	"fontFamily": "\"trebuchet ms\", verdana, arial, sans-serif;",
	"logLevel": 5,
	"securityLevel": "strict",
	"startOnLoad": true,
	"arrowMarkerAbsolute": false,
	"secure": [
		"secure",
		"securityLevel",
		"startOnLoad",
		"maxTextSize",
		"suppressErrorRendering",
		"maxEdges"
	],
	"legacyMathML": false,
	"forceLegacyMathML": false,
	"deterministicIds": false,
	"fontSize": 16,
	"markdownAutoWrap": true,
	"suppressErrorRendering": false
};
var config = _objectSpread2(_objectSpread2({}, config_schema_default), {}, {
	deterministicIDSeed: void 0,
	elk: {
		mergeEdges: false,
		nodePlacementStrategy: "BRANDES_KOEPF",
		forceNodeModelOrder: false,
		considerModelOrder: "NODES_AND_EDGES"
	},
	themeCSS: void 0,
	themeVariables: themes_default.default.getThemeVariables(),
	sequence: _objectSpread2(_objectSpread2({}, config_schema_default.sequence), {}, {
		messageFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.messageFontFamily,
				fontSize: this.messageFontSize,
				fontWeight: this.messageFontWeight
			};
		}, "messageFont"),
		noteFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.noteFontFamily,
				fontSize: this.noteFontSize,
				fontWeight: this.noteFontWeight
			};
		}, "noteFont"),
		actorFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.actorFontFamily,
				fontSize: this.actorFontSize,
				fontWeight: this.actorFontWeight
			};
		}, "actorFont")
	}),
	class: {
		hideEmptyMembersBox: false,
		hierarchicalNamespaces: true
	},
	gantt: _objectSpread2(_objectSpread2({}, config_schema_default.gantt), {}, {
		tickInterval: void 0,
		useWidth: void 0
	}),
	c4: _objectSpread2(_objectSpread2({}, config_schema_default.c4), {}, {
		useWidth: void 0,
		personFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.personFontFamily,
				fontSize: this.personFontSize,
				fontWeight: this.personFontWeight
			};
		}, "personFont"),
		flowchart: _objectSpread2(_objectSpread2({}, config_schema_default.flowchart), {}, { inheritDir: false }),
		external_personFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_personFontFamily,
				fontSize: this.external_personFontSize,
				fontWeight: this.external_personFontWeight
			};
		}, "external_personFont"),
		systemFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.systemFontFamily,
				fontSize: this.systemFontSize,
				fontWeight: this.systemFontWeight
			};
		}, "systemFont"),
		external_systemFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_systemFontFamily,
				fontSize: this.external_systemFontSize,
				fontWeight: this.external_systemFontWeight
			};
		}, "external_systemFont"),
		system_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.system_dbFontFamily,
				fontSize: this.system_dbFontSize,
				fontWeight: this.system_dbFontWeight
			};
		}, "system_dbFont"),
		external_system_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_system_dbFontFamily,
				fontSize: this.external_system_dbFontSize,
				fontWeight: this.external_system_dbFontWeight
			};
		}, "external_system_dbFont"),
		system_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.system_queueFontFamily,
				fontSize: this.system_queueFontSize,
				fontWeight: this.system_queueFontWeight
			};
		}, "system_queueFont"),
		external_system_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_system_queueFontFamily,
				fontSize: this.external_system_queueFontSize,
				fontWeight: this.external_system_queueFontWeight
			};
		}, "external_system_queueFont"),
		containerFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.containerFontFamily,
				fontSize: this.containerFontSize,
				fontWeight: this.containerFontWeight
			};
		}, "containerFont"),
		external_containerFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_containerFontFamily,
				fontSize: this.external_containerFontSize,
				fontWeight: this.external_containerFontWeight
			};
		}, "external_containerFont"),
		container_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.container_dbFontFamily,
				fontSize: this.container_dbFontSize,
				fontWeight: this.container_dbFontWeight
			};
		}, "container_dbFont"),
		external_container_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_container_dbFontFamily,
				fontSize: this.external_container_dbFontSize,
				fontWeight: this.external_container_dbFontWeight
			};
		}, "external_container_dbFont"),
		container_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.container_queueFontFamily,
				fontSize: this.container_queueFontSize,
				fontWeight: this.container_queueFontWeight
			};
		}, "container_queueFont"),
		external_container_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_container_queueFontFamily,
				fontSize: this.external_container_queueFontSize,
				fontWeight: this.external_container_queueFontWeight
			};
		}, "external_container_queueFont"),
		componentFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.componentFontFamily,
				fontSize: this.componentFontSize,
				fontWeight: this.componentFontWeight
			};
		}, "componentFont"),
		external_componentFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_componentFontFamily,
				fontSize: this.external_componentFontSize,
				fontWeight: this.external_componentFontWeight
			};
		}, "external_componentFont"),
		component_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.component_dbFontFamily,
				fontSize: this.component_dbFontSize,
				fontWeight: this.component_dbFontWeight
			};
		}, "component_dbFont"),
		external_component_dbFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_component_dbFontFamily,
				fontSize: this.external_component_dbFontSize,
				fontWeight: this.external_component_dbFontWeight
			};
		}, "external_component_dbFont"),
		component_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.component_queueFontFamily,
				fontSize: this.component_queueFontSize,
				fontWeight: this.component_queueFontWeight
			};
		}, "component_queueFont"),
		external_component_queueFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.external_component_queueFontFamily,
				fontSize: this.external_component_queueFontSize,
				fontWeight: this.external_component_queueFontWeight
			};
		}, "external_component_queueFont"),
		boundaryFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.boundaryFontFamily,
				fontSize: this.boundaryFontSize,
				fontWeight: this.boundaryFontWeight
			};
		}, "boundaryFont"),
		messageFont: /* @__PURE__ */ __name(function() {
			return {
				fontFamily: this.messageFontFamily,
				fontSize: this.messageFontSize,
				fontWeight: this.messageFontWeight
			};
		}, "messageFont")
	}),
	pie: _objectSpread2(_objectSpread2({}, config_schema_default.pie), {}, { useWidth: 984 }),
	xyChart: _objectSpread2(_objectSpread2({}, config_schema_default.xyChart), {}, { useWidth: void 0 }),
	requirement: _objectSpread2(_objectSpread2({}, config_schema_default.requirement), {}, { useWidth: void 0 }),
	packet: _objectSpread2({}, config_schema_default.packet),
	eventmodeling: _objectSpread2({}, config_schema_default.eventmodeling),
	treeView: _objectSpread2(_objectSpread2({}, config_schema_default.treeView), {}, { useWidth: void 0 }),
	radar: _objectSpread2({}, config_schema_default.radar),
	railroad: _objectSpread2(_objectSpread2({}, config_schema_default.railroad), {}, {
		fontSize: void 0,
		fontFamily: void 0,
		terminalFill: void 0,
		terminalStroke: void 0,
		terminalTextColor: void 0,
		nonTerminalFill: void 0,
		nonTerminalStroke: void 0,
		nonTerminalTextColor: void 0,
		lineColor: void 0,
		markerFill: void 0,
		commentFill: void 0,
		commentStroke: void 0,
		commentTextColor: void 0,
		specialFill: void 0,
		specialStroke: void 0,
		ruleNameColor: void 0
	}),
	ishikawa: _objectSpread2({}, config_schema_default.ishikawa),
	sankey: _objectSpread2(_objectSpread2({}, config_schema_default.sankey), {}, { nodeColors: void 0 }),
	treemap: {
		useMaxWidth: true,
		padding: 10,
		diagramPadding: 8,
		showValues: true,
		nodeWidth: 100,
		nodeHeight: 40,
		borderWidth: 1,
		valueFontSize: 12,
		labelFontSize: 14,
		valueFormat: ","
	},
	venn: _objectSpread2({}, config_schema_default.venn),
	cynefin: _objectSpread2({}, config_schema_default.cynefin)
});
var keyify = /* @__PURE__ */ __name((obj, prefix = "") => Object.keys(obj).reduce((res, el) => {
	if (Array.isArray(obj[el])) return res;
	else if (typeof obj[el] === "object" && obj[el] !== null) return [
		...res,
		prefix + el,
		...keyify(obj[el], "")
	];
	return [...res, prefix + el];
}, []), "keyify");
var configKeys = new Set(keyify(config, ""));
var defaultConfig_default = config;
var DICTIONARY_CONFIG_PATTERNS = {
	nodeColors: /^#[\da-f]{3,8}$|^rgb\([\d\s%,.]+\)$|^hsl\([\d\s%,.]+\)$|^[a-z]+$/i,
	filenameIcons: /^[\w-]+(?::[\w-]+)?$/,
	extensionIcons: /^[\w-]+(?::[\w-]+)?$/
};
var sanitizeDictionaryConfig = /* @__PURE__ */ __name((dict, valuePattern) => {
	for (const key of Object.keys(dict)) {
		const value = dict[key];
		if (key.startsWith("__") || key.includes("proto") || key.includes("constr") || typeof value !== "string" || !valuePattern.test(value)) {
			log.debug("sanitize deleting dictionary entry:", key, value);
			delete dict[key];
		}
	}
}, "sanitizeDictionaryConfig");
var sanitizeDirective = /* @__PURE__ */ __name((args) => {
	log.debug("sanitizeDirective called with", args);
	if (typeof args !== "object" || args == null) return;
	if (Array.isArray(args)) {
		args.forEach((arg) => sanitizeDirective(arg));
		return;
	}
	for (const key of Object.keys(args)) {
		log.debug("Checking key", key);
		if (key.startsWith("__") || key.includes("proto") || key.includes("constr") || !configKeys.has(key) || args[key] == null) {
			log.debug("sanitize deleting key: ", key);
			delete args[key];
			continue;
		}
		if (typeof args[key] === "object") {
			const valuePattern = DICTIONARY_CONFIG_PATTERNS[key];
			if (valuePattern) sanitizeDictionaryConfig(args[key], valuePattern);
			else {
				log.debug("sanitizing object", key);
				sanitizeDirective(args[key]);
			}
			continue;
		}
		for (const cssKey of [
			"themeCSS",
			"fontFamily",
			"altFontFamily"
		]) if (key.includes(cssKey)) {
			log.debug("sanitizing css option", key);
			args[key] = sanitizeCss(args[key]);
		}
	}
	if (args.themeVariables) for (const k of Object.keys(args.themeVariables)) {
		const val = args.themeVariables[k];
		if ((val === null || val === void 0 ? void 0 : val.match) && !val.match(/^[\d "#%(),.;A-Za-z]+$/)) args.themeVariables[k] = "";
	}
	log.debug("After sanitization", args);
}, "sanitizeDirective");
var sanitizeCss = /* @__PURE__ */ __name((str) => {
	let startCnt = 0;
	let endCnt = 0;
	for (const element of str) {
		if (startCnt < endCnt) return "{ /* ERROR: Unbalanced CSS */ }";
		if (element === "{") startCnt++;
		else if (element === "}") endCnt++;
	}
	if (startCnt !== endCnt) return "{ /* ERROR: Unbalanced CSS */ }";
	return str;
}, "sanitizeCss");
var defaultConfig = Object.freeze(defaultConfig_default);
var evaluate = /* @__PURE__ */ __name((val) => val === false || [
	"false",
	"null",
	"0"
].includes(String(val).trim().toLowerCase()) ? false : true, "evaluate");
var siteConfig = assignWithDepth_default({}, defaultConfig);
var configFromInitialize;
var directives = [];
var currentConfig = assignWithDepth_default({}, defaultConfig);
var updateCurrentConfig = /* @__PURE__ */ __name((siteCfg, _directives) => {
	let cfg = assignWithDepth_default({}, siteCfg);
	let sumOfDirectives = {};
	for (const d of _directives) {
		sanitize(d);
		sumOfDirectives = assignWithDepth_default(sumOfDirectives, d);
	}
	cfg = assignWithDepth_default(cfg, sumOfDirectives);
	if (sumOfDirectives.theme && sumOfDirectives.theme in themes_default) {
		const themeVariables = assignWithDepth_default(assignWithDepth_default({}, configFromInitialize).themeVariables || {}, sumOfDirectives.themeVariables);
		if (cfg.theme && cfg.theme in themes_default) cfg.themeVariables = themes_default[cfg.theme].getThemeVariables(themeVariables);
	}
	currentConfig = cfg;
	checkConfig(currentConfig);
	return currentConfig;
}, "updateCurrentConfig");
var setSiteConfig = /* @__PURE__ */ __name((conf) => {
	siteConfig = assignWithDepth_default({}, defaultConfig);
	siteConfig = assignWithDepth_default(siteConfig, conf);
	if (conf.theme && themes_default[conf.theme]) siteConfig.themeVariables = themes_default[conf.theme].getThemeVariables(conf.themeVariables);
	updateCurrentConfig(siteConfig, directives);
	return siteConfig;
}, "setSiteConfig");
var saveConfigFromInitialize = /* @__PURE__ */ __name((conf) => {
	configFromInitialize = assignWithDepth_default({}, conf);
}, "saveConfigFromInitialize");
var updateSiteConfig = /* @__PURE__ */ __name((conf) => {
	siteConfig = assignWithDepth_default(siteConfig, conf);
	updateCurrentConfig(siteConfig, directives);
	return siteConfig;
}, "updateSiteConfig");
var getSiteConfig = /* @__PURE__ */ __name(() => {
	return assignWithDepth_default({}, siteConfig);
}, "getSiteConfig");
var setConfig = /* @__PURE__ */ __name((conf) => {
	checkConfig(conf);
	assignWithDepth_default(currentConfig, conf);
	return getConfig();
}, "setConfig");
var getConfig = /* @__PURE__ */ __name(() => {
	return assignWithDepth_default({}, currentConfig);
}, "getConfig");
var sanitize = /* @__PURE__ */ __name((options) => {
	var _siteConfig$secure;
	if (!options) return;
	["secure", ...(_siteConfig$secure = siteConfig.secure) !== null && _siteConfig$secure !== void 0 ? _siteConfig$secure : []].forEach((key) => {
		if (Object.hasOwn(options, key)) {
			log.debug(`Denied attempt to modify a secure key ${key}`, options[key]);
			delete options[key];
		}
	});
	Object.keys(options).forEach((key) => {
		if (key.startsWith("__")) delete options[key];
	});
	Object.keys(options).forEach((key) => {
		if (typeof options[key] === "string" && (options[key].includes("<") || options[key].includes(">") || options[key].includes("url(data:"))) delete options[key];
		if (typeof options[key] === "object") sanitize(options[key]);
	});
}, "sanitize");
var addDirective = /* @__PURE__ */ __name((directive) => {
	var _directive$themeVaria;
	sanitizeDirective(directive);
	if (directive.fontFamily && !((_directive$themeVaria = directive.themeVariables) === null || _directive$themeVaria === void 0 ? void 0 : _directive$themeVaria.fontFamily)) directive.themeVariables = _objectSpread2(_objectSpread2({}, directive.themeVariables), {}, { fontFamily: directive.fontFamily });
	directives.push(directive);
	updateCurrentConfig(siteConfig, directives);
}, "addDirective");
var reset = /* @__PURE__ */ __name((config2 = siteConfig) => {
	directives = [];
	updateCurrentConfig(config2, directives);
}, "reset");
var ConfigWarning = {
	LAZY_LOAD_DEPRECATED: "The configuration options lazyLoadedDiagrams and loadExternalDiagramsAtStartup are deprecated. Please use registerExternalDiagrams instead.",
	FLOWCHART_HTML_LABELS_DEPRECATED: "flowchart.htmlLabels is deprecated. Please use global htmlLabels instead."
};
var issuedWarnings = {};
var issueWarning = /* @__PURE__ */ __name((warning) => {
	if (issuedWarnings[warning]) return;
	log.warn(ConfigWarning[warning]);
	issuedWarnings[warning] = true;
}, "issueWarning");
var checkConfig = /* @__PURE__ */ __name((config2) => {
	if (!config2) return;
	if (config2.lazyLoadedDiagrams || config2.loadExternalDiagramsAtStartup) issueWarning("LAZY_LOAD_DEPRECATED");
}, "checkConfig");
var getUserDefinedConfig = /* @__PURE__ */ __name(() => {
	let userConfig = {};
	if (configFromInitialize) userConfig = assignWithDepth_default(userConfig, configFromInitialize);
	for (const d of directives) userConfig = assignWithDepth_default(userConfig, d);
	return userConfig;
}, "getUserDefinedConfig");
var getEffectiveHtmlLabels = /* @__PURE__ */ __name((config2) => {
	var _config2$flowchart, _ref, _config2$htmlLabels, _config2$flowchart2;
	if (((_config2$flowchart = config2.flowchart) === null || _config2$flowchart === void 0 ? void 0 : _config2$flowchart.htmlLabels) != void 0) issueWarning("FLOWCHART_HTML_LABELS_DEPRECATED");
	return evaluate((_ref = (_config2$htmlLabels = config2.htmlLabels) !== null && _config2$htmlLabels !== void 0 ? _config2$htmlLabels : (_config2$flowchart2 = config2.flowchart) === null || _config2$flowchart2 === void 0 ? void 0 : _config2$flowchart2.htmlLabels) !== null && _ref !== void 0 ? _ref : true);
}, "getEffectiveHtmlLabels");
var frontMatterRegex = /* @__PURE__ */ new RegExp("^([^\\S\\n\\r]*)-{3}\\s*[\\n\\r](.*?)[\\n\\r]\\1-{3}\\s*[\\n\\r]+", "s");
var directiveRegex = /%{2}{\s*(?:(\w+)\s*:|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi;
var anyCommentRegex = /\s*%%.*\n/gm;
var UnknownDiagramError = (_Class12 = class extends Error {
	constructor(message) {
		super(message);
		this.name = "UnknownDiagramError";
	}
}, __name(_Class12, "UnknownDiagramError"), _Class12);
var detectors = {};
var detectType = /* @__PURE__ */ __name(function(text, config2) {
	text = text.replace(frontMatterRegex, "").replace(directiveRegex, "").replace(anyCommentRegex, "\n");
	for (const [key, { detector }] of Object.entries(detectors)) if (detector(text, config2)) return key;
	throw new UnknownDiagramError(`No diagram type detected matching given configuration for text: ${text}`);
}, "detectType");
var registerLazyLoadedDiagrams = /* @__PURE__ */ __name((...diagrams2) => {
	for (const { id, detector, loader } of diagrams2) addDetector(id, detector, loader);
}, "registerLazyLoadedDiagrams");
var addDetector = /* @__PURE__ */ __name((key, detector, loader) => {
	if (detectors[key]) log.warn(`Detector with key ${key} already exists. Overwriting.`);
	detectors[key] = {
		detector,
		loader
	};
	log.debug(`Detector with key ${key} added${loader ? " with loader" : ""}`);
}, "addDetector");
var getDiagramLoader = /* @__PURE__ */ __name((key) => {
	return detectors[key].loader;
}, "getDiagramLoader");
var lineBreakRegex = /<br\s*\/?>/gi;
var getRows = /* @__PURE__ */ __name((s) => {
	if (!s) return [""];
	return breakToPlaceholder(s).replace(/\\n/g, "#br#").split("#br#");
}, "getRows");
var setupDompurifyHooksIfNotSetup = /* @__PURE__ */ (() => {
	let setup = false;
	return () => {
		if (!setup) {
			setupDompurifyHooks();
			setup = true;
		}
	};
})();
function setupDompurifyHooks() {
	const TEMPORARY_ATTRIBUTE = "data-temp-href-target";
	purify.addHook("beforeSanitizeAttributes", (node) => {
		if (node.tagName === "A" && node.hasAttribute("target")) {
			var _node$getAttribute;
			node.setAttribute(TEMPORARY_ATTRIBUTE, (_node$getAttribute = node.getAttribute("target")) !== null && _node$getAttribute !== void 0 ? _node$getAttribute : "");
		}
	});
	purify.addHook("afterSanitizeAttributes", (node) => {
		if (node.tagName === "A" && node.hasAttribute(TEMPORARY_ATTRIBUTE)) {
			var _node$getAttribute2;
			node.setAttribute("target", (_node$getAttribute2 = node.getAttribute(TEMPORARY_ATTRIBUTE)) !== null && _node$getAttribute2 !== void 0 ? _node$getAttribute2 : "");
			node.removeAttribute(TEMPORARY_ATTRIBUTE);
			if (node.getAttribute("target") === "_blank") node.setAttribute("rel", "noopener");
		}
	});
}
__name(setupDompurifyHooks, "setupDompurifyHooks");
var removeScript = /* @__PURE__ */ __name((txt) => {
	setupDompurifyHooksIfNotSetup();
	return purify.sanitize(txt);
}, "removeScript");
var sanitizeMore = /* @__PURE__ */ __name((text, config2) => {
	if (getEffectiveHtmlLabels(config2)) {
		const level = config2.securityLevel;
		if (level === "antiscript" || level === "strict" || level === "sandbox") text = removeScript(text);
		else if (level !== "loose") {
			text = breakToPlaceholder(text);
			text = text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
			text = text.replace(/=/g, "&equals;");
			text = placeholderToBreak(text);
		}
	}
	return text;
}, "sanitizeMore");
var sanitizeText = /* @__PURE__ */ __name((text, config2) => {
	if (!text) return text;
	if (config2.dompurifyConfig) text = purify.sanitize(sanitizeMore(text, config2), config2.dompurifyConfig).toString();
	else text = purify.sanitize(sanitizeMore(text, config2), { FORBID_TAGS: ["style"] }).toString();
	return text;
}, "sanitizeText");
var sanitizeTextOrArray = /* @__PURE__ */ __name((a, config2) => {
	if (typeof a === "string") return sanitizeText(a, config2);
	return a.flat().map((x) => sanitizeText(x, config2));
}, "sanitizeTextOrArray");
var hasBreaks = /* @__PURE__ */ __name((text) => {
	return lineBreakRegex.test(text);
}, "hasBreaks");
var splitBreaks = /* @__PURE__ */ __name((text) => {
	return text.split(lineBreakRegex);
}, "splitBreaks");
var placeholderToBreak = /* @__PURE__ */ __name((s) => {
	return s.replace(/#br#/g, "<br/>");
}, "placeholderToBreak");
var breakToPlaceholder = /* @__PURE__ */ __name((s) => {
	return s.replace(lineBreakRegex, "#br#");
}, "breakToPlaceholder");
var getUrl = /* @__PURE__ */ __name((useAbsolute) => {
	let url = "";
	if (useAbsolute) {
		url = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search;
		url = CSS.escape(url);
	}
	return url;
}, "getUrl");
var getMax = /* @__PURE__ */ __name(function(...values) {
	const newValues = values.filter((value) => {
		return !isNaN(value);
	});
	return Math.max(...newValues);
}, "getMax");
var getMin = /* @__PURE__ */ __name(function(...values) {
	const newValues = values.filter((value) => {
		return !isNaN(value);
	});
	return Math.min(...newValues);
}, "getMin");
var parseGenericTypes = /* @__PURE__ */ __name(function(input) {
	const inputSets = input.split(/(,)/);
	const output = [];
	for (let i = 0; i < inputSets.length; i++) {
		let thisSet = inputSets[i];
		if (thisSet === "," && i > 0 && i + 1 < inputSets.length) {
			const previousSet = inputSets[i - 1];
			const nextSet = inputSets[i + 1];
			if (shouldCombineSets(previousSet, nextSet)) {
				thisSet = previousSet + "," + nextSet;
				i++;
				output.pop();
			}
		}
		output.push(processSet(thisSet));
	}
	return output.join("");
}, "parseGenericTypes");
var countOccurrence = /* @__PURE__ */ __name((string, substring) => {
	return Math.max(0, string.split(substring).length - 1);
}, "countOccurrence");
var shouldCombineSets = /* @__PURE__ */ __name((previousSet, nextSet) => {
	const prevCount = countOccurrence(previousSet, "~");
	const nextCount = countOccurrence(nextSet, "~");
	return prevCount === 1 && nextCount === 1;
}, "shouldCombineSets");
var processSet = /* @__PURE__ */ __name((input) => {
	const tildeCount = countOccurrence(input, "~");
	let hasStartingTilde = false;
	if (tildeCount <= 1) return input;
	if (tildeCount % 2 !== 0 && input.startsWith("~")) {
		input = input.substring(1);
		hasStartingTilde = true;
	}
	const chars = [...input];
	let first = chars.indexOf("~");
	let last = chars.lastIndexOf("~");
	while (first !== -1 && last !== -1 && first !== last) {
		chars[first] = "<";
		chars[last] = ">";
		first = chars.indexOf("~");
		last = chars.lastIndexOf("~");
	}
	if (hasStartingTilde) chars.unshift("~");
	return chars.join("");
}, "processSet");
var isMathMLSupported = /* @__PURE__ */ __name(() => window.MathMLElement !== void 0, "isMathMLSupported");
var katexRegex = /\$\$(.*?)\$\$/g;
var hasKatex = /* @__PURE__ */ __name((text) => {
	var _text$match$length, _text$match;
	return ((_text$match$length = (_text$match = text.match(katexRegex)) === null || _text$match === void 0 ? void 0 : _text$match.length) !== null && _text$match$length !== void 0 ? _text$match$length : 0) > 0;
}, "hasKatex");
var calculateMathMLDimensions = /* @__PURE__ */ __name(function() {
	var _ref2 = _asyncToGenerator(function* (text, config2) {
		const divElem = document.createElement("div");
		divElem.innerHTML = yield renderKatexSanitized(text, config2);
		divElem.id = "katex-temp";
		divElem.style.visibility = "hidden";
		divElem.style.position = "absolute";
		divElem.style.top = "0";
		const body = document.querySelector("body");
		body === null || body === void 0 || body.insertAdjacentElement("beforeend", divElem);
		const dim = {
			width: divElem.clientWidth,
			height: divElem.clientHeight
		};
		divElem.remove();
		return dim;
	});
	return function(_x, _x2) {
		return _ref2.apply(this, arguments);
	};
}(), "calculateMathMLDimensions");
var renderKatexUnsanitized = /* @__PURE__ */ __name(function() {
	var _ref3 = _asyncToGenerator(function* (text, config2) {
		if (!hasKatex(text)) return text;
		if (!(isMathMLSupported() || config2.legacyMathML || config2.forceLegacyMathML)) return text.replace(katexRegex, "MathML is unsupported in this environment.");
		{
			const { default: katex } = yield __vitePreload(_asyncToGenerator(function* () {
				const { default: katex } = yield import("./katex-BdccL6hs.js");
				return { default: katex };
			}), []);
			const outputMode = config2.forceLegacyMathML || !isMathMLSupported() && config2.legacyMathML ? "htmlAndMathml" : "mathml";
			return text.split(lineBreakRegex).map((line) => hasKatex(line) ? `<div style="display: flex; align-items: center; justify-content: center; white-space: nowrap;">${line}</div>` : `<div>${line}</div>`).join("").replace(katexRegex, (_, c) => katex.renderToString(c, {
				throwOnError: true,
				displayMode: true,
				output: outputMode
			}).replace(/\n/g, " ").replace(/<annotation.*<\/annotation>/g, ""));
		}
		return text.replace(katexRegex, "Katex is not supported in @mermaid-js/tiny. Please use the full mermaid library.");
	});
	return function(_x3, _x4) {
		return _ref3.apply(this, arguments);
	};
}(), "renderKatexUnsanitized");
var renderKatexSanitized = /* @__PURE__ */ __name(function() {
	var _ref4 = _asyncToGenerator(function* (text, config2) {
		return sanitizeText(yield renderKatexUnsanitized(text, config2), config2);
	});
	return function(_x5, _x6) {
		return _ref4.apply(this, arguments);
	};
}(), "renderKatexSanitized");
var common_default = {
	getRows,
	sanitizeText,
	sanitizeTextOrArray,
	hasBreaks,
	splitBreaks,
	lineBreakRegex,
	removeScript,
	getUrl,
	evaluate,
	getMax,
	getMin
};
var d3Attrs = /* @__PURE__ */ __name(function(d3Elem, attrs) {
	for (let attr of attrs) d3Elem.attr(attr[0], attr[1]);
}, "d3Attrs");
var calculateSvgSizeAttrs = /* @__PURE__ */ __name(function(height, width, useMaxWidth) {
	let attrs = /* @__PURE__ */ new Map();
	if (useMaxWidth) {
		attrs.set("width", "100%");
		attrs.set("style", `max-width: ${width}px;`);
	} else {
		attrs.set("height", height);
		attrs.set("width", width);
	}
	return attrs;
}, "calculateSvgSizeAttrs");
var configureSvgSize = /* @__PURE__ */ __name(function(svgElem, height, width, useMaxWidth) {
	d3Attrs(svgElem, calculateSvgSizeAttrs(height, width, useMaxWidth));
}, "configureSvgSize");
var setupGraphViewbox = /* @__PURE__ */ __name(function(graph, svgElem, padding, useMaxWidth) {
	const svgBounds = svgElem.node().getBBox();
	const sWidth = svgBounds.width;
	const sHeight = svgBounds.height;
	log.info(`SVG bounds: ${sWidth}x${sHeight}`, svgBounds);
	let width = 0;
	let height = 0;
	log.info(`Graph bounds: ${width}x${height}`, graph);
	width = sWidth + padding * 2;
	height = sHeight + padding * 2;
	log.info(`Calculated bounds: ${width}x${height}`);
	configureSvgSize(svgElem, height, width, useMaxWidth);
	const vBox = `${svgBounds.x - padding} ${svgBounds.y - padding} ${svgBounds.width + 2 * padding} ${svgBounds.height + 2 * padding}`;
	svgElem.attr("viewBox", vBox);
}, "setupGraphViewbox");
var themes = {};
function cssStyleSheetToString(cssStyleSheet) {
	return [...cssStyleSheet.cssRules].map((rule) => rule.cssText).join("\n");
}
__name(cssStyleSheetToString, "cssStyleSheetToString");
var getStyles = /* @__PURE__ */ __name((type, userStyles, options, svgId) => {
	var _options$strokeWidth, _options$strokeWidth2;
	let diagramStyles = "";
	if (type in themes && themes[type]) diagramStyles = themes[type](_objectSpread2(_objectSpread2({}, options), {}, { svgId }));
	else log.warn(`No theme found for ${type}`);
	return ` & {
    font-family: ${options.fontFamily};
    font-size: ${options.fontSize};
    fill: ${options.textColor}
  }
  @keyframes edge-animation-frame {
    from {
      stroke-dashoffset: 0;
    }
  }
  @keyframes dash {
    to {
      stroke-dashoffset: 0;
    }
  }
  & .edge-animation-slow {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 50s linear infinite;
    stroke-linecap: round;
  }
  & .edge-animation-fast {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 20s linear infinite;
    stroke-linecap: round;
  }
  /* Classes common for multiple diagrams */

  & .error-icon {
    fill: ${options.errorBkgColor};
  }
  & .error-text {
    fill: ${options.errorTextColor};
    stroke: ${options.errorTextColor};
  }

  & .edge-thickness-normal {
    stroke-width: ${(_options$strokeWidth = options.strokeWidth) !== null && _options$strokeWidth !== void 0 ? _options$strokeWidth : 1}px;
  }
  & .edge-thickness-thick {
    stroke-width: 3.5px
  }
  & .edge-pattern-solid {
    stroke-dasharray: 0;
  }
  & .edge-thickness-invisible {
    stroke-width: 0;
    fill: none;
  }
  & .edge-pattern-dashed{
    stroke-dasharray: 3;
  }
  .edge-pattern-dotted {
    stroke-dasharray: 2;
  }

  & .marker {
    fill: ${options.lineColor};
    stroke: ${options.lineColor};
  }
  & .marker.cross {
    stroke: ${options.lineColor};
  }

  & svg {
    font-family: ${options.fontFamily};
    font-size: ${options.fontSize};
  }
   & p {
    margin: 0
   }

  ${diagramStyles}
  .node .neo-node {
    stroke: ${options.nodeBorder};
  }

  [data-look="neo"].node rect, [data-look="neo"].cluster rect, [data-look="neo"].node polygon {
    stroke: ${options.useGradient ? "url(" + svgId + "-gradient)" : options.nodeBorder};
    filter: ${options.dropShadow ? options.dropShadow.replace("url(#drop-shadow)", `url(${svgId}-drop-shadow)`) : "none"};
  }
  [data-look="neo"].swimlane.cluster rect {
    filter: none;
  }


  [data-look="neo"].node path {
    stroke: ${options.useGradient ? "url(" + svgId + "-gradient)" : options.nodeBorder};
    stroke-width: ${(_options$strokeWidth2 = options.strokeWidth) !== null && _options$strokeWidth2 !== void 0 ? _options$strokeWidth2 : 1}px;
  }

  [data-look="neo"].node .outer-path {
    filter: ${options.dropShadow ? options.dropShadow.replace("url(#drop-shadow)", `url(${svgId}-drop-shadow)`) : "none"};
  }

  [data-look="neo"].node .neo-line path {
    stroke: ${options.nodeBorder};
    filter: none;
  }

  [data-look="neo"].node circle{
    stroke: ${options.useGradient ? "url(" + svgId + "-gradient)" : options.nodeBorder};
    filter: ${options.dropShadow ? options.dropShadow.replace("url(#drop-shadow)", `url(${svgId}-drop-shadow)`) : "none"};
  }

  [data-look="neo"].node circle .state-start{
    fill: #000000;
  }

  [data-look="neo"].icon-shape .icon {
    fill: ${options.useGradient ? "url(" + svgId + "-gradient)" : options.nodeBorder};
    filter: ${options.dropShadow ? options.dropShadow.replace("url(#drop-shadow)", `url(${svgId}-drop-shadow)`) : "none"};
  }

    [data-look="neo"].icon-shape .icon-neo path {
    stroke: ${options.useGradient ? "url(" + svgId + "-gradient)" : options.nodeBorder};
    filter: ${options.dropShadow ? options.dropShadow.replace("url(#drop-shadow)", `url(${svgId}-drop-shadow)`) : "none"};
  }

  ${userStyles}
`;
}, "getStyles");
var addStylesForDiagram = /* @__PURE__ */ __name((type, diagramTheme) => {
	if (diagramTheme !== void 0) themes[type] = diagramTheme;
}, "addStylesForDiagram");
var styles_default = getStyles;
var commonDb_exports = {};
__export(commonDb_exports, {
	clear: () => clear,
	getAccDescription: () => getAccDescription,
	getAccTitle: () => getAccTitle,
	getDiagramTitle: () => getDiagramTitle,
	setAccDescription: () => setAccDescription,
	setAccTitle: () => setAccTitle,
	setDiagramTitle: () => setDiagramTitle
});
var accTitle = "";
var diagramTitle = "";
var accDescription = "";
var sanitizeText2 = /* @__PURE__ */ __name((txt) => sanitizeText(txt, getConfig()), "sanitizeText");
var clear = /* @__PURE__ */ __name(() => {
	accTitle = "";
	accDescription = "";
	diagramTitle = "";
}, "clear");
var setAccTitle = /* @__PURE__ */ __name((txt) => {
	accTitle = sanitizeText2(txt).replace(/^\s+/g, "");
}, "setAccTitle");
var getAccTitle = /* @__PURE__ */ __name(() => accTitle, "getAccTitle");
var setAccDescription = /* @__PURE__ */ __name((txt) => {
	accDescription = sanitizeText2(txt).replace(/\n\s+/g, "\n");
}, "setAccDescription");
var getAccDescription = /* @__PURE__ */ __name(() => accDescription, "getAccDescription");
var setDiagramTitle = /* @__PURE__ */ __name((txt) => {
	diagramTitle = sanitizeText2(txt);
}, "setDiagramTitle");
var getDiagramTitle = /* @__PURE__ */ __name(() => diagramTitle, "getDiagramTitle");
var log2 = log;
var setLogLevel2 = setLogLevel;
var getConfig2 = getConfig;
var setConfig2 = setConfig;
var defaultConfig2 = defaultConfig;
var sanitizeText3 = /* @__PURE__ */ __name((text) => sanitizeText(text, getConfig2()), "sanitizeText");
var setupGraphViewbox2 = setupGraphViewbox;
var getCommonDb = /* @__PURE__ */ __name(() => {
	return commonDb_exports;
}, "getCommonDb");
var diagrams = {};
var registerDiagram = /* @__PURE__ */ __name((id, diagram, detector) => {
	var _diagram$injectUtils;
	if (diagrams[id]) log2.warn(`Diagram with id ${id} already registered. Overwriting.`);
	diagrams[id] = diagram;
	if (detector) addDetector(id, detector);
	addStylesForDiagram(id, diagram.styles);
	(_diagram$injectUtils = diagram.injectUtils) === null || _diagram$injectUtils === void 0 || _diagram$injectUtils.call(diagram, log2, setLogLevel2, getConfig2, sanitizeText3, setupGraphViewbox2, getCommonDb(), () => {});
}, "registerDiagram");
var getDiagram = /* @__PURE__ */ __name((name) => {
	if (name in diagrams) return diagrams[name];
	throw new DiagramNotFoundError(name);
}, "getDiagram");
var DiagramNotFoundError = (_Class13 = class extends Error {
	constructor(name) {
		super(`Diagram ${name} not found.`);
	}
}, __name(_Class13, "DiagramNotFoundError"), _Class13);
//#endregion
export { purify as $, hasKatex as A, sanitizeText3 as B, getDiagramLoader as C, getThemeVariables3 as D, getSiteConfig as E, renderKatexSanitized as F, setConfig2 as G, setAccDescription as H, reset as I, setupGraphViewbox as J, setDiagramTitle as K, sanitizeCss as L, parseGenericTypes as M, registerDiagram as N, getUrl as O, registerLazyLoadedDiagrams as P, updateSiteConfig as Q, sanitizeDirective as R, getDiagram as S, getEffectiveHtmlLabels as T, setAccTitle as U, saveConfigFromInitialize as V, setConfig as W, styles_default as X, setupGraphViewbox2 as Y, themes_default as Z, frontMatterRegex as _, clear as a, Color as at, getConfig as b, configureSvgSize as c, defaultConfig2 as d, darken as et, defaultConfig_default as f, evaluate as g, directiveRegex as h, calculateMathMLDimensions as i, rgba as it, lineBreakRegex as j, getUserDefinedConfig as k, cssStyleSheetToString as l, detectors as m, addDirective as n, adjustChannel as nt, commonDb_exports as o, Utils as ot, detectType as p, setSiteConfig as q, assignWithDepth_default as r, isDark as rt, common_default as s, UnknownDiagramError as t, lighten as tt, defaultConfig as u, getAccDescription as v, getDiagramTitle as w, getConfig2 as x, getAccTitle as y, sanitizeText as z };

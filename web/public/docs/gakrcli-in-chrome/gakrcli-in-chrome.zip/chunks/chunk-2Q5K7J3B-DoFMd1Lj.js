import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/chunk-2Q5K7J3B.mjs
var _Class;
var ImperativeState = (_Class = class {
	/**
	* @param init - Function that creates the default state.
	*/
	constructor(init) {
		this.init = init;
		this.records = this.init();
	}
	reset() {
		this.records = this.init();
	}
}, __name(_Class, "ImperativeState"), _Class);
//#endregion
export { ImperativeState as t };

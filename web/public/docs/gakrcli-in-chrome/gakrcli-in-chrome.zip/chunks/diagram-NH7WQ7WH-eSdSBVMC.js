import { i as _objectSpread2, o as _asyncToGenerator } from "./_plugin-vue_export-helper-BdaNZm_w.js";
import { n as parse } from "./mermaid-parser.core-98BDf-ly.js";
import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import { m as log } from "./src-C3sq9HJl.js";
import { H as setAccDescription, K as setDiagramTitle, U as setAccTitle, a as clear, b as getConfig, c as configureSvgSize, f as defaultConfig_default, v as getAccDescription, w as getDiagramTitle, y as getAccTitle } from "./chunk-WYO6CB5R-D3hdW-kf.js";
import { i as cleanAndMerge } from "./chunk-ICXQ74PX-BROveA7q.js";
import { t as selectSvgElement } from "./chunk-VAUOI2AC-BR-opl7u.js";
import { t as populateCommonDb } from "./chunk-JWPE2WC7-BB1BWMKO.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/diagram-NH7WQ7WH.mjs
var _Class;
var DEFAULT_PACKET_CONFIG = defaultConfig_default.packet;
var PacketDB = (_Class = class {
	constructor() {
		this.packet = [];
		this.setAccTitle = setAccTitle;
		this.getAccTitle = getAccTitle;
		this.setDiagramTitle = setDiagramTitle;
		this.getDiagramTitle = getDiagramTitle;
		this.getAccDescription = getAccDescription;
		this.setAccDescription = setAccDescription;
	}
	getConfig() {
		const config = cleanAndMerge(_objectSpread2(_objectSpread2({}, DEFAULT_PACKET_CONFIG), getConfig().packet));
		if (config.showBits) config.paddingY += 10;
		return config;
	}
	getPacket() {
		return this.packet;
	}
	pushWord(word) {
		if (word.length > 0) this.packet.push(word);
	}
	clear() {
		clear();
		this.packet = [];
	}
}, __name(_Class, "PacketDB"), _Class);
var maxPacketSize = 1e4;
var populate = /* @__PURE__ */ __name((ast, db) => {
	populateCommonDb(ast, db);
	let lastBit = -1;
	let word = [];
	let row = 1;
	const { bitsPerRow } = db.getConfig();
	for (let { start, end, bits, label } of ast.blocks) {
		var _start, _end2, _bits, _bits2;
		if (start !== void 0 && end !== void 0 && end < start) throw new Error(`Packet block ${start} - ${end} is invalid. End must be greater than start.`);
		(_start = start) !== null && _start !== void 0 || (start = lastBit + 1);
		if (start !== lastBit + 1) {
			var _end;
			throw new Error(`Packet block ${start} - ${(_end = end) !== null && _end !== void 0 ? _end : start} is not contiguous. It should start from ${lastBit + 1}.`);
		}
		if (bits === 0) throw new Error(`Packet block ${start} is invalid. Cannot have a zero bit field.`);
		(_end2 = end) !== null && _end2 !== void 0 || (end = start + ((_bits = bits) !== null && _bits !== void 0 ? _bits : 1) - 1);
		(_bits2 = bits) !== null && _bits2 !== void 0 || (bits = end - start + 1);
		lastBit = end;
		log.debug(`Packet block ${start} - ${lastBit} with label ${label}`);
		while (word.length <= bitsPerRow + 1 && db.getPacket().length < maxPacketSize) {
			const [block, nextBlock] = getNextFittingBlock({
				start,
				end,
				bits,
				label
			}, row, bitsPerRow);
			word.push(block);
			if (block.end + 1 === row * bitsPerRow) {
				db.pushWord(word);
				word = [];
				row++;
			}
			if (!nextBlock) break;
			({start, end, bits, label} = nextBlock);
		}
	}
	db.pushWord(word);
}, "populate");
var getNextFittingBlock = /* @__PURE__ */ __name((block, row, bitsPerRow) => {
	if (block.start === void 0) throw new Error("start should have been set during first phase");
	if (block.end === void 0) throw new Error("end should have been set during first phase");
	if (block.start > block.end) throw new Error(`Block start ${block.start} is greater than block end ${block.end}.`);
	if (block.end + 1 <= row * bitsPerRow) return [block, void 0];
	const rowEnd = row * bitsPerRow - 1;
	const rowStart = row * bitsPerRow;
	return [{
		start: block.start,
		end: rowEnd,
		label: block.label,
		bits: rowEnd - block.start
	}, {
		start: rowStart,
		end: block.end,
		label: block.label,
		bits: block.end - rowStart
	}];
}, "getNextFittingBlock");
var parser = {
	parser: { yy: void 0 },
	parse: /* @__PURE__ */ __name(function() {
		var _ref = _asyncToGenerator(function* (input) {
			var _parser$parser;
			const ast = yield parse("packet", input);
			const db = (_parser$parser = parser.parser) === null || _parser$parser === void 0 ? void 0 : _parser$parser.yy;
			if (!(db instanceof PacketDB)) throw new Error("parser.parser?.yy was not a PacketDB. This is due to a bug within Mermaid, please report this issue at https://github.com/mermaid-js/mermaid/issues.");
			log.debug(ast);
			populate(ast, db);
		});
		return function(_x) {
			return _ref.apply(this, arguments);
		};
	}(), "parse")
};
var draw = /* @__PURE__ */ __name((_text, id, _version, diagram2) => {
	const db = diagram2.db;
	const config = db.getConfig();
	const { rowHeight, paddingY, bitWidth, bitsPerRow } = config;
	const words = db.getPacket();
	const title = db.getDiagramTitle();
	const totalRowHeight = rowHeight + paddingY;
	const svgHeight = totalRowHeight * (words.length + 1) - (title ? 0 : rowHeight);
	const svgWidth = bitWidth * bitsPerRow + 2;
	const svg = selectSvgElement(id);
	svg.attr("viewBox", `0 0 ${svgWidth} ${svgHeight}`);
	configureSvgSize(svg, svgHeight, svgWidth, config.useMaxWidth);
	for (const [word, packet] of words.entries()) drawWord(svg, packet, word, config);
	svg.append("text").text(title).attr("x", svgWidth / 2).attr("y", svgHeight - totalRowHeight / 2).attr("dominant-baseline", "middle").attr("text-anchor", "middle").attr("class", "packetTitle");
}, "draw");
var drawWord = /* @__PURE__ */ __name((svg, word, rowNumber, { rowHeight, paddingX, paddingY, bitWidth, bitsPerRow, showBits }) => {
	const group = svg.append("g");
	const wordY = rowNumber * (rowHeight + paddingY) + paddingY;
	for (const block of word) {
		const blockX = block.start % bitsPerRow * bitWidth + 1;
		const width = (block.end - block.start + 1) * bitWidth - paddingX;
		group.append("rect").attr("x", blockX).attr("y", wordY).attr("width", width).attr("height", rowHeight).attr("class", "packetBlock");
		group.append("text").attr("x", blockX + width / 2).attr("y", wordY + rowHeight / 2).attr("class", "packetLabel").attr("dominant-baseline", "middle").attr("text-anchor", "middle").text(block.label);
		if (!showBits) continue;
		const isSingleBlock = block.end === block.start;
		const bitNumberY = wordY - 2;
		group.append("text").attr("x", blockX + (isSingleBlock ? width / 2 : 0)).attr("y", bitNumberY).attr("class", "packetByte start").attr("dominant-baseline", "auto").attr("text-anchor", isSingleBlock ? "middle" : "start").text(block.start);
		if (!isSingleBlock) group.append("text").attr("x", blockX + width).attr("y", bitNumberY).attr("class", "packetByte end").attr("dominant-baseline", "auto").attr("text-anchor", "end").text(block.end);
	}
}, "drawWord");
var renderer = { draw };
var defaultPacketStyleOptions = {
	byteFontSize: "10px",
	startByteColor: "black",
	endByteColor: "black",
	labelColor: "black",
	labelFontSize: "12px",
	titleColor: "black",
	titleFontSize: "14px",
	blockStrokeColor: "black",
	blockStrokeWidth: "1",
	blockFillColor: "#efefef"
};
var diagram = {
	parser,
	get db() {
		return new PacketDB();
	},
	renderer,
	styles: /* @__PURE__ */ __name(({ packet } = {}) => {
		const options = cleanAndMerge(defaultPacketStyleOptions, packet);
		return `
	.packetByte {
		font-size: ${options.byteFontSize};
	}
	.packetByte.start {
		fill: ${options.startByteColor};
	}
	.packetByte.end {
		fill: ${options.endByteColor};
	}
	.packetLabel {
		fill: ${options.labelColor};
		font-size: ${options.labelFontSize};
	}
	.packetTitle {
		fill: ${options.titleColor};
		font-size: ${options.titleFontSize};
	}
	.packetBlock {
		stroke: ${options.blockStrokeColor};
		stroke-width: ${options.blockStrokeWidth};
		fill: ${options.blockFillColor};
	}
	`;
	}, "styles")
};
//#endregion
export { diagram };

import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import { m as log } from "./src-C3sq9HJl.js";
import { c as configureSvgSize } from "./chunk-WYO6CB5R-DF29PLGk.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/chunk-VR4S4FIN.mjs
var setupViewPortForSVG = /* @__PURE__ */ __name((svg, padding, cssDiagram, useMaxWidth) => {
	svg.attr("class", cssDiagram);
	const { width, height, x, y } = calculateDimensionsWithPadding(svg, padding);
	configureSvgSize(svg, height, width, useMaxWidth);
	const viewBox = createViewBox(x, y, width, height, padding);
	svg.attr("viewBox", viewBox);
	log.debug(`viewBox configured: ${viewBox} with padding: ${padding}`);
}, "setupViewPortForSVG");
var calculateDimensionsWithPadding = /* @__PURE__ */ __name((svg, padding) => {
	var _svg$node;
	const bounds = ((_svg$node = svg.node()) === null || _svg$node === void 0 ? void 0 : _svg$node.getBBox()) || {
		width: 0,
		height: 0,
		x: 0,
		y: 0
	};
	return {
		width: bounds.width + padding * 2,
		height: bounds.height + padding * 2,
		x: bounds.x,
		y: bounds.y
	};
}, "calculateDimensionsWithPadding");
var createViewBox = /* @__PURE__ */ __name((x, y, width, height, padding) => {
	return `${x - padding} ${y - padding} ${width} ${height}`;
}, "createViewBox");
//#endregion
export { setupViewPortForSVG as t };

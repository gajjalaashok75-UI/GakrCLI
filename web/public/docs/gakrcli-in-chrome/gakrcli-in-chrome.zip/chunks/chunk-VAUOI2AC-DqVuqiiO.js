import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import { p as select_default } from "./src-C3sq9HJl.js";
import { x as getConfig2 } from "./chunk-WYO6CB5R-DF29PLGk.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/chunk-VAUOI2AC.mjs
var selectSvgElement = /* @__PURE__ */ __name((id) => {
	const { securityLevel } = getConfig2();
	let root = select_default("body");
	if (securityLevel === "sandbox") {
		var _sandboxElement$node$, _sandboxElement$node;
		root = select_default(((_sandboxElement$node$ = (_sandboxElement$node = select_default(`#i${id}`).node()) === null || _sandboxElement$node === void 0 ? void 0 : _sandboxElement$node.contentDocument) !== null && _sandboxElement$node$ !== void 0 ? _sandboxElement$node$ : document).body);
	}
	return root.select(`#${id}`);
}, "selectSvgElement");
//#endregion
export { selectSvgElement as t };

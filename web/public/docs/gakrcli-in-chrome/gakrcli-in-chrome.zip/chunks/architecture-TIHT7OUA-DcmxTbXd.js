import "./chunk-KEIR6QF5-Af8e2JZB.js";
import { M as createArchitectureServices, j as ArchitectureModule } from "./mermaid-parser.core-DhYO2Vvm.js";
export { ArchitectureModule, createArchitectureServices };

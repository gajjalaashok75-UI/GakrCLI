import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import "./src-C3sq9HJl.js";
import "./chunk-WYO6CB5R-D3hdW-kf.js";
import "./chunk-ICXQ74PX-BROveA7q.js";
import "./chunk-HOUHSVGY-6mKlY5gd.js";
import "./chunk-Q4XR5HBZ-zk1zulYp.js";
import "./chunk-7BUUIJ7U-C8VFPhS9.js";
import "./chunk-OGEWGWER-CRC47pvB.js";
import "./chunk-32BRIVSS-uxbWPu1s.js";
import "./chunk-XXDRQBXY-CWeuWqam.js";
import "./chunk-VR4S4FIN-D9_C6ECh.js";
import "./chunk-C7G6YPKG-C0Dwy7It.js";
import "./chunk-ZGVPDNZ5-DeHkl6jW.js";
import "./chunk-52WLFC77-Cz74qZ02.js";
import "./chunk-FWX5IMBZ-C0t88zp8.js";
import { i as styles_default, n as classDiagram_default, r as classRenderer_v3_unified_default, t as ClassDB } from "./chunk-V7JOEXUC-BCvkoBmJ.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/classDiagram-OUVF2IWQ.mjs
var diagram = {
	parser: classDiagram_default,
	get db() {
		return new ClassDB();
	},
	renderer: classRenderer_v3_unified_default,
	styles: styles_default,
	init: /* @__PURE__ */ __name((cnf) => {
		if (!cnf.class) cnf.class = {};
		cnf.class.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
	}, "init")
};
//#endregion
export { diagram };

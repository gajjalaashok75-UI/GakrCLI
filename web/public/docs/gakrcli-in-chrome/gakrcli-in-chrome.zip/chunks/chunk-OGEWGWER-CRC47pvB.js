import { o as _asyncToGenerator } from "./_plugin-vue_export-helper-BdaNZm_w.js";
import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import { f as defaultConfig_default, x as getConfig2 } from "./chunk-WYO6CB5R-D3hdW-kf.js";
import { p as parseFontSize } from "./chunk-ICXQ74PX-BROveA7q.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/chunk-OGEWGWER.mjs
var getSubGraphTitleMargins = /* @__PURE__ */ __name(({ flowchart }) => {
	var _flowchart$subGraphTi, _flowchart$subGraphTi2, _flowchart$subGraphTi3, _flowchart$subGraphTi4;
	const subGraphTitleTopMargin = (_flowchart$subGraphTi = flowchart === null || flowchart === void 0 || (_flowchart$subGraphTi2 = flowchart.subGraphTitleMargin) === null || _flowchart$subGraphTi2 === void 0 ? void 0 : _flowchart$subGraphTi2.top) !== null && _flowchart$subGraphTi !== void 0 ? _flowchart$subGraphTi : 0;
	const subGraphTitleBottomMargin = (_flowchart$subGraphTi3 = flowchart === null || flowchart === void 0 || (_flowchart$subGraphTi4 = flowchart.subGraphTitleMargin) === null || _flowchart$subGraphTi4 === void 0 ? void 0 : _flowchart$subGraphTi4.bottom) !== null && _flowchart$subGraphTi3 !== void 0 ? _flowchart$subGraphTi3 : 0;
	return {
		subGraphTitleTopMargin,
		subGraphTitleBottomMargin,
		subGraphTitleTotalMargin: subGraphTitleTopMargin + subGraphTitleBottomMargin
	};
}, "getSubGraphTitleMargins");
function configureLabelImages(_x, _x2) {
	return _configureLabelImages.apply(this, arguments);
}
function _configureLabelImages() {
	_configureLabelImages = _asyncToGenerator(function* (container, labelText) {
		const images = container.getElementsByTagName("img");
		if (!images || images.length === 0) return;
		const noImgText = labelText.replace(/<img[^>]*>/g, "").trim() === "";
		yield Promise.all([...images].map((img) => new Promise((res) => {
			function setupImage() {
				img.style.display = "flex";
				img.style.flexDirection = "column";
				if (noImgText) {
					const bodyFontSize = getConfig2().fontSize ? getConfig2().fontSize : window.getComputedStyle(document.body).fontSize;
					const enlargingFactor = 5;
					const [parsedBodyFontSize = defaultConfig_default.fontSize] = parseFontSize(bodyFontSize);
					const width = parsedBodyFontSize * enlargingFactor + "px";
					img.style.minWidth = width;
					img.style.maxWidth = width;
				} else img.style.width = "100%";
				res(img);
			}
			__name(setupImage, "setupImage");
			setTimeout(() => {
				if (img.complete) setupImage();
			});
			img.addEventListener("error", setupImage);
			img.addEventListener("load", setupImage);
		})));
	});
	return _configureLabelImages.apply(this, arguments);
}
__name(configureLabelImages, "configureLabelImages");
//#endregion
export { getSubGraphTitleMargins as n, configureLabelImages as t };

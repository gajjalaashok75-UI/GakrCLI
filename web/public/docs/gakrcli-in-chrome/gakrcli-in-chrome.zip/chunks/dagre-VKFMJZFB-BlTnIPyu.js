import { i as _objectSpread2, o as _asyncToGenerator } from "./_plugin-vue_export-helper-BdaNZm_w.js";
import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import { m as log } from "./src-C3sq9HJl.js";
import { x as getConfig2 } from "./chunk-WYO6CB5R-DF29PLGk.js";
import "./chunk-ICXQ74PX-uHG3Ffj0.js";
import "./chunk-HOUHSVGY-CVL8H-HK.js";
import "./chunk-Q4XR5HBZ-DZCdVpNm.js";
import "./chunk-7BUUIJ7U-C8VFPhS9.js";
import { n as getSubGraphTitleMargins } from "./chunk-OGEWGWER-uLtBsKke.js";
import { t as Graph } from "./graphlib-BeRFn2Zg.js";
import { t as layout } from "./dagre-DCesMOFZ.js";
import { a as sortNodesByHierarchy, i as findNonClusterChild, n as clear, o as write, r as clusterDb, t as adjustClustersAndEdges } from "./chunk-RYQCIY6F-DgeY5dqo.js";
import "./chunk-C7G6YPKG-DYyxSEiR.js";
import { a as insertNode, c as positionNode, i as insertCluster, l as setNodeElem, n as clear2, t as clear$1, u as updateNodeBounds } from "./chunk-ZGVPDNZ5-wnE8lhSD.js";
import { a as markers_default, i as insertEdgeLabel, o as positionEdgeLabel, r as insertEdge, t as clear$2 } from "./chunk-52WLFC77-Cn5lWL_k.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/dagre-VKFMJZFB.mjs
var clamp = /* @__PURE__ */ __name((value, min, max) => Math.max(min, Math.min(max, value)), "clamp");
var getDefaultSelfLoopSide = /* @__PURE__ */ __name((rankdir = "TB") => {
	switch (rankdir) {
		case "BT": return "bottom";
		case "LR": return "right";
		case "RL": return "left";
		default: return "top";
	}
}, "getDefaultSelfLoopSide");
var shouldMergeSelfLoopSegments = /* @__PURE__ */ __name((diagramType) => diagramType === "flowchart" || diagramType === "flowchart-v2" || diagramType === "stateDiagram", "shouldMergeSelfLoopSegments");
var getSelfLoopSide = /* @__PURE__ */ __name((graph, node, segments, originalNodeId, rankdir) => {
	const layoutHints = [];
	const dummyNodeIds = /* @__PURE__ */ new Set();
	segments.forEach(({ start, end }) => {
		if (start !== originalNodeId) dummyNodeIds.add(start);
		if (end !== originalNodeId) dummyNodeIds.add(end);
	});
	dummyNodeIds.forEach((id) => {
		const dummyNode = graph.node(id);
		if (typeof (dummyNode === null || dummyNode === void 0 ? void 0 : dummyNode.x) === "number" && typeof (dummyNode === null || dummyNode === void 0 ? void 0 : dummyNode.y) === "number") layoutHints.push(dummyNode);
	});
	if (layoutHints.length === 0) segments.forEach(({ edge }) => {
		var _edge$points;
		((_edge$points = edge.points) !== null && _edge$points !== void 0 ? _edge$points : []).forEach((point) => {
			if (typeof (point === null || point === void 0 ? void 0 : point.x) === "number" && typeof (point === null || point === void 0 ? void 0 : point.y) === "number") layoutHints.push(point);
		});
	});
	if (layoutHints.length === 0) return getDefaultSelfLoopSide(rankdir);
	const center = layoutHints.reduce((acc, point) => ({
		x: acc.x + point.x / layoutHints.length,
		y: acc.y + point.y / layoutHints.length
	}), {
		x: 0,
		y: 0
	});
	const dx = center.x - node.x;
	const dy = center.y - node.y;
	if (Math.abs(dx) > Math.abs(dy)) return dx > 0 ? "right" : "left";
	if (Math.abs(dy) > 0) return dy > 0 ? "bottom" : "top";
	return getDefaultSelfLoopSide(rankdir);
}, "getSelfLoopSide");
var getSelfLoopPoints = /* @__PURE__ */ __name((node, side = "top", yOffset = 0, labelWidth = 0) => {
	const x = node.x;
	const y = node.y - yOffset;
	const halfWidth = node.width / 2;
	const halfHeight = node.height / 2;
	const maxSpan = Math.max(36, Math.min(100, node.width * .8));
	const span = clamp(Math.max(labelWidth, node.width * .35), 36, maxSpan);
	const depth = clamp(Math.min(node.width, node.height) * .45, 24, 48);
	switch (side) {
		case "bottom": {
			const bottom = y + halfHeight;
			return [
				{
					x: x - span / 2,
					y: bottom
				},
				{
					x: x - span / 2,
					y: bottom + depth
				},
				{
					x: x + span / 2,
					y: bottom + depth
				},
				{
					x: x + span / 2,
					y: bottom
				}
			];
		}
		case "right": {
			const right = x + halfWidth;
			return [
				{
					x: right,
					y: y - span / 2
				},
				{
					x: right + depth,
					y: y - span / 2
				},
				{
					x: right + depth,
					y: y + span / 2
				},
				{
					x: right,
					y: y + span / 2
				}
			];
		}
		case "left": {
			const left = x - halfWidth;
			return [
				{
					x: left,
					y: y - span / 2
				},
				{
					x: left - depth,
					y: y - span / 2
				},
				{
					x: left - depth,
					y: y + span / 2
				},
				{
					x: left,
					y: y + span / 2
				}
			];
		}
		default: {
			const top = y - halfHeight;
			return [
				{
					x: x - span / 2,
					y: top
				},
				{
					x: x - span / 2,
					y: top - depth
				},
				{
					x: x + span / 2,
					y: top - depth
				},
				{
					x: x + span / 2,
					y: top
				}
			];
		}
	}
}, "getSelfLoopPoints");
var getSelfLoopLabelPosition = /* @__PURE__ */ __name((node, points, side = "top", yOffset = 0, label = {}) => {
	var _label$width, _label$height;
	const gap = 4;
	const x = node.x;
	const y = node.y - yOffset;
	const labelWidth = (_label$width = label.width) !== null && _label$width !== void 0 ? _label$width : 0;
	const labelHeight = (_label$height = label.height) !== null && _label$height !== void 0 ? _label$height : 0;
	switch (side) {
		case "bottom": return {
			x,
			y: Math.max(...points.map((point) => point.y)) + labelHeight / 2 + gap
		};
		case "right": return {
			x: Math.max(...points.map((point) => point.x)) + labelWidth / 2 + gap,
			y
		};
		case "left": return {
			x: Math.min(...points.map((point) => point.x)) - labelWidth / 2 - gap,
			y
		};
		default: return {
			x,
			y: Math.min(...points.map((point) => point.y)) - labelHeight / 2 - gap
		};
	}
}, "getSelfLoopLabelPosition");
var getEdgesToRender = /* @__PURE__ */ __name((graph, yOffset = 0, { mergeSelfLoops = true } = {}) => {
	var _graph$graph;
	const selfLoopEdgeGroups = /* @__PURE__ */ new Map();
	const edgesToRender = [];
	const rankdir = (_graph$graph = graph.graph()) === null || _graph$graph === void 0 ? void 0 : _graph$graph.rankdir;
	graph.edges().forEach((e) => {
		const edge = graph.edge(e);
		if (mergeSelfLoops && edge.selfLoop) {
			const key = edge.selfLoop.id;
			if (!selfLoopEdgeGroups.has(key)) selfLoopEdgeGroups.set(key, []);
			selfLoopEdgeGroups.get(key).push({
				edge,
				start: e.v,
				end: e.w
			});
		} else edgesToRender.push({
			edge,
			start: e.v,
			end: e.w
		});
	});
	selfLoopEdgeGroups.forEach((segments) => {
		var _ref, _ref2, _firstSegment$edge$or, _label$width2, _ref3, _firstSegment$edge$fr, _ref4, _firstSegment$edge$to;
		if (segments.length !== 3) {
			segments.forEach((segment) => edgesToRender.push(segment));
			return;
		}
		segments.sort((a, b) => a.edge.selfLoop.order - b.edge.selfLoop.order);
		const [firstSegment, middleSegment, lastSegment] = segments;
		const originalEdge = (_ref = (_ref2 = (_firstSegment$edge$or = firstSegment.edge.originalEdge) !== null && _firstSegment$edge$or !== void 0 ? _firstSegment$edge$or : middleSegment.edge.originalEdge) !== null && _ref2 !== void 0 ? _ref2 : lastSegment.edge.originalEdge) !== null && _ref !== void 0 ? _ref : middleSegment.edge;
		const node = graph.node(originalEdge.start);
		if (!node) {
			segments.forEach((segment) => edgesToRender.push(segment));
			return;
		}
		const label = {
			width: middleSegment.edge.width,
			height: middleSegment.edge.height
		};
		const side = getSelfLoopSide(graph, node, segments, originalEdge.start, rankdir);
		const points = getSelfLoopPoints(node, side, yOffset, (_label$width2 = label.width) !== null && _label$width2 !== void 0 ? _label$width2 : 0);
		const labelPosition = getSelfLoopLabelPosition(node, points, side, yOffset, label);
		const mergedEdge = _objectSpread2(_objectSpread2(_objectSpread2({}, middleSegment.edge), originalEdge), {}, {
			id: originalEdge.id,
			points,
			start: originalEdge.start,
			end: originalEdge.end,
			x: labelPosition.x,
			y: labelPosition.y,
			width: label.width,
			height: label.height,
			labelStyle: middleSegment.edge.labelStyle,
			fromCluster: (_ref3 = (_firstSegment$edge$fr = firstSegment.edge.fromCluster) !== null && _firstSegment$edge$fr !== void 0 ? _firstSegment$edge$fr : middleSegment.edge.fromCluster) !== null && _ref3 !== void 0 ? _ref3 : lastSegment.edge.fromCluster,
			toCluster: (_ref4 = (_firstSegment$edge$to = firstSegment.edge.toCluster) !== null && _firstSegment$edge$to !== void 0 ? _firstSegment$edge$to : middleSegment.edge.toCluster) !== null && _ref4 !== void 0 ? _ref4 : lastSegment.edge.toCluster
		});
		delete mergedEdge.selfLoop;
		delete mergedEdge.originalEdge;
		edgesToRender.push({
			edge: mergedEdge,
			start: mergedEdge.start,
			end: mergedEdge.end
		});
	});
	return edgesToRender;
}, "getEdgesToRender");
var recursiveRender = /* @__PURE__ */ __name(function() {
	var _ref8 = _asyncToGenerator(function* (_elem, graph, diagramType, id, parentCluster, siteConfig) {
		log.warn("Graph in recursive render:XAX", write(graph), parentCluster);
		const dir = graph.graph().rankdir;
		log.trace("Dir in recursive render - dir:", dir);
		const elem = _elem.insert("g").attr("class", "root");
		if (!graph.nodes()) log.info("No nodes found for", graph);
		else log.info("Recursive render XXX", graph.nodes());
		if (graph.edges().length > 0) log.info("Recursive edges", graph.edge(graph.edges()[0]));
		const clusters = elem.insert("g").attr("class", "clusters");
		const edgePaths = elem.insert("g").attr("class", "edgePaths");
		const edgeLabels = elem.insert("g").attr("class", "edgeLabels");
		const nodes = elem.insert("g").attr("class", "nodes");
		const mergeSelfLoops = shouldMergeSelfLoopSegments(diagramType);
		yield Promise.all(graph.nodes().map(/* @__PURE__ */ function() {
			var _ref5 = _asyncToGenerator(function* (v) {
				const node = graph.node(v);
				if (parentCluster !== void 0) {
					const data = JSON.parse(JSON.stringify(parentCluster.clusterData));
					log.trace("Setting data for parent cluster XXX\n Node.id = ", v, "\n data=", data.height, "\nParent cluster", parentCluster.height);
					graph.setNode(parentCluster.id, data);
					if (!graph.parent(v)) {
						log.trace("Setting parent", v, parentCluster.id);
						graph.setParent(v, parentCluster.id, data);
					}
				}
				log.info("(Insert) Node XXX" + v + ": " + JSON.stringify(graph.node(v)));
				if (node === null || node === void 0 ? void 0 : node.clusterNode) {
					log.info("Cluster identified XBX", v, node.width, graph.node(v));
					const { ranksep, nodesep } = graph.graph();
					node.graph.setGraph(_objectSpread2(_objectSpread2({}, node.graph.graph()), {}, {
						ranksep: ranksep + 25,
						nodesep
					}));
					const o = yield recursiveRender(nodes, node.graph, diagramType, id, graph.node(v), siteConfig);
					const newEl = o.elem;
					updateNodeBounds(node, newEl);
					node.diff = o.diff || 0;
					log.info("New compound node after recursive render XAX", v, "width", node.width, "height", node.height);
					setNodeElem(newEl, node);
				} else if (graph.children(v).length > 0) {
					log.trace("Cluster - the non recursive path XBX", v, node.id, node, node.width, "Graph:", graph);
					log.trace(findNonClusterChild(node.id, graph));
					clusterDb.set(node.id, {
						id: findNonClusterChild(node.id, graph),
						node
					});
				} else {
					log.trace("Node - the non recursive path XAX", v, nodes, graph.node(v), dir);
					yield insertNode(nodes, graph.node(v), {
						config: siteConfig,
						dir
					});
				}
			});
			return function(_x) {
				return _ref5.apply(this, arguments);
			};
		}()));
		yield (/* @__PURE__ */ __name(_asyncToGenerator(function* () {
			const edgePromises = graph.edges().map(/* @__PURE__ */ function() {
				var _ref6 = _asyncToGenerator(function* (e) {
					const edge = graph.edge(e.v, e.w, e.name);
					log.info("Edge " + e.v + " -> " + e.w + ": " + JSON.stringify(e));
					log.info("Edge " + e.v + " -> " + e.w + ": ", e, " ", JSON.stringify(graph.edge(e)));
					log.info("Fix", clusterDb, "ids:", e.v, e.w, "Translating: ", clusterDb.get(e.v), clusterDb.get(e.w));
					if (mergeSelfLoops && edge.selfLoop) {
						if (edge.selfLoop.order !== 1) return;
						const segmentId = edge.id;
						edge.id = edge.selfLoop.id;
						yield insertEdgeLabel(edgeLabels, edge);
						edge.id = segmentId;
						return;
					}
					yield insertEdgeLabel(edgeLabels, edge);
				});
				return function(_x2) {
					return _ref6.apply(this, arguments);
				};
			}());
			yield Promise.all(edgePromises);
		}), "processEdges"))();
		log.info("Graph before layout:", JSON.stringify(write(graph)));
		log.info("############################################# XXX");
		log.info("###                Layout                 ### XXX");
		log.info("############################################# XXX");
		layout(graph);
		log.info("Graph after layout:", JSON.stringify(write(graph)));
		let diff = 0;
		let { subGraphTitleTotalMargin } = getSubGraphTitleMargins(siteConfig);
		yield Promise.all(sortNodesByHierarchy(graph).map(/* @__PURE__ */ function() {
			var _ref7 = _asyncToGenerator(function* (v) {
				const node = graph.node(v);
				log.info("Position XBX => " + v + ": (" + node.x, "," + node.y, ") width: ", node.width, " height: ", node.height);
				if (node === null || node === void 0 ? void 0 : node.clusterNode) {
					node.y += subGraphTitleTotalMargin;
					log.info("A tainted cluster node XBX1", v, node.id, node.width, node.height, node.x, node.y, graph.parent(v));
					clusterDb.get(node.id).node = node;
					positionNode(node);
				} else if (graph.children(v).length > 0) {
					var _node$labelBBox;
					log.info("A pure cluster node XBX1", v, node.id, node.x, node.y, node.width, node.height, graph.parent(v));
					node.height += subGraphTitleTotalMargin;
					graph.node(node.parentId);
					const halfPadding = (node === null || node === void 0 ? void 0 : node.padding) / 2 || 0;
					const labelHeight = (node === null || node === void 0 || (_node$labelBBox = node.labelBBox) === null || _node$labelBBox === void 0 ? void 0 : _node$labelBBox.height) || 0;
					const offsetY = labelHeight - halfPadding || 0;
					log.debug("OffsetY", offsetY, "labelHeight", labelHeight, "halfPadding", halfPadding);
					yield insertCluster(clusters, node);
					clusterDb.get(node.id).node = node;
				} else {
					const parent = graph.node(node.parentId);
					node.y += subGraphTitleTotalMargin / 2;
					log.info("A regular node XBX1 - using the padding", node.id, "parent", node.parentId, node.width, node.height, node.x, node.y, "offsetY", node.offsetY, "parent", parent, parent === null || parent === void 0 ? void 0 : parent.offsetY, node);
					positionNode(node);
				}
			});
			return function(_x3) {
				return _ref7.apply(this, arguments);
			};
		}()));
		const edgeOffsetY = subGraphTitleTotalMargin / 2;
		getEdgesToRender(graph, edgeOffsetY, { mergeSelfLoops }).forEach(function({ edge, start, end }) {
			log.info("Edge " + start + " -> " + end + ": " + JSON.stringify(edge), edge);
			edge.points.forEach((point) => point.y += edgeOffsetY);
			positionEdgeLabel(edge, insertEdge(edgePaths, edge, clusterDb, diagramType, graph.node(start), graph.node(end), id));
		});
		graph.nodes().forEach(function(v) {
			const n = graph.node(v);
			log.info(v, n.type, n.diff);
			if (n.isGroup) diff = n.diff;
		});
		log.warn("Returning from recursive render XAX", elem, diff);
		return {
			elem,
			diff
		};
	});
	return function(_x4, _x5, _x6, _x7, _x8, _x9) {
		return _ref8.apply(this, arguments);
	};
}(), "recursiveRender");
var render = /* @__PURE__ */ __name(function() {
	var _ref9 = _asyncToGenerator(function* (data4Layout, svg) {
		var _data4Layout$config, _data4Layout$config2, _data4Layout$config3, _data4Layout$config4;
		const graph = new Graph({
			multigraph: true,
			compound: true
		}).setGraph({
			rankdir: data4Layout.direction,
			nodesep: ((_data4Layout$config = data4Layout.config) === null || _data4Layout$config === void 0 ? void 0 : _data4Layout$config.nodeSpacing) || ((_data4Layout$config2 = data4Layout.config) === null || _data4Layout$config2 === void 0 || (_data4Layout$config2 = _data4Layout$config2.flowchart) === null || _data4Layout$config2 === void 0 ? void 0 : _data4Layout$config2.nodeSpacing) || data4Layout.nodeSpacing,
			ranksep: ((_data4Layout$config3 = data4Layout.config) === null || _data4Layout$config3 === void 0 ? void 0 : _data4Layout$config3.rankSpacing) || ((_data4Layout$config4 = data4Layout.config) === null || _data4Layout$config4 === void 0 || (_data4Layout$config4 = _data4Layout$config4.flowchart) === null || _data4Layout$config4 === void 0 ? void 0 : _data4Layout$config4.rankSpacing) || data4Layout.rankSpacing,
			marginx: 8,
			marginy: 8
		}).setDefaultEdgeLabel(function() {
			return {};
		});
		const element = svg.select("g");
		markers_default(element, data4Layout.markers, data4Layout.type, data4Layout.diagramId);
		clear2();
		clear$2();
		clear$1();
		clear();
		data4Layout.nodes.forEach((node) => {
			graph.setNode(node.id, _objectSpread2({}, node));
			if (node.parentId) graph.setParent(node.id, node.parentId);
		});
		log.debug("Edges:", data4Layout.edges);
		data4Layout.edges.forEach((edge) => {
			if (edge.start === edge.end) {
				const nodeId = edge.start;
				const specialId1 = nodeId + "---" + nodeId + "---1";
				const specialId2 = nodeId + "---" + nodeId + "---2";
				const node = graph.node(nodeId);
				graph.setNode(specialId1, {
					domId: specialId1,
					id: specialId1,
					parentId: node.parentId,
					labelStyle: "",
					label: "",
					padding: 0,
					shape: "labelRect",
					style: "",
					width: 10,
					height: 10
				});
				graph.setParent(specialId1, node.parentId);
				graph.setNode(specialId2, {
					domId: specialId2,
					id: specialId2,
					parentId: node.parentId,
					labelStyle: "",
					padding: 0,
					shape: "labelRect",
					label: "",
					style: "",
					width: 10,
					height: 10
				});
				graph.setParent(specialId2, node.parentId);
				const originalEdge = structuredClone(edge);
				const edge1 = structuredClone(edge);
				const edgeMid = structuredClone(edge);
				const edge2 = structuredClone(edge);
				edge1.originalEdge = originalEdge;
				edge1.selfLoop = {
					id: originalEdge.id,
					order: 0
				};
				edgeMid.originalEdge = originalEdge;
				edgeMid.selfLoop = {
					id: originalEdge.id,
					order: 1
				};
				edge2.originalEdge = originalEdge;
				edge2.selfLoop = {
					id: originalEdge.id,
					order: 2
				};
				edge1.label = "";
				edge1.arrowTypeEnd = "none";
				edge1.endLabelLeft = "";
				edge1.endLabelRight = "";
				edge1.startLabelLeft = "";
				edge1.id = nodeId + "-cyclic-special-1";
				edgeMid.startLabelRight = "";
				edgeMid.startLabelLeft = "";
				edgeMid.endLabelLeft = "";
				edgeMid.endLabelRight = "";
				edgeMid.arrowTypeStart = "none";
				edgeMid.arrowTypeEnd = "none";
				edgeMid.id = nodeId + "-cyclic-special-mid";
				edge2.label = "";
				edge2.startLabelRight = "";
				edge2.startLabelLeft = "";
				edge2.arrowTypeStart = "none";
				if (node.isGroup) {
					edge1.fromCluster = nodeId;
					edge2.toCluster = nodeId;
				}
				edge2.id = nodeId + "-cyclic-special-2";
				edge2.arrowTypeStart = "none";
				graph.setEdge(nodeId, specialId1, edge1, nodeId + "-cyclic-special-0");
				graph.setEdge(specialId1, specialId2, edgeMid, nodeId + "-cyclic-special-1");
				graph.setEdge(specialId2, nodeId, edge2, nodeId + "-cyclic-special-2");
			} else graph.setEdge(edge.start, edge.end, _objectSpread2({}, edge), edge.id);
		});
		log.warn("Graph at first:", JSON.stringify(write(graph)));
		adjustClustersAndEdges(graph);
		log.warn("Graph after XAX:", JSON.stringify(write(graph)));
		const siteConfig = getConfig2();
		yield recursiveRender(element, graph, data4Layout.type, data4Layout.diagramId, void 0, siteConfig);
	});
	return function(_x10, _x11) {
		return _ref9.apply(this, arguments);
	};
}(), "render");
//#endregion
export { getEdgesToRender, render };

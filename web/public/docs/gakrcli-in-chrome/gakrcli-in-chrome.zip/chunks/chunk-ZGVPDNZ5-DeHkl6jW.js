import { i as _objectSpread2, o as _asyncToGenerator } from "./_plugin-vue_export-helper-BdaNZm_w.js";
import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import { m as log, p as select_default } from "./src-C3sq9HJl.js";
import { A as hasKatex, B as sanitizeText3, M as parseGenericTypes, T as getEffectiveHtmlLabels, b as getConfig, g as evaluate, x as getConfig2, z as sanitizeText } from "./chunk-WYO6CB5R-D3hdW-kf.js";
import { a as decodeEntities, r as calculateTextWidth, u as handleUndefinedAttr } from "./chunk-ICXQ74PX-BROveA7q.js";
import { t as getIconSVG } from "./chunk-HOUHSVGY-6mKlY5gd.js";
import { n as createText } from "./chunk-Q4XR5HBZ-zk1zulYp.js";
import { n as getSubGraphTitleMargins, t as configureLabelImages } from "./chunk-OGEWGWER-CRC47pvB.js";
import { a as userNodeOverrides, i as styles2String, r as solidStateFill, t as compileStyles } from "./chunk-C7G6YPKG-C0Dwy7It.js";
import { t as at } from "./rough.esm-Bw0dQC91.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/chunk-ZGVPDNZ5.mjs
var labelHelper = /* @__PURE__ */ __name(function() {
	var _ref = _asyncToGenerator(function* (parent, node, _classes) {
		var _getConfig, _getConfig2$flowchart, _node$padding;
		let cssClasses;
		const useHtmlLabels = node.useHtmlLabels || evaluate((_getConfig = getConfig2()) === null || _getConfig === void 0 ? void 0 : _getConfig.htmlLabels);
		if (!_classes) cssClasses = "node default";
		else cssClasses = _classes;
		const shapeSvg = parent.insert("g").attr("class", cssClasses).attr("id", node.domId || node.id);
		const labelEl = shapeSvg.insert("g").attr("class", "label").attr("style", handleUndefinedAttr(node.labelStyle));
		let label;
		if (node.label === void 0) label = "";
		else label = typeof node.label === "string" ? node.label : node.label[0];
		const addBackground = !!node.icon || !!node.img;
		const isMarkdown = node.labelType === "markdown";
		const text2 = yield createText(labelEl, sanitizeText(decodeEntities(label), getConfig2()), {
			useHtmlLabels,
			width: node.width || ((_getConfig2$flowchart = getConfig2().flowchart) === null || _getConfig2$flowchart === void 0 ? void 0 : _getConfig2$flowchart.wrappingWidth),
			classes: isMarkdown ? "markdown-node-label" : "",
			style: node.labelStyle,
			addSvgBackground: addBackground,
			markdown: isMarkdown
		}, getConfig2());
		let bbox = text2.getBBox();
		const halfPadding = ((_node$padding = node === null || node === void 0 ? void 0 : node.padding) !== null && _node$padding !== void 0 ? _node$padding : 0) / 2;
		if (useHtmlLabels) {
			const div = text2.children[0];
			const dv = select_default(text2);
			yield configureLabelImages(div, label);
			bbox = div.getBoundingClientRect();
			dv.attr("width", bbox.width);
			dv.attr("height", bbox.height);
		}
		if (useHtmlLabels) labelEl.attr("transform", "translate(" + -bbox.width / 2 + ", " + -bbox.height / 2 + ")");
		else labelEl.attr("transform", "translate(0, " + -bbox.height / 2 + ")");
		if (node.centerLabel) labelEl.attr("transform", "translate(" + -bbox.width / 2 + ", " + -bbox.height / 2 + ")");
		labelEl.insert("rect", ":first-child");
		return {
			shapeSvg,
			bbox,
			halfPadding,
			label: labelEl
		};
	});
	return function(_x, _x2, _x3) {
		return _ref.apply(this, arguments);
	};
}(), "labelHelper");
var insertLabel = /* @__PURE__ */ __name(function() {
	var _ref2 = _asyncToGenerator(function* (parent, label, options) {
		var _options$useHtmlLabel, _getConfig2;
		const useHtmlLabels = (_options$useHtmlLabel = options.useHtmlLabels) !== null && _options$useHtmlLabel !== void 0 ? _options$useHtmlLabel : getEffectiveHtmlLabels(getConfig2());
		const labelEl = parent.insert("g").attr("class", "label").attr("style", options.labelStyle || "");
		const text2 = yield createText(labelEl, sanitizeText(decodeEntities(label), getConfig2()), {
			useHtmlLabels,
			width: options.width || ((_getConfig2 = getConfig2()) === null || _getConfig2 === void 0 || (_getConfig2 = _getConfig2.flowchart) === null || _getConfig2 === void 0 ? void 0 : _getConfig2.wrappingWidth),
			style: options.labelStyle,
			addSvgBackground: !!options.icon || !!options.img
		});
		let bbox = text2.getBBox();
		const halfPadding = options.padding / 2;
		if (getEffectiveHtmlLabels(getConfig2())) {
			const div = text2.children[0];
			const dv = select_default(text2);
			bbox = div.getBoundingClientRect();
			dv.attr("width", bbox.width);
			dv.attr("height", bbox.height);
		}
		if (useHtmlLabels) labelEl.attr("transform", "translate(" + -bbox.width / 2 + ", " + -bbox.height / 2 + ")");
		else labelEl.attr("transform", "translate(0, " + -bbox.height / 2 + ")");
		if (options.centerLabel) labelEl.attr("transform", "translate(" + -bbox.width / 2 + ", " + -bbox.height / 2 + ")");
		labelEl.insert("rect", ":first-child");
		return {
			shapeSvg: parent,
			bbox,
			halfPadding,
			label: labelEl
		};
	});
	return function(_x4, _x5, _x6) {
		return _ref2.apply(this, arguments);
	};
}(), "insertLabel");
var updateNodeBounds = /* @__PURE__ */ __name((node, element) => {
	const bbox = element.node().getBBox();
	node.width = bbox.width;
	node.height = bbox.height;
}, "updateNodeBounds");
var getNodeClasses = /* @__PURE__ */ __name((node, extra) => (node.look === "handDrawn" ? "rough-node" : "node") + " " + node.cssClasses + " " + (extra || ""), "getNodeClasses");
function createPathFromPoints(points) {
	const pointStrings = points.map((p, i) => `${i === 0 ? "M" : "L"}${p.x},${p.y}`);
	pointStrings.push("Z");
	return pointStrings.join(" ");
}
__name(createPathFromPoints, "createPathFromPoints");
function generateFullSineWavePoints(x1, y1, x2, y2, amplitude, numCycles) {
	const points = [];
	const steps = 50;
	const deltaX = x2 - x1;
	const deltaY = y2 - y1;
	const cycleLength = deltaX / numCycles;
	const frequency = 2 * Math.PI / cycleLength;
	const midY = y1 + deltaY / 2;
	for (let i = 0; i <= steps; i++) {
		const x = x1 + i / steps * deltaX;
		const y = midY + amplitude * Math.sin(frequency * (x - x1));
		points.push({
			x,
			y
		});
	}
	return points;
}
__name(generateFullSineWavePoints, "generateFullSineWavePoints");
function generateCirclePoints(centerX, centerY, radius, numPoints, startAngle, endAngle) {
	const points = [];
	const startAngleRad = startAngle * Math.PI / 180;
	const angleStep = (endAngle * Math.PI / 180 - startAngleRad) / (numPoints - 1);
	for (let i = 0; i < numPoints; i++) {
		const angle = startAngleRad + i * angleStep;
		const x = centerX + radius * Math.cos(angle);
		const y = centerY + radius * Math.sin(angle);
		points.push({
			x: -x,
			y: -y
		});
	}
	return points;
}
__name(generateCirclePoints, "generateCirclePoints");
function mergePaths(roughElement) {
	const paths = Array.from(roughElement.childNodes).filter((node) => node.tagName === "path");
	const mergedPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
	const combinedPathData = paths.map((path) => path.getAttribute("d")).filter((d) => d !== null).join(" ");
	mergedPath.setAttribute("d", combinedPathData);
	const fillPath = paths.find((path) => path.getAttribute("fill") !== "none");
	const strokePath = paths.find((path) => path.getAttribute("stroke") !== "none");
	const getAttr = /* @__PURE__ */ __name((element, attr) => {
		var _element$getAttribute;
		return (_element$getAttribute = element === null || element === void 0 ? void 0 : element.getAttribute(attr)) !== null && _element$getAttribute !== void 0 ? _element$getAttribute : void 0;
	}, "getAttr");
	if (fillPath) {
		var _getAttr;
		const fillAttrs = {
			fill: getAttr(fillPath, "fill"),
			"fill-opacity": (_getAttr = getAttr(fillPath, "fill-opacity")) !== null && _getAttr !== void 0 ? _getAttr : "1"
		};
		Object.entries(fillAttrs).forEach(([attr, value]) => {
			if (value) mergedPath.setAttribute(attr, value);
		});
	}
	if (strokePath) {
		var _getAttr2, _getAttr3;
		const strokeAttrs = {
			stroke: getAttr(strokePath, "stroke"),
			"stroke-width": (_getAttr2 = getAttr(strokePath, "stroke-width")) !== null && _getAttr2 !== void 0 ? _getAttr2 : "1",
			"stroke-opacity": (_getAttr3 = getAttr(strokePath, "stroke-opacity")) !== null && _getAttr3 !== void 0 ? _getAttr3 : "1"
		};
		Object.entries(strokeAttrs).forEach(([attr, value]) => {
			if (value) mergedPath.setAttribute(attr, value);
		});
	}
	const group = document.createElementNS("http://www.w3.org/2000/svg", "g");
	group.appendChild(mergedPath);
	return group;
}
__name(mergePaths, "mergePaths");
var intersect_rect_default = /* @__PURE__ */ __name((node, point) => {
	var x = node.x;
	var y = node.y;
	var dx = point.x - x;
	var dy = point.y - y;
	var w = node.width / 2;
	var h = node.height / 2;
	var sx, sy;
	if (Math.abs(dy) * w > Math.abs(dx) * h) {
		if (dy < 0) h = -h;
		sx = dy === 0 ? 0 : h * dx / dy;
		sy = h;
	} else {
		if (dx < 0) w = -w;
		sx = w;
		sy = dx === 0 ? 0 : w * dy / dx;
	}
	return {
		x: x + sx,
		y: y + sy
	};
}, "intersectRect");
var createLabel_default = /* @__PURE__ */ __name(function() {
	var _ref3 = _asyncToGenerator(function* (element, _vertexText, style, isTitle = false, isNode = false) {
		let vertexText = _vertexText || "";
		if (typeof vertexText === "object") vertexText = vertexText[0];
		const config = getConfig2();
		const useHtmlLabels = getEffectiveHtmlLabels(config);
		return yield createText(element, vertexText, {
			style,
			isTitle,
			useHtmlLabels,
			markdown: false,
			isNode,
			width: Number.POSITIVE_INFINITY
		}, config);
	});
	return function(_x7, _x8, _x9) {
		return _ref3.apply(this, arguments);
	};
}(), "createLabel");
var createRoundedRectPathD = /* @__PURE__ */ __name((x, y, totalWidth, totalHeight, radius) => [
	"M",
	x + radius,
	y,
	"H",
	x + totalWidth - radius,
	"A",
	radius,
	radius,
	0,
	0,
	1,
	x + totalWidth,
	y + radius,
	"V",
	y + totalHeight - radius,
	"A",
	radius,
	radius,
	0,
	0,
	1,
	x + totalWidth - radius,
	y + totalHeight,
	"H",
	x + radius,
	"A",
	radius,
	radius,
	0,
	0,
	1,
	x,
	y + totalHeight - radius,
	"V",
	y + radius,
	"A",
	radius,
	radius,
	0,
	0,
	1,
	x + radius,
	y,
	"Z"
].join(" "), "createRoundedRectPathD");
var swimlane = /* @__PURE__ */ __name(function() {
	var _ref4 = _asyncToGenerator(function* (parent, node) {
		var _node$padding2;
		const siteConfig = getConfig2();
		const { themeVariables, handDrawnSeed } = siteConfig;
		const { clusterBkg, clusterBorder } = themeVariables;
		const laneStroke = clusterBorder;
		const { labelStyles, nodeStyles, borderStyles, backgroundStyles } = styles2String(node);
		const shapeSvg = parent.insert("g").attr("class", "cluster swimlane " + (node.cssClasses || "")).attr("id", node.id).attr("data-id", node.id).attr("data-et", "cluster").attr("data-look", node.look);
		const useHtmlLabels = evaluate(siteConfig.flowchart.htmlLabels);
		const isLR = node.direction === "LR";
		const labelEl = shapeSvg.insert("g").attr("class", "cluster-label swimlane-label");
		const text2 = yield createText(labelEl, node.label, {
			style: node.labelStyle,
			useHtmlLabels,
			isNode: true,
			width: node.width
		});
		let bbox = text2.getBBox();
		if (useHtmlLabels) {
			const div = text2.children[0];
			const dv = select_default(text2);
			bbox = div.getBoundingClientRect();
			dv.attr("width", bbox.width);
			dv.attr("height", bbox.height);
		}
		const padding = (_node$padding2 = node.padding) !== null && _node$padding2 !== void 0 ? _node$padding2 : 0;
		const width = node.width <= bbox.width + padding ? bbox.width + padding : node.width;
		if (node.width <= bbox.width + padding) node.diff = (width - node.width) / 2 - padding;
		else node.diff = -padding;
		const height = node.height;
		const laneTop = node.y - height / 2;
		const laneBottom = node.y + height / 2;
		const laneLeft = node.x - width / 2;
		const contentTop = node.swimlaneContentTop !== void 0 ? node.swimlaneContentTop : laneTop + height / 3;
		const titlePaddingY = isLR ? 4 : 0;
		const desiredTitleSize = bbox.height + 2 * titlePaddingY;
		let titleRect;
		let bodyRect;
		if (isLR) {
			const titleWidth = Math.max(desiredTitleSize, bbox.height + 2 * titlePaddingY);
			const bodyX = laneLeft + titleWidth;
			const bodyWidth = Math.max(0, width - titleWidth);
			if (node.look === "handDrawn") {
				const rc = at.svg(shapeSvg);
				const titleOptions = userNodeOverrides(node, {
					roughness: .7,
					fill: clusterBkg,
					stroke: laneStroke,
					fillWeight: 3,
					seed: handDrawnSeed
				});
				const bodyOptions = userNodeOverrides(node, {
					roughness: .7,
					fill: "none",
					stroke: laneStroke,
					seed: handDrawnSeed
				});
				const roughTitle = rc.rectangle(laneLeft, laneTop, titleWidth, height, titleOptions);
				titleRect = shapeSvg.insert(() => roughTitle, ":first-child");
				const roughBody = rc.rectangle(bodyX, laneTop, bodyWidth, height, bodyOptions);
				bodyRect = shapeSvg.insert(() => roughBody, ":first-child");
				titleRect.select("path:nth-child(2)").attr("style", borderStyles.join(";"));
				titleRect.select("path").attr("style", backgroundStyles.join(";").replace("fill", "stroke"));
			} else {
				titleRect = shapeSvg.insert("rect", ":first-child");
				bodyRect = shapeSvg.insert("rect", ":first-child");
				titleRect.attr("class", "swimlane-title").attr("style", nodeStyles).attr("x", laneLeft).attr("y", laneTop).attr("width", titleWidth).attr("height", height).attr("fill", clusterBkg).attr("stroke", laneStroke);
				bodyRect.attr("class", "swimlane-body").attr("style", nodeStyles).attr("x", bodyX).attr("y", laneTop).attr("width", bodyWidth).attr("height", height).attr("fill", "none").attr("stroke", laneStroke);
			}
			const labelCenterX = laneLeft + titleWidth / 2;
			const labelCenterY = node.y;
			labelEl.attr("transform", `translate(${labelCenterX}, ${labelCenterY}) rotate(-90) translate(${-bbox.width / 2}, ${-bbox.height / 2})`);
		} else {
			const headerMaxHeight = Math.max(0, contentTop - laneTop);
			const titleHeight = Math.min(desiredTitleSize, headerMaxHeight);
			const bodyY = laneTop + titleHeight;
			const contentHeight = Math.max(0, laneBottom - bodyY);
			const x = node.x - width / 2;
			if (node.look === "handDrawn") {
				const rc = at.svg(shapeSvg);
				const titleOptions = userNodeOverrides(node, {
					roughness: .7,
					fill: clusterBkg,
					stroke: laneStroke,
					fillWeight: 3,
					seed: handDrawnSeed
				});
				const bodyOptions = userNodeOverrides(node, {
					roughness: .7,
					fill: "none",
					stroke: laneStroke,
					seed: handDrawnSeed
				});
				const roughTitle = rc.rectangle(x, laneTop, width, titleHeight, titleOptions);
				titleRect = shapeSvg.insert(() => roughTitle, ":first-child");
				const roughBody = rc.rectangle(x, bodyY, width, contentHeight, bodyOptions);
				bodyRect = shapeSvg.insert(() => roughBody, ":first-child");
				titleRect.select("path:nth-child(2)").attr("style", borderStyles.join(";"));
				titleRect.select("path").attr("style", backgroundStyles.join(";").replace("fill", "stroke"));
			} else {
				titleRect = shapeSvg.insert("rect", ":first-child");
				bodyRect = shapeSvg.insert("rect", ":first-child");
				titleRect.attr("class", "swimlane-title").attr("style", nodeStyles).attr("x", x).attr("y", laneTop).attr("width", width).attr("height", titleHeight).attr("fill", clusterBkg).attr("stroke", laneStroke);
				bodyRect.attr("class", "swimlane-body").attr("style", nodeStyles).attr("x", x).attr("y", bodyY).attr("width", width).attr("height", contentHeight).attr("fill", "none").attr("stroke", laneStroke);
			}
			const labelX = node.x - bbox.width / 2;
			const labelY = laneTop + (titleHeight - bbox.height) / 2;
			labelEl.attr("transform", `translate(${labelX}, ${labelY})`);
		}
		log.trace("Swimlane data ", node, JSON.stringify(node));
		if (labelStyles) {
			const span = labelEl.select("span");
			if (span) span.attr("style", labelStyles);
		}
		node.offsetX = 0;
		node.width = width;
		node.height = height;
		node.offsetY = bbox.height - padding / 2;
		node.intersect = function(point) {
			return intersect_rect_default(node, point);
		};
		return {
			cluster: shapeSvg,
			labelBBox: bbox
		};
	});
	return function(_x10, _x11) {
		return _ref4.apply(this, arguments);
	};
}(), "swimlane");
var rect = /* @__PURE__ */ __name(function() {
	var _ref5 = _asyncToGenerator(function* (parent, node) {
		log.info("Creating subgraph rect for ", node.id, node);
		const siteConfig = getConfig2();
		const { themeVariables, handDrawnSeed } = siteConfig;
		const { clusterBkg, clusterBorder } = themeVariables;
		const { labelStyles, nodeStyles, borderStyles, backgroundStyles } = styles2String(node);
		const shapeSvg = parent.insert("g").attr("class", "cluster " + node.cssClasses).attr("id", node.domId).attr("data-look", node.look);
		const useHtmlLabels = getEffectiveHtmlLabels(siteConfig);
		const labelEl = shapeSvg.insert("g").attr("class", "cluster-label ");
		let text2;
		if (node.labelType === "markdown") text2 = yield createText(labelEl, node.label, {
			style: node.labelStyle,
			useHtmlLabels,
			isNode: true,
			width: node.width
		});
		else text2 = yield createLabel_default(labelEl, node.label, node.labelStyle || "", false, true);
		let bbox = text2.getBBox();
		if (getEffectiveHtmlLabels(siteConfig)) {
			const div = text2.children[0];
			const dv = select_default(text2);
			bbox = div.getBoundingClientRect();
			dv.attr("width", bbox.width);
			dv.attr("height", bbox.height);
		}
		const width = node.width <= bbox.width + node.padding ? bbox.width + node.padding : node.width;
		if (node.width <= bbox.width + node.padding) node.diff = (width - node.width) / 2 - node.padding;
		else node.diff = -node.padding;
		const height = node.height;
		const x = node.x - width / 2;
		const y = node.y - height / 2;
		log.trace("Data ", node, JSON.stringify(node));
		let rect2;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {
				roughness: .7,
				fill: clusterBkg,
				stroke: clusterBorder,
				fillWeight: 3,
				seed: handDrawnSeed
			});
			const roughNode = rc.path(createRoundedRectPathD(x, y, width, height, 0), options);
			rect2 = shapeSvg.insert(() => {
				log.debug("Rough node insert CXC", roughNode);
				return roughNode;
			}, ":first-child");
			rect2.select("path:nth-child(2)").attr("style", borderStyles.join(";"));
			rect2.select("path").attr("style", backgroundStyles.join(";").replace("fill", "stroke"));
		} else {
			rect2 = shapeSvg.insert("rect", ":first-child");
			rect2.attr("style", nodeStyles).attr("rx", node.rx).attr("ry", node.ry).attr("x", x).attr("y", y).attr("width", width).attr("height", height);
		}
		const { subGraphTitleTopMargin } = getSubGraphTitleMargins(siteConfig);
		labelEl.attr("transform", `translate(${node.x - bbox.width / 2}, ${node.y - node.height / 2 + subGraphTitleTopMargin})`);
		if (labelStyles) {
			const span = labelEl.select("span");
			if (span) span.attr("style", labelStyles);
		}
		const rectBox = rect2.node().getBBox();
		node.offsetX = 0;
		node.width = rectBox.width;
		node.height = rectBox.height;
		node.offsetY = bbox.height - node.padding / 2;
		node.intersect = function(point) {
			return intersect_rect_default(node, point);
		};
		return {
			cluster: shapeSvg,
			labelBBox: bbox
		};
	});
	return function(_x12, _x13) {
		return _ref5.apply(this, arguments);
	};
}(), "rect");
var noteGroup = /* @__PURE__ */ __name((parent, node) => {
	const shapeSvg = parent.insert("g").attr("class", "note-cluster").attr("id", node.domId);
	const rect2 = shapeSvg.insert("rect", ":first-child");
	const padding = 0 * node.padding;
	const halfPadding = padding / 2;
	rect2.attr("rx", node.rx).attr("ry", node.ry).attr("x", node.x - node.width / 2 - halfPadding).attr("y", node.y - node.height / 2 - halfPadding).attr("width", node.width + padding).attr("height", node.height + padding).attr("fill", "none");
	const rectBox = rect2.node().getBBox();
	node.width = rectBox.width;
	node.height = rectBox.height;
	node.intersect = function(point) {
		return intersect_rect_default(node, point);
	};
	return {
		cluster: shapeSvg,
		labelBBox: {
			width: 0,
			height: 0
		}
	};
}, "noteGroup");
var roundedWithTitle = /* @__PURE__ */ __name(function() {
	var _ref6 = _asyncToGenerator(function* (parent, node) {
		const siteConfig = getConfig2();
		const { themeVariables, handDrawnSeed } = siteConfig;
		const { altBackground, compositeBackground, compositeTitleBackground, nodeBorder } = themeVariables;
		const shapeSvg = parent.insert("g").attr("class", node.cssClasses).attr("id", node.domId).attr("data-id", node.id).attr("data-look", node.look);
		const outerRectG = shapeSvg.insert("g", ":first-child");
		const label = shapeSvg.insert("g").attr("class", "cluster-label");
		let innerRect = shapeSvg.append("rect");
		const text2 = yield createLabel_default(label, node.label, node.labelStyle, void 0, true);
		let bbox = text2.getBBox();
		if (getEffectiveHtmlLabels(siteConfig)) {
			const div = text2.children[0];
			const dv = select_default(text2);
			bbox = div.getBoundingClientRect();
			dv.attr("width", bbox.width);
			dv.attr("height", bbox.height);
		}
		const padding = 0 * node.padding;
		const halfPadding = padding / 2;
		const width = (node.width <= bbox.width + node.padding ? bbox.width + node.padding : node.width) + padding;
		if (node.width <= bbox.width + node.padding) node.diff = (width - node.width) / 2 - node.padding;
		else node.diff = -node.padding;
		const height = node.height + padding;
		const innerHeight = node.height + padding - bbox.height - 6;
		const x = node.x - width / 2;
		const y = node.y - height / 2;
		node.width = width;
		const innerY = node.y - node.height / 2 - halfPadding + bbox.height + 2;
		let rect2;
		if (node.look === "handDrawn") {
			const isAlt = node.cssClasses.includes("statediagram-cluster-alt");
			const rc = at.svg(shapeSvg);
			const roughOuterNode = node.rx || node.ry ? rc.path(createRoundedRectPathD(x, y, width, height, 10), {
				roughness: .7,
				fill: compositeTitleBackground,
				fillStyle: "solid",
				stroke: nodeBorder,
				seed: handDrawnSeed
			}) : rc.rectangle(x, y, width, height, { seed: handDrawnSeed });
			rect2 = shapeSvg.insert(() => roughOuterNode, ":first-child");
			const roughInnerNode = rc.rectangle(x, innerY, width, innerHeight, {
				fill: isAlt ? altBackground : compositeBackground,
				fillStyle: isAlt ? "hachure" : "solid",
				stroke: nodeBorder,
				seed: handDrawnSeed
			});
			rect2 = shapeSvg.insert(() => roughOuterNode, ":first-child");
			innerRect = shapeSvg.insert(() => roughInnerNode);
		} else {
			rect2 = outerRectG.insert("rect", ":first-child");
			rect2.attr("class", "outer").attr("x", x).attr("y", y).attr("width", width).attr("height", height).attr("data-look", node.look);
			innerRect.attr("class", "inner").attr("x", x).attr("y", innerY).attr("width", width).attr("height", innerHeight);
		}
		label.attr("transform", `translate(${node.x - bbox.width / 2}, ${y + 1 - (getEffectiveHtmlLabels(siteConfig) ? 0 : 3)})`);
		node.height = rect2.node().getBBox().height;
		node.offsetX = 0;
		node.offsetY = bbox.height - node.padding / 2;
		node.labelBBox = bbox;
		node.intersect = function(point) {
			return intersect_rect_default(node, point);
		};
		return {
			cluster: shapeSvg,
			labelBBox: bbox
		};
	});
	return function(_x14, _x15) {
		return _ref6.apply(this, arguments);
	};
}(), "roundedWithTitle");
var kanbanSection = /* @__PURE__ */ __name(function() {
	var _ref7 = _asyncToGenerator(function* (parent, node) {
		log.info("Creating subgraph rect for ", node.id, node);
		const siteConfig = getConfig2();
		const { themeVariables, handDrawnSeed } = siteConfig;
		const { clusterBkg, clusterBorder } = themeVariables;
		const { labelStyles, nodeStyles, borderStyles, backgroundStyles } = styles2String(node);
		const shapeSvg = parent.insert("g").attr("class", "cluster " + node.cssClasses).attr("id", node.domId).attr("data-look", node.look);
		const useHtmlLabels = getEffectiveHtmlLabels(siteConfig);
		const labelEl = shapeSvg.insert("g").attr("class", "cluster-label ");
		const text2 = yield createText(labelEl, node.label, {
			style: node.labelStyle,
			useHtmlLabels,
			isNode: true,
			width: node.width
		});
		let bbox = text2.getBBox();
		if (getEffectiveHtmlLabels(siteConfig)) {
			const div = text2.children[0];
			const dv = select_default(text2);
			bbox = div.getBoundingClientRect();
			dv.attr("width", bbox.width);
			dv.attr("height", bbox.height);
		}
		const width = node.width <= bbox.width + node.padding ? bbox.width + node.padding : node.width;
		if (node.width <= bbox.width + node.padding) node.diff = (width - node.width) / 2 - node.padding;
		else node.diff = -node.padding;
		const height = node.height;
		const x = node.x - width / 2;
		const y = node.y - height / 2;
		log.trace("Data ", node, JSON.stringify(node));
		let rect2;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {
				roughness: .7,
				fill: clusterBkg,
				stroke: clusterBorder,
				fillWeight: 4,
				seed: handDrawnSeed
			});
			const roughNode = rc.path(createRoundedRectPathD(x, y, width, height, node.rx), options);
			rect2 = shapeSvg.insert(() => {
				log.debug("Rough node insert CXC", roughNode);
				return roughNode;
			}, ":first-child");
			rect2.select("path:nth-child(2)").attr("style", borderStyles.join(";"));
			rect2.select("path").attr("style", backgroundStyles.join(";").replace("fill", "stroke"));
		} else {
			rect2 = shapeSvg.insert("rect", ":first-child");
			rect2.attr("style", nodeStyles).attr("rx", node.rx).attr("ry", node.ry).attr("x", x).attr("y", y).attr("width", width).attr("height", height);
		}
		const { subGraphTitleTopMargin } = getSubGraphTitleMargins(siteConfig);
		labelEl.attr("transform", `translate(${node.x - bbox.width / 2}, ${node.y - node.height / 2 + subGraphTitleTopMargin})`);
		if (labelStyles) {
			const span = labelEl.select("span");
			if (span) span.attr("style", labelStyles);
		}
		const rectBox = rect2.node().getBBox();
		node.offsetX = 0;
		node.width = rectBox.width;
		node.height = rectBox.height;
		node.offsetY = bbox.height - node.padding / 2;
		node.intersect = function(point) {
			return intersect_rect_default(node, point);
		};
		return {
			cluster: shapeSvg,
			labelBBox: bbox
		};
	});
	return function(_x16, _x17) {
		return _ref7.apply(this, arguments);
	};
}(), "kanbanSection");
var shapes = {
	rect,
	squareRect: rect,
	roundedWithTitle,
	noteGroup,
	divider: /* @__PURE__ */ __name((parent, node) => {
		const { themeVariables, handDrawnSeed } = getConfig2();
		const { nodeBorder } = themeVariables;
		const shapeSvg = parent.insert("g").attr("class", node.cssClasses).attr("id", node.domId).attr("data-look", node.look);
		const outerRectG = shapeSvg.insert("g", ":first-child");
		const padding = 0 * node.padding;
		const width = node.width + padding;
		node.diff = -node.padding;
		const height = node.height + padding;
		const x = node.x - width / 2;
		const y = node.y - height / 2;
		node.width = width;
		let rect2;
		if (node.look === "handDrawn") {
			const roughOuterNode = at.svg(shapeSvg).rectangle(x, y, width, height, {
				fill: "lightgrey",
				roughness: .5,
				strokeLineDash: [5],
				stroke: nodeBorder,
				seed: handDrawnSeed
			});
			rect2 = shapeSvg.insert(() => roughOuterNode, ":first-child");
		} else {
			rect2 = outerRectG.insert("rect", ":first-child");
			let outerRectClass = "outer";
			if (node.look === "neo") outerRectClass = "divider";
			else outerRectClass = "divider";
			rect2.attr("class", outerRectClass).attr("x", x).attr("y", y).attr("width", width).attr("height", height).attr("data-look", node.look);
		}
		node.height = rect2.node().getBBox().height;
		node.offsetX = 0;
		node.offsetY = 0;
		node.intersect = function(point) {
			return intersect_rect_default(node, point);
		};
		return {
			cluster: shapeSvg,
			labelBBox: {}
		};
	}, "divider"),
	kanbanSection,
	swimlane
};
var clusterElems = /* @__PURE__ */ new Map();
var insertCluster = /* @__PURE__ */ __name(function() {
	var _ref8 = _asyncToGenerator(function* (elem, node) {
		const cluster = yield shapes[node.shape || "rect"](elem, node);
		clusterElems.set(node.id, cluster);
		return cluster;
	});
	return function(_x18, _x19) {
		return _ref8.apply(this, arguments);
	};
}(), "insertCluster");
var clear = /* @__PURE__ */ __name(() => {
	clusterElems = /* @__PURE__ */ new Map();
}, "clear");
function intersectNode(node, point) {
	return node.intersect(point);
}
__name(intersectNode, "intersectNode");
var intersect_node_default = intersectNode;
function intersectEllipse(node, rx, ry, point) {
	var cx = node.x;
	var cy = node.y;
	var px = cx - point.x;
	var py = cy - point.y;
	var det = Math.sqrt(rx * rx * py * py + ry * ry * px * px);
	var dx = Math.abs(rx * ry * px / det);
	if (point.x < cx) dx = -dx;
	var dy = Math.abs(rx * ry * py / det);
	if (point.y < cy) dy = -dy;
	return {
		x: cx + dx,
		y: cy + dy
	};
}
__name(intersectEllipse, "intersectEllipse");
var intersect_ellipse_default = intersectEllipse;
function intersectCircle(node, rx, point) {
	return intersect_ellipse_default(node, rx, rx, point);
}
__name(intersectCircle, "intersectCircle");
var intersect_circle_default = intersectCircle;
function intersectLine(p1, p2, q1, q2) {
	{
		const a1 = p2.y - p1.y;
		const b1 = p1.x - p2.x;
		const c1 = p2.x * p1.y - p1.x * p2.y;
		const r3 = a1 * q1.x + b1 * q1.y + c1;
		const r4 = a1 * q2.x + b1 * q2.y + c1;
		const epsilon = 1e-6;
		if (r3 !== 0 && r4 !== 0 && sameSign(r3, r4)) return;
		const a2 = q2.y - q1.y;
		const b2 = q1.x - q2.x;
		const c2 = q2.x * q1.y - q1.x * q2.y;
		const r1 = a2 * p1.x + b2 * p1.y + c2;
		const r2 = a2 * p2.x + b2 * p2.y + c2;
		if (Math.abs(r1) < epsilon && Math.abs(r2) < epsilon && sameSign(r1, r2)) return;
		const denom = a1 * b2 - a2 * b1;
		if (denom === 0) return;
		const offset = Math.abs(denom / 2);
		let num = b1 * c2 - b2 * c1;
		const x = num < 0 ? (num - offset) / denom : (num + offset) / denom;
		num = a2 * c1 - a1 * c2;
		return {
			x,
			y: num < 0 ? (num - offset) / denom : (num + offset) / denom
		};
	}
}
__name(intersectLine, "intersectLine");
function sameSign(r1, r2) {
	return r1 * r2 > 0;
}
__name(sameSign, "sameSign");
var intersect_line_default = intersectLine;
function intersectPolygon(node, polyPoints, point) {
	let x1 = node.x;
	let y1 = node.y;
	let intersections = [];
	let minX = Number.POSITIVE_INFINITY;
	let minY = Number.POSITIVE_INFINITY;
	if (typeof polyPoints.forEach === "function") polyPoints.forEach(function(entry) {
		minX = Math.min(minX, entry.x);
		minY = Math.min(minY, entry.y);
	});
	else {
		minX = Math.min(minX, polyPoints.x);
		minY = Math.min(minY, polyPoints.y);
	}
	let left = x1 - node.width / 2 - minX;
	let top = y1 - node.height / 2 - minY;
	for (let i = 0; i < polyPoints.length; i++) {
		let p1 = polyPoints[i];
		let p2 = polyPoints[i < polyPoints.length - 1 ? i + 1 : 0];
		let intersect = intersect_line_default(node, point, {
			x: left + p1.x,
			y: top + p1.y
		}, {
			x: left + p2.x,
			y: top + p2.y
		});
		if (intersect) intersections.push(intersect);
	}
	if (!intersections.length) return node;
	if (intersections.length > 1) intersections.sort(function(p, q) {
		let pdx = p.x - point.x;
		let pdy = p.y - point.y;
		let distp = Math.sqrt(pdx * pdx + pdy * pdy);
		let qdx = q.x - point.x;
		let qdy = q.y - point.y;
		let distq = Math.sqrt(qdx * qdx + qdy * qdy);
		return distp < distq ? -1 : distp === distq ? 0 : 1;
	});
	return intersections[0];
}
__name(intersectPolygon, "intersectPolygon");
var intersect_default = {
	node: intersect_node_default,
	circle: intersect_circle_default,
	ellipse: intersect_ellipse_default,
	polygon: intersectPolygon,
	rect: intersect_rect_default
};
function anchor(parent, node) {
	const { labelStyles } = styles2String(node);
	node.labelStyle = labelStyles;
	const classes = getNodeClasses(node);
	let cssClasses = classes;
	if (!classes) cssClasses = "anchor";
	const shapeSvg = parent.insert("g").attr("class", cssClasses).attr("id", node.domId || node.id);
	const radius = 1;
	const { cssStyles } = node;
	const rc = at.svg(shapeSvg);
	const options = userNodeOverrides(node, {
		fill: "black",
		stroke: "none",
		fillStyle: "solid"
	});
	if (node.look !== "handDrawn") options.roughness = 0;
	const roughNode = rc.circle(0, 0, radius * 2, options);
	const circleElem = shapeSvg.insert(() => roughNode, ":first-child");
	circleElem.attr("class", "anchor").attr("style", handleUndefinedAttr(cssStyles));
	updateNodeBounds(node, circleElem);
	node.intersect = function(point) {
		log.info("Circle intersect", node, radius, point);
		return intersect_default.circle(node, radius, point);
	};
	return shapeSvg;
}
__name(anchor, "anchor");
function generateArcPoints(x1, y1, x2, y2, rx, ry, clockwise) {
	const numPoints = 20;
	const midX = (x1 + x2) / 2;
	const midY = (y1 + y2) / 2;
	const angle = Math.atan2(y2 - y1, x2 - x1);
	const dx = (x2 - x1) / 2;
	const dy = (y2 - y1) / 2;
	const transformedX = dx / rx;
	const transformedY = dy / ry;
	const distance = Math.sqrt(Math.pow(transformedX, 2) + Math.pow(transformedY, 2));
	if (distance > 1) throw new Error("The given radii are too small to create an arc between the points.");
	const scaledCenterDistance = Math.sqrt(1 - Math.pow(distance, 2));
	const centerX = midX + scaledCenterDistance * ry * Math.sin(angle) * (clockwise ? -1 : 1);
	const centerY = midY - scaledCenterDistance * rx * Math.cos(angle) * (clockwise ? -1 : 1);
	const startAngle = Math.atan2((y1 - centerY) / ry, (x1 - centerX) / rx);
	let angleRange = Math.atan2((y2 - centerY) / ry, (x2 - centerX) / rx) - startAngle;
	if (clockwise && angleRange < 0) angleRange += 2 * Math.PI;
	if (!clockwise && angleRange > 0) angleRange -= 2 * Math.PI;
	const points = [];
	for (let i = 0; i < numPoints; i++) {
		const angle2 = startAngle + i / (numPoints - 1) * angleRange;
		const x = centerX + rx * Math.cos(angle2);
		const y = centerY + ry * Math.sin(angle2);
		points.push({
			x,
			y
		});
	}
	return points;
}
__name(generateArcPoints, "generateArcPoints");
function calculateArcSagitta(chord, radiusX, radiusY) {
	const [semiMajorAxis, semiMinorAxis] = [radiusX, radiusY].sort((a, b) => b - a);
	return semiMinorAxis * (1 - Math.sqrt(1 - Math.pow(chord / semiMajorAxis / 2, 2)));
}
__name(calculateArcSagitta, "calculateArcSagitta");
function bowTieRect(_x20, _x21) {
	return _bowTieRect.apply(this, arguments);
}
function _bowTieRect() {
	_bowTieRect = _asyncToGenerator(function* (parent, node) {
		var _node$padding3;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding3 = node.padding) !== null && _node$padding3 !== void 0 ? _node$padding3 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		const calcTotalHeight = /* @__PURE__ */ __name((labelHeight) => labelHeight + labelPaddingY, "calcTotalHeight");
		const calcEllipseRadius = /* @__PURE__ */ __name((totalHeight2) => {
			const ry2 = totalHeight2 / 2;
			return [ry2 / (2.5 + totalHeight2 / 50), ry2];
		}, "calcEllipseRadius");
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const totalHeight = calcTotalHeight((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : bbox.height);
		const [rx, ry] = calcEllipseRadius(totalHeight);
		const sagitta = calculateArcSagitta(totalHeight, rx, ry);
		const w = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + labelPaddingX * 2 + sagitta - sagitta;
		const h = totalHeight;
		const { cssStyles } = node;
		const points = [
			{
				x: w / 2,
				y: -h / 2
			},
			{
				x: -w / 2,
				y: -h / 2
			},
			...generateArcPoints(-w / 2, -h / 2, -w / 2, h / 2, rx, ry, false),
			{
				x: w / 2,
				y: h / 2
			},
			...generateArcPoints(w / 2, h / 2, w / 2, -h / 2, rx, ry, true)
		];
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const bowTieRectPath = createPathFromPoints(points);
		const bowTieRectShapePath = rc.path(bowTieRectPath, options);
		const bowTieRectShape = shapeSvg.insert(() => bowTieRectShapePath, ":first-child");
		bowTieRectShape.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") bowTieRectShape.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") bowTieRectShape.selectAll("path").attr("style", nodeStyles);
		bowTieRectShape.attr("transform", `translate(${rx / 2}, 0)`);
		updateNodeBounds(node, bowTieRectShape);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _bowTieRect.apply(this, arguments);
}
__name(bowTieRect, "bowTieRect");
function insertPolygonShape(parent, w, h, points) {
	return parent.insert("polygon", ":first-child").attr("points", points.map(function(d) {
		return d.x + "," + d.y;
	}).join(" ")).attr("class", "label-container").attr("transform", "translate(" + -w / 2 + "," + h / 2 + ")");
}
__name(insertPolygonShape, "insertPolygonShape");
var NOTCH_SIZE = 12;
function card(_x22, _x23) {
	return _card.apply(this, arguments);
}
function _card() {
	_card = _asyncToGenerator(function* (parent, node) {
		var _node$padding4, _node$width, _node$height;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding4 = node.padding) !== null && _node$padding4 !== void 0 ? _node$padding4 : 0;
		const labelPaddingX = node.look === "neo" ? 28 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 24 : nodePadding;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = ((_node$width = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width !== void 0 ? _node$width : bbox.width) + (node.look === "neo" ? labelPaddingX * 2 : labelPaddingX + NOTCH_SIZE);
		const h = ((_node$height = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height !== void 0 ? _node$height : bbox.height) + (node.look === "neo" ? labelPaddingY * 2 : labelPaddingY);
		const left = 0;
		const right = w;
		const top = -h;
		const bottom = 0;
		const points = [
			{
				x: left + NOTCH_SIZE,
				y: top
			},
			{
				x: right,
				y: top
			},
			{
				x: right,
				y: bottom
			},
			{
				x: left,
				y: bottom
			},
			{
				x: left,
				y: top + NOTCH_SIZE
			},
			{
				x: left + NOTCH_SIZE,
				y: top
			}
		];
		let polygon;
		const { cssStyles } = node;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {});
			const pathData = createPathFromPoints(points);
			const roughNode = rc.path(pathData, options);
			polygon = shapeSvg.insert(() => roughNode, ":first-child").attr("transform", `translate(${-w / 2}, ${h / 2})`);
			if (cssStyles) polygon.attr("style", cssStyles);
		} else polygon = insertPolygonShape(shapeSvg, w, h, points);
		if (nodeStyles) polygon.attr("style", nodeStyles);
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _card.apply(this, arguments);
}
__name(card, "card");
function choice(parent, node) {
	var _node$domId, _node$width2;
	const { nodeStyles } = styles2String(node);
	node.label = "";
	const shapeSvg = parent.insert("g").attr("class", getNodeClasses(node)).attr("id", (_node$domId = node.domId) !== null && _node$domId !== void 0 ? _node$domId : node.id);
	const { cssStyles } = node;
	const s = Math.max(28, (_node$width2 = node.width) !== null && _node$width2 !== void 0 ? _node$width2 : 0);
	const points = [
		{
			x: 0,
			y: s / 2
		},
		{
			x: s / 2,
			y: 0
		},
		{
			x: 0,
			y: -s / 2
		},
		{
			x: -s / 2,
			y: 0
		}
	];
	const rc = at.svg(shapeSvg);
	const options = userNodeOverrides(node, {});
	if (node.look !== "handDrawn") {
		options.roughness = 0;
		options.fillStyle = "solid";
	}
	const choicePath = createPathFromPoints(points);
	const roughNode = rc.path(choicePath, options);
	const choiceShape = shapeSvg.insert(() => roughNode, ":first-child");
	if (cssStyles && node.look !== "handDrawn") choiceShape.selectAll("path").attr("style", cssStyles);
	if (nodeStyles && node.look !== "handDrawn") choiceShape.selectAll("path").attr("style", nodeStyles);
	node.width = 28;
	node.height = 28;
	node.intersect = function(point) {
		return intersect_default.polygon(node, points, point);
	};
	return shapeSvg;
}
__name(choice, "choice");
function circle(_x24, _x25, _x26) {
	return _circle.apply(this, arguments);
}
function _circle() {
	_circle = _asyncToGenerator(function* (parent, node, options) {
		var _options$padding;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox, halfPadding } = yield labelHelper(parent, node, getNodeClasses(node));
		const labelPadding = 16;
		const padding = (_options$padding = options === null || options === void 0 ? void 0 : options.padding) !== null && _options$padding !== void 0 ? _options$padding : halfPadding;
		const radius = node.look === "neo" ? bbox.width / 2 + labelPadding * 2 : bbox.width / 2 + padding;
		let circleElem;
		const { cssStyles } = node;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options2 = userNodeOverrides(node, {});
			const roughNode = rc.circle(0, 0, radius * 2, options2);
			circleElem = shapeSvg.insert(() => roughNode, ":first-child");
			circleElem.attr("class", "basic label-container").attr("style", handleUndefinedAttr(cssStyles));
		} else circleElem = shapeSvg.insert("circle", ":first-child").attr("class", "basic label-container").attr("style", nodeStyles).attr("r", radius).attr("cx", 0).attr("cy", 0);
		updateNodeBounds(node, circleElem);
		node.calcIntersect = function(bounds, point) {
			const radius2 = bounds.width / 2;
			return intersect_default.circle(bounds, radius2, point);
		};
		node.intersect = function(point) {
			log.info("Circle intersect", node, radius, point);
			return intersect_default.circle(node, radius, point);
		};
		return shapeSvg;
	});
	return _circle.apply(this, arguments);
}
__name(circle, "circle");
function createLine(r) {
	const xAxis45 = Math.cos(Math.PI / 4);
	const yAxis45 = Math.sin(Math.PI / 4);
	const lineLength = r * 2;
	const pointQ1 = {
		x: lineLength / 2 * xAxis45,
		y: lineLength / 2 * yAxis45
	};
	const pointQ2 = {
		x: -(lineLength / 2) * xAxis45,
		y: lineLength / 2 * yAxis45
	};
	const pointQ3 = {
		x: -(lineLength / 2) * xAxis45,
		y: -(lineLength / 2) * yAxis45
	};
	const pointQ4 = {
		x: lineLength / 2 * xAxis45,
		y: -(lineLength / 2) * yAxis45
	};
	return `M ${pointQ2.x},${pointQ2.y} L ${pointQ4.x},${pointQ4.y}
                   M ${pointQ1.x},${pointQ1.y} L ${pointQ3.x},${pointQ3.y}`;
}
__name(createLine, "createLine");
function crossedCircle(parent, node) {
	var _node$domId2, _node$width3;
	const { labelStyles, nodeStyles } = styles2String(node);
	node.labelStyle = labelStyles;
	node.label = "";
	const shapeSvg = parent.insert("g").attr("class", getNodeClasses(node)).attr("id", (_node$domId2 = node.domId) !== null && _node$domId2 !== void 0 ? _node$domId2 : node.id);
	const radius = Math.max(30, (_node$width3 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width3 !== void 0 ? _node$width3 : 0);
	const { cssStyles } = node;
	const rc = at.svg(shapeSvg);
	const options = userNodeOverrides(node, {});
	if (node.look !== "handDrawn") {
		options.roughness = 0;
		options.fillStyle = "solid";
	}
	const circleNode = rc.circle(0, 0, radius * 2, options);
	const linePath = createLine(radius);
	const lineNode = rc.path(linePath, options);
	const crossedCircle2 = shapeSvg.insert(() => circleNode, ":first-child");
	crossedCircle2.insert(() => lineNode);
	crossedCircle2.attr("class", "outer-path");
	if (cssStyles && node.look !== "handDrawn") crossedCircle2.selectAll("path").attr("style", cssStyles);
	if (nodeStyles && node.look !== "handDrawn") crossedCircle2.selectAll("path").attr("style", nodeStyles);
	updateNodeBounds(node, crossedCircle2);
	node.intersect = function(point) {
		log.info("crossedCircle intersect", node, {
			radius,
			point
		});
		return intersect_default.circle(node, radius, point);
	};
	return shapeSvg;
}
__name(crossedCircle, "crossedCircle");
function generateCirclePoints2(centerX, centerY, radius, numPoints = 100, startAngle = 0, endAngle = 180) {
	const points = [];
	const startAngleRad = startAngle * Math.PI / 180;
	const angleStep = (endAngle * Math.PI / 180 - startAngleRad) / (numPoints - 1);
	for (let i = 0; i < numPoints; i++) {
		const angle = startAngleRad + i * angleStep;
		const x = centerX + radius * Math.cos(angle);
		const y = centerY + radius * Math.sin(angle);
		points.push({
			x: -x,
			y: -y
		});
	}
	return points;
}
__name(generateCirclePoints2, "generateCirclePoints");
function curlyBraceLeft(_x27, _x28) {
	return _curlyBraceLeft.apply(this, arguments);
}
function _curlyBraceLeft() {
	_curlyBraceLeft = _asyncToGenerator(function* (parent, node) {
		var _node$padding5, _node$padding6, _bbox$left, _node$padding7, _bbox$top;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const paddingX = node.look === "neo" ? 18 : (_node$padding5 = node.padding) !== null && _node$padding5 !== void 0 ? _node$padding5 : 0;
		const paddingY = node.look === "neo" ? 12 : (_node$padding6 = node.padding) !== null && _node$padding6 !== void 0 ? _node$padding6 : 0;
		const w = bbox.width + paddingX;
		const h = bbox.height + paddingY;
		const radius = Math.max(5, h * .1);
		const { cssStyles } = node;
		const points = [
			...generateCirclePoints2(w / 2, -h / 2, radius, 30, -90, 0),
			{
				x: -w / 2 - radius,
				y: radius
			},
			...generateCirclePoints2(w / 2 + radius * 2, -radius, radius, 20, -180, -270),
			...generateCirclePoints2(w / 2 + radius * 2, radius, radius, 20, -90, -180),
			{
				x: -w / 2 - radius,
				y: -h / 2
			},
			...generateCirclePoints2(w / 2, h / 2, radius, 20, 0, 90)
		];
		const rectPoints = [
			{
				x: w / 2,
				y: -h / 2 - radius
			},
			{
				x: -w / 2,
				y: -h / 2 - radius
			},
			...generateCirclePoints2(w / 2, -h / 2, radius, 20, -90, 0),
			{
				x: -w / 2 - radius,
				y: -radius
			},
			...generateCirclePoints2(w / 2 + w * .1, -radius, radius, 20, -180, -270),
			...generateCirclePoints2(w / 2 + w * .1, radius, radius, 20, -90, -180),
			{
				x: -w / 2 - radius,
				y: h / 2
			},
			...generateCirclePoints2(w / 2, h / 2, radius, 20, 0, 90),
			{
				x: -w / 2,
				y: h / 2 + radius
			},
			{
				x: w / 2,
				y: h / 2 + radius
			}
		];
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, { fill: "none" });
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const newCurlyBracePath = createPathFromPoints(points).replace("Z", "");
		const curlyBraceLeftNode = rc.path(newCurlyBracePath, options);
		const rectPath = createPathFromPoints(rectPoints);
		const rectShape = rc.path(rectPath, _objectSpread2({}, options));
		const curlyBraceLeftShape = shapeSvg.insert("g", ":first-child");
		curlyBraceLeftShape.insert(() => rectShape, ":first-child").attr("stroke-opacity", 0);
		curlyBraceLeftShape.insert(() => curlyBraceLeftNode, ":first-child");
		curlyBraceLeftShape.attr("class", "text");
		if (cssStyles && node.look !== "handDrawn") curlyBraceLeftShape.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") curlyBraceLeftShape.selectAll("path").attr("style", nodeStyles);
		curlyBraceLeftShape.attr("transform", `translate(${radius}, 0)`);
		label.attr("transform", `translate(${-w / 2 + radius - (bbox.x - ((_bbox$left = bbox.left) !== null && _bbox$left !== void 0 ? _bbox$left : 0))},${-h / 2 + ((_node$padding7 = node.padding) !== null && _node$padding7 !== void 0 ? _node$padding7 : 0) / 2 - (bbox.y - ((_bbox$top = bbox.top) !== null && _bbox$top !== void 0 ? _bbox$top : 0))})`);
		updateNodeBounds(node, curlyBraceLeftShape);
		node.intersect = function(point) {
			return intersect_default.polygon(node, rectPoints, point);
		};
		return shapeSvg;
	});
	return _curlyBraceLeft.apply(this, arguments);
}
__name(curlyBraceLeft, "curlyBraceLeft");
function generateCirclePoints3(centerX, centerY, radius, numPoints = 100, startAngle = 0, endAngle = 180) {
	const points = [];
	const startAngleRad = startAngle * Math.PI / 180;
	const angleStep = (endAngle * Math.PI / 180 - startAngleRad) / (numPoints - 1);
	for (let i = 0; i < numPoints; i++) {
		const angle = startAngleRad + i * angleStep;
		const x = centerX + radius * Math.cos(angle);
		const y = centerY + radius * Math.sin(angle);
		points.push({
			x,
			y
		});
	}
	return points;
}
__name(generateCirclePoints3, "generateCirclePoints");
function curlyBraceRight(_x29, _x30) {
	return _curlyBraceRight.apply(this, arguments);
}
function _curlyBraceRight() {
	_curlyBraceRight = _asyncToGenerator(function* (parent, node) {
		var _node$padding8, _node$padding9, _node$padding10, _bbox$left2, _node$padding11, _bbox$top2;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const labelPaddingX = node.look === "neo" ? 18 : (_node$padding8 = node.padding) !== null && _node$padding8 !== void 0 ? _node$padding8 : 0;
		const labelPaddingY = node.look === "neo" ? 12 : (_node$padding9 = node.padding) !== null && _node$padding9 !== void 0 ? _node$padding9 : 0;
		const w = bbox.width + (node.look === "neo" ? labelPaddingX * 2 : labelPaddingX);
		const h = bbox.height + (node.look === "neo" ? labelPaddingY * 2 : labelPaddingY);
		const radius = Math.max(5, h * .1);
		const { cssStyles } = node;
		const points = [
			...generateCirclePoints3(w / 2, -h / 2, radius, 20, -90, 0),
			{
				x: w / 2 + radius,
				y: -radius
			},
			...generateCirclePoints3(w / 2 + radius * 2, -radius, radius, 20, -180, -270),
			...generateCirclePoints3(w / 2 + radius * 2, radius, radius, 20, -90, -180),
			{
				x: w / 2 + radius,
				y: h / 2
			},
			...generateCirclePoints3(w / 2, h / 2, radius, 20, 0, 90)
		];
		const rectPoints = [
			{
				x: -w / 2,
				y: -h / 2 - radius
			},
			{
				x: w / 2,
				y: -h / 2 - radius
			},
			...generateCirclePoints3(w / 2, -h / 2, radius, 20, -90, 0),
			{
				x: w / 2 + radius,
				y: -radius
			},
			...generateCirclePoints3(w / 2 + radius * 2, -radius, radius, 20, -180, -270),
			...generateCirclePoints3(w / 2 + radius * 2, radius, radius, 20, -90, -180),
			{
				x: w / 2 + radius,
				y: h / 2
			},
			...generateCirclePoints3(w / 2, h / 2, radius, 20, 0, 90),
			{
				x: w / 2,
				y: h / 2 + radius
			},
			{
				x: -w / 2,
				y: h / 2 + radius
			}
		];
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, { fill: "none" });
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const newCurlyBracePath = createPathFromPoints(points).replace("Z", "");
		const curlyBraceRightNode = rc.path(newCurlyBracePath, options);
		const rectPath = createPathFromPoints(rectPoints);
		const rectShape = rc.path(rectPath, _objectSpread2({}, options));
		const curlyBraceRightShape = shapeSvg.insert("g", ":first-child");
		curlyBraceRightShape.insert(() => rectShape, ":first-child").attr("stroke-opacity", 0);
		curlyBraceRightShape.insert(() => curlyBraceRightNode, ":first-child");
		curlyBraceRightShape.attr("class", "text");
		if (cssStyles && node.look !== "handDrawn") curlyBraceRightShape.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") curlyBraceRightShape.selectAll("path").attr("style", nodeStyles);
		curlyBraceRightShape.attr("transform", `translate(${-radius}, 0)`);
		label.attr("transform", `translate(${-w / 2 + ((_node$padding10 = node.padding) !== null && _node$padding10 !== void 0 ? _node$padding10 : 0) / 2 - (bbox.x - ((_bbox$left2 = bbox.left) !== null && _bbox$left2 !== void 0 ? _bbox$left2 : 0))},${-h / 2 + ((_node$padding11 = node.padding) !== null && _node$padding11 !== void 0 ? _node$padding11 : 0) / 2 - (bbox.y - ((_bbox$top2 = bbox.top) !== null && _bbox$top2 !== void 0 ? _bbox$top2 : 0))})`);
		updateNodeBounds(node, curlyBraceRightShape);
		node.intersect = function(point) {
			return intersect_default.polygon(node, rectPoints, point);
		};
		return shapeSvg;
	});
	return _curlyBraceRight.apply(this, arguments);
}
__name(curlyBraceRight, "curlyBraceRight");
function generateCirclePoints4(centerX, centerY, radius, numPoints = 100, startAngle = 0, endAngle = 180) {
	const points = [];
	const startAngleRad = startAngle * Math.PI / 180;
	const angleStep = (endAngle * Math.PI / 180 - startAngleRad) / (numPoints - 1);
	for (let i = 0; i < numPoints; i++) {
		const angle = startAngleRad + i * angleStep;
		const x = centerX + radius * Math.cos(angle);
		const y = centerY + radius * Math.sin(angle);
		points.push({
			x: -x,
			y: -y
		});
	}
	return points;
}
__name(generateCirclePoints4, "generateCirclePoints");
function curlyBraces(_x31, _x32) {
	return _curlyBraces.apply(this, arguments);
}
function _curlyBraces() {
	_curlyBraces = _asyncToGenerator(function* (parent, node) {
		var _node$padding12, _node$padding13, _node$padding14, _bbox$left3, _node$padding15, _bbox$top3;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const labelPaddingX = node.look === "neo" ? 18 : (_node$padding12 = node.padding) !== null && _node$padding12 !== void 0 ? _node$padding12 : 0;
		const labelPaddingY = node.look === "neo" ? 12 : (_node$padding13 = node.padding) !== null && _node$padding13 !== void 0 ? _node$padding13 : 0;
		const w = bbox.width + (node.look === "neo" ? labelPaddingX * 2 : labelPaddingX);
		const h = bbox.height + (node.look === "neo" ? labelPaddingY * 2 : labelPaddingY);
		const radius = Math.max(5, h * .1);
		const { cssStyles } = node;
		const leftCurlyBracePoints = [
			...generateCirclePoints4(w / 2, -h / 2, radius, 30, -90, 0),
			{
				x: -w / 2 - radius,
				y: radius
			},
			...generateCirclePoints4(w / 2 + radius * 2, -radius, radius, 20, -180, -270),
			...generateCirclePoints4(w / 2 + radius * 2, radius, radius, 20, -90, -180),
			{
				x: -w / 2 - radius,
				y: -h / 2
			},
			...generateCirclePoints4(w / 2, h / 2, radius, 20, 0, 90)
		];
		const rightCurlyBracePoints = [
			...generateCirclePoints4(-w / 2 + radius + radius / 2, -h / 2, radius, 20, -90, -180),
			{
				x: w / 2 - radius / 2,
				y: radius
			},
			...generateCirclePoints4(-w / 2 - radius / 2, -radius, radius, 20, 0, 90),
			...generateCirclePoints4(-w / 2 - radius / 2, radius, radius, 20, -90, 0),
			{
				x: w / 2 - radius / 2,
				y: -radius
			},
			...generateCirclePoints4(-w / 2 + radius + radius / 2, h / 2, radius, 30, -180, -270)
		];
		const rectPoints = [
			{
				x: w / 2,
				y: -h / 2 - radius
			},
			{
				x: -w / 2,
				y: -h / 2 - radius
			},
			...generateCirclePoints4(w / 2, -h / 2, radius, 20, -90, 0),
			{
				x: -w / 2 - radius,
				y: -radius
			},
			...generateCirclePoints4(w / 2 + radius * 2, -radius, radius, 20, -180, -270),
			...generateCirclePoints4(w / 2 + radius * 2, radius, radius, 20, -90, -180),
			{
				x: -w / 2 - radius,
				y: h / 2
			},
			...generateCirclePoints4(w / 2, h / 2, radius, 20, 0, 90),
			{
				x: -w / 2,
				y: h / 2 + radius
			},
			{
				x: w / 2 - radius - radius / 2,
				y: h / 2 + radius
			},
			...generateCirclePoints4(-w / 2 + radius + radius / 2, -h / 2, radius, 20, -90, -180),
			{
				x: w / 2 - radius / 2,
				y: radius
			},
			...generateCirclePoints4(-w / 2 - radius / 2, -radius, radius, 20, 0, 90),
			...generateCirclePoints4(-w / 2 - radius / 2, radius, radius, 20, -90, 0),
			{
				x: w / 2 - radius / 2,
				y: -radius
			},
			...generateCirclePoints4(-w / 2 + radius + radius / 2, h / 2, radius, 30, -180, -270)
		];
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, { fill: "none" });
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const newLeftCurlyBracePath = createPathFromPoints(leftCurlyBracePoints).replace("Z", "");
		const leftCurlyBraceNode = rc.path(newLeftCurlyBracePath, options);
		const newRightCurlyBracePath = createPathFromPoints(rightCurlyBracePoints).replace("Z", "");
		const rightCurlyBraceNode = rc.path(newRightCurlyBracePath, options);
		const rectPath = createPathFromPoints(rectPoints);
		const rectShape = rc.path(rectPath, _objectSpread2({}, options));
		const curlyBracesShape = shapeSvg.insert("g", ":first-child");
		curlyBracesShape.insert(() => rectShape, ":first-child").attr("stroke-opacity", 0);
		curlyBracesShape.insert(() => leftCurlyBraceNode, ":first-child");
		curlyBracesShape.insert(() => rightCurlyBraceNode, ":first-child");
		curlyBracesShape.attr("class", "text");
		if (cssStyles && node.look !== "handDrawn") curlyBracesShape.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") curlyBracesShape.selectAll("path").attr("style", nodeStyles);
		curlyBracesShape.attr("transform", `translate(${radius - radius / 4}, 0)`);
		label.attr("transform", `translate(${-w / 2 + ((_node$padding14 = node.padding) !== null && _node$padding14 !== void 0 ? _node$padding14 : 0) / 2 - (bbox.x - ((_bbox$left3 = bbox.left) !== null && _bbox$left3 !== void 0 ? _bbox$left3 : 0))},${-h / 2 + ((_node$padding15 = node.padding) !== null && _node$padding15 !== void 0 ? _node$padding15 : 0) / 2 - (bbox.y - ((_bbox$top3 = bbox.top) !== null && _bbox$top3 !== void 0 ? _bbox$top3 : 0))})`);
		updateNodeBounds(node, curlyBracesShape);
		node.intersect = function(point) {
			return intersect_default.polygon(node, rectPoints, point);
		};
		return shapeSvg;
	});
	return _curlyBraces.apply(this, arguments);
}
__name(curlyBraces, "curlyBraces");
function curvedTrapezoid(_x33, _x34) {
	return _curvedTrapezoid.apply(this, arguments);
}
function _curvedTrapezoid() {
	_curvedTrapezoid = _asyncToGenerator(function* (parent, node) {
		var _node$padding16, _node$width4, _node$height2;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding16 = node.padding) !== null && _node$padding16 !== void 0 ? _node$padding16 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		const minWidth = 20, minHeight = 5;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = Math.max(minWidth, (bbox.width + labelPaddingX * 2) * 1.25, (_node$width4 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width4 !== void 0 ? _node$width4 : 0);
		const h = Math.max(minHeight, bbox.height + labelPaddingY * 2, (_node$height2 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height2 !== void 0 ? _node$height2 : 0);
		const radius = h / 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const totalWidth = w, totalHeight = h;
		const rw = totalWidth - radius;
		const tw = totalHeight / 4;
		const points = [
			{
				x: rw,
				y: 0
			},
			{
				x: tw,
				y: 0
			},
			{
				x: 0,
				y: totalHeight / 2
			},
			{
				x: tw,
				y: totalHeight
			},
			{
				x: rw,
				y: totalHeight
			},
			...generateCirclePoints(-rw, -totalHeight / 2, radius, 50, 270, 90)
		];
		const pathData = createPathFromPoints(points);
		const shapeNode = rc.path(pathData, options);
		const polygon = shapeSvg.insert(() => shapeNode, ":first-child");
		polygon.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", nodeStyles);
		polygon.attr("transform", `translate(${-w / 2}, ${-h / 2})`);
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _curvedTrapezoid.apply(this, arguments);
}
__name(curvedTrapezoid, "curvedTrapezoid");
var createCylinderPathD = /* @__PURE__ */ __name((x, y, width, height, rx, ry) => {
	return [
		`M${x},${y + ry}`,
		`a${rx},${ry} 0,0,0 ${width},0`,
		`a${rx},${ry} 0,0,0 ${-width},0`,
		`l0,${height}`,
		`a${rx},${ry} 0,0,0 ${width},0`,
		`l0,${-height}`
	].join(" ");
}, "createCylinderPathD");
var createOuterCylinderPathD = /* @__PURE__ */ __name((x, y, width, height, rx, ry) => {
	return [
		`M${x},${y + ry}`,
		`M${x + width},${y + ry}`,
		`a${rx},${ry} 0,0,0 ${-width},0`,
		`l0,${height}`,
		`a${rx},${ry} 0,0,0 ${width},0`,
		`l0,${-height}`
	].join(" ");
}, "createOuterCylinderPathD");
var createInnerCylinderPathD = /* @__PURE__ */ __name((x, y, width, height, rx, ry) => {
	return [`M${x - width / 2},${-height / 2}`, `a${rx},${ry} 0,0,0 ${width},0`].join(" ");
}, "createInnerCylinderPathD");
var MIN_HEIGHT = 8;
var MIN_WIDTH = 8;
function cylinder(_x35, _x36) {
	return _cylinder.apply(this, arguments);
}
function _cylinder() {
	_cylinder = _asyncToGenerator(function* (parent, node) {
		var _node$padding17, _bbox$left4, _node$padding18, _bbox$top4;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding17 = node.padding) !== null && _node$padding17 !== void 0 ? _node$padding17 : 0;
		const labelPaddingX = node.look === "neo" ? 24 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 24 : nodePadding;
		if (node.width || node.height) {
			var _node$width5, _node$width6, _node$height3;
			const originalWidth = (_node$width5 = node.width) !== null && _node$width5 !== void 0 ? _node$width5 : 0;
			node.width = ((_node$width6 = node.width) !== null && _node$width6 !== void 0 ? _node$width6 : 0) - labelPaddingY;
			if (node.width < MIN_WIDTH) node.width = MIN_WIDTH;
			const ry2 = originalWidth / 2 / (2.5 + originalWidth / 50);
			node.height = ((_node$height3 = node.height) !== null && _node$height3 !== void 0 ? _node$height3 : 0) - labelPaddingX - ry2 * 3;
			if (node.height < MIN_HEIGHT) node.height = MIN_HEIGHT;
		}
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = (node.width ? node.width : bbox.width) + labelPaddingY;
		const rx = w / 2;
		const ry = rx / (2.5 + w / 50);
		const h = (node.height ? node.height : bbox.height) + labelPaddingX + ry;
		let cylinder2;
		const { cssStyles } = node;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const outerPathData = createOuterCylinderPathD(0, 0, w, h, rx, ry);
			const innerPathData = createInnerCylinderPathD(0, ry, w, h, rx, ry);
			const options = userNodeOverrides(node, {});
			const outerNode = rc.path(outerPathData, options);
			const innerLine = rc.path(innerPathData, userNodeOverrides(node, { fill: "none" }));
			cylinder2 = shapeSvg.insert(() => innerLine, ":first-child");
			cylinder2 = shapeSvg.insert(() => outerNode, ":first-child");
			cylinder2.attr("class", "basic label-container");
			if (cssStyles) cylinder2.attr("style", cssStyles);
		} else {
			const pathData = createCylinderPathD(0, 0, w, h, rx, ry);
			cylinder2 = shapeSvg.insert("path", ":first-child").attr("d", pathData).attr("class", "basic label-container outer-path").attr("style", handleUndefinedAttr(cssStyles)).attr("style", nodeStyles);
		}
		cylinder2.attr("label-offset-y", ry);
		cylinder2.attr("transform", `translate(${-w / 2}, ${-(h / 2 + ry)})`);
		updateNodeBounds(node, cylinder2);
		label.attr("transform", `translate(${-(bbox.width / 2) - (bbox.x - ((_bbox$left4 = bbox.left) !== null && _bbox$left4 !== void 0 ? _bbox$left4 : 0))}, ${-(bbox.height / 2) + ((_node$padding18 = node.padding) !== null && _node$padding18 !== void 0 ? _node$padding18 : 0) / 1.5 - (bbox.y - ((_bbox$top4 = bbox.top) !== null && _bbox$top4 !== void 0 ? _bbox$top4 : 0))})`);
		node.intersect = function(point) {
			var _node$x, _node$width7, _node$width8, _node$y, _node$height4;
			const pos = intersect_default.rect(node, point);
			const x = pos.x - ((_node$x = node.x) !== null && _node$x !== void 0 ? _node$x : 0);
			if (rx != 0 && (Math.abs(x) < ((_node$width7 = node.width) !== null && _node$width7 !== void 0 ? _node$width7 : 0) / 2 || Math.abs(x) == ((_node$width8 = node.width) !== null && _node$width8 !== void 0 ? _node$width8 : 0) / 2 && Math.abs(pos.y - ((_node$y = node.y) !== null && _node$y !== void 0 ? _node$y : 0)) > ((_node$height4 = node.height) !== null && _node$height4 !== void 0 ? _node$height4 : 0) / 2 - ry)) {
				var _node$y2;
				let y = ry * ry * (1 - x * x / (rx * rx));
				if (y > 0) y = Math.sqrt(y);
				y = ry - y;
				if (point.y - ((_node$y2 = node.y) !== null && _node$y2 !== void 0 ? _node$y2 : 0) > 0) y = -y;
				pos.y += y;
			}
			return pos;
		};
		return shapeSvg;
	});
	return _cylinder.apply(this, arguments);
}
__name(cylinder, "cylinder");
function drawRect(_x37, _x38, _x39) {
	return _drawRect.apply(this, arguments);
}
function _drawRect() {
	_drawRect = _asyncToGenerator(function* (parent, node, options) {
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const totalWidth = Math.max(bbox.width + options.labelPaddingX * 2, (node === null || node === void 0 ? void 0 : node.width) || 0);
		const totalHeight = Math.max(bbox.height + options.labelPaddingY * 2, (node === null || node === void 0 ? void 0 : node.height) || 0);
		const x = -totalWidth / 2;
		const y = -totalHeight / 2;
		let rect2;
		let { rx, ry } = node;
		const { cssStyles } = node;
		if ((options === null || options === void 0 ? void 0 : options.rx) && options.ry) {
			rx = options.rx;
			ry = options.ry;
		}
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options2 = userNodeOverrides(node, {});
			const roughNode = rx || ry ? rc.path(createRoundedRectPathD(x, y, totalWidth, totalHeight, rx || 0), options2) : rc.rectangle(x, y, totalWidth, totalHeight, options2);
			rect2 = shapeSvg.insert(() => roughNode, ":first-child");
			rect2.attr("class", "basic label-container").attr("style", handleUndefinedAttr(cssStyles));
		} else {
			rect2 = shapeSvg.insert("rect", ":first-child");
			rect2.attr("class", "basic label-container").attr("style", nodeStyles).attr("rx", handleUndefinedAttr(rx)).attr("ry", handleUndefinedAttr(ry)).attr("x", x).attr("y", y).attr("width", totalWidth).attr("height", totalHeight);
		}
		updateNodeBounds(node, rect2);
		node.calcIntersect = function(bounds, point) {
			return intersect_default.rect(bounds, point);
		};
		node.intersect = function(point) {
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _drawRect.apply(this, arguments);
}
__name(drawRect, "drawRect");
function datastore(_x40, _x41) {
	return _datastore.apply(this, arguments);
}
function _datastore() {
	_datastore = _asyncToGenerator(function* (parent, node) {
		var _ref9, _ref10, _ref11;
		const { cssClasses, labelPaddingX, labelPaddingY, padding, width, height } = node;
		const rect2 = yield drawRect(parent, node, {
			rx: 0,
			ry: 0,
			classes: cssClasses !== null && cssClasses !== void 0 ? cssClasses : "",
			labelPaddingX: labelPaddingX !== null && labelPaddingX !== void 0 ? labelPaddingX : (padding !== null && padding !== void 0 ? padding : 0) * 2,
			labelPaddingY: (_ref9 = labelPaddingY !== null && labelPaddingY !== void 0 ? labelPaddingY : padding) !== null && _ref9 !== void 0 ? _ref9 : 0
		});
		if (node.look === "handDrawn") {
			const rc = at.svg(rect2);
			const nodeOverrideOptions = userNodeOverrides(node, {});
			const borderSelection = rect2.select(".basic.label-container > path:nth-child(2)");
			const borderPath = borderSelection.node();
			if (!borderPath) return rect2;
			let bbox = null;
			if (borderPath instanceof SVGGraphicsElement) bbox = borderPath.getBBox();
			else return rect2;
			rect2.insert(() => rc.line(bbox.x, bbox.y, bbox.x + bbox.width, bbox.y, nodeOverrideOptions), ".basic.label-container g.label");
			rect2.insert(() => rc.line(bbox.x, bbox.y + bbox.height, bbox.x + bbox.width, bbox.y + bbox.height, nodeOverrideOptions), ".basic.label-container g.label");
			borderSelection.remove();
			return rect2;
		}
		const selection = rect2.select(".basic.label-container");
		const datastoreWidth = (_ref10 = Number(selection.attr("width")) || width) !== null && _ref10 !== void 0 ? _ref10 : 0;
		const datastoreHeight = (_ref11 = Number(selection.attr("height")) || height) !== null && _ref11 !== void 0 ? _ref11 : 0;
		if (datastoreWidth > 0 && datastoreHeight > 0) selection.attr("stroke-dasharray", `${datastoreWidth} ${datastoreHeight}`);
		return rect2;
	});
	return _datastore.apply(this, arguments);
}
__name(datastore, "datastore");
function dividedRectangle(_x42, _x43) {
	return _dividedRectangle.apply(this, arguments);
}
function _dividedRectangle() {
	_dividedRectangle = _asyncToGenerator(function* (parent, node) {
		var _node$padding19, _node$padding20, _node$padding21, _bbox$left5, _node$padding22, _bbox$top5;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const paddingX = node.look === "neo" ? 16 : (_node$padding19 = node.padding) !== null && _node$padding19 !== void 0 ? _node$padding19 : 0;
		const paddingY = node.look === "neo" ? 16 : (_node$padding20 = node.padding) !== null && _node$padding20 !== void 0 ? _node$padding20 : 0;
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = bbox.width + paddingX;
		const h = bbox.height + paddingY;
		const rectOffset2 = h * .2;
		const x = -w / 2;
		const y = -h / 2 - rectOffset2 / 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const pts = [
			{
				x,
				y: y + rectOffset2
			},
			{
				x: -x,
				y: y + rectOffset2
			},
			{
				x: -x,
				y: -y
			},
			{
				x,
				y: -y
			},
			{
				x,
				y
			},
			{
				x: -x,
				y
			},
			{
				x: -x,
				y: y + rectOffset2
			}
		];
		const poly = rc.polygon(pts.map((p) => [p.x, p.y]), options);
		const polygon = shapeSvg.insert(() => poly, ":first-child");
		polygon.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") polygon.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") polygon.selectAll("path").attr("style", nodeStyles);
		label.attr("transform", `translate(${x + ((_node$padding21 = node.padding) !== null && _node$padding21 !== void 0 ? _node$padding21 : 0) / 2 - (bbox.x - ((_bbox$left5 = bbox.left) !== null && _bbox$left5 !== void 0 ? _bbox$left5 : 0))}, ${y + rectOffset2 + ((_node$padding22 = node.padding) !== null && _node$padding22 !== void 0 ? _node$padding22 : 0) / 2 - (bbox.y - ((_bbox$top5 = bbox.top) !== null && _bbox$top5 !== void 0 ? _bbox$top5 : 0))})`);
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _dividedRectangle.apply(this, arguments);
}
__name(dividedRectangle, "dividedRectangle");
function doublecircle(_x44, _x45) {
	return _doublecircle.apply(this, arguments);
}
function _doublecircle() {
	_doublecircle = _asyncToGenerator(function* (parent, node) {
		var _node$padding23;
		const { labelStyles, nodeStyles } = styles2String(node);
		const gap = node.look === "neo" ? 12 : 5;
		node.labelStyle = labelStyles;
		const padding = (_node$padding23 = node.padding) !== null && _node$padding23 !== void 0 ? _node$padding23 : 0;
		const labelPadding = node.look === "neo" ? 16 : padding;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const outerRadius = ((node === null || node === void 0 ? void 0 : node.width) ? (node === null || node === void 0 ? void 0 : node.width) / 2 : bbox.width / 2) + (labelPadding !== null && labelPadding !== void 0 ? labelPadding : 0);
		const innerRadius = outerRadius - gap;
		let circleGroup;
		const { cssStyles } = node;
		if (node.look === "handDrawn") {
			var _circleGroup$node, _circleGroup$node2;
			const rc = at.svg(shapeSvg);
			const outerOptions = userNodeOverrides(node, {
				roughness: .2,
				strokeWidth: 2.5
			});
			const innerOptions = userNodeOverrides(node, {
				roughness: .2,
				strokeWidth: 1.5
			});
			const outerRoughNode = rc.circle(0, 0, outerRadius * 2, outerOptions);
			const innerRoughNode = rc.circle(0, 0, innerRadius * 2, innerOptions);
			circleGroup = shapeSvg.insert("g", ":first-child");
			circleGroup.attr("class", handleUndefinedAttr(node.cssClasses)).attr("style", handleUndefinedAttr(cssStyles));
			(_circleGroup$node = circleGroup.node()) === null || _circleGroup$node === void 0 || _circleGroup$node.appendChild(outerRoughNode);
			(_circleGroup$node2 = circleGroup.node()) === null || _circleGroup$node2 === void 0 || _circleGroup$node2.appendChild(innerRoughNode);
		} else {
			circleGroup = shapeSvg.insert("g", ":first-child");
			const outerCircle = circleGroup.insert("circle", ":first-child");
			const innerCircle = circleGroup.insert("circle");
			circleGroup.attr("class", "basic label-container").attr("style", nodeStyles);
			outerCircle.attr("class", "outer-circle").attr("style", nodeStyles).attr("r", outerRadius).attr("cx", 0).attr("cy", 0);
			innerCircle.attr("class", "inner-circle").attr("style", nodeStyles).attr("r", innerRadius).attr("cx", 0).attr("cy", 0);
		}
		updateNodeBounds(node, circleGroup);
		node.intersect = function(point) {
			log.info("DoubleCircle intersect", node, outerRadius, point);
			return intersect_default.circle(node, outerRadius, point);
		};
		return shapeSvg;
	});
	return _doublecircle.apply(this, arguments);
}
__name(doublecircle, "doublecircle");
function filledCircle(parent, node, { config: { themeVariables } }) {
	var _node$domId3;
	const { labelStyles, nodeStyles } = styles2String(node);
	node.label = "";
	node.labelStyle = labelStyles;
	const shapeSvg = parent.insert("g").attr("class", getNodeClasses(node)).attr("id", (_node$domId3 = node.domId) !== null && _node$domId3 !== void 0 ? _node$domId3 : node.id);
	const radius = 7;
	const { cssStyles } = node;
	const rc = at.svg(shapeSvg);
	const { nodeBorder } = themeVariables;
	const options = userNodeOverrides(node, { fillStyle: "solid" });
	if (node.look !== "handDrawn") options.roughness = 0;
	const circleNode = rc.circle(0, 0, radius * 2, options);
	const filledCircle2 = shapeSvg.insert(() => circleNode, ":first-child");
	filledCircle2.selectAll("path").attr("style", `fill: ${nodeBorder} !important;`);
	if (cssStyles && cssStyles.length > 0 && node.look !== "handDrawn") filledCircle2.selectAll("path").attr("style", cssStyles);
	if (nodeStyles && node.look !== "handDrawn") filledCircle2.selectAll("path").attr("style", nodeStyles);
	updateNodeBounds(node, filledCircle2);
	node.intersect = function(point) {
		log.info("filledCircle intersect", node, {
			radius,
			point
		});
		return intersect_default.circle(node, radius, point);
	};
	return shapeSvg;
}
__name(filledCircle, "filledCircle");
var MIN_HEIGHT2 = 10;
var MIN_WIDTH2 = 10;
function flippedTriangle(_x46, _x47) {
	return _flippedTriangle.apply(this, arguments);
}
function _flippedTriangle() {
	_flippedTriangle = _asyncToGenerator(function* (parent, node) {
		var _node$padding24, _bbox$left6, _node$padding25, _bbox$top6;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding24 = node.padding) !== null && _node$padding24 !== void 0 ? _node$padding24 : 0;
		const labelPaddingX = node.look === "neo" ? nodePadding * 2 : nodePadding;
		if (node.width || node.height) {
			var _node$height5, _node$width9;
			node.height = (_node$height5 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height5 !== void 0 ? _node$height5 : 0;
			if (node.height < MIN_HEIGHT2) node.height = MIN_HEIGHT2;
			node.width = ((_node$width9 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width9 !== void 0 ? _node$width9 : 0) - labelPaddingX - labelPaddingX / 2;
			if (node.width < MIN_WIDTH2) node.width = MIN_WIDTH2;
		}
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + (labelPaddingX !== null && labelPaddingX !== void 0 ? labelPaddingX : 0);
		const h = (node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : w + bbox.height;
		const tw = h;
		const points = [
			{
				x: 0,
				y: -h
			},
			{
				x: tw,
				y: -h
			},
			{
				x: tw / 2,
				y: 0
			}
		];
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const pathData = createPathFromPoints(points);
		const roughNode = rc.path(pathData, options);
		const flippedTriangle2 = shapeSvg.insert(() => roughNode, ":first-child").attr("transform", `translate(${-h / 2}, ${h / 2})`).attr("class", "outer-path");
		if (cssStyles && node.look !== "handDrawn") flippedTriangle2.selectChildren("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") flippedTriangle2.selectChildren("path").attr("style", nodeStyles);
		node.width = w;
		node.height = h;
		updateNodeBounds(node, flippedTriangle2);
		label.attr("transform", `translate(${-bbox.width / 2 - (bbox.x - ((_bbox$left6 = bbox.left) !== null && _bbox$left6 !== void 0 ? _bbox$left6 : 0))}, ${-h / 2 + ((_node$padding25 = node.padding) !== null && _node$padding25 !== void 0 ? _node$padding25 : 0) / 2 + (bbox.y - ((_bbox$top6 = bbox.top) !== null && _bbox$top6 !== void 0 ? _bbox$top6 : 0))})`);
		node.intersect = function(point) {
			log.info("Triangle intersect", node, points, point);
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _flippedTriangle.apply(this, arguments);
}
__name(flippedTriangle, "flippedTriangle");
function forkJoin(parent, node, { dir, config: { state: state2, themeVariables } }) {
	var _node$domId4, _node$width10, _node$height6, _state2$padding;
	const { nodeStyles } = styles2String(node);
	node.label = "";
	const shapeSvg = parent.insert("g").attr("class", getNodeClasses(node)).attr("id", (_node$domId4 = node.domId) !== null && _node$domId4 !== void 0 ? _node$domId4 : node.id);
	const { cssStyles } = node;
	let width = Math.max(70, (_node$width10 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width10 !== void 0 ? _node$width10 : 0);
	let height = Math.max(10, (_node$height6 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height6 !== void 0 ? _node$height6 : 0);
	if (dir === "LR") {
		var _node$width11, _node$height7;
		width = Math.max(10, (_node$width11 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width11 !== void 0 ? _node$width11 : 0);
		height = Math.max(70, (_node$height7 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height7 !== void 0 ? _node$height7 : 0);
	}
	const x = -1 * width / 2;
	const y = -1 * height / 2;
	const rc = at.svg(shapeSvg);
	const options = userNodeOverrides(node, {
		stroke: themeVariables.lineColor,
		fill: themeVariables.lineColor
	});
	if (node.look !== "handDrawn") {
		options.roughness = 0;
		options.fillStyle = "solid";
	}
	const roughNode = rc.rectangle(x, y, width, height, options);
	const shape = shapeSvg.insert(() => roughNode, ":first-child");
	if (cssStyles && node.look !== "handDrawn") shape.selectAll("path").attr("style", cssStyles);
	if (nodeStyles && node.look !== "handDrawn") shape.selectAll("path").attr("style", nodeStyles);
	updateNodeBounds(node, shape);
	const padding = (_state2$padding = state2 === null || state2 === void 0 ? void 0 : state2.padding) !== null && _state2$padding !== void 0 ? _state2$padding : 0;
	if (node.width && node.height) {
		node.width += padding / 2 || 0;
		node.height += padding / 2 || 0;
	}
	node.intersect = function(point) {
		return intersect_default.rect(node, point);
	};
	return shapeSvg;
}
__name(forkJoin, "forkJoin");
function halfRoundedRectangle(_x48, _x49) {
	return _halfRoundedRectangle.apply(this, arguments);
}
function _halfRoundedRectangle() {
	_halfRoundedRectangle = _asyncToGenerator(function* (parent, node) {
		var _node$padding26, _node$padding27;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const minWidth = 15, minHeight = 10;
		const paddingX = node.look === "neo" ? 16 : (_node$padding26 = node.padding) !== null && _node$padding26 !== void 0 ? _node$padding26 : 0;
		const paddingY = node.look === "neo" ? 12 : (_node$padding27 = node.padding) !== null && _node$padding27 !== void 0 ? _node$padding27 : 0;
		if (node.width || node.height) {
			var _node$height8, _node$width12;
			node.height = ((_node$height8 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height8 !== void 0 ? _node$height8 : 0) - paddingY * 2;
			if (node.height < minHeight) node.height = minHeight;
			node.width = ((_node$width12 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width12 !== void 0 ? _node$width12 : 0) - paddingX * 2;
			if (node.width < minWidth) node.width = minWidth;
		}
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : Math.max(minWidth, bbox.width)) + paddingX * 2;
		const h = ((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : Math.max(minHeight, bbox.height)) + paddingY * 2;
		const radius = h / 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const points = [
			{
				x: -w / 2,
				y: -h / 2
			},
			{
				x: w / 2 - radius,
				y: -h / 2
			},
			...generateCirclePoints(-w / 2 + radius, 0, radius, 50, 90, 270),
			{
				x: w / 2 - radius,
				y: h / 2
			},
			{
				x: -w / 2,
				y: h / 2
			}
		];
		const pathData = createPathFromPoints(points);
		const shapeNode = rc.path(pathData, options);
		const polygon = shapeSvg.insert(() => shapeNode, ":first-child");
		polygon.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", nodeStyles);
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			log.info("Pill intersect", node, {
				radius,
				point
			});
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _halfRoundedRectangle.apply(this, arguments);
}
__name(halfRoundedRectangle, "halfRoundedRectangle");
var createHexagonPathD = /* @__PURE__ */ __name((x, y, width, height, m) => {
	return [
		`M${x + m},${y}`,
		`L${x + width - m},${y}`,
		`L${x + width},${y - height / 2}`,
		`L${x + width - m},${y - height}`,
		`L${x + m},${y - height}`,
		`L${x},${y - height / 2}`,
		"Z"
	].join(" ");
}, "createHexagonPathD");
function hexagon(_x50, _x51) {
	return _hexagon.apply(this, arguments);
}
function _hexagon() {
	_hexagon = _asyncToGenerator(function* (parent, node) {
		var _node$padding28;
		const { labelStyles, nodeStyles } = styles2String(node);
		const f = node.look === "neo" ? 3.5 : 4;
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding28 = node.padding) !== null && _node$padding28 !== void 0 ? _node$padding28 : 0;
		const wa = 70;
		const ha = 32;
		const labelPaddingX = node.look === "neo" ? wa : nodePadding;
		const labelPaddingY = node.look === "neo" ? ha : nodePadding;
		if (node.width || node.height) {
			var _node$height9, _node$width13, _node$height10;
			const m2 = ((_node$height9 = node.height) !== null && _node$height9 !== void 0 ? _node$height9 : 0) / f;
			node.width = ((_node$width13 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width13 !== void 0 ? _node$width13 : 0) - 2 * m2 - labelPaddingY;
			node.height = ((_node$height10 = node.height) !== null && _node$height10 !== void 0 ? _node$height10 : 0) - labelPaddingX;
		}
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const h = ((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : bbox.height) + labelPaddingX;
		const m = h / f;
		const w = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + 2 * m + labelPaddingY;
		const points = [
			{
				x: m,
				y: 0
			},
			{
				x: w - m,
				y: 0
			},
			{
				x: w,
				y: -h / 2
			},
			{
				x: w - m,
				y: -h
			},
			{
				x: m,
				y: -h
			},
			{
				x: 0,
				y: -h / 2
			}
		];
		let polygon;
		const { cssStyles } = node;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {});
			const pathData = createHexagonPathD(0, 0, w, h, m);
			const roughNode = rc.path(pathData, options);
			polygon = shapeSvg.insert(() => roughNode, ":first-child").attr("transform", `translate(${-w / 2}, ${h / 2})`);
			if (cssStyles) polygon.attr("style", cssStyles);
		} else polygon = insertPolygonShape(shapeSvg, w, h, points);
		if (nodeStyles) polygon.attr("style", nodeStyles);
		node.width = w;
		node.height = h;
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _hexagon.apply(this, arguments);
}
__name(hexagon, "hexagon");
function hourglass(_x52, _x53) {
	return _hourglass.apply(this, arguments);
}
function _hourglass() {
	_hourglass = _asyncToGenerator(function* (parent, node) {
		var _node$width14, _node$height11;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.label = "";
		node.labelStyle = labelStyles;
		const { shapeSvg } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = Math.max(30, (_node$width14 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width14 !== void 0 ? _node$width14 : 0);
		const h = Math.max(30, (_node$height11 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height11 !== void 0 ? _node$height11 : 0);
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const points = [
			{
				x: 0,
				y: 0
			},
			{
				x: w,
				y: 0
			},
			{
				x: 0,
				y: h
			},
			{
				x: w,
				y: h
			}
		];
		const pathData = createPathFromPoints(points);
		const shapeNode = rc.path(pathData, options);
		const polygon = shapeSvg.insert(() => shapeNode, ":first-child");
		polygon.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", nodeStyles);
		polygon.attr("transform", `translate(${-w / 2}, ${-h / 2})`);
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			log.info("Pill intersect", node, { points });
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _hourglass.apply(this, arguments);
}
__name(hourglass, "hourglass");
function icon(_x54, _x55, _x56) {
	return _icon.apply(this, arguments);
}
function _icon() {
	_icon = _asyncToGenerator(function* (parent, node, { config: { themeVariables, flowchart } }) {
		var _node$assetHeight, _node$assetWidth, _bbox$left7;
		const { labelStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const assetHeight = (_node$assetHeight = node.assetHeight) !== null && _node$assetHeight !== void 0 ? _node$assetHeight : 48;
		const assetWidth = (_node$assetWidth = node.assetWidth) !== null && _node$assetWidth !== void 0 ? _node$assetWidth : 48;
		const iconSize = Math.max(assetHeight, assetWidth);
		const defaultWidth = flowchart === null || flowchart === void 0 ? void 0 : flowchart.wrappingWidth;
		node.width = Math.max(iconSize, defaultWidth !== null && defaultWidth !== void 0 ? defaultWidth : 0);
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, "icon-shape default");
		const topLabel = node.pos === "t";
		const height = iconSize;
		const width = iconSize;
		const { nodeBorder } = themeVariables;
		const { stylesMap } = compileStyles(node);
		const x = -width / 2;
		const y = -height / 2;
		const labelPadding = node.label ? 8 : 0;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {
			stroke: "none",
			fill: "none"
		});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const iconNode = rc.rectangle(x, y, width, height, options);
		const outerWidth = Math.max(width, bbox.width);
		const outerHeight = height + bbox.height + labelPadding;
		const outerNode = rc.rectangle(-outerWidth / 2, -outerHeight / 2, outerWidth, outerHeight, _objectSpread2(_objectSpread2({}, options), {}, {
			fill: "transparent",
			stroke: "none"
		}));
		const iconShape = shapeSvg.insert(() => iconNode, ":first-child");
		const outerShape = shapeSvg.insert(() => outerNode);
		if (node.icon) {
			var _stylesMap$get;
			const iconElem = shapeSvg.append("g");
			iconElem.html(`<g>${yield getIconSVG(node.icon, {
				height: iconSize,
				width: iconSize,
				fallbackPrefix: ""
			})}</g>`);
			const iconBBox = iconElem.node().getBBox();
			const iconWidth = iconBBox.width;
			const iconHeight = iconBBox.height;
			const iconX = iconBBox.x;
			const iconY = iconBBox.y;
			iconElem.attr("transform", `translate(${-iconWidth / 2 - iconX},${topLabel ? bbox.height / 2 + labelPadding / 2 - iconHeight / 2 - iconY : -bbox.height / 2 - labelPadding / 2 - iconHeight / 2 - iconY})`);
			iconElem.attr("style", `color: ${(_stylesMap$get = stylesMap.get("stroke")) !== null && _stylesMap$get !== void 0 ? _stylesMap$get : nodeBorder};`);
		}
		label.attr("transform", `translate(${-bbox.width / 2 - (bbox.x - ((_bbox$left7 = bbox.left) !== null && _bbox$left7 !== void 0 ? _bbox$left7 : 0))},${topLabel ? -outerHeight / 2 : outerHeight / 2 - bbox.height})`);
		iconShape.attr("transform", `translate(0,${topLabel ? bbox.height / 2 + labelPadding / 2 : -bbox.height / 2 - labelPadding / 2})`);
		updateNodeBounds(node, outerShape);
		node.intersect = function(point) {
			var _node$x2, _node$y3, _node$height12;
			log.info("iconSquare intersect", node, point);
			if (!node.label) return intersect_default.rect(node, point);
			const dx = (_node$x2 = node.x) !== null && _node$x2 !== void 0 ? _node$x2 : 0;
			const dy = (_node$y3 = node.y) !== null && _node$y3 !== void 0 ? _node$y3 : 0;
			const nodeHeight = (_node$height12 = node.height) !== null && _node$height12 !== void 0 ? _node$height12 : 0;
			let points = [];
			if (topLabel) points = [
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx + width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx + width / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - width / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				}
			];
			else points = [
				{
					x: dx - width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + width / 2,
					y: dy - nodeHeight / 2 + height
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2 + height
				},
				{
					x: dx + bbox.width / 2 / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - bbox.width / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2 + height
				},
				{
					x: dx - width / 2,
					y: dy - nodeHeight / 2 + height
				}
			];
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _icon.apply(this, arguments);
}
__name(icon, "icon");
function iconCircle(_x57, _x58, _x59) {
	return _iconCircle.apply(this, arguments);
}
function _iconCircle() {
	_iconCircle = _asyncToGenerator(function* (parent, node, { config: { themeVariables, flowchart } }) {
		var _node$assetHeight2, _node$assetWidth2, _stylesMap$get2, _bbox$left8;
		const { labelStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const assetHeight = (_node$assetHeight2 = node.assetHeight) !== null && _node$assetHeight2 !== void 0 ? _node$assetHeight2 : 48;
		const assetWidth = (_node$assetWidth2 = node.assetWidth) !== null && _node$assetWidth2 !== void 0 ? _node$assetWidth2 : 48;
		const iconSize = Math.max(assetHeight, assetWidth);
		const defaultWidth = flowchart === null || flowchart === void 0 ? void 0 : flowchart.wrappingWidth;
		node.width = Math.max(iconSize, defaultWidth !== null && defaultWidth !== void 0 ? defaultWidth : 0);
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, "icon-shape default");
		const padding = 20;
		const labelPadding = node.label ? 8 : 0;
		const topLabel = node.pos === "t";
		const { nodeBorder, mainBkg } = themeVariables;
		const { stylesMap } = compileStyles(node);
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const fill = stylesMap.get("fill");
		options.stroke = fill !== null && fill !== void 0 ? fill : mainBkg;
		const iconElem = shapeSvg.append("g");
		if (node.icon) iconElem.html(`<g>${yield getIconSVG(node.icon, {
			height: iconSize,
			width: iconSize,
			fallbackPrefix: ""
		})}</g>`);
		const iconBBox = iconElem.node().getBBox();
		const iconWidth = iconBBox.width;
		const iconHeight = iconBBox.height;
		const iconX = iconBBox.x;
		const iconY = iconBBox.y;
		const diameter = Math.max(iconWidth, iconHeight) * Math.SQRT2 + padding * 2;
		const iconNode = rc.circle(0, 0, diameter, options);
		const outerWidth = Math.max(diameter, bbox.width);
		const outerHeight = diameter + bbox.height + labelPadding;
		const outerNode = rc.rectangle(-outerWidth / 2, -outerHeight / 2, outerWidth, outerHeight, _objectSpread2(_objectSpread2({}, options), {}, {
			fill: "transparent",
			stroke: "none"
		}));
		const iconShape = shapeSvg.insert(() => iconNode, ":first-child");
		const outerShape = shapeSvg.insert(() => outerNode);
		iconElem.attr("transform", `translate(${-iconWidth / 2 - iconX},${topLabel ? bbox.height / 2 + labelPadding / 2 - iconHeight / 2 - iconY : -bbox.height / 2 - labelPadding / 2 - iconHeight / 2 - iconY})`);
		iconElem.attr("style", `color: ${(_stylesMap$get2 = stylesMap.get("stroke")) !== null && _stylesMap$get2 !== void 0 ? _stylesMap$get2 : nodeBorder};`);
		label.attr("transform", `translate(${-bbox.width / 2 - (bbox.x - ((_bbox$left8 = bbox.left) !== null && _bbox$left8 !== void 0 ? _bbox$left8 : 0))},${topLabel ? -outerHeight / 2 : outerHeight / 2 - bbox.height})`);
		iconShape.attr("transform", `translate(0,${topLabel ? bbox.height / 2 + labelPadding / 2 : -bbox.height / 2 - labelPadding / 2})`);
		updateNodeBounds(node, outerShape);
		node.intersect = function(point) {
			log.info("iconSquare intersect", node, point);
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _iconCircle.apply(this, arguments);
}
__name(iconCircle, "iconCircle");
function iconRounded(_x60, _x61, _x62) {
	return _iconRounded.apply(this, arguments);
}
function _iconRounded() {
	_iconRounded = _asyncToGenerator(function* (parent, node, { config: { themeVariables, flowchart } }) {
		var _node$assetHeight3, _node$assetWidth3, _bbox$left9;
		const { labelStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const assetHeight = (_node$assetHeight3 = node.assetHeight) !== null && _node$assetHeight3 !== void 0 ? _node$assetHeight3 : 48;
		const assetWidth = (_node$assetWidth3 = node.assetWidth) !== null && _node$assetWidth3 !== void 0 ? _node$assetWidth3 : 48;
		const iconSize = Math.max(assetHeight, assetWidth);
		const defaultWidth = flowchart === null || flowchart === void 0 ? void 0 : flowchart.wrappingWidth;
		node.width = Math.max(iconSize, defaultWidth !== null && defaultWidth !== void 0 ? defaultWidth : 0);
		const { shapeSvg, bbox, halfPadding, label } = yield labelHelper(parent, node, "icon-shape default");
		const topLabel = node.pos === "t";
		const height = iconSize + halfPadding * 2;
		const width = iconSize + halfPadding * 2;
		const { nodeBorder, mainBkg } = themeVariables;
		const { stylesMap } = compileStyles(node);
		const x = -width / 2;
		const y = -height / 2;
		const labelPadding = node.label ? 8 : 0;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const fill = stylesMap.get("fill");
		options.stroke = fill !== null && fill !== void 0 ? fill : mainBkg;
		const iconNode = rc.path(createRoundedRectPathD(x, y, width, height, 5), options);
		const outerWidth = Math.max(width, bbox.width);
		const outerHeight = height + bbox.height + labelPadding;
		const outerNode = rc.rectangle(-outerWidth / 2, -outerHeight / 2, outerWidth, outerHeight, _objectSpread2(_objectSpread2({}, options), {}, {
			fill: "transparent",
			stroke: "none"
		}));
		const iconShape = shapeSvg.insert(() => iconNode, ":first-child").attr("class", "icon-shape2");
		const outerShape = shapeSvg.insert(() => outerNode);
		if (node.icon) {
			var _stylesMap$get3;
			const iconElem = shapeSvg.append("g");
			iconElem.html(`<g>${yield getIconSVG(node.icon, {
				height: iconSize,
				width: iconSize,
				fallbackPrefix: ""
			})}</g>`);
			const iconBBox = iconElem.node().getBBox();
			const iconWidth = iconBBox.width;
			const iconHeight = iconBBox.height;
			const iconX = iconBBox.x;
			const iconY = iconBBox.y;
			iconElem.attr("transform", `translate(${-iconWidth / 2 - iconX},${topLabel ? bbox.height / 2 + labelPadding / 2 - iconHeight / 2 - iconY : -bbox.height / 2 - labelPadding / 2 - iconHeight / 2 - iconY})`);
			iconElem.attr("style", `color: ${(_stylesMap$get3 = stylesMap.get("stroke")) !== null && _stylesMap$get3 !== void 0 ? _stylesMap$get3 : nodeBorder};`);
		}
		label.attr("transform", `translate(${-bbox.width / 2 - (bbox.x - ((_bbox$left9 = bbox.left) !== null && _bbox$left9 !== void 0 ? _bbox$left9 : 0))},${topLabel ? -outerHeight / 2 : outerHeight / 2 - bbox.height})`);
		iconShape.attr("transform", `translate(0,${topLabel ? bbox.height / 2 + labelPadding / 2 : -bbox.height / 2 - labelPadding / 2})`);
		updateNodeBounds(node, outerShape);
		node.intersect = function(point) {
			var _node$x3, _node$y4, _node$height13;
			log.info("iconSquare intersect", node, point);
			if (!node.label) return intersect_default.rect(node, point);
			const dx = (_node$x3 = node.x) !== null && _node$x3 !== void 0 ? _node$x3 : 0;
			const dy = (_node$y4 = node.y) !== null && _node$y4 !== void 0 ? _node$y4 : 0;
			const nodeHeight = (_node$height13 = node.height) !== null && _node$height13 !== void 0 ? _node$height13 : 0;
			let points = [];
			if (topLabel) points = [
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx + width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx + width / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - width / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				}
			];
			else points = [
				{
					x: dx - width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + width / 2,
					y: dy - nodeHeight / 2 + height
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2 + height
				},
				{
					x: dx + bbox.width / 2 / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - bbox.width / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2 + height
				},
				{
					x: dx - width / 2,
					y: dy - nodeHeight / 2 + height
				}
			];
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _iconRounded.apply(this, arguments);
}
__name(iconRounded, "iconRounded");
function iconSquare(_x63, _x64, _x65) {
	return _iconSquare.apply(this, arguments);
}
function _iconSquare() {
	_iconSquare = _asyncToGenerator(function* (parent, node, { config: { themeVariables, flowchart } }) {
		var _node$assetHeight4, _node$assetWidth4, _bbox$left10;
		const { labelStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const assetHeight = (_node$assetHeight4 = node.assetHeight) !== null && _node$assetHeight4 !== void 0 ? _node$assetHeight4 : 48;
		const assetWidth = (_node$assetWidth4 = node.assetWidth) !== null && _node$assetWidth4 !== void 0 ? _node$assetWidth4 : 48;
		const iconSize = Math.max(assetHeight, assetWidth);
		const defaultWidth = flowchart === null || flowchart === void 0 ? void 0 : flowchart.wrappingWidth;
		node.width = Math.max(iconSize, defaultWidth !== null && defaultWidth !== void 0 ? defaultWidth : 0);
		const { shapeSvg, bbox, halfPadding, label } = yield labelHelper(parent, node, "icon-shape default");
		const topLabel = node.pos === "t";
		const height = iconSize + halfPadding * 2;
		const width = iconSize + halfPadding * 2;
		const { nodeBorder, mainBkg } = themeVariables;
		const { stylesMap } = compileStyles(node);
		const x = -width / 2;
		const y = -height / 2;
		const labelPadding = node.label ? 8 : 0;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const fill = stylesMap.get("fill");
		options.stroke = fill !== null && fill !== void 0 ? fill : mainBkg;
		const iconNode = rc.path(createRoundedRectPathD(x, y, width, height, .1), options);
		const outerWidth = Math.max(width, bbox.width);
		const outerHeight = height + bbox.height + labelPadding;
		const outerNode = rc.rectangle(-outerWidth / 2, -outerHeight / 2, outerWidth, outerHeight, _objectSpread2(_objectSpread2({}, options), {}, {
			fill: "transparent",
			stroke: "none"
		}));
		const iconShape = shapeSvg.insert(() => iconNode, ":first-child");
		const outerShape = shapeSvg.insert(() => outerNode);
		if (node.icon) {
			var _stylesMap$get4;
			const iconElem = shapeSvg.append("g");
			iconElem.html(`<g>${yield getIconSVG(node.icon, {
				height: iconSize,
				width: iconSize,
				fallbackPrefix: ""
			})}</g>`);
			const iconBBox = iconElem.node().getBBox();
			const iconWidth = iconBBox.width;
			const iconHeight = iconBBox.height;
			const iconX = iconBBox.x;
			const iconY = iconBBox.y;
			iconElem.attr("transform", `translate(${-iconWidth / 2 - iconX},${topLabel ? bbox.height / 2 + labelPadding / 2 - iconHeight / 2 - iconY : -bbox.height / 2 - labelPadding / 2 - iconHeight / 2 - iconY})`);
			iconElem.attr("style", `color: ${(_stylesMap$get4 = stylesMap.get("stroke")) !== null && _stylesMap$get4 !== void 0 ? _stylesMap$get4 : nodeBorder};`);
		}
		label.attr("transform", `translate(${-bbox.width / 2 - (bbox.x - ((_bbox$left10 = bbox.left) !== null && _bbox$left10 !== void 0 ? _bbox$left10 : 0))},${topLabel ? -outerHeight / 2 : outerHeight / 2 - bbox.height})`);
		iconShape.attr("transform", `translate(0,${topLabel ? bbox.height / 2 + labelPadding / 2 : -bbox.height / 2 - labelPadding / 2})`);
		updateNodeBounds(node, outerShape);
		node.intersect = function(point) {
			var _node$x4, _node$y5, _node$height14;
			log.info("iconSquare intersect", node, point);
			if (!node.label) return intersect_default.rect(node, point);
			const dx = (_node$x4 = node.x) !== null && _node$x4 !== void 0 ? _node$x4 : 0;
			const dy = (_node$y5 = node.y) !== null && _node$y5 !== void 0 ? _node$y5 : 0;
			const nodeHeight = (_node$height14 = node.height) !== null && _node$height14 !== void 0 ? _node$height14 : 0;
			let points = [];
			if (topLabel) points = [
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx + width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx + width / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - width / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				}
			];
			else points = [
				{
					x: dx - width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + width / 2,
					y: dy - nodeHeight / 2 + height
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2 + height
				},
				{
					x: dx + bbox.width / 2 / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - bbox.width / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2 + height
				},
				{
					x: dx - width / 2,
					y: dy - nodeHeight / 2 + height
				}
			];
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _iconSquare.apply(this, arguments);
}
__name(iconSquare, "iconSquare");
function imageSquare(_x66, _x67, _x68) {
	return _imageSquare.apply(this, arguments);
}
function _imageSquare() {
	_imageSquare = _asyncToGenerator(function* (parent, node, { config: { flowchart } }) {
		var _node$img, _node$assetWidth5, _node$assetHeight5, _bbox$left11;
		const img = new Image();
		img.src = (_node$img = node === null || node === void 0 ? void 0 : node.img) !== null && _node$img !== void 0 ? _node$img : "";
		yield img.decode();
		const imageNaturalWidth = Number(img.naturalWidth.toString().replace("px", ""));
		const imageNaturalHeight = Number(img.naturalHeight.toString().replace("px", ""));
		node.imageAspectRatio = imageNaturalWidth / imageNaturalHeight;
		const { labelStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const defaultWidth = flowchart === null || flowchart === void 0 ? void 0 : flowchart.wrappingWidth;
		node.defaultWidth = flowchart === null || flowchart === void 0 ? void 0 : flowchart.wrappingWidth;
		const imageRawWidth = Math.max(node.label ? defaultWidth !== null && defaultWidth !== void 0 ? defaultWidth : 0 : 0, (_node$assetWidth5 = node === null || node === void 0 ? void 0 : node.assetWidth) !== null && _node$assetWidth5 !== void 0 ? _node$assetWidth5 : imageNaturalWidth);
		const imageWidth = node.constraint === "on" ? (node === null || node === void 0 ? void 0 : node.assetHeight) ? node.assetHeight * node.imageAspectRatio : imageRawWidth : imageRawWidth;
		const imageHeight = node.constraint === "on" ? imageWidth / node.imageAspectRatio : (_node$assetHeight5 = node === null || node === void 0 ? void 0 : node.assetHeight) !== null && _node$assetHeight5 !== void 0 ? _node$assetHeight5 : imageNaturalHeight;
		node.width = Math.max(imageWidth, defaultWidth !== null && defaultWidth !== void 0 ? defaultWidth : 0);
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, "image-shape default");
		const topLabel = node.pos === "t";
		const x = -imageWidth / 2;
		const y = -imageHeight / 2;
		const labelPadding = node.label ? 8 : 0;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const imageNode = rc.rectangle(x, y, imageWidth, imageHeight, options);
		const outerWidth = Math.max(imageWidth, bbox.width);
		const outerHeight = imageHeight + bbox.height + labelPadding;
		const outerNode = rc.rectangle(-outerWidth / 2, -outerHeight / 2, outerWidth, outerHeight, _objectSpread2(_objectSpread2({}, options), {}, {
			fill: "none",
			stroke: "none"
		}));
		const iconShape = shapeSvg.insert(() => imageNode, ":first-child");
		const outerShape = shapeSvg.insert(() => outerNode);
		if (node.img) {
			const image = shapeSvg.append("image");
			image.attr("href", node.img);
			image.attr("width", imageWidth);
			image.attr("height", imageHeight);
			image.attr("preserveAspectRatio", "none");
			image.attr("transform", `translate(${-imageWidth / 2},${topLabel ? outerHeight / 2 - imageHeight : -outerHeight / 2})`);
		}
		label.attr("transform", `translate(${-bbox.width / 2 - (bbox.x - ((_bbox$left11 = bbox.left) !== null && _bbox$left11 !== void 0 ? _bbox$left11 : 0))},${topLabel ? -imageHeight / 2 - bbox.height / 2 - labelPadding / 2 : imageHeight / 2 - bbox.height / 2 + labelPadding / 2})`);
		iconShape.attr("transform", `translate(0,${topLabel ? bbox.height / 2 + labelPadding / 2 : -bbox.height / 2 - labelPadding / 2})`);
		updateNodeBounds(node, outerShape);
		node.intersect = function(point) {
			var _node$x5, _node$y6, _node$height15;
			log.info("iconSquare intersect", node, point);
			if (!node.label) return intersect_default.rect(node, point);
			const dx = (_node$x5 = node.x) !== null && _node$x5 !== void 0 ? _node$x5 : 0;
			const dy = (_node$y6 = node.y) !== null && _node$y6 !== void 0 ? _node$y6 : 0;
			const nodeHeight = (_node$height15 = node.height) !== null && _node$height15 !== void 0 ? _node$height15 : 0;
			let points = [];
			if (topLabel) points = [
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx + imageWidth / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx + imageWidth / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - imageWidth / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - imageWidth / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				},
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2 + bbox.height + labelPadding
				}
			];
			else points = [
				{
					x: dx - imageWidth / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + imageWidth / 2,
					y: dy - nodeHeight / 2
				},
				{
					x: dx + imageWidth / 2,
					y: dy - nodeHeight / 2 + imageHeight
				},
				{
					x: dx + bbox.width / 2,
					y: dy - nodeHeight / 2 + imageHeight
				},
				{
					x: dx + bbox.width / 2 / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - bbox.width / 2,
					y: dy + nodeHeight / 2
				},
				{
					x: dx - bbox.width / 2,
					y: dy - nodeHeight / 2 + imageHeight
				},
				{
					x: dx - imageWidth / 2,
					y: dy - nodeHeight / 2 + imageHeight
				}
			];
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _imageSquare.apply(this, arguments);
}
__name(imageSquare, "imageSquare");
function inv_trapezoid(_x69, _x70) {
	return _inv_trapezoid.apply(this, arguments);
}
function _inv_trapezoid() {
	_inv_trapezoid = _asyncToGenerator(function* (parent, node) {
		var _node$padding29, _node$width15, _node$height16;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding29 = node.padding) !== null && _node$padding29 !== void 0 ? _node$padding29 : 0;
		const labelPaddingY = nodePadding;
		const labelPaddingX = node.look === "neo" ? nodePadding * 2 : nodePadding;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = Math.max(bbox.width + (labelPaddingX !== null && labelPaddingX !== void 0 ? labelPaddingX : 0) * 2, (_node$width15 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width15 !== void 0 ? _node$width15 : 0);
		const h = Math.max(bbox.height + (labelPaddingY !== null && labelPaddingY !== void 0 ? labelPaddingY : 0) * 2, (_node$height16 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height16 !== void 0 ? _node$height16 : 0);
		const points = [
			{
				x: 0,
				y: 0
			},
			{
				x: w,
				y: 0
			},
			{
				x: w + 3 * h / 6,
				y: -h
			},
			{
				x: -3 * h / 6,
				y: -h
			}
		];
		let polygon;
		const { cssStyles } = node;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {});
			const pathData = createPathFromPoints(points);
			const roughNode = rc.path(pathData, options);
			polygon = shapeSvg.insert(() => roughNode, ":first-child").attr("transform", `translate(${-w / 2}, ${h / 2})`);
			if (cssStyles) polygon.attr("style", cssStyles);
		} else polygon = insertPolygonShape(shapeSvg, w, h, points);
		if (nodeStyles) polygon.attr("style", nodeStyles);
		node.width = w;
		node.height = h;
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _inv_trapezoid.apply(this, arguments);
}
__name(inv_trapezoid, "inv_trapezoid");
function labelRect(_x71, _x72) {
	return _labelRect.apply(this, arguments);
}
function _labelRect() {
	_labelRect = _asyncToGenerator(function* (parent, node) {
		var _bbox$left12, _bbox$top7;
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, "label");
		const rect2 = shapeSvg.insert("rect", ":first-child");
		rect2.attr("width", .1).attr("height", .1);
		shapeSvg.attr("class", "label edgeLabel");
		label.attr("transform", `translate(${-(bbox.width / 2) - (bbox.x - ((_bbox$left12 = bbox.left) !== null && _bbox$left12 !== void 0 ? _bbox$left12 : 0))}, ${-(bbox.height / 2) - (bbox.y - ((_bbox$top7 = bbox.top) !== null && _bbox$top7 !== void 0 ? _bbox$top7 : 0))})`);
		updateNodeBounds(node, rect2);
		node.intersect = function(point) {
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _labelRect.apply(this, arguments);
}
__name(labelRect, "labelRect");
function lean_left(_x73, _x74) {
	return _lean_left.apply(this, arguments);
}
function _lean_left() {
	_lean_left = _asyncToGenerator(function* (parent, node) {
		var _node$padding30, _node$height17, _node$width16;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding30 = node.padding) !== null && _node$padding30 !== void 0 ? _node$padding30 : 0;
		const labelPaddingY = nodePadding;
		const labelPaddingX = node.look === "neo" ? nodePadding * 2 : nodePadding;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const h = ((_node$height17 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height17 !== void 0 ? _node$height17 : bbox.height) + labelPaddingY;
		const w = ((_node$width16 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width16 !== void 0 ? _node$width16 : bbox.width) + labelPaddingX;
		const points = [
			{
				x: 0,
				y: 0
			},
			{
				x: w + 3 * h / 6,
				y: 0
			},
			{
				x: w,
				y: -h
			},
			{
				x: -(3 * h) / 6,
				y: -h
			}
		];
		let polygon;
		const { cssStyles } = node;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {});
			const pathData = createPathFromPoints(points);
			const roughNode = rc.path(pathData, options);
			polygon = shapeSvg.insert(() => roughNode, ":first-child").attr("transform", `translate(${-w / 2}, ${h / 2})`);
			if (cssStyles) polygon.attr("style", cssStyles);
		} else polygon = insertPolygonShape(shapeSvg, w, h, points);
		if (nodeStyles) polygon.attr("style", nodeStyles);
		node.width = w;
		node.height = h;
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _lean_left.apply(this, arguments);
}
__name(lean_left, "lean_left");
function lean_right(_x75, _x76) {
	return _lean_right.apply(this, arguments);
}
function _lean_right() {
	_lean_right = _asyncToGenerator(function* (parent, node) {
		var _node$padding31, _node$height18, _node$width17;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding31 = node.padding) !== null && _node$padding31 !== void 0 ? _node$padding31 : 0;
		const labelPaddingY = nodePadding;
		const labelPaddingX = node.look === "neo" ? nodePadding * 2 : nodePadding;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const h = ((_node$height18 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height18 !== void 0 ? _node$height18 : bbox.height) + labelPaddingY;
		const w = ((_node$width17 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width17 !== void 0 ? _node$width17 : bbox.width) + labelPaddingX;
		const points = [
			{
				x: -3 * h / 6,
				y: 0
			},
			{
				x: w,
				y: 0
			},
			{
				x: w + 3 * h / 6,
				y: -h
			},
			{
				x: 0,
				y: -h
			}
		];
		let polygon;
		const { cssStyles } = node;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {});
			const pathData = createPathFromPoints(points);
			const roughNode = rc.path(pathData, options);
			polygon = shapeSvg.insert(() => roughNode, ":first-child").attr("transform", `translate(${-w / 2}, ${h / 2})`);
			if (cssStyles) polygon.attr("style", cssStyles);
		} else polygon = insertPolygonShape(shapeSvg, w, h, points);
		if (nodeStyles) polygon.attr("style", nodeStyles);
		node.width = w;
		node.height = h;
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _lean_right.apply(this, arguments);
}
__name(lean_right, "lean_right");
function lightningBolt(parent, node) {
	var _node$domId5, _node$width18, _node$height19;
	const { labelStyles, nodeStyles } = styles2String(node);
	node.label = "";
	node.labelStyle = labelStyles;
	const shapeSvg = parent.insert("g").attr("class", getNodeClasses(node)).attr("id", (_node$domId5 = node.domId) !== null && _node$domId5 !== void 0 ? _node$domId5 : node.id);
	const { cssStyles } = node;
	const width = Math.max(35, (_node$width18 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width18 !== void 0 ? _node$width18 : 0);
	const height = Math.max(35, (_node$height19 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height19 !== void 0 ? _node$height19 : 0);
	const gap = 7;
	const points = [
		{
			x: width,
			y: 0
		},
		{
			x: 0,
			y: height + gap / 2
		},
		{
			x: width - 2 * gap,
			y: height + gap / 2
		},
		{
			x: 0,
			y: 2 * height
		},
		{
			x: width,
			y: height - gap / 2
		},
		{
			x: 2 * gap,
			y: height - gap / 2
		}
	];
	const rc = at.svg(shapeSvg);
	const options = userNodeOverrides(node, {});
	if (node.look !== "handDrawn") {
		options.roughness = 0;
		options.fillStyle = "solid";
	}
	const linePath = createPathFromPoints(points);
	const lineNode = rc.path(linePath, options);
	const lightningBolt2 = shapeSvg.insert(() => lineNode, ":first-child");
	lightningBolt2.attr("class", "outer-path");
	if (cssStyles && node.look !== "handDrawn") lightningBolt2.selectAll("path").attr("style", cssStyles);
	if (nodeStyles && node.look !== "handDrawn") lightningBolt2.selectAll("path").attr("style", nodeStyles);
	lightningBolt2.attr("transform", `translate(-${width / 2},${-height})`);
	updateNodeBounds(node, lightningBolt2);
	node.intersect = function(point) {
		log.info("lightningBolt intersect", node, point);
		return intersect_default.polygon(node, points, point);
	};
	return shapeSvg;
}
__name(lightningBolt, "lightningBolt");
var createCylinderPathD2 = /* @__PURE__ */ __name((x, y, width, height, rx, ry, outerOffset) => {
	return [
		`M${x},${y + ry}`,
		`a${rx},${ry} 0,0,0 ${width},0`,
		`a${rx},${ry} 0,0,0 ${-width},0`,
		`l0,${height}`,
		`a${rx},${ry} 0,0,0 ${width},0`,
		`l0,${-height}`,
		`M${x},${y + ry + outerOffset}`,
		`a${rx},${ry} 0,0,0 ${width},0`
	].join(" ");
}, "createCylinderPathD");
var createOuterCylinderPathD2 = /* @__PURE__ */ __name((x, y, width, height, rx, ry, outerOffset) => {
	return [
		`M${x},${y + ry}`,
		`M${x + width},${y + ry}`,
		`a${rx},${ry} 0,0,0 ${-width},0`,
		`l0,${height}`,
		`a${rx},${ry} 0,0,0 ${width},0`,
		`l0,${-height}`,
		`M${x},${y + ry + outerOffset}`,
		`a${rx},${ry} 0,0,0 ${width},0`
	].join(" ");
}, "createOuterCylinderPathD");
var createInnerCylinderPathD2 = /* @__PURE__ */ __name((x, y, width, height, rx, ry) => {
	return [`M${x - width / 2},${-height / 2}`, `a${rx},${ry} 0,0,0 ${width},0`].join(" ");
}, "createInnerCylinderPathD");
var MIN_HEIGHT3 = 10;
var MIN_WIDTH3 = 10;
function linedCylinder(_x77, _x78) {
	return _linedCylinder.apply(this, arguments);
}
function _linedCylinder() {
	_linedCylinder = _asyncToGenerator(function* (parent, node) {
		var _node$padding32, _bbox$left13, _bbox$top8;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding32 = node.padding) !== null && _node$padding32 !== void 0 ? _node$padding32 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 24 : nodePadding;
		if (node.width || node.height) {
			var _node$width19, _node$width20, _node$height20;
			const originalWidth = (_node$width19 = node.width) !== null && _node$width19 !== void 0 ? _node$width19 : 0;
			node.width = ((_node$width20 = node.width) !== null && _node$width20 !== void 0 ? _node$width20 : 0) - labelPaddingX;
			if (node.width < MIN_WIDTH3) node.width = MIN_WIDTH3;
			const ry2 = originalWidth / 2 / (2.5 + originalWidth / 50);
			node.height = ((_node$height20 = node.height) !== null && _node$height20 !== void 0 ? _node$height20 : 0) - labelPaddingY - ry2 * 3;
			if (node.height < MIN_HEIGHT3) node.height = MIN_HEIGHT3;
		}
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + labelPaddingX * 2;
		const rx = w / 2;
		const ry = rx / (2.5 + w / 50);
		const h = ((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : bbox.height) + ry + labelPaddingY * 2;
		const outerOffset = h * .1;
		let cylinder2;
		const { cssStyles } = node;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const outerPathData = createOuterCylinderPathD2(0, 0, w, h, rx, ry, outerOffset);
			const innerPathData = createInnerCylinderPathD2(0, ry, w, h, rx, ry);
			const options = userNodeOverrides(node, {});
			const outerNode = rc.path(outerPathData, options);
			const innerLine = rc.path(innerPathData, options);
			shapeSvg.insert(() => innerLine, ":first-child").attr("class", "line");
			cylinder2 = shapeSvg.insert(() => outerNode, ":first-child");
			cylinder2.attr("class", "basic label-container");
			if (cssStyles) cylinder2.attr("style", cssStyles);
		} else {
			const pathData = createCylinderPathD2(0, 0, w, h, rx, ry, outerOffset);
			cylinder2 = shapeSvg.insert("path", ":first-child").attr("d", pathData).attr("class", "basic label-container outer-path").attr("style", handleUndefinedAttr(cssStyles)).attr("style", nodeStyles);
		}
		cylinder2.attr("label-offset-y", ry);
		cylinder2.attr("transform", `translate(${-w / 2}, ${-(h / 2 + ry)})`);
		updateNodeBounds(node, cylinder2);
		label.attr("transform", `translate(${-(bbox.width / 2) - (bbox.x - ((_bbox$left13 = bbox.left) !== null && _bbox$left13 !== void 0 ? _bbox$left13 : 0))}, ${-(bbox.height / 2) + ry - (bbox.y - ((_bbox$top8 = bbox.top) !== null && _bbox$top8 !== void 0 ? _bbox$top8 : 0))})`);
		node.intersect = function(point) {
			var _node$x6, _node$width21, _node$width22, _node$y7, _node$height21;
			const pos = intersect_default.rect(node, point);
			const x = pos.x - ((_node$x6 = node.x) !== null && _node$x6 !== void 0 ? _node$x6 : 0);
			if (rx != 0 && (Math.abs(x) < ((_node$width21 = node.width) !== null && _node$width21 !== void 0 ? _node$width21 : 0) / 2 || Math.abs(x) == ((_node$width22 = node.width) !== null && _node$width22 !== void 0 ? _node$width22 : 0) / 2 && Math.abs(pos.y - ((_node$y7 = node.y) !== null && _node$y7 !== void 0 ? _node$y7 : 0)) > ((_node$height21 = node.height) !== null && _node$height21 !== void 0 ? _node$height21 : 0) / 2 - ry)) {
				var _node$y8;
				let y = ry * ry * (1 - x * x / (rx * rx));
				if (y > 0) y = Math.sqrt(y);
				y = ry - y;
				if (point.y - ((_node$y8 = node.y) !== null && _node$y8 !== void 0 ? _node$y8 : 0) > 0) y = -y;
				pos.y += y;
			}
			return pos;
		};
		return shapeSvg;
	});
	return _linedCylinder.apply(this, arguments);
}
__name(linedCylinder, "linedCylinder");
function linedWaveEdgedRect(_x79, _x80) {
	return _linedWaveEdgedRect.apply(this, arguments);
}
function _linedWaveEdgedRect() {
	_linedWaveEdgedRect = _asyncToGenerator(function* (parent, node) {
		var _node$padding33, _node$padding34, _bbox$left14, _node$padding35, _bbox$top9;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding33 = node.padding) !== null && _node$padding33 !== void 0 ? _node$padding33 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		if (node.width || node.height) {
			var _node$height22;
			const originalWidth = node.width;
			node.width = (originalWidth !== null && originalWidth !== void 0 ? originalWidth : 0) * 10 / 11 - labelPaddingX * 2;
			if (node.width < 10) node.width = 10;
			node.height = ((_node$height22 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height22 !== void 0 ? _node$height22 : 0) - labelPaddingY * 2;
			if (node.height < 10) node.height = 10;
		}
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + (labelPaddingX !== null && labelPaddingX !== void 0 ? labelPaddingX : 0) * 2;
		const h = ((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : bbox.height) + (labelPaddingY !== null && labelPaddingY !== void 0 ? labelPaddingY : 0) * 2;
		const waveAmplitude = node.look === "neo" ? h / 4 : h / 8;
		const finalH = h + waveAmplitude;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const points = [
			{
				x: -w / 2 - w / 2 * .1,
				y: -finalH / 2
			},
			{
				x: -w / 2 - w / 2 * .1,
				y: finalH / 2
			},
			...generateFullSineWavePoints(-w / 2 - w / 2 * .1, finalH / 2, w / 2 + w / 2 * .1, finalH / 2, waveAmplitude, .8),
			{
				x: w / 2 + w / 2 * .1,
				y: -finalH / 2
			},
			{
				x: -w / 2 - w / 2 * .1,
				y: -finalH / 2
			},
			{
				x: -w / 2,
				y: -finalH / 2
			},
			{
				x: -w / 2,
				y: finalH / 2 * 1.1
			},
			{
				x: -w / 2,
				y: -finalH / 2
			}
		];
		const poly = rc.polygon(points.map((p) => [p.x, p.y]), options);
		const waveEdgeRect = shapeSvg.insert(() => poly, ":first-child");
		waveEdgeRect.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") waveEdgeRect.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") waveEdgeRect.selectAll("path").attr("style", nodeStyles);
		waveEdgeRect.attr("transform", `translate(0,${-waveAmplitude / 2})`);
		label.attr("transform", `translate(${-w / 2 + ((_node$padding34 = node.padding) !== null && _node$padding34 !== void 0 ? _node$padding34 : 0) + w / 2 * .1 / 2 - (bbox.x - ((_bbox$left14 = bbox.left) !== null && _bbox$left14 !== void 0 ? _bbox$left14 : 0))},${-h / 2 + ((_node$padding35 = node.padding) !== null && _node$padding35 !== void 0 ? _node$padding35 : 0) - waveAmplitude / 2 - (bbox.y - ((_bbox$top9 = bbox.top) !== null && _bbox$top9 !== void 0 ? _bbox$top9 : 0))})`);
		updateNodeBounds(node, waveEdgeRect);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _linedWaveEdgedRect.apply(this, arguments);
}
__name(linedWaveEdgedRect, "linedWaveEdgedRect");
function multiRect(_x81, _x82) {
	return _multiRect.apply(this, arguments);
}
function _multiRect() {
	_multiRect = _asyncToGenerator(function* (parent, node) {
		var _node$padding36, _bbox$left15, _bbox$top10;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding36 = node.padding) !== null && _node$padding36 !== void 0 ? _node$padding36 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		const rectOffset2 = node.look === "neo" ? 10 : 5;
		if (node.width || node.height) {
			var _node$width23, _node$height23;
			node.width = Math.max(((_node$width23 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width23 !== void 0 ? _node$width23 : 0) - labelPaddingX * 2 - 2 * rectOffset2, 10);
			node.height = Math.max(((_node$height23 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height23 !== void 0 ? _node$height23 : 0) - labelPaddingY * 2 - 2 * rectOffset2, 10);
		}
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const totalWidth = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + labelPaddingX * 2 + 2 * rectOffset2;
		const totalHeight = ((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : bbox.height) + labelPaddingY * 2 + 2 * rectOffset2;
		const w = totalWidth - 2 * rectOffset2;
		const h = totalHeight - 2 * rectOffset2;
		const x = -w / 2;
		const y = -h / 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		const outerPathPoints = [
			{
				x: x - rectOffset2,
				y: y + rectOffset2
			},
			{
				x: x - rectOffset2,
				y: y + h + rectOffset2
			},
			{
				x: x + w - rectOffset2,
				y: y + h + rectOffset2
			},
			{
				x: x + w - rectOffset2,
				y: y + h
			},
			{
				x: x + w,
				y: y + h
			},
			{
				x: x + w,
				y: y + h - rectOffset2
			},
			{
				x: x + w + rectOffset2,
				y: y + h - rectOffset2
			},
			{
				x: x + w + rectOffset2,
				y: y - rectOffset2
			},
			{
				x: x + rectOffset2,
				y: y - rectOffset2
			},
			{
				x: x + rectOffset2,
				y
			},
			{
				x,
				y
			},
			{
				x,
				y: y + rectOffset2
			}
		];
		const innerPathPoints = [
			{
				x,
				y: y + rectOffset2
			},
			{
				x: x + w - rectOffset2,
				y: y + rectOffset2
			},
			{
				x: x + w - rectOffset2,
				y: y + h
			},
			{
				x: x + w,
				y: y + h
			},
			{
				x: x + w,
				y
			},
			{
				x,
				y
			}
		];
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const outerPath = createPathFromPoints(outerPathPoints);
		let outerNode = rc.path(outerPath, options);
		const innerPath = createPathFromPoints(innerPathPoints);
		let innerNode = rc.path(innerPath, options);
		if (node.look !== "handDrawn") {
			outerNode = mergePaths(outerNode);
			innerNode = mergePaths(innerNode);
		}
		const multiRect2 = shapeSvg.insert("g", ":first-child");
		multiRect2.insert(() => outerNode);
		multiRect2.insert(() => innerNode);
		multiRect2.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") multiRect2.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") multiRect2.selectAll("path").attr("style", nodeStyles);
		label.attr("transform", `translate(${-(bbox.width / 2) - rectOffset2 - (bbox.x - ((_bbox$left15 = bbox.left) !== null && _bbox$left15 !== void 0 ? _bbox$left15 : 0))}, ${-(bbox.height / 2) + rectOffset2 - (bbox.y - ((_bbox$top10 = bbox.top) !== null && _bbox$top10 !== void 0 ? _bbox$top10 : 0))})`);
		updateNodeBounds(node, multiRect2);
		node.intersect = function(point) {
			return intersect_default.polygon(node, outerPathPoints, point);
		};
		return shapeSvg;
	});
	return _multiRect.apply(this, arguments);
}
__name(multiRect, "multiRect");
function multiWaveEdgedRectangle(_x83, _x84) {
	return _multiWaveEdgedRectangle.apply(this, arguments);
}
function _multiWaveEdgedRectangle() {
	_multiWaveEdgedRectangle = _asyncToGenerator(function* (parent, node) {
		var _node$padding37, _node$width25, _node$height25, _bbox$left16, _bbox$top11;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const nodePadding = (_node$padding37 = node.padding) !== null && _node$padding37 !== void 0 ? _node$padding37 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		let adjustFinalHeight = true;
		if (node.width || node.height) {
			var _node$width24, _node$height24;
			adjustFinalHeight = false;
			node.width = ((_node$width24 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width24 !== void 0 ? _node$width24 : 0) - labelPaddingX * 2;
			node.height = ((_node$height24 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height24 !== void 0 ? _node$height24 : 0) - labelPaddingY * 3;
		}
		const w = Math.max(bbox.width, (_node$width25 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width25 !== void 0 ? _node$width25 : 0) + labelPaddingX * 2;
		const h = Math.max(bbox.height, (_node$height25 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height25 !== void 0 ? _node$height25 : 0) + labelPaddingY * 3;
		const waveAmplitude = node.look === "neo" ? h / 4 : h / 8;
		const finalH = h + (adjustFinalHeight ? waveAmplitude / 2 : -waveAmplitude / 2);
		const x = -w / 2;
		const y = -finalH / 2;
		const rectOffset2 = 10;
		const { cssStyles } = node;
		const wavePoints = generateFullSineWavePoints(x - rectOffset2, y + finalH + rectOffset2, x + w - rectOffset2, y + finalH + rectOffset2, waveAmplitude, .8);
		const lastWavePoint = wavePoints === null || wavePoints === void 0 ? void 0 : wavePoints[wavePoints.length - 1];
		const outerPathPoints = [
			{
				x: x - rectOffset2,
				y: y + rectOffset2
			},
			{
				x: x - rectOffset2,
				y: y + finalH + rectOffset2
			},
			...wavePoints,
			{
				x: x + w - rectOffset2,
				y: lastWavePoint.y - rectOffset2
			},
			{
				x: x + w,
				y: lastWavePoint.y - rectOffset2
			},
			{
				x: x + w,
				y: lastWavePoint.y - 2 * rectOffset2
			},
			{
				x: x + w + rectOffset2,
				y: lastWavePoint.y - 2 * rectOffset2
			},
			{
				x: x + w + rectOffset2,
				y: y - rectOffset2
			},
			{
				x: x + rectOffset2,
				y: y - rectOffset2
			},
			{
				x: x + rectOffset2,
				y
			},
			{
				x,
				y
			},
			{
				x,
				y: y + rectOffset2
			}
		];
		const innerPathPoints = [
			{
				x,
				y: y + rectOffset2
			},
			{
				x: x + w - rectOffset2,
				y: y + rectOffset2
			},
			{
				x: x + w - rectOffset2,
				y: lastWavePoint.y - rectOffset2
			},
			{
				x: x + w,
				y: lastWavePoint.y - rectOffset2
			},
			{
				x: x + w,
				y
			},
			{
				x,
				y
			}
		];
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const outerPath = createPathFromPoints(outerPathPoints);
		const outerNode = rc.path(outerPath, options);
		const innerPath = createPathFromPoints(innerPathPoints);
		const innerNode = rc.path(innerPath, options);
		const shape = shapeSvg.insert(() => outerNode, ":first-child");
		shape.insert(() => innerNode);
		shape.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") shape.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") shape.selectAll("path").attr("style", nodeStyles);
		shape.attr("transform", `translate(0,${-waveAmplitude / 2})`);
		label.attr("transform", `translate(${-(bbox.width / 2) - rectOffset2 - (bbox.x - ((_bbox$left16 = bbox.left) !== null && _bbox$left16 !== void 0 ? _bbox$left16 : 0))}, ${-(bbox.height / 2) + rectOffset2 - waveAmplitude / 2 - (bbox.y - ((_bbox$top11 = bbox.top) !== null && _bbox$top11 !== void 0 ? _bbox$top11 : 0))})`);
		updateNodeBounds(node, shape);
		node.intersect = function(point) {
			return intersect_default.polygon(node, outerPathPoints, point);
		};
		return shapeSvg;
	});
	return _multiWaveEdgedRectangle.apply(this, arguments);
}
__name(multiWaveEdgedRectangle, "multiWaveEdgedRectangle");
function note(_x85, _x86, _x87) {
	return _note.apply(this, arguments);
}
function _note() {
	_note = _asyncToGenerator(function* (parent, node, { config: { themeVariables } }) {
		var _node$padding38, _node$width26, _node$padding39, _node$height26, _bbox$left17, _bbox$top12;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		if (!(node.useHtmlLabels || getEffectiveHtmlLabels(getConfig()))) node.centerLabel = true;
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const totalWidth = Math.max(bbox.width + ((_node$padding38 = node.padding) !== null && _node$padding38 !== void 0 ? _node$padding38 : 0) * 2, (_node$width26 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width26 !== void 0 ? _node$width26 : 0);
		const totalHeight = Math.max(bbox.height + ((_node$padding39 = node.padding) !== null && _node$padding39 !== void 0 ? _node$padding39 : 0) * 2, (_node$height26 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height26 !== void 0 ? _node$height26 : 0);
		const x = -totalWidth / 2;
		const y = -totalHeight / 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {
			fill: themeVariables.noteBkgColor,
			stroke: themeVariables.noteBorderColor
		});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const noteShapeNode = rc.rectangle(x, y, totalWidth, totalHeight, options);
		const rect2 = shapeSvg.insert(() => noteShapeNode, ":first-child");
		rect2.attr("class", "basic label-container outer-path");
		label.attr("class", "label noteLabel");
		if (cssStyles && node.look !== "handDrawn") rect2.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") rect2.selectAll("path").attr("style", nodeStyles);
		label.attr("transform", `translate(${-bbox.width / 2 - (bbox.x - ((_bbox$left17 = bbox.left) !== null && _bbox$left17 !== void 0 ? _bbox$left17 : 0))}, ${-(bbox.height / 2) - (bbox.y - ((_bbox$top12 = bbox.top) !== null && _bbox$top12 !== void 0 ? _bbox$top12 : 0))})`);
		updateNodeBounds(node, rect2);
		node.intersect = function(point) {
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _note.apply(this, arguments);
}
__name(note, "note");
var createDecisionBoxPathD = /* @__PURE__ */ __name((x, y, size) => {
	return [
		`M${x + size / 2},${y}`,
		`L${x + size},${y - size / 2}`,
		`L${x + size / 2},${y - size}`,
		`L${x},${y - size / 2}`,
		"Z"
	].join(" ");
}, "createDecisionBoxPathD");
function question(_x88, _x89) {
	return _question.apply(this, arguments);
}
function _question() {
	_question = _asyncToGenerator(function* (parent, node) {
		var _node$padding40, _node$padding41;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const s = bbox.width + ((_node$padding40 = node.padding) !== null && _node$padding40 !== void 0 ? _node$padding40 : 0) + (bbox.height + ((_node$padding41 = node.padding) !== null && _node$padding41 !== void 0 ? _node$padding41 : 0));
		const adjustment = .5;
		const points = [
			{
				x: s / 2,
				y: 0
			},
			{
				x: s,
				y: -s / 2
			},
			{
				x: s / 2,
				y: -s
			},
			{
				x: 0,
				y: -s / 2
			}
		];
		let polygon;
		const { cssStyles } = node;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {});
			const pathData = createDecisionBoxPathD(0, 0, s);
			const roughNode = rc.path(pathData, options);
			polygon = shapeSvg.insert(() => roughNode, ":first-child").attr("transform", `translate(${-s / 2 + adjustment}, ${s / 2})`);
			if (cssStyles) polygon.attr("style", cssStyles);
		} else {
			polygon = insertPolygonShape(shapeSvg, s, s, points);
			polygon.attr("transform", `translate(${-s / 2 + adjustment}, ${s / 2})`);
		}
		if (nodeStyles) polygon.attr("style", nodeStyles);
		updateNodeBounds(node, polygon);
		node.calcIntersect = function(bounds, point) {
			const s2 = bounds.width;
			const points2 = [
				{
					x: s2 / 2,
					y: 0
				},
				{
					x: s2,
					y: -s2 / 2
				},
				{
					x: s2 / 2,
					y: -s2
				},
				{
					x: 0,
					y: -s2 / 2
				}
			];
			const res = intersect_default.polygon(bounds, points2, point);
			return {
				x: res.x - .5,
				y: res.y - .5
			};
		};
		node.intersect = function(point) {
			return this.calcIntersect(node, point);
		};
		return shapeSvg;
	});
	return _question.apply(this, arguments);
}
__name(question, "question");
function rect_left_inv_arrow(_x90, _x91) {
	return _rect_left_inv_arrow.apply(this, arguments);
}
function _rect_left_inv_arrow() {
	_rect_left_inv_arrow = _asyncToGenerator(function* (parent, node) {
		var _node$padding42, _node$width27, _node$height27, _bbox$left18, _bbox$top13;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding42 = node.padding) !== null && _node$padding42 !== void 0 ? _node$padding42 : 0;
		const labelPaddingX = node.look === "neo" ? 21 : nodePadding !== null && nodePadding !== void 0 ? nodePadding : 0;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding !== null && nodePadding !== void 0 ? nodePadding : 0;
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = ((_node$width27 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width27 !== void 0 ? _node$width27 : bbox.width) + (node.look === "neo" ? labelPaddingX * 2 : labelPaddingX);
		const h = ((_node$height27 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height27 !== void 0 ? _node$height27 : bbox.height) + (node.look === "neo" ? labelPaddingY * 2 : labelPaddingY);
		const x = -w / 2;
		const y = -h / 2;
		const notch = y / 2;
		const points = [
			{
				x: x + notch,
				y
			},
			{
				x,
				y: 0
			},
			{
				x: x + notch,
				y: -y
			},
			{
				x: -x,
				y: -y
			},
			{
				x: -x,
				y
			}
		];
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const pathData = createPathFromPoints(points);
		const roughNode = rc.path(pathData, options);
		const polygon = shapeSvg.insert(() => roughNode, ":first-child");
		polygon.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") polygon.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") polygon.selectAll("path").attr("style", nodeStyles);
		polygon.attr("transform", `translate(${-notch / 2},0)`);
		label.attr("transform", `translate(${-notch / 2 - bbox.width / 2 - (bbox.x - ((_bbox$left18 = bbox.left) !== null && _bbox$left18 !== void 0 ? _bbox$left18 : 0))}, ${-(bbox.height / 2) - (bbox.y - ((_bbox$top13 = bbox.top) !== null && _bbox$top13 !== void 0 ? _bbox$top13 : 0))})`);
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _rect_left_inv_arrow.apply(this, arguments);
}
__name(rect_left_inv_arrow, "rect_left_inv_arrow");
function rectWithTitle(_x92, _x93) {
	return _rectWithTitle.apply(this, arguments);
}
function _rectWithTitle() {
	_rectWithTitle = _asyncToGenerator(function* (parent, node) {
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		let classes;
		if (!node.cssClasses) classes = "node default";
		else classes = "node " + node.cssClasses;
		const shapeSvg = parent.insert("g").attr("class", classes).attr("id", node.domId || node.id);
		const g = shapeSvg.insert("g");
		const label = shapeSvg.insert("g").attr("class", "label").attr("style", nodeStyles);
		const description = node.description;
		const title = node.label;
		const text2 = yield createLabel_default(label, title, node.labelStyle, true, true);
		let bbox = {
			width: 0,
			height: 0
		};
		if (getEffectiveHtmlLabels(getConfig2())) {
			const div2 = text2.children[0];
			const dv2 = select_default(text2);
			bbox = div2.getBoundingClientRect();
			dv2.attr("width", bbox.width);
			dv2.attr("height", bbox.height);
		}
		log.info("Text 2", description);
		const textRows = description || [];
		const titleBox = text2.getBBox();
		const descr = yield createLabel_default(label, Array.isArray(textRows) ? textRows.join("<br/>") : textRows, node.labelStyle, true, true);
		const div = descr.children[0];
		const dv = select_default(descr);
		bbox = div.getBoundingClientRect();
		dv.attr("width", bbox.width);
		dv.attr("height", bbox.height);
		const halfPadding = (node.padding || 0) / 2;
		select_default(descr).attr("transform", "translate( " + (bbox.width > titleBox.width ? 0 : (titleBox.width - bbox.width) / 2) + ", " + (titleBox.height + halfPadding + 5) + ")");
		select_default(text2).attr("transform", "translate( " + (bbox.width < titleBox.width ? 0 : -(titleBox.width - bbox.width) / 2) + ", 0)");
		bbox = label.node().getBBox();
		label.attr("transform", "translate(" + -bbox.width / 2 + ", " + (-bbox.height / 2 - halfPadding + 3) + ")");
		const totalWidth = bbox.width + (node.padding || 0);
		const totalHeight = bbox.height + (node.padding || 0);
		const x = -bbox.width / 2 - halfPadding;
		const y = -bbox.height / 2 - halfPadding;
		let rect2;
		let innerLine;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {});
			const roughNode = rc.path(createRoundedRectPathD(x, y, totalWidth, totalHeight, node.rx || 0), options);
			const roughLine = rc.line(-bbox.width / 2 - halfPadding, -bbox.height / 2 - halfPadding + titleBox.height + halfPadding, bbox.width / 2 + halfPadding, -bbox.height / 2 - halfPadding + titleBox.height + halfPadding, options);
			innerLine = shapeSvg.insert(() => {
				log.debug("Rough node insert CXC", roughNode);
				return roughLine;
			}, ":first-child");
			rect2 = shapeSvg.insert(() => {
				log.debug("Rough node insert CXC", roughNode);
				return roughNode;
			}, ":first-child");
		} else {
			rect2 = g.insert("rect", ":first-child");
			innerLine = g.insert("line");
			rect2.attr("class", "outer title-state").attr("style", nodeStyles).attr("x", -bbox.width / 2 - halfPadding).attr("y", -bbox.height / 2 - halfPadding).attr("width", bbox.width + (node.padding || 0)).attr("height", bbox.height + (node.padding || 0));
			innerLine.attr("class", "divider").attr("x1", -bbox.width / 2 - halfPadding).attr("x2", bbox.width / 2 + halfPadding).attr("y1", -bbox.height / 2 - halfPadding + titleBox.height + halfPadding).attr("y2", -bbox.height / 2 - halfPadding + titleBox.height + halfPadding);
		}
		updateNodeBounds(node, rect2);
		node.intersect = function(point) {
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _rectWithTitle.apply(this, arguments);
}
__name(rectWithTitle, "rectWithTitle");
function roundedRect(_x94, _x95, _x96) {
	return _roundedRect.apply(this, arguments);
}
function _roundedRect() {
	_roundedRect = _asyncToGenerator(function* (parent, node, { config: { themeVariables } }) {
		var _themeVariables$radiu, _node$padding43, _node$padding44;
		const radius = (_themeVariables$radiu = themeVariables === null || themeVariables === void 0 ? void 0 : themeVariables.radius) !== null && _themeVariables$radiu !== void 0 ? _themeVariables$radiu : 5;
		return drawRect(parent, node, {
			rx: radius,
			ry: radius,
			classes: "",
			labelPaddingX: ((_node$padding43 = node === null || node === void 0 ? void 0 : node.padding) !== null && _node$padding43 !== void 0 ? _node$padding43 : 0) * 1,
			labelPaddingY: ((_node$padding44 = node === null || node === void 0 ? void 0 : node.padding) !== null && _node$padding44 !== void 0 ? _node$padding44 : 0) * 1
		});
	});
	return _roundedRect.apply(this, arguments);
}
__name(roundedRect, "roundedRect");
var FRAME_WIDTH = 8;
function shadedProcess(_x97, _x98) {
	return _shadedProcess.apply(this, arguments);
}
function _shadedProcess() {
	_shadedProcess = _asyncToGenerator(function* (parent, node) {
		var _node$padding45, _node$padding46, _node$width28, _node$height28, _bbox$left19, _bbox$top14;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const paddingX = node.look === "neo" ? 16 : (_node$padding45 = node.padding) !== null && _node$padding45 !== void 0 ? _node$padding45 : 0;
		const paddingY = node.look === "neo" ? 12 : (_node$padding46 = node.padding) !== null && _node$padding46 !== void 0 ? _node$padding46 : 0;
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const totalWidth = ((_node$width28 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width28 !== void 0 ? _node$width28 : bbox.width) + paddingX * 2 + (node.look === "neo" ? FRAME_WIDTH : FRAME_WIDTH * 2);
		const totalHeight = ((_node$height28 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height28 !== void 0 ? _node$height28 : bbox.height) + paddingY * 2;
		const w = totalWidth - FRAME_WIDTH;
		const h = totalHeight;
		const x = FRAME_WIDTH - totalWidth / 2;
		const y = -totalHeight / 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const points = [
			{
				x,
				y
			},
			{
				x: x + w,
				y
			},
			{
				x: x + w,
				y: y + h
			},
			{
				x: x - FRAME_WIDTH,
				y: y + h
			},
			{
				x: x - FRAME_WIDTH,
				y
			},
			{
				x,
				y
			},
			{
				x,
				y: y + h
			}
		];
		const roughNode = rc.polygon(points.map((p) => [p.x, p.y]), options);
		const rect2 = shapeSvg.insert(() => roughNode, ":first-child");
		rect2.attr("class", "basic label-container outer-path").attr("style", handleUndefinedAttr(cssStyles));
		if (nodeStyles && node.look !== "handDrawn") rect2.selectAll("path").attr("style", nodeStyles);
		if (cssStyles && node.look !== "handDrawn") rect2.selectAll("path").attr("style", nodeStyles);
		label.attr("transform", `translate(${FRAME_WIDTH / 2 - bbox.width / 2 - (bbox.x - ((_bbox$left19 = bbox.left) !== null && _bbox$left19 !== void 0 ? _bbox$left19 : 0))}, ${-(bbox.height / 2) - (bbox.y - ((_bbox$top14 = bbox.top) !== null && _bbox$top14 !== void 0 ? _bbox$top14 : 0))})`);
		updateNodeBounds(node, rect2);
		node.intersect = function(point) {
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _shadedProcess.apply(this, arguments);
}
__name(shadedProcess, "shadedProcess");
function slopedRect(_x99, _x100) {
	return _slopedRect.apply(this, arguments);
}
function _slopedRect() {
	_slopedRect = _asyncToGenerator(function* (parent, node) {
		var _node$padding47, _node$padding48, _bbox$left20, _node$padding49, _bbox$top15;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding47 = node.padding) !== null && _node$padding47 !== void 0 ? _node$padding47 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		if (node.width || node.height) {
			var _node$width29, _node$height29;
			node.width = Math.max(((_node$width29 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width29 !== void 0 ? _node$width29 : 0) - labelPaddingX * 2, 10);
			node.height = Math.max(((_node$height29 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height29 !== void 0 ? _node$height29 : 0) / 1.5 - labelPaddingY * 2, 10);
		}
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const totalWidth = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + labelPaddingX * 2;
		const totalHeight = (((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : bbox.height) + labelPaddingY * 2) * 1.5;
		const w = totalWidth;
		const h = totalHeight / 1.5;
		const x = -w / 2;
		const y = -h / 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const points = [
			{
				x,
				y
			},
			{
				x,
				y: y + h
			},
			{
				x: x + w,
				y: y + h
			},
			{
				x: x + w,
				y: y - h / 2
			}
		];
		const pathData = createPathFromPoints(points);
		const shapeNode = rc.path(pathData, options);
		const polygon = shapeSvg.insert(() => shapeNode, ":first-child");
		polygon.attr("class", "basic label-container  outer-path");
		if (cssStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", nodeStyles);
		polygon.attr("transform", `translate(0, ${h / 4})`);
		label.attr("transform", `translate(${-w / 2 + ((_node$padding48 = node.padding) !== null && _node$padding48 !== void 0 ? _node$padding48 : 0) - (bbox.x - ((_bbox$left20 = bbox.left) !== null && _bbox$left20 !== void 0 ? _bbox$left20 : 0))}, ${-h / 4 + ((_node$padding49 = node.padding) !== null && _node$padding49 !== void 0 ? _node$padding49 : 0) - (bbox.y - ((_bbox$top15 = bbox.top) !== null && _bbox$top15 !== void 0 ? _bbox$top15 : 0))})`);
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _slopedRect.apply(this, arguments);
}
__name(slopedRect, "slopedRect");
function squareRect2(_x101, _x102) {
	return _squareRect.apply(this, arguments);
}
function _squareRect() {
	_squareRect = _asyncToGenerator(function* (parent, node) {
		var _node$padding50, _node$labelPaddingX;
		const nodePadding = (_node$padding50 = node.padding) !== null && _node$padding50 !== void 0 ? _node$padding50 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding * 2;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		return drawRect(parent, node, {
			rx: 0,
			ry: 0,
			classes: "",
			labelPaddingX: (_node$labelPaddingX = node.labelPaddingX) !== null && _node$labelPaddingX !== void 0 ? _node$labelPaddingX : labelPaddingX,
			labelPaddingY
		});
	});
	return _squareRect.apply(this, arguments);
}
__name(squareRect2, "squareRect");
function stadium(_x103, _x104) {
	return _stadium.apply(this, arguments);
}
function _stadium() {
	_stadium = _asyncToGenerator(function* (parent, node) {
		var _node$padding51;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding51 = node.padding) !== null && _node$padding51 !== void 0 ? _node$padding51 : 0;
		const labelPaddingX = node.look === "neo" ? 20 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const h = bbox.height + (node.look === "neo" ? labelPaddingY * 2 : labelPaddingY);
		const w = bbox.width + h / 4 + (node.look === "neo" ? labelPaddingX * 2 : labelPaddingX);
		const radius = h / 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const points = [
			{
				x: -w / 2 + radius,
				y: -h / 2
			},
			{
				x: w / 2 - radius,
				y: -h / 2
			},
			...generateCirclePoints(-w / 2 + radius, 0, radius, 50, 90, 270),
			{
				x: w / 2 - radius,
				y: h / 2
			},
			...generateCirclePoints(w / 2 - radius, 0, radius, 50, 270, 450)
		];
		const pathData = createPathFromPoints(points);
		const shapeNode = rc.path(pathData, options);
		const polygon = shapeSvg.insert(() => shapeNode, ":first-child");
		polygon.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", nodeStyles);
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _stadium.apply(this, arguments);
}
__name(stadium, "stadium");
function state(_x105, _x106) {
	return _state.apply(this, arguments);
}
function _state() {
	_state = _asyncToGenerator(function* (parent, node) {
		return drawRect(parent, node, {
			rx: node.look === "neo" ? 3 : 5,
			ry: node.look === "neo" ? 3 : 5,
			classes: "flowchart-node"
		});
	});
	return _state.apply(this, arguments);
}
__name(state, "state");
function stateEnd(parent, node, { config: { themeVariables } }) {
	var _node$domId6, _node$width31;
	const { labelStyles, nodeStyles } = styles2String(node);
	node.labelStyle = labelStyles;
	const { cssStyles } = node;
	const { lineColor, stateBorder, nodeBorder, nodeShadow } = themeVariables;
	if (node.width || node.height) {
		var _node$width30, _node$height30;
		if (((_node$width30 = node.width) !== null && _node$width30 !== void 0 ? _node$width30 : 0) < 14) node.width = 14;
		if (((_node$height30 = node.height) !== null && _node$height30 !== void 0 ? _node$height30 : 0) < 14) node.height = 14;
	}
	if (!node.width) node.width = 14;
	if (!node.height) node.height = 14;
	const shapeSvg = parent.insert("g").attr("class", "node default").attr("id", (_node$domId6 = node.domId) !== null && _node$domId6 !== void 0 ? _node$domId6 : node.id);
	const rc = at.svg(shapeSvg);
	const options = userNodeOverrides(node, {});
	if (node.look !== "handDrawn") {
		options.roughness = 0;
		options.fillStyle = "solid";
	}
	const roughNode = rc.circle(0, 0, node.width, _objectSpread2(_objectSpread2({}, options), {}, {
		stroke: lineColor,
		strokeWidth: 2
	}));
	const innerFill = stateBorder !== null && stateBorder !== void 0 ? stateBorder : nodeBorder;
	const innerNodeRadius = ((_node$width31 = node.width) !== null && _node$width31 !== void 0 ? _node$width31 : 0) * 5 / 14;
	const roughInnerNode = rc.circle(0, 0, innerNodeRadius, _objectSpread2(_objectSpread2({}, options), {}, {
		fill: innerFill,
		stroke: innerFill,
		strokeWidth: 2,
		fillStyle: "solid"
	}));
	const circle2 = shapeSvg.insert(() => roughNode, ":first-child");
	circle2.insert(() => roughInnerNode);
	if (node.look !== "handDrawn") circle2.attr("class", "outer-path");
	if (cssStyles) circle2.selectAll("path").attr("style", cssStyles);
	if (nodeStyles) circle2.selectAll("path").attr("style", nodeStyles);
	if (node.width < 25 && nodeShadow && node.look !== "handDrawn") {
		var _parent$node$ownerSVG, _parent$node;
		const svgId = (_parent$node$ownerSVG = (_parent$node = parent.node()) === null || _parent$node === void 0 || (_parent$node = _parent$node.ownerSVGElement) === null || _parent$node === void 0 ? void 0 : _parent$node.id) !== null && _parent$node$ownerSVG !== void 0 ? _parent$node$ownerSVG : "";
		const filterId = svgId ? `${svgId}-drop-shadow-small` : "drop-shadow-small";
		circle2.attr("style", `filter:url(#${filterId})`);
	}
	updateNodeBounds(node, circle2);
	node.intersect = function(point) {
		var _node$width32;
		return intersect_default.circle(node, ((_node$width32 = node.width) !== null && _node$width32 !== void 0 ? _node$width32 : 0) / 2, point);
	};
	return shapeSvg;
}
__name(stateEnd, "stateEnd");
function stateStart(parent, node, { config: { themeVariables } }) {
	const { lineColor, nodeShadow } = themeVariables;
	if (node.width || node.height) {
		var _node$width33, _node$height31;
		if (((_node$width33 = node.width) !== null && _node$width33 !== void 0 ? _node$width33 : 0) < 14) node.width = 14;
		if (((_node$height31 = node.height) !== null && _node$height31 !== void 0 ? _node$height31 : 0) < 14) node.height = 14;
	}
	if (!node.width) node.width = 14;
	if (!node.height) node.height = 14;
	const shapeSvg = parent.insert("g").attr("class", "node default").attr("id", node.domId || node.id);
	let circle2;
	if (node.look === "handDrawn") {
		var _node$width34, _node$width35, _node$height32;
		const roughNode = at.svg(shapeSvg).circle(0, 0, node.width, solidStateFill(lineColor));
		circle2 = shapeSvg.insert(() => roughNode);
		circle2.attr("class", "state-start").attr("r", ((_node$width34 = node.width) !== null && _node$width34 !== void 0 ? _node$width34 : 7) / 2).attr("width", (_node$width35 = node.width) !== null && _node$width35 !== void 0 ? _node$width35 : 14).attr("height", (_node$height32 = node.height) !== null && _node$height32 !== void 0 ? _node$height32 : 14);
	} else {
		var _node$width36, _node$width37, _node$height33;
		circle2 = shapeSvg.insert("circle", ":first-child");
		circle2.attr("class", "state-start").attr("r", ((_node$width36 = node.width) !== null && _node$width36 !== void 0 ? _node$width36 : 7) / 2).attr("width", (_node$width37 = node.width) !== null && _node$width37 !== void 0 ? _node$width37 : 14).attr("height", (_node$height33 = node.height) !== null && _node$height33 !== void 0 ? _node$height33 : 14);
	}
	if (node.width < 25 && nodeShadow && node.look !== "handDrawn") {
		var _parent$node$ownerSVG2, _parent$node2;
		const svgId = (_parent$node$ownerSVG2 = (_parent$node2 = parent.node()) === null || _parent$node2 === void 0 || (_parent$node2 = _parent$node2.ownerSVGElement) === null || _parent$node2 === void 0 ? void 0 : _parent$node2.id) !== null && _parent$node$ownerSVG2 !== void 0 ? _parent$node$ownerSVG2 : "";
		const filterId = svgId ? `${svgId}-drop-shadow-small` : "drop-shadow-small";
		circle2.attr("style", `filter:url(#${filterId})`);
	}
	updateNodeBounds(node, circle2);
	node.intersect = function(point) {
		var _node$width38;
		return intersect_default.circle(node, ((_node$width38 = node.width) !== null && _node$width38 !== void 0 ? _node$width38 : 7) / 2, point);
	};
	return shapeSvg;
}
__name(stateStart, "stateStart");
var FRAME_WIDTH2 = 8;
function subroutine(_x107, _x108) {
	return _subroutine.apply(this, arguments);
}
function _subroutine() {
	_subroutine = _asyncToGenerator(function* (parent, node) {
		var _node$padding52, _node$width39, _node$height34;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding52 = node === null || node === void 0 ? void 0 : node.padding) !== null && _node$padding52 !== void 0 ? _node$padding52 : 8;
		const labelPaddingX = node.look === "neo" ? 28 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const totalWidth = ((_node$width39 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width39 !== void 0 ? _node$width39 : bbox.width) + 2 * FRAME_WIDTH2 + labelPaddingX;
		const totalHeight = ((_node$height34 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height34 !== void 0 ? _node$height34 : bbox.height) + labelPaddingY;
		const w = totalWidth - 2 * FRAME_WIDTH2;
		const h = totalHeight;
		const x = -totalWidth / 2;
		const y = -totalHeight / 2;
		const points = [
			{
				x: 0,
				y: 0
			},
			{
				x: w,
				y: 0
			},
			{
				x: w,
				y: -h
			},
			{
				x: 0,
				y: -h
			},
			{
				x: 0,
				y: 0
			},
			{
				x: -8,
				y: 0
			},
			{
				x: w + 8,
				y: 0
			},
			{
				x: w + 8,
				y: -h
			},
			{
				x: -8,
				y: -h
			},
			{
				x: -8,
				y: 0
			}
		];
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {});
			const roughNode = rc.rectangle(x, y, w + 16, h, options);
			const l1 = rc.line(x + FRAME_WIDTH2, y, x + FRAME_WIDTH2, y + h, options);
			const l2 = rc.line(x + FRAME_WIDTH2 + w, y, x + FRAME_WIDTH2 + w, y + h, options);
			shapeSvg.insert(() => l1, ":first-child");
			shapeSvg.insert(() => l2, ":first-child");
			const rect2 = shapeSvg.insert(() => roughNode, ":first-child");
			const { cssStyles } = node;
			rect2.attr("class", "basic label-container").attr("style", handleUndefinedAttr(cssStyles));
			updateNodeBounds(node, rect2);
		} else {
			const el = insertPolygonShape(shapeSvg, w, h, points);
			if (nodeStyles) el.attr("style", nodeStyles);
			updateNodeBounds(node, el);
		}
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _subroutine.apply(this, arguments);
}
__name(subroutine, "subroutine");
var TAG_RATIO = .2;
function taggedRect(_x109, _x110) {
	return _taggedRect.apply(this, arguments);
}
function _taggedRect() {
	_taggedRect = _asyncToGenerator(function* (parent, node) {
		var _node$padding53;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding53 = node.padding) !== null && _node$padding53 !== void 0 ? _node$padding53 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		if (node.width || node.height) {
			var _node$height35, _node$width40;
			node.height = Math.max(((_node$height35 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height35 !== void 0 ? _node$height35 : 0) - labelPaddingY * 2, 10);
			node.width = Math.max(((_node$width40 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width40 !== void 0 ? _node$width40 : 0) - labelPaddingX * 2 - TAG_RATIO * (node.height + labelPaddingY * 2), 10);
		}
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const totalHeight = ((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : bbox.height) + labelPaddingY * 2;
		const tagWidth = TAG_RATIO * totalHeight;
		const tagHeight = TAG_RATIO * totalHeight;
		const w = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + labelPaddingX * 2 + tagWidth - tagWidth;
		const h = totalHeight;
		const x = -w / 2;
		const y = -h / 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		const rectPoints = [
			{
				x: x - tagWidth / 2,
				y
			},
			{
				x: x + w + tagWidth / 2,
				y
			},
			{
				x: x + w + tagWidth / 2,
				y: y + h
			},
			{
				x: x - tagWidth / 2,
				y: y + h
			}
		];
		const tagPoints = [
			{
				x: x + w - tagWidth / 2,
				y: y + h
			},
			{
				x: x + w + tagWidth / 2,
				y: y + h
			},
			{
				x: x + w + tagWidth / 2,
				y: y + h - tagHeight
			}
		];
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const rectPath = createPathFromPoints(rectPoints);
		const rectNode = rc.path(rectPath, options);
		const tagPath = createPathFromPoints(tagPoints);
		const tagNode = rc.path(tagPath, _objectSpread2(_objectSpread2({}, options), {}, { fillStyle: "solid" }));
		const taggedRect2 = shapeSvg.insert(() => tagNode, ":first-child");
		taggedRect2.insert(() => rectNode, ":first-child");
		taggedRect2.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") taggedRect2.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") taggedRect2.selectAll("path").attr("style", nodeStyles);
		updateNodeBounds(node, taggedRect2);
		node.intersect = function(point) {
			return intersect_default.polygon(node, rectPoints, point);
		};
		return shapeSvg;
	});
	return _taggedRect.apply(this, arguments);
}
__name(taggedRect, "taggedRect");
function taggedWaveEdgedRectangle(_x111, _x112) {
	return _taggedWaveEdgedRectangle.apply(this, arguments);
}
function _taggedWaveEdgedRectangle() {
	_taggedWaveEdgedRectangle = _asyncToGenerator(function* (parent, node) {
		var _node$padding54, _node$width41, _node$padding55, _node$height36, _node$padding56, _bbox$left21, _node$padding57, _bbox$top16;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = Math.max(bbox.width + ((_node$padding54 = node.padding) !== null && _node$padding54 !== void 0 ? _node$padding54 : 0) * 2, (_node$width41 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width41 !== void 0 ? _node$width41 : 0);
		const h = Math.max(bbox.height + ((_node$padding55 = node.padding) !== null && _node$padding55 !== void 0 ? _node$padding55 : 0) * 2, (_node$height36 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height36 !== void 0 ? _node$height36 : 0);
		const waveAmplitude = h / 8;
		const tagWidth = .2 * w;
		const tagHeight = .2 * h;
		const finalH = h + waveAmplitude;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const points = [
			{
				x: -w / 2 - w / 2 * .1,
				y: finalH / 2
			},
			...generateFullSineWavePoints(-w / 2 - w / 2 * .1, finalH / 2, w / 2 + w / 2 * .1, finalH / 2, waveAmplitude, .8),
			{
				x: w / 2 + w / 2 * .1,
				y: -finalH / 2
			},
			{
				x: -w / 2 - w / 2 * .1,
				y: -finalH / 2
			}
		];
		const x = -w / 2 + w / 2 * .1;
		const y = -finalH / 2 - tagHeight * .4;
		const tagPoints = [
			{
				x: x + w - tagWidth,
				y: (y + h) * 1.3
			},
			{
				x: x + w,
				y: y + h - tagHeight
			},
			{
				x: x + w,
				y: (y + h) * .9
			},
			...generateFullSineWavePoints(x + w, (y + h) * 1.25, x + w - tagWidth, (y + h) * 1.3, -h * .02, .5)
		];
		const waveEdgeRectPath = createPathFromPoints(points);
		const waveEdgeRectNode = rc.path(waveEdgeRectPath, options);
		const taggedWaveEdgeRectPath = createPathFromPoints(tagPoints);
		const taggedWaveEdgeRectNode = rc.path(taggedWaveEdgeRectPath, _objectSpread2(_objectSpread2({}, options), {}, { fillStyle: "solid" }));
		const waveEdgeRect = shapeSvg.insert(() => taggedWaveEdgeRectNode, ":first-child");
		waveEdgeRect.insert(() => waveEdgeRectNode, ":first-child");
		waveEdgeRect.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") waveEdgeRect.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") waveEdgeRect.selectAll("path").attr("style", nodeStyles);
		waveEdgeRect.attr("transform", `translate(0,${-waveAmplitude / 2})`);
		label.attr("transform", `translate(${-w / 2 + ((_node$padding56 = node.padding) !== null && _node$padding56 !== void 0 ? _node$padding56 : 0) - (bbox.x - ((_bbox$left21 = bbox.left) !== null && _bbox$left21 !== void 0 ? _bbox$left21 : 0))},${-h / 2 + ((_node$padding57 = node.padding) !== null && _node$padding57 !== void 0 ? _node$padding57 : 0) - waveAmplitude / 2 - (bbox.y - ((_bbox$top16 = bbox.top) !== null && _bbox$top16 !== void 0 ? _bbox$top16 : 0))})`);
		updateNodeBounds(node, waveEdgeRect);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _taggedWaveEdgedRectangle.apply(this, arguments);
}
__name(taggedWaveEdgedRectangle, "taggedWaveEdgedRectangle");
function text(_x113, _x114) {
	return _text.apply(this, arguments);
}
function _text() {
	_text = _asyncToGenerator(function* (parent, node) {
		var _node$padding58, _node$padding59;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const totalWidth = Math.max(bbox.width + ((_node$padding58 = node.padding) !== null && _node$padding58 !== void 0 ? _node$padding58 : 0), (node === null || node === void 0 ? void 0 : node.width) || 0);
		const totalHeight = Math.max(bbox.height + ((_node$padding59 = node.padding) !== null && _node$padding59 !== void 0 ? _node$padding59 : 0), (node === null || node === void 0 ? void 0 : node.height) || 0);
		const x = -totalWidth / 2;
		const y = -totalHeight / 2;
		const rect2 = shapeSvg.insert("rect", ":first-child");
		rect2.attr("class", "text").attr("style", nodeStyles).attr("rx", 0).attr("ry", 0).attr("x", x).attr("y", y).attr("width", totalWidth).attr("height", totalHeight);
		updateNodeBounds(node, rect2);
		node.intersect = function(point) {
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _text.apply(this, arguments);
}
__name(text, "text");
var createCylinderPathD3 = /* @__PURE__ */ __name((x, y, width, height, rx, ry) => {
	return `M${x},${y}
    a${rx},${ry} 0,0,1 0,${-height}
    l${width},0
    a${rx},${ry} 0,0,1 0,${height}
    M${width},${-height}
    a${rx},${ry} 0,0,0 0,${height}
    l${-width},0`;
}, "createCylinderPathD");
var createOuterCylinderPathD3 = /* @__PURE__ */ __name((x, y, width, height, rx, ry) => {
	return [
		`M${x},${y}`,
		`M${x + width},${y}`,
		`a${rx},${ry} 0,0,0 0,${-height}`,
		`l${-width},0`,
		`a${rx},${ry} 0,0,0 0,${height}`,
		`l${width},0`
	].join(" ");
}, "createOuterCylinderPathD");
var createInnerCylinderPathD3 = /* @__PURE__ */ __name((x, y, width, height, rx, ry) => {
	return [`M${x + width / 2},${-height / 2}`, `a${rx},${ry} 0,0,0 0,${height}`].join(" ");
}, "createInnerCylinderPathD");
var MIN_HEIGHT4 = 5;
var MIN_WIDTH4 = 10;
function tiltedCylinder(_x115, _x116) {
	return _tiltedCylinder.apply(this, arguments);
}
function _tiltedCylinder() {
	_tiltedCylinder = _asyncToGenerator(function* (parent, node) {
		var _node$padding60, _bbox$left22, _bbox$top17;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding60 = node.padding) !== null && _node$padding60 !== void 0 ? _node$padding60 : 0;
		const labelPadding = node.look === "neo" ? 12 : nodePadding / 2;
		if (node.width || node.height) {
			var _node$height37, _node$height38, _node$width42;
			const originalHeight = (_node$height37 = node.height) !== null && _node$height37 !== void 0 ? _node$height37 : 0;
			node.height = ((_node$height38 = node.height) !== null && _node$height38 !== void 0 ? _node$height38 : 0) - labelPadding;
			if (node.height < MIN_HEIGHT4) node.height = MIN_HEIGHT4;
			const rx2 = originalHeight / 2 / (2.5 + originalHeight / 50);
			node.width = ((_node$width42 = node.width) !== null && _node$width42 !== void 0 ? _node$width42 : 0) - labelPadding - rx2 * 3;
			if (node.width < MIN_WIDTH4) node.width = MIN_WIDTH4;
		}
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const h = (node.height ? node.height : bbox.height) + labelPadding;
		const ry = h / 2;
		const rx = ry / (2.5 + h / 50);
		const w = (node.width ? node.width : bbox.width) + rx + labelPadding;
		const { cssStyles } = node;
		let cylinder2;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const outerPathData = createOuterCylinderPathD3(0, 0, w, h, rx, ry);
			const innerPathData = createInnerCylinderPathD3(0, 0, w, h, rx, ry);
			const outerNode = rc.path(outerPathData, userNodeOverrides(node, {}));
			const innerLine = rc.path(innerPathData, userNodeOverrides(node, { fill: "none" }));
			cylinder2 = shapeSvg.insert(() => innerLine, ":first-child");
			cylinder2 = shapeSvg.insert(() => outerNode, ":first-child");
			cylinder2.attr("class", "basic label-container");
			if (cssStyles) cylinder2.attr("style", cssStyles);
		} else {
			const pathData = createCylinderPathD3(0, 0, w, h, rx, ry);
			cylinder2 = shapeSvg.insert("path", ":first-child").attr("d", pathData).attr("class", "basic label-container").attr("style", handleUndefinedAttr(cssStyles)).attr("style", nodeStyles);
			cylinder2.attr("class", "basic label-container outer-path");
			if (cssStyles) cylinder2.selectAll("path").attr("style", cssStyles);
			if (nodeStyles) cylinder2.selectAll("path").attr("style", nodeStyles);
		}
		cylinder2.attr("label-offset-x", rx);
		cylinder2.attr("transform", `translate(${-w / 2}, ${h / 2} )`);
		label.attr("transform", `translate(${-(bbox.width / 2) - rx - (bbox.x - ((_bbox$left22 = bbox.left) !== null && _bbox$left22 !== void 0 ? _bbox$left22 : 0))}, ${-(bbox.height / 2) - (bbox.y - ((_bbox$top17 = bbox.top) !== null && _bbox$top17 !== void 0 ? _bbox$top17 : 0))})`);
		updateNodeBounds(node, cylinder2);
		node.intersect = function(point) {
			var _node$y9, _node$height39, _node$height40, _node$x7, _node$width43;
			const pos = intersect_default.rect(node, point);
			const y = pos.y - ((_node$y9 = node.y) !== null && _node$y9 !== void 0 ? _node$y9 : 0);
			if (ry != 0 && (Math.abs(y) < ((_node$height39 = node.height) !== null && _node$height39 !== void 0 ? _node$height39 : 0) / 2 || Math.abs(y) == ((_node$height40 = node.height) !== null && _node$height40 !== void 0 ? _node$height40 : 0) / 2 && Math.abs(pos.x - ((_node$x7 = node.x) !== null && _node$x7 !== void 0 ? _node$x7 : 0)) > ((_node$width43 = node.width) !== null && _node$width43 !== void 0 ? _node$width43 : 0) / 2 - rx)) {
				var _node$x8;
				let x = rx * rx * (1 - y * y / (ry * ry));
				if (x != 0) x = Math.sqrt(Math.abs(x));
				x = rx - x;
				if (point.x - ((_node$x8 = node.x) !== null && _node$x8 !== void 0 ? _node$x8 : 0) > 0) x = -x;
				pos.x += x;
			}
			return pos;
		};
		return shapeSvg;
	});
	return _tiltedCylinder.apply(this, arguments);
}
__name(tiltedCylinder, "tiltedCylinder");
function trapezoid(_x117, _x118) {
	return _trapezoid.apply(this, arguments);
}
function _trapezoid() {
	_trapezoid = _asyncToGenerator(function* (parent, node) {
		var _node$padding61, _node$height41, _node$width44;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding61 = node.padding) !== null && _node$padding61 !== void 0 ? _node$padding61 : 0;
		const labelPaddingY = node.look === "neo" ? nodePadding : nodePadding;
		const labelPaddingX = node.look === "neo" ? nodePadding * 2 : nodePadding;
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const h = ((_node$height41 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height41 !== void 0 ? _node$height41 : bbox.height) + labelPaddingY;
		const w = ((_node$width44 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width44 !== void 0 ? _node$width44 : bbox.width) + labelPaddingX;
		const points = [
			{
				x: -3 * h / 6,
				y: 0
			},
			{
				x: w + 3 * h / 6,
				y: 0
			},
			{
				x: w,
				y: -h
			},
			{
				x: 0,
				y: -h
			}
		];
		let polygon;
		const { cssStyles } = node;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {});
			const pathData = createPathFromPoints(points);
			const roughNode = rc.path(pathData, options);
			polygon = shapeSvg.insert(() => roughNode, ":first-child").attr("transform", `translate(${-w / 2}, ${h / 2})`);
			if (cssStyles) polygon.attr("style", cssStyles);
		} else polygon = insertPolygonShape(shapeSvg, w, h, points);
		if (nodeStyles) polygon.attr("style", nodeStyles);
		node.width = w;
		node.height = h;
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _trapezoid.apply(this, arguments);
}
__name(trapezoid, "trapezoid");
function trapezoidalPentagon(_x119, _x120) {
	return _trapezoidalPentagon.apply(this, arguments);
}
function _trapezoidalPentagon() {
	_trapezoidalPentagon = _asyncToGenerator(function* (parent, node) {
		var _node$padding62;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding62 = node.padding) !== null && _node$padding62 !== void 0 ? _node$padding62 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		const minWidth = 15, minHeight = 5;
		if (node.width || node.height) {
			var _node$height42, _node$width45;
			node.height = ((_node$height42 = node.height) !== null && _node$height42 !== void 0 ? _node$height42 : 0) - labelPaddingY * 2;
			if (node.height < minHeight) node.height = minHeight;
			node.width = ((_node$width45 = node.width) !== null && _node$width45 !== void 0 ? _node$width45 : 0) - labelPaddingX * 2;
			if (node.width < minWidth) node.width = minWidth;
		}
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + labelPaddingX * 2;
		const h = ((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : bbox.height) + labelPaddingY * 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const points = [
			{
				x: -w / 2 * .8,
				y: -h / 2
			},
			{
				x: w / 2 * .8,
				y: -h / 2
			},
			{
				x: w / 2,
				y: -h / 2 * .6
			},
			{
				x: w / 2,
				y: h / 2
			},
			{
				x: -w / 2,
				y: h / 2
			},
			{
				x: -w / 2,
				y: -h / 2 * .6
			}
		];
		const pathData = createPathFromPoints(points);
		const shapeNode = rc.path(pathData, options);
		const polygon = shapeSvg.insert(() => shapeNode, ":first-child");
		polygon.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", nodeStyles);
		updateNodeBounds(node, polygon);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _trapezoidalPentagon.apply(this, arguments);
}
__name(trapezoidalPentagon, "trapezoidalPentagon");
var MIN_HEIGHT5 = 10;
var MIN_WIDTH5 = 10;
function triangle(_x121, _x122) {
	return _triangle.apply(this, arguments);
}
function _triangle() {
	_triangle = _asyncToGenerator(function* (parent, node) {
		var _node$padding63, _getConfig2$flowchart2, _bbox$left23, _node$padding64, _bbox$top18;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding63 = node.padding) !== null && _node$padding63 !== void 0 ? _node$padding63 : 0;
		const labelPaddingX = node.look === "neo" ? nodePadding * 2 : nodePadding;
		if (node.width || node.height) {
			var _node$width46, _node$height43;
			node.width = (((_node$width46 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width46 !== void 0 ? _node$width46 : 0) - labelPaddingX) / 2;
			if (node.width < MIN_WIDTH5) node.width = MIN_WIDTH5;
			node.height = (_node$height43 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height43 !== void 0 ? _node$height43 : 0;
			if (node.height < MIN_HEIGHT5) node.height = MIN_HEIGHT5;
		}
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const useHtmlLabels = evaluate((_getConfig2$flowchart2 = getConfig2().flowchart) === null || _getConfig2$flowchart2 === void 0 ? void 0 : _getConfig2$flowchart2.htmlLabels);
		const w = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + labelPaddingX;
		const h = (node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : w + bbox.height;
		const tw = h;
		const points = [
			{
				x: 0,
				y: 0
			},
			{
				x: tw,
				y: 0
			},
			{
				x: tw / 2,
				y: -h
			}
		];
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const pathData = createPathFromPoints(points);
		const roughNode = rc.path(pathData, options);
		const polygon = shapeSvg.insert(() => roughNode, ":first-child").attr("transform", `translate(${-h / 2}, ${h / 2})`).attr("class", "outer-path");
		if (cssStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") polygon.selectChildren("path").attr("style", nodeStyles);
		node.width = w;
		node.height = h;
		updateNodeBounds(node, polygon);
		label.attr("transform", `translate(${-bbox.width / 2 - (bbox.x - ((_bbox$left23 = bbox.left) !== null && _bbox$left23 !== void 0 ? _bbox$left23 : 0))}, ${h / 2 - (bbox.height + ((_node$padding64 = node.padding) !== null && _node$padding64 !== void 0 ? _node$padding64 : 0) / (useHtmlLabels ? 2 : 1) - (bbox.y - ((_bbox$top18 = bbox.top) !== null && _bbox$top18 !== void 0 ? _bbox$top18 : 0)))})`);
		node.intersect = function(point) {
			log.info("Triangle intersect", node, points, point);
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _triangle.apply(this, arguments);
}
__name(triangle, "triangle");
function waveEdgedRectangle(_x123, _x124) {
	return _waveEdgedRectangle.apply(this, arguments);
}
function _waveEdgedRectangle() {
	_waveEdgedRectangle = _asyncToGenerator(function* (parent, node) {
		var _node$padding65, _node$padding66, _bbox$left24, _node$padding67, _bbox$top19;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding65 = node.padding) !== null && _node$padding65 !== void 0 ? _node$padding65 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 12 : nodePadding;
		let adjustFinalHeight = true;
		if (node.width || node.height) {
			var _node$width47, _node$height44;
			adjustFinalHeight = false;
			node.width = ((_node$width47 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width47 !== void 0 ? _node$width47 : 0) - labelPaddingX * 2;
			if (node.width < 10) node.width = 10;
			node.height = ((_node$height44 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height44 !== void 0 ? _node$height44 : 0) - labelPaddingY * 2;
			if (node.height < 10) node.height = 10;
		}
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + (labelPaddingX !== null && labelPaddingX !== void 0 ? labelPaddingX : 0) * 2;
		const h = ((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : bbox.height) + (labelPaddingY !== null && labelPaddingY !== void 0 ? labelPaddingY : 0) * 2;
		const waveAmplitude = node.look === "neo" ? h / 4 : h / 8;
		const finalH = h + (adjustFinalHeight ? waveAmplitude : -waveAmplitude);
		const { cssStyles } = node;
		const widthDif = 14 - w;
		const extraW = widthDif > 0 ? widthDif / 2 : 0;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const points = [
			{
				x: -w / 2 - extraW,
				y: finalH / 2
			},
			...generateFullSineWavePoints(-w / 2 - extraW, finalH / 2, w / 2 + extraW, finalH / 2, waveAmplitude, .8),
			{
				x: w / 2 + extraW,
				y: -finalH / 2
			},
			{
				x: -w / 2 - extraW,
				y: -finalH / 2
			}
		];
		const waveEdgeRectPath = createPathFromPoints(points);
		const waveEdgeRectNode = rc.path(waveEdgeRectPath, options);
		const waveEdgeRect = shapeSvg.insert(() => waveEdgeRectNode, ":first-child");
		waveEdgeRect.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") waveEdgeRect.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") waveEdgeRect.selectAll("path").attr("style", nodeStyles);
		waveEdgeRect.attr("transform", `translate(0,${-waveAmplitude / 2})`);
		label.attr("transform", `translate(${-w / 2 + ((_node$padding66 = node.padding) !== null && _node$padding66 !== void 0 ? _node$padding66 : 0) - (bbox.x - ((_bbox$left24 = bbox.left) !== null && _bbox$left24 !== void 0 ? _bbox$left24 : 0))},${-h / 2 + ((_node$padding67 = node.padding) !== null && _node$padding67 !== void 0 ? _node$padding67 : 0) - waveAmplitude - (bbox.y - ((_bbox$top19 = bbox.top) !== null && _bbox$top19 !== void 0 ? _bbox$top19 : 0))})`);
		updateNodeBounds(node, waveEdgeRect);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _waveEdgedRectangle.apply(this, arguments);
}
__name(waveEdgedRectangle, "waveEdgedRectangle");
function waveRectangle(_x125, _x126) {
	return _waveRectangle.apply(this, arguments);
}
function _waveRectangle() {
	_waveRectangle = _asyncToGenerator(function* (parent, node) {
		var _node$padding68;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const nodePadding = (_node$padding68 = node.padding) !== null && _node$padding68 !== void 0 ? _node$padding68 : 0;
		const labelPaddingX = node.look === "neo" ? 16 : nodePadding;
		const labelPaddingY = node.look === "neo" ? 20 : nodePadding;
		if (node.width || node.height) {
			var _node$width48, _node$height45;
			node.width = (_node$width48 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width48 !== void 0 ? _node$width48 : 0;
			if (node.width < 20) node.width = 20;
			node.height = (_node$height45 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height45 !== void 0 ? _node$height45 : 0;
			if (node.height < 10) node.height = 10;
			const waveAmplitude2 = Math.min(node.height * .2, node.height / 4);
			node.height = Math.ceil(node.height - labelPaddingY - waveAmplitude2 * (20 / 9));
			node.width = node.width - labelPaddingX * 2;
		}
		const { shapeSvg, bbox } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + labelPaddingX * 2;
		const h = ((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : bbox.height) + labelPaddingY;
		const waveAmplitude = h / 8;
		const finalH = h + waveAmplitude * 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const points = [
			{
				x: -w / 2,
				y: finalH / 2
			},
			...generateFullSineWavePoints(-w / 2, finalH / 2, w / 2, finalH / 2, waveAmplitude, 1),
			{
				x: w / 2,
				y: -finalH / 2
			},
			...generateFullSineWavePoints(w / 2, -finalH / 2, -w / 2, -finalH / 2, waveAmplitude, -1)
		];
		const waveRectPath = createPathFromPoints(points);
		const waveRectNode = rc.path(waveRectPath, options);
		const waveRect = shapeSvg.insert(() => waveRectNode, ":first-child");
		waveRect.attr("class", "basic label-container");
		if (cssStyles && node.look !== "handDrawn") waveRect.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") waveRect.selectAll("path").attr("style", nodeStyles);
		updateNodeBounds(node, waveRect);
		node.intersect = function(point) {
			return intersect_default.polygon(node, points, point);
		};
		return shapeSvg;
	});
	return _waveRectangle.apply(this, arguments);
}
__name(waveRectangle, "waveRectangle");
var rectOffset = 10;
function windowPane(_x127, _x128) {
	return _windowPane.apply(this, arguments);
}
function _windowPane() {
	_windowPane = _asyncToGenerator(function* (parent, node) {
		var _node$padding69, _node$padding70, _bbox$left25, _bbox$top20;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const paddingX = node.look === "neo" ? 16 : (_node$padding69 = node.padding) !== null && _node$padding69 !== void 0 ? _node$padding69 : 0;
		const paddingY = node.look === "neo" ? 12 : (_node$padding70 = node.padding) !== null && _node$padding70 !== void 0 ? _node$padding70 : 0;
		if (node.width || node.height) {
			var _node$width49, _node$height46;
			node.width = Math.max(((_node$width49 = node === null || node === void 0 ? void 0 : node.width) !== null && _node$width49 !== void 0 ? _node$width49 : 0) - paddingX * 2 - rectOffset, 10);
			node.height = Math.max(((_node$height46 = node === null || node === void 0 ? void 0 : node.height) !== null && _node$height46 !== void 0 ? _node$height46 : 0) - paddingY * 2 - rectOffset, 10);
		}
		const { shapeSvg, bbox, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const totalWidth = ((node === null || node === void 0 ? void 0 : node.width) ? node === null || node === void 0 ? void 0 : node.width : bbox.width) + paddingX * 2 + rectOffset;
		const totalHeight = ((node === null || node === void 0 ? void 0 : node.height) ? node === null || node === void 0 ? void 0 : node.height : bbox.height) + paddingY * 2 + rectOffset;
		const w = totalWidth - rectOffset;
		const h = totalHeight - rectOffset;
		const x = -w / 2;
		const y = -h / 2;
		const { cssStyles } = node;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		const outerPathPoints = [
			{
				x: x - rectOffset,
				y: y - rectOffset
			},
			{
				x: x - rectOffset,
				y: y + h
			},
			{
				x: x + w,
				y: y + h
			},
			{
				x: x + w,
				y: y - rectOffset
			}
		];
		const path = `M${x - rectOffset},${y - rectOffset} L${x + w},${y - rectOffset} L${x + w},${y + h} L${x - rectOffset},${y + h} L${x - rectOffset},${y - rectOffset}
                M${x - rectOffset},${y} L${x + w},${y}
                M${x},${y - rectOffset} L${x},${y + h}`;
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const no = rc.path(path, options);
		const windowPane2 = shapeSvg.insert(() => no, ":first-child");
		windowPane2.attr("transform", `translate(${rectOffset / 2}, ${rectOffset / 2})`);
		windowPane2.attr("class", "basic label-container outer-path");
		if (cssStyles && node.look !== "handDrawn") windowPane2.selectAll("path").attr("style", cssStyles);
		if (nodeStyles && node.look !== "handDrawn") windowPane2.selectAll("path").attr("style", nodeStyles);
		label.attr("transform", `translate(${-(bbox.width / 2) + rectOffset / 2 - (bbox.x - ((_bbox$left25 = bbox.left) !== null && _bbox$left25 !== void 0 ? _bbox$left25 : 0))}, ${-(bbox.height / 2) + rectOffset / 2 - (bbox.y - ((_bbox$top20 = bbox.top) !== null && _bbox$top20 !== void 0 ? _bbox$top20 : 0))})`);
		updateNodeBounds(node, windowPane2);
		node.intersect = function(point) {
			return intersect_default.polygon(node, outerPathPoints, point);
		};
		return shapeSvg;
	});
	return _windowPane.apply(this, arguments);
}
__name(windowPane, "windowPane");
var COLOR_THEMES = /* @__PURE__ */ new Set(["redux-color", "redux-dark-color"]);
var REDUX_THEMES = /* @__PURE__ */ new Set([
	"redux",
	"redux-dark",
	"redux-color",
	"redux-dark-color"
]);
function erBox(_x129, _x130) {
	return _erBox.apply(this, arguments);
}
function _erBox() {
	_erBox = _asyncToGenerator(function* (parent, node) {
		var _config$er$diagramPad, _config$er, _config$er$entityPadd, _config$er2, _node$label, _totalShapeBBoxHeight;
		const entityNode = node;
		if (entityNode.alias) node.label = entityNode.alias;
		const { theme, themeVariables } = getConfig();
		const { rowEven, rowOdd, nodeBorder, borderColorArray } = themeVariables;
		if (node.look === "handDrawn") {
			const { themeVariables: themeVariables2 } = getConfig();
			const { background } = themeVariables2;
			yield erBox(parent, _objectSpread2(_objectSpread2({}, node), {}, {
				id: node.id + "-background",
				domId: (node.domId || node.id) + "-background",
				look: "default",
				cssStyles: ["stroke: none", `fill: ${background}`]
			}));
		}
		const config = getConfig();
		node.useHtmlLabels = config.htmlLabels;
		let PADDING = (_config$er$diagramPad = (_config$er = config.er) === null || _config$er === void 0 ? void 0 : _config$er.diagramPadding) !== null && _config$er$diagramPad !== void 0 ? _config$er$diagramPad : 10;
		let TEXT_PADDING = (_config$er$entityPadd = (_config$er2 = config.er) === null || _config$er2 === void 0 ? void 0 : _config$er2.entityPadding) !== null && _config$er$entityPadd !== void 0 ? _config$er$entityPadd : 6;
		const { cssStyles } = node;
		const { labelStyles, nodeStyles } = styles2String(node);
		if (entityNode.attributes.length === 0 && node.label) {
			const options2 = {
				rx: 0,
				ry: 0,
				labelPaddingX: PADDING,
				labelPaddingY: PADDING * 1.5,
				classes: ""
			};
			if (calculateTextWidth(node.label, config) + options2.labelPaddingX * 2 < config.er.minEntityWidth) node.width = config.er.minEntityWidth;
			const shapeSvg2 = yield drawRect(parent, node, options2);
			if (theme != null && COLOR_THEMES.has(theme)) {
				var _entityNode$colorInde;
				const colorIndex = (_entityNode$colorInde = entityNode.colorIndex) !== null && _entityNode$colorInde !== void 0 ? _entityNode$colorInde : 0;
				shapeSvg2.attr("data-color-id", `color-${colorIndex % borderColorArray.length}`);
			}
			if (!evaluate(config.htmlLabels)) {
				var _textElement$node;
				const textElement = shapeSvg2.select("text");
				const bbox = (_textElement$node = textElement.node()) === null || _textElement$node === void 0 ? void 0 : _textElement$node.getBBox();
				textElement.attr("transform", `translate(${-bbox.width / 2}, 0)`);
			}
			return shapeSvg2;
		}
		if (!config.htmlLabels) {
			PADDING *= 1.25;
			TEXT_PADDING *= 1.25;
		}
		let cssClasses = getNodeClasses(node);
		if (!cssClasses) cssClasses = "node default";
		const shapeSvg = parent.insert("g").attr("class", cssClasses).attr("id", node.domId || node.id);
		const nameBBox = yield addText(shapeSvg, (_node$label = node.label) !== null && _node$label !== void 0 ? _node$label : "", config, 0, 0, ["name"], labelStyles);
		nameBBox.height += TEXT_PADDING;
		let yOffset = 0;
		const yOffsets = [];
		const rows = [];
		let maxTypeWidth = 0;
		let maxNameWidth = 0;
		let maxKeysWidth = 0;
		let maxCommentWidth = 0;
		let keysPresent = true;
		let commentPresent = true;
		for (const attribute of entityNode.attributes) {
			const typeBBox = yield addText(shapeSvg, attribute.type, config, 0, yOffset, ["attribute-type"], labelStyles);
			maxTypeWidth = Math.max(maxTypeWidth, typeBBox.width + PADDING);
			const nameBBox2 = yield addText(shapeSvg, attribute.name, config, 0, yOffset, ["attribute-name"], labelStyles);
			maxNameWidth = Math.max(maxNameWidth, nameBBox2.width + PADDING);
			const keysBBox = yield addText(shapeSvg, attribute.keys.join(), config, 0, yOffset, ["attribute-keys"], labelStyles);
			maxKeysWidth = Math.max(maxKeysWidth, keysBBox.width + PADDING);
			const commentBBox = yield addText(shapeSvg, attribute.comment, config, 0, yOffset, ["attribute-comment"], labelStyles);
			maxCommentWidth = Math.max(maxCommentWidth, commentBBox.width + PADDING);
			const rowHeight = Math.max(typeBBox.height, nameBBox2.height, keysBBox.height, commentBBox.height) + TEXT_PADDING;
			rows.push({
				yOffset,
				rowHeight
			});
			yOffset += rowHeight;
		}
		let totalWidthSections = 4;
		if (maxKeysWidth <= PADDING) {
			keysPresent = false;
			maxKeysWidth = 0;
			totalWidthSections--;
		}
		if (maxCommentWidth <= PADDING) {
			commentPresent = false;
			maxCommentWidth = 0;
			totalWidthSections--;
		}
		const shapeBBox = shapeSvg.node().getBBox();
		if (nameBBox.width + PADDING * 2 - (maxTypeWidth + maxNameWidth + maxKeysWidth + maxCommentWidth) > 0) {
			const difference = nameBBox.width + PADDING * 2 - (maxTypeWidth + maxNameWidth + maxKeysWidth + maxCommentWidth);
			maxTypeWidth += difference / totalWidthSections;
			maxNameWidth += difference / totalWidthSections;
			if (maxKeysWidth > 0) maxKeysWidth += difference / totalWidthSections;
			if (maxCommentWidth > 0) maxCommentWidth += difference / totalWidthSections;
		}
		const maxWidth = maxTypeWidth + maxNameWidth + maxKeysWidth + maxCommentWidth;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		let totalShapeBBoxHeight = 0;
		if (rows.length > 0) totalShapeBBoxHeight = rows.reduce((sum, row) => {
			var _row$rowHeight;
			return sum + ((_row$rowHeight = row === null || row === void 0 ? void 0 : row.rowHeight) !== null && _row$rowHeight !== void 0 ? _row$rowHeight : 0);
		}, 0);
		const w = Math.max(shapeBBox.width + PADDING * 2, (node === null || node === void 0 ? void 0 : node.width) || 0, maxWidth);
		const h = Math.max(((_totalShapeBBoxHeight = totalShapeBBoxHeight) !== null && _totalShapeBBoxHeight !== void 0 ? _totalShapeBBoxHeight : 0) + nameBBox.height, (node === null || node === void 0 ? void 0 : node.height) || 0);
		const x = -w / 2;
		const y = -h / 2;
		shapeSvg.selectAll("g:not(:first-child)").each((_, i, nodes) => {
			const text2 = select_default(nodes[i]);
			const transform = text2.attr("transform");
			let translateX = 0;
			let translateY = 0;
			if (transform) {
				const translate = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(transform);
				if (translate) {
					translateX = parseFloat(translate[1]);
					translateY = parseFloat(translate[2]);
					if (text2.attr("class").includes("attribute-name")) translateX += maxTypeWidth;
					else if (text2.attr("class").includes("attribute-keys")) translateX += maxTypeWidth + maxNameWidth;
					else if (text2.attr("class").includes("attribute-comment")) translateX += maxTypeWidth + maxNameWidth + maxKeysWidth;
				}
			}
			text2.attr("transform", `translate(${x + PADDING / 2 + translateX}, ${translateY + y + nameBBox.height + TEXT_PADDING / 2})`);
		});
		shapeSvg.select(".name").attr("transform", "translate(" + -nameBBox.width / 2 + ", " + (y + TEXT_PADDING / 2) + ")");
		if (theme != null && COLOR_THEMES.has(theme)) {
			var _entityNode$colorInde2;
			const colorIndex = (_entityNode$colorInde2 = entityNode.colorIndex) !== null && _entityNode$colorInde2 !== void 0 ? _entityNode$colorInde2 : 0;
			shapeSvg.attr("data-color-id", `color-${colorIndex % borderColorArray.length}`);
		}
		const roughRect = rc.rectangle(x, y, w, h, options);
		const rect2 = shapeSvg.insert(() => roughRect, ":first-child").attr("class", "outer-path").attr("style", cssStyles.join(""));
		yOffsets.push(0);
		for (const [i, row] of rows.entries()) {
			const isEven = (i + 1) % 2 === 0 && row.yOffset !== 0;
			const roughRect2 = rc.rectangle(x, nameBBox.height + y + (row === null || row === void 0 ? void 0 : row.yOffset), w, row === null || row === void 0 ? void 0 : row.rowHeight, _objectSpread2(_objectSpread2({}, options), {}, {
				fill: isEven ? rowEven : rowOdd,
				stroke: nodeBorder
			}));
			shapeSvg.insert(() => roughRect2, "g.label").attr("style", cssStyles.join("")).attr("class", `row-rect-${isEven ? "even" : "odd"}`);
		}
		const thickness = 1e-4;
		let points = lineToPolygon(x, nameBBox.height + y, w + x, nameBBox.height + y, thickness);
		let roughLine = rc.polygon(points.map((p) => [p.x, p.y]), options);
		shapeSvg.insert(() => roughLine).attr("class", "divider");
		points = lineToPolygon(maxTypeWidth + x, nameBBox.height + y, maxTypeWidth + x, h + y, thickness);
		roughLine = rc.polygon(points.map((p) => [p.x, p.y]), options);
		shapeSvg.insert(() => roughLine).attr("class", "divider");
		if (keysPresent) {
			const xCoord = maxTypeWidth + maxNameWidth + x;
			points = lineToPolygon(xCoord, nameBBox.height + y, xCoord, h + y, thickness);
			roughLine = rc.polygon(points.map((p) => [p.x, p.y]), options);
			shapeSvg.insert(() => roughLine).attr("class", "divider");
		}
		if (commentPresent) {
			const xCoord = maxTypeWidth + maxNameWidth + maxKeysWidth + x;
			points = lineToPolygon(xCoord, nameBBox.height + y, xCoord, h + y, thickness);
			roughLine = rc.polygon(points.map((p) => [p.x, p.y]), options);
			shapeSvg.insert(() => roughLine).attr("class", "divider");
		}
		for (const yOffset2 of yOffsets) {
			const yCoord = nameBBox.height + y + yOffset2;
			points = lineToPolygon(x, yCoord, w + x, yCoord, thickness);
			roughLine = rc.polygon(points.map((p) => [p.x, p.y]), options);
			shapeSvg.insert(() => roughLine).attr("class", "divider");
		}
		updateNodeBounds(node, rect2);
		if (nodeStyles && node.look !== "handDrawn") if (theme != null && REDUX_THEMES.has(theme)) shapeSvg.selectAll("path").attr("style", nodeStyles);
		else {
			var _allStyle$filter;
			const allStyle = nodeStyles.split(";");
			const strokeStyles = allStyle === null || allStyle === void 0 || (_allStyle$filter = allStyle.filter((e) => {
				return e.includes("stroke");
			})) === null || _allStyle$filter === void 0 ? void 0 : _allStyle$filter.map((s) => `${s}`).join("; ");
			shapeSvg.selectAll("path").attr("style", strokeStyles !== null && strokeStyles !== void 0 ? strokeStyles : "");
			shapeSvg.selectAll(".row-rect-even path").attr("style", nodeStyles);
		}
		node.intersect = function(point) {
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _erBox.apply(this, arguments);
}
__name(erBox, "erBox");
function addText(_x131, _x132, _x133) {
	return _addText.apply(this, arguments);
}
function _addText() {
	_addText = _asyncToGenerator(function* (shapeSvg, labelText, config, translateX = 0, translateY = 0, classes = [], style = "") {
		const label = shapeSvg.insert("g").attr("class", `label ${classes.join(" ")}`).attr("transform", `translate(${translateX}, ${translateY})`).attr("style", style);
		if (labelText !== parseGenericTypes(labelText)) {
			labelText = parseGenericTypes(labelText);
			labelText = labelText.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
		}
		const text2 = label.node().appendChild(yield createText(label, labelText, {
			width: calculateTextWidth(labelText, config) + 100,
			style,
			useHtmlLabels: config.htmlLabels
		}, config));
		if (labelText.includes("&lt;") || labelText.includes("&gt;")) {
			let child = text2.children[0];
			child.textContent = child.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">");
			while (child.childNodes[0]) {
				child = child.childNodes[0];
				child.textContent = child.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">");
			}
		}
		let bbox = text2.getBBox();
		if (evaluate(config.htmlLabels)) {
			const div = text2.children[0];
			div.style.textAlign = "start";
			const dv = select_default(text2);
			bbox = div.getBoundingClientRect();
			dv.attr("width", bbox.width);
			dv.attr("height", bbox.height);
		}
		return bbox;
	});
	return _addText.apply(this, arguments);
}
__name(addText, "addText");
function lineToPolygon(x1, y1, x2, y2, thickness) {
	if (x1 === x2) return [
		{
			x: x1 - thickness / 2,
			y: y1
		},
		{
			x: x1 + thickness / 2,
			y: y1
		},
		{
			x: x2 + thickness / 2,
			y: y2
		},
		{
			x: x2 - thickness / 2,
			y: y2
		}
	];
	return [
		{
			x: x1,
			y: y1 - thickness / 2
		},
		{
			x: x1,
			y: y1 + thickness / 2
		},
		{
			x: x2,
			y: y2 + thickness / 2
		},
		{
			x: x2,
			y: y2 - thickness / 2
		}
	];
}
__name(lineToPolygon, "lineToPolygon");
function textHelper(_x134, _x135, _x136, _x137) {
	return _textHelper.apply(this, arguments);
}
function _textHelper() {
	_textHelper = _asyncToGenerator(function* (parent, node, config, useHtmlLabels, GAP = ((_config$class$padding) => (_config$class$padding = config.class.padding) !== null && _config$class$padding !== void 0 ? _config$class$padding : 12)()) {
		const TEXT_PADDING = !useHtmlLabels ? 3 : 0;
		const shapeSvg = parent.insert("g").attr("class", getNodeClasses(node)).attr("id", node.domId || node.id);
		let annotationGroup = null;
		let labelGroup = null;
		let membersGroup = null;
		let methodsGroup = null;
		let annotationGroupHeight = 0;
		let labelGroupHeight = 0;
		let membersGroupHeight = 0;
		annotationGroup = shapeSvg.insert("g").attr("class", "annotation-group text");
		if (node.annotations.length > 0) {
			const annotation = node.annotations[0];
			yield addText2(annotationGroup, { text: `\xAB${annotation}\xBB` }, 0);
			annotationGroupHeight = annotationGroup.node().getBBox().height;
		}
		labelGroup = shapeSvg.insert("g").attr("class", "label-group text");
		yield addText2(labelGroup, node, 0, ["font-weight: bolder"]);
		const labelGroupBBox = labelGroup.node().getBBox();
		labelGroupHeight = labelGroupBBox.height;
		membersGroup = shapeSvg.insert("g").attr("class", "members-group text");
		let yOffset = 0;
		for (const member of node.members) {
			const height = yield addText2(membersGroup, member, yOffset, [member.parseClassifier()]);
			yOffset += height + TEXT_PADDING;
		}
		membersGroupHeight = membersGroup.node().getBBox().height;
		if (membersGroupHeight <= 0) membersGroupHeight = GAP / 2;
		methodsGroup = shapeSvg.insert("g").attr("class", "methods-group text");
		let methodsYOffset = 0;
		for (const method of node.methods) {
			const height = yield addText2(methodsGroup, method, methodsYOffset, [method.parseClassifier()]);
			methodsYOffset += height + TEXT_PADDING;
		}
		let bbox = shapeSvg.node().getBBox();
		if (annotationGroup !== null) {
			const annotationGroupBBox = annotationGroup.node().getBBox();
			annotationGroup.attr("transform", `translate(${-annotationGroupBBox.width / 2})`);
		}
		labelGroup.attr("transform", `translate(${-labelGroupBBox.width / 2}, ${annotationGroupHeight})`);
		bbox = shapeSvg.node().getBBox();
		membersGroup.attr("transform", `translate(0, ${annotationGroupHeight + labelGroupHeight + GAP * 2})`);
		bbox = shapeSvg.node().getBBox();
		methodsGroup.attr("transform", `translate(0, ${annotationGroupHeight + labelGroupHeight + (membersGroupHeight ? membersGroupHeight + GAP * 4 : GAP * 2)})`);
		bbox = shapeSvg.node().getBBox();
		return {
			shapeSvg,
			bbox
		};
	});
	return _textHelper.apply(this, arguments);
}
__name(textHelper, "textHelper");
function addText2(_x138, _x139, _x140) {
	return _addText2.apply(this, arguments);
}
function _addText2() {
	_addText2 = _asyncToGenerator(function* (parentGroup, node, yOffset, styles = []) {
		var _evaluate;
		const textEl = parentGroup.insert("g").attr("class", "label").attr("style", styles.join("; "));
		const config = getConfig();
		let useHtmlLabels = "useHtmlLabels" in node ? node.useHtmlLabels : (_evaluate = evaluate(config.htmlLabels)) !== null && _evaluate !== void 0 ? _evaluate : true;
		let textContent = "";
		if ("text" in node) textContent = node.text;
		else textContent = node.label;
		if (!useHtmlLabels && textContent.startsWith("\\")) textContent = textContent.substring(1);
		if (hasKatex(textContent)) useHtmlLabels = true;
		const text2 = yield createText(textEl, sanitizeText3(decodeEntities(textContent)), {
			width: calculateTextWidth(textContent, config) + 50,
			classes: "markdown-node-label",
			useHtmlLabels
		}, config);
		let bbox;
		let numberOfLines = 1;
		if (!useHtmlLabels) {
			if (styles.includes("font-weight: bolder")) select_default(text2).selectAll("tspan").attr("font-weight", "");
			numberOfLines = text2.children.length;
			const textChild = text2.children[0];
			if (text2.textContent === "" || text2.textContent.includes("&gt")) {
				textChild.textContent = textContent[0] + textContent.substring(1).replaceAll("&gt;", ">").replaceAll("&lt;", "<").trim();
				if (textContent[1] === " ") textChild.textContent = textChild.textContent[0] + " " + textChild.textContent.substring(1);
			}
			if (textChild.textContent === "undefined") textChild.textContent = "";
			bbox = text2.getBBox();
		} else {
			const div = text2.children[0];
			const dv = select_default(text2);
			numberOfLines = div.innerHTML.split("<br>").length;
			if (div.innerHTML.includes("</math>")) numberOfLines += div.innerHTML.split("<mrow>").length - 1;
			const images = div.getElementsByTagName("img");
			if (images) {
				const noImgText = textContent.replace(/<img[^>]*>/g, "").trim() === "";
				yield Promise.all([...images].map((img) => new Promise((res) => {
					function setupImage() {
						img.style.display = "flex";
						img.style.flexDirection = "column";
						if (noImgText) {
							var _config$fontSize$toSt, _config$fontSize;
							const bodyFontSize = (_config$fontSize$toSt = (_config$fontSize = config.fontSize) === null || _config$fontSize === void 0 ? void 0 : _config$fontSize.toString()) !== null && _config$fontSize$toSt !== void 0 ? _config$fontSize$toSt : window.getComputedStyle(document.body).fontSize;
							const width = parseInt(bodyFontSize, 10) * 5 + "px";
							img.style.minWidth = width;
							img.style.maxWidth = width;
						} else img.style.width = "100%";
						res(img);
					}
					__name(setupImage, "setupImage");
					setTimeout(() => {
						if (img.complete) setupImage();
					});
					img.addEventListener("error", setupImage);
					img.addEventListener("load", setupImage);
				})));
			}
			bbox = div.getBoundingClientRect();
			dv.attr("width", bbox.width);
			dv.attr("height", bbox.height);
		}
		textEl.attr("transform", "translate(0," + (-bbox.height / (2 * numberOfLines) + yOffset) + ")");
		return bbox.height;
	});
	return _addText2.apply(this, arguments);
}
__name(addText2, "addText");
function classBox(_x141, _x142) {
	return _classBox.apply(this, arguments);
}
function _classBox() {
	_classBox = _asyncToGenerator(function* (parent, node) {
		var _config$class$padding2, _ref12, _node$useHtmlLabels, _classNode$annotation, _classNode$members, _classNode$methods, _classNode$styles, _config$class, _node$width50, _node$height47, _node$height48;
		const config = getConfig2();
		const { themeVariables } = config;
		const { useGradient } = themeVariables;
		const PADDING = (_config$class$padding2 = config.class.padding) !== null && _config$class$padding2 !== void 0 ? _config$class$padding2 : 12;
		const GAP = PADDING;
		const useHtmlLabels = (_ref12 = (_node$useHtmlLabels = node.useHtmlLabels) !== null && _node$useHtmlLabels !== void 0 ? _node$useHtmlLabels : evaluate(config.htmlLabels)) !== null && _ref12 !== void 0 ? _ref12 : true;
		const classNode = node;
		classNode.annotations = (_classNode$annotation = classNode.annotations) !== null && _classNode$annotation !== void 0 ? _classNode$annotation : [];
		classNode.members = (_classNode$members = classNode.members) !== null && _classNode$members !== void 0 ? _classNode$members : [];
		classNode.methods = (_classNode$methods = classNode.methods) !== null && _classNode$methods !== void 0 ? _classNode$methods : [];
		const { shapeSvg, bbox } = yield textHelper(parent, node, config, useHtmlLabels, GAP);
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		node.cssStyles = classNode.styles || "";
		const styles = ((_classNode$styles = classNode.styles) === null || _classNode$styles === void 0 ? void 0 : _classNode$styles.join(";")) || nodeStyles || "";
		if (!node.cssStyles) node.cssStyles = styles.replaceAll("!important", "").split(";");
		const renderExtraBox = classNode.members.length === 0 && classNode.methods.length === 0 && !((_config$class = config.class) === null || _config$class === void 0 ? void 0 : _config$class.hideEmptyMembersBox);
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const w = Math.max((_node$width50 = node.width) !== null && _node$width50 !== void 0 ? _node$width50 : 0, bbox.width);
		let h = Math.max((_node$height47 = node.height) !== null && _node$height47 !== void 0 ? _node$height47 : 0, bbox.height);
		const nodeHeightGreater = ((_node$height48 = node.height) !== null && _node$height48 !== void 0 ? _node$height48 : 0) > bbox.height;
		if (classNode.members.length === 0 && classNode.methods.length === 0) h += GAP;
		else if (classNode.members.length > 0 && classNode.methods.length === 0) h += GAP * 2;
		const x = -w / 2;
		const y = -h / 2;
		let extraHeight = renderExtraBox ? PADDING * 2 : classNode.members.length === 0 && classNode.methods.length === 0 ? -PADDING : 0;
		if (nodeHeightGreater) extraHeight = PADDING * 2;
		const roughRect = rc.rectangle(x - PADDING, y - PADDING - (renderExtraBox ? PADDING : classNode.members.length === 0 && classNode.methods.length === 0 ? -PADDING / 2 : 0), w + 2 * PADDING, h + 2 * PADDING + extraHeight, options);
		const rect2 = shapeSvg.insert(() => roughRect, ":first-child");
		rect2.attr("class", "basic label-container outer-path");
		const rectBBox = rect2.node().getBBox();
		const annotationGroupHeight = shapeSvg.select(".annotation-group").node().getBBox().height - (renderExtraBox ? PADDING / 2 : 0) || 0;
		const labelGroupHeight = shapeSvg.select(".label-group").node().getBBox().height - (renderExtraBox ? PADDING / 2 : 0) || 0;
		const membersGroupHeight = shapeSvg.select(".members-group").node().getBBox().height - (renderExtraBox ? PADDING / 2 : 0) || 0;
		const methodsAreaPlacement = (annotationGroupHeight + labelGroupHeight + y + PADDING - (y - PADDING - (renderExtraBox ? PADDING : classNode.members.length === 0 && classNode.methods.length === 0 ? -PADDING / 2 : 0))) / 2;
		shapeSvg.selectAll(".text").each((_, i, nodes) => {
			var _config$class2;
			const text2 = select_default(nodes[i]);
			const transform = text2.attr("transform");
			let translateY = 0;
			if (transform) {
				const translate = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(transform);
				if (translate) translateY = parseFloat(translate[2]);
			}
			let newTranslateY = translateY + y + PADDING - (renderExtraBox ? PADDING : classNode.members.length === 0 && classNode.methods.length === 0 ? -PADDING / 2 : 0);
			if (text2.attr("class").includes("methods-group")) {
				const membersGroupHeightForMethods = Math.max(membersGroupHeight, GAP / 2);
				if (nodeHeightGreater) newTranslateY = Math.max(methodsAreaPlacement, annotationGroupHeight + labelGroupHeight + membersGroupHeightForMethods + y + GAP * 2 + PADDING) + GAP * 2;
				else newTranslateY = annotationGroupHeight + labelGroupHeight + membersGroupHeightForMethods + y + GAP * 4 + PADDING;
			}
			if (classNode.members.length === 0 && classNode.methods.length === 0 && ((_config$class2 = config.class) === null || _config$class2 === void 0 ? void 0 : _config$class2.hideEmptyMembersBox)) if (classNode.annotations.length > 0) newTranslateY = translateY - GAP;
			else newTranslateY = translateY;
			if (!useHtmlLabels) newTranslateY -= 4;
			let newTranslateX = x;
			if (text2.attr("class").includes("label-group") || text2.attr("class").includes("annotation-group")) {
				var _text2$node;
				newTranslateX = -((_text2$node = text2.node()) === null || _text2$node === void 0 ? void 0 : _text2$node.getBBox().width) / 2 || 0;
				shapeSvg.selectAll("text").each(function(_2, i2, nodes2) {
					if (window.getComputedStyle(nodes2[i2]).textAnchor === "middle") newTranslateX = 0;
				});
			}
			text2.attr("transform", `translate(${newTranslateX}, ${newTranslateY})`);
		});
		if (classNode.members.length > 0 || classNode.methods.length > 0 || renderExtraBox) {
			const firstLineY = annotationGroupHeight + labelGroupHeight + y + PADDING;
			const roughLine = rc.line(rectBBox.x, firstLineY, rectBBox.x + rectBBox.width, firstLineY + .001, options);
			shapeSvg.insert(() => roughLine).attr("class", `divider${node.look === "neo" && !useGradient ? " neo-line" : ""}`).attr("style", styles);
		}
		if (renderExtraBox || classNode.members.length > 0 || classNode.methods.length > 0) {
			const secondLineY = annotationGroupHeight + labelGroupHeight + membersGroupHeight + y + GAP * 2 + PADDING;
			const roughLine = rc.line(rectBBox.x, nodeHeightGreater ? Math.max(methodsAreaPlacement, secondLineY) : secondLineY, rectBBox.x + rectBBox.width, (nodeHeightGreater ? Math.max(methodsAreaPlacement, secondLineY) : secondLineY) + .001, options);
			shapeSvg.insert(() => roughLine).attr("class", `divider${node.look === "neo" && !useGradient ? " neo-line" : ""}`).attr("style", styles);
		}
		if (classNode.look !== "handDrawn") shapeSvg.selectAll("path").attr("style", styles);
		rect2.select(":nth-child(2)").attr("style", styles);
		shapeSvg.selectAll(".divider").select("path").attr("style", styles);
		if (node.labelStyle) shapeSvg.selectAll("span").attr("style", node.labelStyle);
		else shapeSvg.selectAll("span").attr("style", styles);
		if (!useHtmlLabels) {
			const colorRegex = RegExp(/color\s*:\s*([^;]*)/);
			const match = colorRegex.exec(styles);
			if (match) {
				const colorStyle = match[0].replace("color", "fill");
				shapeSvg.selectAll("tspan").attr("style", colorStyle);
			} else if (labelStyles) {
				const match2 = colorRegex.exec(labelStyles);
				if (match2) {
					const colorStyle = match2[0].replace("color", "fill");
					shapeSvg.selectAll("tspan").attr("style", colorStyle);
				}
			}
		}
		updateNodeBounds(node, rect2);
		node.intersect = function(point) {
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _classBox.apply(this, arguments);
}
__name(classBox, "classBox");
function requirementBox(_x143, _x144) {
	return _requirementBox.apply(this, arguments);
}
function _requirementBox() {
	_requirementBox = _asyncToGenerator(function* (parent, node) {
		var _node$domId7, _shapeSvg$node$getBBo, _shapeSvg$node, _shapeSvg$node$getBBo2, _shapeSvg$node2;
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const requirementNode = node;
		const elementNode = node;
		const padding = 20;
		const gap = 20;
		const isRequirementNode = "verifyMethod" in node;
		const classes = getNodeClasses(node);
		const { themeVariables } = getConfig2();
		const { borderColorArray, requirementEdgeLabelBackground } = themeVariables;
		const shapeSvg = parent.insert("g").attr("class", classes).attr("id", (_node$domId7 = node.domId) !== null && _node$domId7 !== void 0 ? _node$domId7 : node.id);
		let typeHeight;
		if (isRequirementNode) typeHeight = yield addText3(shapeSvg, `&lt;&lt;${requirementNode.type}&gt;&gt;`, 0, node.labelStyle);
		else typeHeight = yield addText3(shapeSvg, "&lt;&lt;Element&gt;&gt;", 0, node.labelStyle);
		let accumulativeHeight = typeHeight;
		const nameHeight = yield addText3(shapeSvg, requirementNode.name, accumulativeHeight, node.labelStyle + "; font-weight: bold;");
		accumulativeHeight += nameHeight + gap;
		if (isRequirementNode) {
			const idHeight = yield addText3(shapeSvg, `${requirementNode.requirementId ? `ID: ${requirementNode.requirementId}` : ""}`, accumulativeHeight, node.labelStyle);
			accumulativeHeight += idHeight;
			const textHeight = yield addText3(shapeSvg, `${requirementNode.text ? `Text: ${requirementNode.text}` : ""}`, accumulativeHeight, node.labelStyle);
			accumulativeHeight += textHeight;
			const riskHeight = yield addText3(shapeSvg, `${requirementNode.risk ? `Risk: ${requirementNode.risk}` : ""}`, accumulativeHeight, node.labelStyle);
			accumulativeHeight += riskHeight;
			yield addText3(shapeSvg, `${requirementNode.verifyMethod ? `Verification: ${requirementNode.verifyMethod}` : ""}`, accumulativeHeight, node.labelStyle);
		} else {
			const typeHeight2 = yield addText3(shapeSvg, `${elementNode.type ? `Type: ${elementNode.type}` : ""}`, accumulativeHeight, node.labelStyle);
			accumulativeHeight += typeHeight2;
			yield addText3(shapeSvg, `${elementNode.docRef ? `Doc Ref: ${elementNode.docRef}` : ""}`, accumulativeHeight, node.labelStyle);
		}
		const totalWidth = ((_shapeSvg$node$getBBo = (_shapeSvg$node = shapeSvg.node()) === null || _shapeSvg$node === void 0 ? void 0 : _shapeSvg$node.getBBox().width) !== null && _shapeSvg$node$getBBo !== void 0 ? _shapeSvg$node$getBBo : 200) + padding;
		const totalHeight = ((_shapeSvg$node$getBBo2 = (_shapeSvg$node2 = shapeSvg.node()) === null || _shapeSvg$node2 === void 0 ? void 0 : _shapeSvg$node2.getBBox().height) !== null && _shapeSvg$node$getBBo2 !== void 0 ? _shapeSvg$node$getBBo2 : 200) + padding;
		const x = -totalWidth / 2;
		const y = -totalHeight / 2;
		const rc = at.svg(shapeSvg);
		const options = userNodeOverrides(node, {});
		if (node.look !== "handDrawn") {
			options.roughness = 0;
			options.fillStyle = "solid";
		}
		const roughRect = rc.rectangle(x, y, totalWidth, totalHeight, options);
		const rect2 = shapeSvg.insert(() => roughRect, ":first-child");
		rect2.attr("class", "basic label-container outer-path").attr("style", nodeStyles);
		if (borderColorArray === null || borderColorArray === void 0 ? void 0 : borderColorArray.length) {
			var _node$colorIndex;
			const colorIndex = (_node$colorIndex = node.colorIndex) !== null && _node$colorIndex !== void 0 ? _node$colorIndex : 0;
			shapeSvg.attr("data-color-id", `color-${colorIndex % borderColorArray.length}`);
		}
		shapeSvg.selectAll(".label").each((_, i, nodes) => {
			const text2 = select_default(nodes[i]);
			const transform = text2.attr("transform");
			let translateX = 0;
			let translateY = 0;
			if (transform) {
				const translate = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(transform);
				if (translate) {
					translateX = parseFloat(translate[1]);
					translateY = parseFloat(translate[2]);
				}
			}
			const newTranslateY = translateY - totalHeight / 2;
			let newTranslateX = x + padding / 2;
			if (i === 0 || i === 1) newTranslateX = translateX;
			text2.attr("transform", `translate(${newTranslateX}, ${newTranslateY + padding})`);
		});
		if (accumulativeHeight > typeHeight + nameHeight + gap) {
			const lineY = y + typeHeight + nameHeight + gap;
			let roughLine;
			if (node.look === "neo") {
				const thickness = .001;
				const polygonPoints = [
					[x, lineY],
					[x + totalWidth, lineY],
					[x + totalWidth, lineY + thickness],
					[x, lineY + thickness]
				];
				roughLine = rc.polygon(polygonPoints, options);
			} else roughLine = rc.line(x, lineY, x + totalWidth, lineY, options);
			shapeSvg.insert(() => roughLine).attr("class", "divider");
		}
		updateNodeBounds(node, rect2);
		node.intersect = function(point) {
			return intersect_default.rect(node, point);
		};
		if (nodeStyles && node.look !== "handDrawn" && (requirementEdgeLabelBackground || (borderColorArray === null || borderColorArray === void 0 ? void 0 : borderColorArray.length))) shapeSvg.selectAll("path").attr("style", nodeStyles);
		return shapeSvg;
	});
	return _requirementBox.apply(this, arguments);
}
__name(requirementBox, "requirementBox");
function addText3(_x145, _x146, _x147) {
	return _addText3.apply(this, arguments);
}
function _addText3() {
	_addText3 = _asyncToGenerator(function* (parentGroup, inputText, yOffset, style = "") {
		var _config$htmlLabels;
		if (inputText === "") return 0;
		const textEl = parentGroup.insert("g").attr("class", "label").attr("style", style);
		const config = getConfig2();
		const useHtmlLabels = (_config$htmlLabels = config.htmlLabels) !== null && _config$htmlLabels !== void 0 ? _config$htmlLabels : true;
		const text2 = yield createText(textEl, sanitizeText3(decodeEntities(inputText)), {
			width: calculateTextWidth(inputText, config) + 50,
			classes: "markdown-node-label",
			useHtmlLabels,
			style
		}, config);
		let bbox;
		if (!useHtmlLabels) {
			const textChild = text2.children[0];
			for (const child of textChild.children) if (style) child.setAttribute("style", style);
			bbox = text2.getBBox();
			bbox.height += 6;
		} else {
			const div = text2.children[0];
			const dv = select_default(text2);
			bbox = div.getBoundingClientRect();
			dv.attr("width", bbox.width);
			dv.attr("height", bbox.height);
		}
		textEl.attr("transform", `translate(${-bbox.width / 2},${-bbox.height / 2 + yOffset})`);
		return bbox.height;
	});
	return _addText3.apply(this, arguments);
}
__name(addText3, "addText");
var colorFromPriority = /* @__PURE__ */ __name((priority) => {
	switch (priority) {
		case "Very High": return "red";
		case "High": return "orange";
		case "Medium": return null;
		case "Low": return "blue";
		case "Very Low": return "lightblue";
	}
}, "colorFromPriority");
function kanbanItem(_x148, _x149, _x150) {
	return _kanbanItem.apply(this, arguments);
}
function _kanbanItem() {
	_kanbanItem = _asyncToGenerator(function* (parent, kanbanNode, { config }) {
		var _kanbanNode$width, _config$kanban;
		const { labelStyles, nodeStyles } = styles2String(kanbanNode);
		kanbanNode.labelStyle = labelStyles || "";
		const labelPaddingX = 10;
		const orgWidth = kanbanNode.width;
		kanbanNode.width = ((_kanbanNode$width = kanbanNode.width) !== null && _kanbanNode$width !== void 0 ? _kanbanNode$width : 200) - 10;
		const { shapeSvg, bbox, label: labelElTitle } = yield labelHelper(parent, kanbanNode, getNodeClasses(kanbanNode));
		const padding = kanbanNode.padding || 10;
		let ticketUrl = "";
		let link;
		if ("ticket" in kanbanNode && kanbanNode.ticket && (config === null || config === void 0 || (_config$kanban = config.kanban) === null || _config$kanban === void 0 ? void 0 : _config$kanban.ticketBaseUrl)) {
			var _config$kanban2;
			ticketUrl = config === null || config === void 0 || (_config$kanban2 = config.kanban) === null || _config$kanban2 === void 0 ? void 0 : _config$kanban2.ticketBaseUrl.replace("#TICKET#", kanbanNode.ticket);
			link = shapeSvg.insert("svg:a", ":first-child").attr("class", "kanban-ticket-link").attr("xlink:href", ticketUrl).attr("target", "_blank");
		}
		const options = {
			useHtmlLabels: kanbanNode.useHtmlLabels,
			labelStyle: kanbanNode.labelStyle || "",
			width: kanbanNode.width,
			img: kanbanNode.img,
			padding: kanbanNode.padding || 8,
			centerLabel: false
		};
		let labelEl, bbox2;
		if (link) ({label: labelEl, bbox: bbox2} = yield insertLabel(link, "ticket" in kanbanNode && kanbanNode.ticket || "", options));
		else ({label: labelEl, bbox: bbox2} = yield insertLabel(shapeSvg, "ticket" in kanbanNode && kanbanNode.ticket || "", options));
		const { label: labelElAssigned, bbox: bboxAssigned } = yield insertLabel(shapeSvg, "assigned" in kanbanNode && kanbanNode.assigned || "", options);
		kanbanNode.width = orgWidth;
		const labelPaddingY = 10;
		const totalWidth = (kanbanNode === null || kanbanNode === void 0 ? void 0 : kanbanNode.width) || 0;
		const heightAdj = Math.max(bbox2.height, bboxAssigned.height) / 2;
		const totalHeight = Math.max(bbox.height + labelPaddingY * 2, (kanbanNode === null || kanbanNode === void 0 ? void 0 : kanbanNode.height) || 0) + heightAdj;
		const x = -totalWidth / 2;
		const y = -totalHeight / 2;
		labelElTitle.attr("transform", "translate(" + (padding - totalWidth / 2) + ", " + (-heightAdj - bbox.height / 2) + ")");
		labelEl.attr("transform", "translate(" + (padding - totalWidth / 2) + ", " + (-heightAdj + bbox.height / 2) + ")");
		labelElAssigned.attr("transform", "translate(" + (padding + totalWidth / 2 - bboxAssigned.width - 2 * labelPaddingX) + ", " + (-heightAdj + bbox.height / 2) + ")");
		let rect2;
		const { rx, ry } = kanbanNode;
		const { cssStyles } = kanbanNode;
		if (kanbanNode.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options2 = userNodeOverrides(kanbanNode, {});
			const roughNode = rx || ry ? rc.path(createRoundedRectPathD(x, y, totalWidth, totalHeight, rx || 0), options2) : rc.rectangle(x, y, totalWidth, totalHeight, options2);
			rect2 = shapeSvg.insert(() => roughNode, ":first-child");
			rect2.attr("class", "basic label-container").attr("style", cssStyles ? cssStyles : null);
		} else {
			rect2 = shapeSvg.insert("rect", ":first-child");
			rect2.attr("class", "basic label-container __APA__").attr("style", nodeStyles).attr("rx", rx !== null && rx !== void 0 ? rx : 5).attr("ry", ry !== null && ry !== void 0 ? ry : 5).attr("x", x).attr("y", y).attr("width", totalWidth).attr("height", totalHeight);
			const priority = "priority" in kanbanNode && kanbanNode.priority;
			if (priority) {
				const line = shapeSvg.append("line");
				const lineX = x + 2;
				const y1 = y + Math.floor((rx !== null && rx !== void 0 ? rx : 0) / 2);
				const y2 = y + totalHeight - Math.floor((rx !== null && rx !== void 0 ? rx : 0) / 2);
				line.attr("x1", lineX).attr("y1", y1).attr("x2", lineX).attr("y2", y2).attr("stroke-width", "4").attr("stroke", colorFromPriority(priority));
			}
		}
		updateNodeBounds(kanbanNode, rect2);
		kanbanNode.height = totalHeight;
		kanbanNode.intersect = function(point) {
			return intersect_default.rect(kanbanNode, point);
		};
		return shapeSvg;
	});
	return _kanbanItem.apply(this, arguments);
}
__name(kanbanItem, "kanbanItem");
function bang(_x151, _x152) {
	return _bang.apply(this, arguments);
}
function _bang() {
	_bang = _asyncToGenerator(function* (parent, node) {
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox, halfPadding, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = bbox.width + 10 * halfPadding;
		const h = bbox.height + 8 * halfPadding;
		const r = .15 * w;
		const { cssStyles } = node;
		const minWidth = bbox.width + 20;
		const minHeight = bbox.height + 20;
		const effectiveWidth = Math.max(w, minWidth);
		const effectiveHeight = Math.max(h, minHeight);
		label.attr("transform", `translate(${-bbox.width / 2}, ${-bbox.height / 2})`);
		let bangElem;
		const path = `M0 0 
    a${r},${r} 1 0,0 ${effectiveWidth * .25},${-1 * effectiveHeight * .1}
    a${r},${r} 1 0,0 ${effectiveWidth * .25},0
    a${r},${r} 1 0,0 ${effectiveWidth * .25},0
    a${r},${r} 1 0,0 ${effectiveWidth * .25},${effectiveHeight * .1}

    a${r},${r} 1 0,0 ${effectiveWidth * .15},${effectiveHeight * .33}
    a${r * .8},${r * .8} 1 0,0 0,${effectiveHeight * .34}
    a${r},${r} 1 0,0 ${-1 * effectiveWidth * .15},${effectiveHeight * .33}

    a${r},${r} 1 0,0 ${-1 * effectiveWidth * .25},${effectiveHeight * .15}
    a${r},${r} 1 0,0 ${-1 * effectiveWidth * .25},0
    a${r},${r} 1 0,0 ${-1 * effectiveWidth * .25},0
    a${r},${r} 1 0,0 ${-1 * effectiveWidth * .25},${-1 * effectiveHeight * .15}

    a${r},${r} 1 0,0 ${-1 * effectiveWidth * .1},${-1 * effectiveHeight * .33}
    a${r * .8},${r * .8} 1 0,0 0,${-1 * effectiveHeight * .34}
    a${r},${r} 1 0,0 ${effectiveWidth * .1},${-1 * effectiveHeight * .33}
  H0 V0 Z`;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {});
			const roughNode = rc.path(path, options);
			bangElem = shapeSvg.insert(() => roughNode, ":first-child");
			bangElem.attr("class", "basic label-container").attr("style", handleUndefinedAttr(cssStyles));
		} else bangElem = shapeSvg.insert("path", ":first-child").attr("class", "basic label-container").attr("style", nodeStyles).attr("d", path);
		bangElem.attr("transform", `translate(${-effectiveWidth / 2}, ${-effectiveHeight / 2})`);
		updateNodeBounds(node, bangElem);
		node.calcIntersect = function(bounds, point) {
			return intersect_default.rect(bounds, point);
		};
		node.intersect = function(point) {
			log.info("Bang intersect", node, point);
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _bang.apply(this, arguments);
}
__name(bang, "bang");
function cloud(_x153, _x154) {
	return _cloud.apply(this, arguments);
}
function _cloud() {
	_cloud = _asyncToGenerator(function* (parent, node) {
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox, halfPadding, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = bbox.width + 2 * halfPadding;
		const h = bbox.height + 2 * halfPadding;
		const r1 = .15 * w;
		const r2 = .25 * w;
		const r3 = .35 * w;
		const r4 = .2 * w;
		const { cssStyles } = node;
		let cloudElem;
		const path = `M0 0 
    a${r1},${r1} 0 0,1 ${w * .25},${-1 * w * .1}
    a${r3},${r3} 1 0,1 ${w * .4},${-1 * w * .1}
    a${r2},${r2} 1 0,1 ${w * .35},${w * .2}

    a${r1},${r1} 1 0,1 ${w * .15},${h * .35}
    a${r4},${r4} 1 0,1 ${-1 * w * .15},${h * .65}

    a${r2},${r1} 1 0,1 ${-1 * w * .25},${w * .15}
    a${r3},${r3} 1 0,1 ${-1 * w * .5},0
    a${r1},${r1} 1 0,1 ${-1 * w * .25},${-1 * w * .15}

    a${r1},${r1} 1 0,1 ${-1 * w * .1},${-1 * h * .35}
    a${r4},${r4} 1 0,1 ${w * .1},${-1 * h * .65}
  H0 V0 Z`;
		if (node.look === "handDrawn") {
			const rc = at.svg(shapeSvg);
			const options = userNodeOverrides(node, {});
			const roughNode = rc.path(path, options);
			cloudElem = shapeSvg.insert(() => roughNode, ":first-child");
			cloudElem.attr("class", "basic label-container").attr("style", handleUndefinedAttr(cssStyles));
		} else cloudElem = shapeSvg.insert("path", ":first-child").attr("class", "basic label-container").attr("style", nodeStyles).attr("d", path);
		label.attr("transform", `translate(${-bbox.width / 2}, ${-bbox.height / 2})`);
		cloudElem.attr("transform", `translate(${-w / 2}, ${-h / 2})`);
		updateNodeBounds(node, cloudElem);
		node.calcIntersect = function(bounds, point) {
			return intersect_default.rect(bounds, point);
		};
		node.intersect = function(point) {
			log.info("Cloud intersect", node, point);
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _cloud.apply(this, arguments);
}
__name(cloud, "cloud");
function defaultMindmapNode(_x155, _x156) {
	return _defaultMindmapNode.apply(this, arguments);
}
function _defaultMindmapNode() {
	_defaultMindmapNode = _asyncToGenerator(function* (parent, node) {
		const { labelStyles, nodeStyles } = styles2String(node);
		node.labelStyle = labelStyles;
		const { shapeSvg, bbox, halfPadding, label } = yield labelHelper(parent, node, getNodeClasses(node));
		const w = bbox.width + 8 * halfPadding;
		const h = bbox.height + 2 * halfPadding;
		const rd = 5;
		const rectPath = node.look === "neo" ? `
    M${-w / 2} ${h / 2 - rd}
    v${-h + 2 * rd}
    q0,-${rd} ${rd},-${rd}
    h${w - 2 * rd}
    q${rd},0 ${rd},${rd}
    v${h - rd}
    H${-w / 2}
    Z
  ` : `
    M${-w / 2} ${h / 2 - rd}
    v${-h + 2 * rd}
    q0,-${rd} ${rd},-${rd}
    h${w - 2 * rd}
    q${rd},0 ${rd},${rd}
    v${h - 2 * rd}
    q0,${rd} -5,${rd}
    h${-(w - 2 * rd)}
    q-5,0 -5,-5
    Z
  `;
		if (!node.domId) throw new Error(`defaultMindmapNode: node "${node.id}" is missing a domId \u2014 was render.ts domId prefixing skipped?`);
		const bg = shapeSvg.append("path").attr("id", node.domId).attr("class", "node-bkg node-" + node.type).attr("style", nodeStyles).attr("d", rectPath);
		shapeSvg.append("line").attr("class", "node-line-").attr("x1", -w / 2).attr("y1", h / 2).attr("x2", w / 2).attr("y2", h / 2);
		label.attr("transform", `translate(${-bbox.width / 2}, ${-bbox.height / 2})`);
		shapeSvg.append(() => label.node());
		updateNodeBounds(node, bg);
		node.calcIntersect = function(bounds, point) {
			return intersect_default.rect(bounds, point);
		};
		node.intersect = function(point) {
			return intersect_default.rect(node, point);
		};
		return shapeSvg;
	});
	return _defaultMindmapNode.apply(this, arguments);
}
__name(defaultMindmapNode, "defaultMindmapNode");
function mindmapCircle(_x157, _x158) {
	return _mindmapCircle.apply(this, arguments);
}
function _mindmapCircle() {
	_mindmapCircle = _asyncToGenerator(function* (parent, node) {
		var _node$padding71;
		return circle(parent, node, { padding: (_node$padding71 = node.padding) !== null && _node$padding71 !== void 0 ? _node$padding71 : 0 });
	});
	return _mindmapCircle.apply(this, arguments);
}
__name(mindmapCircle, "mindmapCircle");
var shapesDefs = [
	{
		semanticName: "Process",
		name: "Rectangle",
		shortName: "rect",
		description: "Standard process shape",
		aliases: [
			"proc",
			"process",
			"rectangle"
		],
		internalAliases: ["squareRect"],
		handler: squareRect2
	},
	{
		semanticName: "Event",
		name: "Rounded Rectangle",
		shortName: "rounded",
		description: "Represents an event",
		aliases: ["event"],
		internalAliases: ["roundedRect"],
		handler: roundedRect
	},
	{
		semanticName: "Terminal Point",
		name: "Stadium",
		shortName: "stadium",
		description: "Terminal point",
		aliases: ["terminal", "pill"],
		handler: stadium
	},
	{
		semanticName: "Subprocess",
		name: "Framed Rectangle",
		shortName: "fr-rect",
		description: "Subprocess",
		aliases: [
			"subprocess",
			"subproc",
			"framed-rectangle",
			"subroutine"
		],
		handler: subroutine
	},
	{
		semanticName: "Database",
		name: "Cylinder",
		shortName: "cyl",
		description: "Database storage",
		aliases: [
			"db",
			"database",
			"cylinder"
		],
		handler: cylinder
	},
	{
		semanticName: "Data Store",
		name: "Data Store",
		shortName: "datastore",
		description: "Data flow diagram data store",
		aliases: ["data-store"],
		handler: datastore
	},
	{
		semanticName: "Start",
		name: "Circle",
		shortName: "circle",
		description: "Starting point",
		aliases: ["circ"],
		handler: circle
	},
	{
		semanticName: "Bang",
		name: "Bang",
		shortName: "bang",
		description: "Bang",
		aliases: ["bang"],
		handler: bang
	},
	{
		semanticName: "Cloud",
		name: "Cloud",
		shortName: "cloud",
		description: "cloud",
		aliases: ["cloud"],
		handler: cloud
	},
	{
		semanticName: "Decision",
		name: "Diamond",
		shortName: "diam",
		description: "Decision-making step",
		aliases: [
			"decision",
			"diamond",
			"question"
		],
		handler: question
	},
	{
		semanticName: "Prepare Conditional",
		name: "Hexagon",
		shortName: "hex",
		description: "Preparation or condition step",
		aliases: ["hexagon", "prepare"],
		handler: hexagon
	},
	{
		semanticName: "Data Input/Output",
		name: "Lean Right",
		shortName: "lean-r",
		description: "Represents input or output",
		aliases: ["lean-right", "in-out"],
		internalAliases: ["lean_right"],
		handler: lean_right
	},
	{
		semanticName: "Data Input/Output",
		name: "Lean Left",
		shortName: "lean-l",
		description: "Represents output or input",
		aliases: ["lean-left", "out-in"],
		internalAliases: ["lean_left"],
		handler: lean_left
	},
	{
		semanticName: "Priority Action",
		name: "Trapezoid Base Bottom",
		shortName: "trap-b",
		description: "Priority action",
		aliases: [
			"priority",
			"trapezoid-bottom",
			"trapezoid"
		],
		handler: trapezoid
	},
	{
		semanticName: "Manual Operation",
		name: "Trapezoid Base Top",
		shortName: "trap-t",
		description: "Represents a manual task",
		aliases: [
			"manual",
			"trapezoid-top",
			"inv-trapezoid"
		],
		internalAliases: ["inv_trapezoid"],
		handler: inv_trapezoid
	},
	{
		semanticName: "Stop",
		name: "Double Circle",
		shortName: "dbl-circ",
		description: "Represents a stop point",
		aliases: ["double-circle"],
		internalAliases: ["doublecircle"],
		handler: doublecircle
	},
	{
		semanticName: "Text Block",
		name: "Text Block",
		shortName: "text",
		description: "Text block",
		handler: text
	},
	{
		semanticName: "Card",
		name: "Notched Rectangle",
		shortName: "notch-rect",
		description: "Represents a card",
		aliases: ["card", "notched-rectangle"],
		handler: card
	},
	{
		semanticName: "Lined/Shaded Process",
		name: "Lined Rectangle",
		shortName: "lin-rect",
		description: "Lined process shape",
		aliases: [
			"lined-rectangle",
			"lined-process",
			"lin-proc",
			"shaded-process"
		],
		handler: shadedProcess
	},
	{
		semanticName: "Start",
		name: "Small Circle",
		shortName: "sm-circ",
		description: "Small starting point",
		aliases: ["start", "small-circle"],
		internalAliases: ["stateStart"],
		handler: stateStart
	},
	{
		semanticName: "Stop",
		name: "Framed Circle",
		shortName: "fr-circ",
		description: "Stop point",
		aliases: ["stop", "framed-circle"],
		internalAliases: ["stateEnd"],
		handler: stateEnd
	},
	{
		semanticName: "Fork/Join",
		name: "Filled Rectangle",
		shortName: "fork",
		description: "Fork or join in process flow",
		aliases: ["join"],
		internalAliases: ["forkJoin"],
		handler: forkJoin
	},
	{
		semanticName: "Collate",
		name: "Hourglass",
		shortName: "hourglass",
		description: "Represents a collate operation",
		aliases: ["hourglass", "collate"],
		handler: hourglass
	},
	{
		semanticName: "Comment",
		name: "Curly Brace",
		shortName: "brace",
		description: "Adds a comment",
		aliases: ["comment", "brace-l"],
		handler: curlyBraceLeft
	},
	{
		semanticName: "Comment Right",
		name: "Curly Brace",
		shortName: "brace-r",
		description: "Adds a comment",
		handler: curlyBraceRight
	},
	{
		semanticName: "Comment with braces on both sides",
		name: "Curly Braces",
		shortName: "braces",
		description: "Adds a comment",
		handler: curlyBraces
	},
	{
		semanticName: "Com Link",
		name: "Lightning Bolt",
		shortName: "bolt",
		description: "Communication link",
		aliases: ["com-link", "lightning-bolt"],
		handler: lightningBolt
	},
	{
		semanticName: "Document",
		name: "Document",
		shortName: "doc",
		description: "Represents a document",
		aliases: ["doc", "document"],
		handler: waveEdgedRectangle
	},
	{
		semanticName: "Delay",
		name: "Half-Rounded Rectangle",
		shortName: "delay",
		description: "Represents a delay",
		aliases: ["half-rounded-rectangle"],
		handler: halfRoundedRectangle
	},
	{
		semanticName: "Direct Access Storage",
		name: "Horizontal Cylinder",
		shortName: "h-cyl",
		description: "Direct access storage",
		aliases: ["das", "horizontal-cylinder"],
		handler: tiltedCylinder
	},
	{
		semanticName: "Disk Storage",
		name: "Lined Cylinder",
		shortName: "lin-cyl",
		description: "Disk storage",
		aliases: ["disk", "lined-cylinder"],
		handler: linedCylinder
	},
	{
		semanticName: "Display",
		name: "Curved Trapezoid",
		shortName: "curv-trap",
		description: "Represents a display",
		aliases: ["curved-trapezoid", "display"],
		handler: curvedTrapezoid
	},
	{
		semanticName: "Divided Process",
		name: "Divided Rectangle",
		shortName: "div-rect",
		description: "Divided process shape",
		aliases: [
			"div-proc",
			"divided-rectangle",
			"divided-process"
		],
		handler: dividedRectangle
	},
	{
		semanticName: "Extract",
		name: "Triangle",
		shortName: "tri",
		description: "Extraction process",
		aliases: ["extract", "triangle"],
		handler: triangle
	},
	{
		semanticName: "Internal Storage",
		name: "Window Pane",
		shortName: "win-pane",
		description: "Internal storage",
		aliases: ["internal-storage", "window-pane"],
		handler: windowPane
	},
	{
		semanticName: "Junction",
		name: "Filled Circle",
		shortName: "f-circ",
		description: "Junction point",
		aliases: ["junction", "filled-circle"],
		handler: filledCircle
	},
	{
		semanticName: "Loop Limit",
		name: "Trapezoidal Pentagon",
		shortName: "notch-pent",
		description: "Loop limit step",
		aliases: ["loop-limit", "notched-pentagon"],
		handler: trapezoidalPentagon
	},
	{
		semanticName: "Manual File",
		name: "Flipped Triangle",
		shortName: "flip-tri",
		description: "Manual file operation",
		aliases: ["manual-file", "flipped-triangle"],
		handler: flippedTriangle
	},
	{
		semanticName: "Manual Input",
		name: "Sloped Rectangle",
		shortName: "sl-rect",
		description: "Manual input step",
		aliases: ["manual-input", "sloped-rectangle"],
		handler: slopedRect
	},
	{
		semanticName: "Multi-Document",
		name: "Stacked Document",
		shortName: "docs",
		description: "Multiple documents",
		aliases: [
			"documents",
			"st-doc",
			"stacked-document"
		],
		handler: multiWaveEdgedRectangle
	},
	{
		semanticName: "Multi-Process",
		name: "Stacked Rectangle",
		shortName: "st-rect",
		description: "Multiple processes",
		aliases: [
			"procs",
			"processes",
			"stacked-rectangle"
		],
		handler: multiRect
	},
	{
		semanticName: "Stored Data",
		name: "Bow Tie Rectangle",
		shortName: "bow-rect",
		description: "Stored data",
		aliases: ["stored-data", "bow-tie-rectangle"],
		handler: bowTieRect
	},
	{
		semanticName: "Summary",
		name: "Crossed Circle",
		shortName: "cross-circ",
		description: "Summary",
		aliases: ["summary", "crossed-circle"],
		handler: crossedCircle
	},
	{
		semanticName: "Tagged Document",
		name: "Tagged Document",
		shortName: "tag-doc",
		description: "Tagged document",
		aliases: ["tag-doc", "tagged-document"],
		handler: taggedWaveEdgedRectangle
	},
	{
		semanticName: "Tagged Process",
		name: "Tagged Rectangle",
		shortName: "tag-rect",
		description: "Tagged process",
		aliases: [
			"tagged-rectangle",
			"tag-proc",
			"tagged-process"
		],
		handler: taggedRect
	},
	{
		semanticName: "Paper Tape",
		name: "Flag",
		shortName: "flag",
		description: "Paper tape",
		aliases: ["paper-tape"],
		handler: waveRectangle
	},
	{
		semanticName: "Odd",
		name: "Odd",
		shortName: "odd",
		description: "Odd shape",
		internalAliases: ["rect_left_inv_arrow"],
		handler: rect_left_inv_arrow
	},
	{
		semanticName: "Lined Document",
		name: "Lined Document",
		shortName: "lin-doc",
		description: "Lined document",
		aliases: ["lined-document"],
		handler: linedWaveEdgedRect
	}
];
var shapes2 = (/* @__PURE__ */ __name(() => {
	const entries = [...Object.entries({
		state,
		choice,
		note,
		rectWithTitle,
		labelRect,
		iconSquare,
		iconCircle,
		icon,
		iconRounded,
		imageSquare,
		anchor,
		kanbanItem,
		mindmapCircle,
		defaultMindmapNode,
		classBox,
		erBox,
		requirementBox
	}), ...shapesDefs.flatMap((shape) => {
		return [
			shape.shortName,
			..."aliases" in shape ? shape.aliases : [],
			..."internalAliases" in shape ? shape.internalAliases : []
		].map((alias) => [alias, shape.handler]);
	})];
	return Object.fromEntries(entries);
}, "generateShapeMap"))();
function isValidShape(shape) {
	return shape in shapes2;
}
__name(isValidShape, "isValidShape");
var nodeElems = /* @__PURE__ */ new Map();
function insertNode(_x159, _x160, _x161) {
	return _insertNode.apply(this, arguments);
}
function _insertNode() {
	_insertNode = _asyncToGenerator(function* (elem, node, renderOptions) {
		let newEl;
		let el;
		if (node.shape === "rect") if (node.rx && node.ry) node.shape = "roundedRect";
		else node.shape = "squareRect";
		const shapeHandler = node.shape ? shapes2[node.shape] : void 0;
		if (!shapeHandler) throw new Error(`No such shape: ${node.shape}. Please check your syntax.`);
		if (node.link) {
			var _target;
			let target;
			if (renderOptions.config.securityLevel === "sandbox") target = "_top";
			else if (node.linkTarget) target = node.linkTarget || "_blank";
			newEl = elem.insert("svg:a").attr("xlink:href", node.link).attr("target", (_target = target) !== null && _target !== void 0 ? _target : null);
			el = yield shapeHandler(newEl, node, renderOptions);
		} else {
			el = yield shapeHandler(elem, node, renderOptions);
			newEl = el;
		}
		newEl.attr("data-look", handleUndefinedAttr(node.look));
		if (node.tooltip) el.attr("title", node.tooltip);
		nodeElems.set(node.id, newEl);
		if (node.haveCallback) newEl.attr("class", newEl.attr("class") + " clickable");
		return newEl;
	});
	return _insertNode.apply(this, arguments);
}
__name(insertNode, "insertNode");
var setNodeElem = /* @__PURE__ */ __name((elem, node) => {
	nodeElems.set(node.id, elem);
}, "setNodeElem");
var clear2 = /* @__PURE__ */ __name(() => {
	nodeElems.clear();
}, "clear");
var positionNode = /* @__PURE__ */ __name((node) => {
	const el = nodeElems.get(node.id);
	log.trace("Transforming node", node.diff, node, "translate(" + (node.x - node.width / 2 - 5) + ", " + node.width / 2 + ")");
	const padding = 8;
	const diff = node.diff || 0;
	if (node.clusterNode) el.attr("transform", "translate(" + (node.x + diff - node.width / 2) + ", " + (node.y - node.height / 2 - padding) + ")");
	else el.attr("transform", "translate(" + node.x + ", " + node.y + ")");
	return diff;
}, "positionNode");
//#endregion
export { insertNode as a, positionNode as c, insertCluster as i, setNodeElem as l, clear2 as n, isValidShape as o, createLabel_default as r, labelHelper as s, clear as t, updateNodeBounds as u };

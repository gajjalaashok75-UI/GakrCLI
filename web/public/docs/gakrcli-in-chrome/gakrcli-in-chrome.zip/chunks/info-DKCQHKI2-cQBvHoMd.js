import "./chunk-KEIR6QF5-Af8e2JZB.js";
import { C as InfoModule, w as createInfoServices } from "./mermaid-parser.core-DhYO2Vvm.js";
export { InfoModule, createInfoServices };

import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/chunk-7BUUIJ7U.mjs
var computeLabelTransform = /* @__PURE__ */ __name((bbox, useHtmlLabels) => {
	var _bbox$x, _bbox$y;
	if (useHtmlLabels) return "translate(" + -bbox.width / 2 + ", " + -bbox.height / 2 + ")";
	const x = (_bbox$x = bbox.x) !== null && _bbox$x !== void 0 ? _bbox$x : 0;
	const y = (_bbox$y = bbox.y) !== null && _bbox$y !== void 0 ? _bbox$y : 0;
	return "translate(" + -(x + bbox.width / 2) + ", " + -(y + bbox.height / 2) + ")";
}, "computeLabelTransform");
var markerOffsets = {
	aggregation: 17.25,
	extension: 17.25,
	composition: 17.25,
	dependency: 6,
	lollipop: 13.5,
	arrow_point: 4,
	arrow_barb: 0,
	arrow_barb_neo: 5.5
};
var markerOffsets2 = {
	arrow_point: 4,
	arrow_cross: 12.5,
	arrow_circle: 12.5
};
function calculateDeltaAndAngle(point1, point2) {
	if (point1 === void 0 || point2 === void 0) return {
		angle: 0,
		deltaX: 0,
		deltaY: 0
	};
	point1 = pointTransformer(point1);
	point2 = pointTransformer(point2);
	const [x1, y1] = [point1.x, point1.y];
	const [x2, y2] = [point2.x, point2.y];
	const deltaX = x2 - x1;
	const deltaY = y2 - y1;
	return {
		angle: Math.atan(deltaY / deltaX),
		deltaX,
		deltaY
	};
}
__name(calculateDeltaAndAngle, "calculateDeltaAndAngle");
var pointTransformer = /* @__PURE__ */ __name((data) => {
	if (Array.isArray(data)) return {
		x: data[0],
		y: data[1]
	};
	return data;
}, "pointTransformer");
var getLineFunctionsWithOffset = /* @__PURE__ */ __name((edge) => {
	return {
		x: /* @__PURE__ */ __name(function(d, i, data) {
			let offset = 0;
			const DIRECTION = pointTransformer(data[0]).x < pointTransformer(data[data.length - 1]).x ? "left" : "right";
			if (i === 0 && Object.hasOwn(markerOffsets, edge.arrowTypeStart)) {
				const { angle, deltaX } = calculateDeltaAndAngle(data[0], data[1]);
				offset = markerOffsets[edge.arrowTypeStart] * Math.cos(angle) * (deltaX >= 0 ? 1 : -1);
			} else if (i === data.length - 1 && Object.hasOwn(markerOffsets, edge.arrowTypeEnd)) {
				const { angle, deltaX } = calculateDeltaAndAngle(data[data.length - 1], data[data.length - 2]);
				offset = markerOffsets[edge.arrowTypeEnd] * Math.cos(angle) * (deltaX >= 0 ? 1 : -1);
			}
			const differenceToEnd = Math.abs(pointTransformer(d).x - pointTransformer(data[data.length - 1]).x);
			const differenceInYEnd = Math.abs(pointTransformer(d).y - pointTransformer(data[data.length - 1]).y);
			const differenceToStart = Math.abs(pointTransformer(d).x - pointTransformer(data[0]).x);
			const differenceInYStart = Math.abs(pointTransformer(d).y - pointTransformer(data[0]).y);
			const startMarkerHeight = markerOffsets[edge.arrowTypeStart];
			const endMarkerHeight = markerOffsets[edge.arrowTypeEnd];
			const extraRoom = 1;
			if (differenceToEnd < endMarkerHeight && differenceToEnd > 0 && differenceInYEnd < endMarkerHeight) {
				let adjustment = endMarkerHeight + extraRoom - differenceToEnd;
				adjustment *= DIRECTION === "right" ? -1 : 1;
				offset -= adjustment;
			}
			if (differenceToStart < startMarkerHeight && differenceToStart > 0 && differenceInYStart < startMarkerHeight) {
				let adjustment = startMarkerHeight + extraRoom - differenceToStart;
				adjustment *= DIRECTION === "right" ? -1 : 1;
				offset += adjustment;
			}
			return pointTransformer(d).x + offset;
		}, "x"),
		y: /* @__PURE__ */ __name(function(d, i, data) {
			let offset = 0;
			const DIRECTION = pointTransformer(data[0]).y < pointTransformer(data[data.length - 1]).y ? "down" : "up";
			if (i === 0 && Object.hasOwn(markerOffsets, edge.arrowTypeStart)) {
				const { angle, deltaY } = calculateDeltaAndAngle(data[0], data[1]);
				offset = markerOffsets[edge.arrowTypeStart] * Math.abs(Math.sin(angle)) * (deltaY >= 0 ? 1 : -1);
			} else if (i === data.length - 1 && Object.hasOwn(markerOffsets, edge.arrowTypeEnd)) {
				const { angle, deltaY } = calculateDeltaAndAngle(data[data.length - 1], data[data.length - 2]);
				offset = markerOffsets[edge.arrowTypeEnd] * Math.abs(Math.sin(angle)) * (deltaY >= 0 ? 1 : -1);
			}
			const differenceToEnd = Math.abs(pointTransformer(d).y - pointTransformer(data[data.length - 1]).y);
			const differenceInXEnd = Math.abs(pointTransformer(d).x - pointTransformer(data[data.length - 1]).x);
			const differenceToStart = Math.abs(pointTransformer(d).y - pointTransformer(data[0]).y);
			const differenceInXStart = Math.abs(pointTransformer(d).x - pointTransformer(data[0]).x);
			const startMarkerHeight = markerOffsets[edge.arrowTypeStart];
			const endMarkerHeight = markerOffsets[edge.arrowTypeEnd];
			const extraRoom = 1;
			if (differenceToEnd < endMarkerHeight && differenceToEnd > 0 && differenceInXEnd < endMarkerHeight) {
				let adjustment = endMarkerHeight + extraRoom - differenceToEnd;
				adjustment *= DIRECTION === "up" ? -1 : 1;
				offset -= adjustment;
			}
			if (differenceToStart < startMarkerHeight && differenceToStart > 0 && differenceInXStart < startMarkerHeight) {
				let adjustment = startMarkerHeight + extraRoom - differenceToStart;
				adjustment *= DIRECTION === "up" ? -1 : 1;
				offset += adjustment;
			}
			return pointTransformer(d).y + offset;
		}, "y")
	};
}, "getLineFunctionsWithOffset");
//#endregion
export { markerOffsets2 as i, getLineFunctionsWithOffset as n, markerOffsets as r, computeLabelTransform as t };

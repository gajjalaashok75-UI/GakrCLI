import "./_virtual_wxt-html-plugins-DIeKMq_K.js";
import { D as toDisplayString, E as normalizeClass, T as unref, _ as defineComponent, a as createApp, b as onUnmounted, d as createBaseVNode, f as createCommentVNode, g as createVNode, h as createTextVNode, i as _asyncToGenerator, m as createStaticVNode, n as NativeMessageType, p as createElementBlock, t as _plugin_vue_export_helper_default, u as computed, w as ref, x as openBlock, y as onMounted } from "./_plugin-vue_export-helper-DsaS8js6.js";
import { n as useAgentTheme, t as preloadAgentTheme } from "./useAgentTheme-CmxbMqQI.js";
import { t as BACKGROUND_MESSAGE_TYPES } from "./message-types-BDQJBj9s.js";
import { t as LINKS } from "./constants-D3QavKeT.js";
// utils/i18n.ts
/**
* Chrome Extension i18n utility
* Provides safe access to chrome.i18n.getMessage with fallbacks
*/
var fallbackMessages = {
	extensionName: "chrome-mcp-server",
	extensionDescription: "Exposes browser capabilities with your own chrome",
	nativeServerConfigLabel: "Native Server Configuration",
	semanticEngineLabel: "Semantic Engine",
	embeddingModelLabel: "Embedding Model",
	indexDataManagementLabel: "Index Data Management",
	modelCacheManagementLabel: "Model Cache Management",
	statusLabel: "Status",
	runningStatusLabel: "Running Status",
	connectionStatusLabel: "Connection Status",
	lastUpdatedLabel: "Last Updated:",
	connectButton: "Connect",
	disconnectButton: "Disconnect",
	connectingStatus: "Connecting...",
	connectedStatus: "Connected",
	disconnectedStatus: "Disconnected",
	detectingStatus: "Detecting...",
	serviceRunningStatus: "Service Running (Port: {0})",
	serviceNotConnectedStatus: "Service Not Connected",
	connectedServiceNotStartedStatus: "Connected, Service Not Started",
	mcpServerConfigLabel: "MCP Server Configuration",
	connectionPortLabel: "Connection Port",
	refreshStatusButton: "Refresh Status",
	copyConfigButton: "Copy Configuration",
	retryButton: "Retry",
	cancelButton: "Cancel",
	confirmButton: "Confirm",
	saveButton: "Save",
	closeButton: "Close",
	resetButton: "Reset",
	initializingStatus: "Initializing...",
	processingStatus: "Processing...",
	loadingStatus: "Loading...",
	clearingStatus: "Clearing...",
	cleaningStatus: "Cleaning...",
	downloadingStatus: "Downloading...",
	semanticEngineReadyStatus: "Semantic Engine Ready",
	semanticEngineInitializingStatus: "Semantic Engine Initializing...",
	semanticEngineInitFailedStatus: "Semantic Engine Initialization Failed",
	semanticEngineNotInitStatus: "Semantic Engine Not Initialized",
	initSemanticEngineButton: "Initialize Semantic Engine",
	reinitializeButton: "Reinitialize",
	downloadingModelStatus: "Downloading Model... {0}%",
	switchingModelStatus: "Switching Model...",
	modelLoadedStatus: "Model Loaded",
	modelFailedStatus: "Model Failed to Load",
	lightweightModelDescription: "Lightweight Multilingual Model",
	betterThanSmallDescription: "Slightly larger than e5-small, but better performance",
	multilingualModelDescription: "Multilingual Semantic Model",
	fastPerformance: "Fast",
	balancedPerformance: "Balanced",
	accuratePerformance: "Accurate",
	networkErrorMessage: "Network connection error, please check network and retry",
	modelCorruptedErrorMessage: "Model file corrupted or incomplete, please retry download",
	unknownErrorMessage: "Unknown error, please check if your network can access HuggingFace",
	permissionDeniedErrorMessage: "Permission denied",
	timeoutErrorMessage: "Operation timed out",
	indexedPagesLabel: "Indexed Pages",
	indexSizeLabel: "Index Size",
	activeTabsLabel: "Active Tabs",
	vectorDocumentsLabel: "Vector Documents",
	cacheSizeLabel: "Cache Size",
	cacheEntriesLabel: "Cache Entries",
	clearAllDataButton: "Clear All Data",
	clearAllCacheButton: "Clear All Cache",
	cleanExpiredCacheButton: "Clean Expired Cache",
	exportDataButton: "Export Data",
	importDataButton: "Import Data",
	confirmClearDataTitle: "Confirm Clear Data",
	settingsTitle: "Settings",
	aboutTitle: "About",
	helpTitle: "Help",
	clearDataWarningMessage: "This operation will clear all indexed webpage content and vector data, including:",
	clearDataList1: "All webpage text content index",
	clearDataList2: "Vector embedding data",
	clearDataList3: "Search history and cache",
	clearDataIrreversibleWarning: "This operation is irreversible! After clearing, you need to browse webpages again to rebuild the index.",
	confirmClearButton: "Confirm Clear",
	cacheDetailsLabel: "Cache Details",
	noCacheDataMessage: "No cache data",
	loadingCacheInfoStatus: "Loading cache information...",
	processingCacheStatus: "Processing cache...",
	expiredLabel: "Expired",
	bookmarksBarLabel: "Bookmarks Bar",
	newTabLabel: "New Tab",
	currentPageLabel: "Current Page",
	menuLabel: "Menu",
	navigationLabel: "Navigation",
	mainContentLabel: "Main Content",
	languageSelectorLabel: "Language",
	themeLabel: "Theme",
	lightTheme: "Light",
	darkTheme: "Dark",
	autoTheme: "Auto",
	advancedSettingsLabel: "Advanced Settings",
	debugModeLabel: "Debug Mode",
	verboseLoggingLabel: "Verbose Logging",
	successNotification: "Operation completed successfully",
	warningNotification: "Warning: Please review before proceeding",
	infoNotification: "Information",
	configCopiedNotification: "Configuration copied to clipboard",
	dataClearedNotification: "Data cleared successfully",
	bytesUnit: "bytes",
	kilobytesUnit: "KB",
	megabytesUnit: "MB",
	gigabytesUnit: "GB",
	itemsUnit: "items",
	pagesUnit: "pages",
	nativeServerConfig: "Native Server Configuration",
	runningStatus: "Running Status",
	refreshStatus: "Refresh Status",
	lastUpdated: "Last Updated:",
	mcpServerConfig: "MCP Server Configuration",
	connectionPort: "Connection Port",
	connecting: "Connecting...",
	disconnect: "Disconnect",
	connect: "Connect",
	semanticEngine: "Semantic Engine",
	embeddingModel: "Embedding Model",
	retry: "Retry",
	indexDataManagement: "Index Data Management",
	clearing: "Clearing...",
	clearAllData: "Clear All Data",
	copyConfig: "Copy Configuration",
	serviceRunning: "Service Running (Port: {0})",
	connectedServiceNotStarted: "Connected, Service Not Started. Run `gakrcli --chrome-extension` to start the side panel.",
	serviceNotConnected: "Service Not Connected",
	detecting: "Detecting...",
	lightweightModel: "Lightweight Multilingual Model",
	betterThanSmall: "Slightly larger than e5-small, but better performance",
	multilingualModel: "Multilingual Semantic Model",
	fast: "Fast",
	balanced: "Balanced",
	accurate: "Accurate",
	semanticEngineReady: "Semantic Engine Ready",
	semanticEngineInitializing: "Semantic Engine Initializing...",
	semanticEngineInitFailed: "Semantic Engine Initialization Failed",
	semanticEngineNotInit: "Semantic Engine Not Initialized",
	downloadingModel: "Downloading Model... {0}%",
	switchingModel: "Switching Model...",
	networkError: "Network connection error, please check network and retry",
	modelCorrupted: "Model file corrupted or incomplete, please retry download",
	unknownError: "Unknown error, please check if your network can access HuggingFace",
	reinitialize: "Reinitialize",
	initializing: "Initializing...",
	initSemanticEngine: "Initialize Semantic Engine",
	indexedPages: "Indexed Pages",
	indexSize: "Index Size",
	activeTabs: "Active Tabs",
	vectorDocuments: "Vector Documents",
	confirmClearData: "Confirm Clear Data",
	clearDataWarning: "This operation will clear all indexed webpage content and vector data, including:",
	clearDataIrreversible: "This operation is irreversible! After clearing, you need to browse webpages again to rebuild the index.",
	confirmClear: "Confirm Clear",
	cancel: "Cancel",
	confirm: "Confirm",
	processing: "Processing...",
	modelCacheManagement: "Model Cache Management",
	cacheSize: "Cache Size",
	cacheEntries: "Cache Entries",
	cacheDetails: "Cache Details",
	noCacheData: "No cache data",
	loadingCacheInfo: "Loading cache information...",
	processingCache: "Processing cache...",
	cleaning: "Cleaning...",
	cleanExpiredCache: "Clean Expired Cache",
	clearAllCache: "Clear All Cache",
	expired: "Expired",
	bookmarksBar: "Bookmarks Bar"
};
/**
* Safe i18n message getter with fallback support
* @param key Message key
* @param substitutions Optional substitution values
* @returns Localized message or fallback
*/
function getMessage(key, substitutions) {
	try {
		if (typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage) {
			const message = chrome.i18n.getMessage(key, substitutions);
			if (message) return message;
		}
	} catch (error) {
		console.warn(`Failed to get i18n message for key "${key}":`, error);
	}
	let fallback = fallbackMessages[key] || key;
	if (substitutions && substitutions.length > 0) substitutions.forEach((value, index) => {
		fallback = fallback.replace(`{${index}}`, value);
	});
	return fallback;
}
// entrypoints/popup/components/icons/BoltIcon.vue
var BoltIcon_default = /* @__PURE__ */ defineComponent({
	__name: "BoltIcon",
	props: { className: { default: "icon-default" } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("svg", {
				xmlns: "http://www.w3.org/2000/svg",
				fill: "none",
				viewBox: "0 0 24 24",
				"stroke-width": "1.5",
				stroke: "currentColor",
				class: normalizeClass(__props.className)
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
				"stroke-linecap": "round",
				"stroke-linejoin": "round",
				d: "m3.75 13.5 10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75Z"
			}, null, -1)])], 2);
		};
	}
});
// entrypoints/popup/components/icons/RefreshIcon.vue
var RefreshIcon_default = /* @__PURE__ */ defineComponent({
	__name: "RefreshIcon",
	props: { className: { default: "icon-default" } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("svg", {
				xmlns: "http://www.w3.org/2000/svg",
				fill: "none",
				viewBox: "0 0 24 24",
				"stroke-width": "2",
				stroke: "currentColor",
				class: normalizeClass(__props.className)
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
				"stroke-linecap": "round",
				"stroke-linejoin": "round",
				d: "M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99"
			}, null, -1)])], 2);
		};
	}
});
// entrypoints/popup/App.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = ["data-agent-theme"];
var _hoisted_2 = { class: "home-view" };
var _hoisted_3 = { class: "content" };
var _hoisted_4 = { class: "section" };
var _hoisted_5 = { class: "section-title" };
var _hoisted_6 = { class: "config-card" };
var _hoisted_7 = { class: "status-section" };
var _hoisted_8 = { class: "status-header" };
var _hoisted_9 = { class: "status-label" };
var _hoisted_10 = ["title"];
var _hoisted_11 = { class: "status-info" };
var _hoisted_12 = { class: "status-text" };
var _hoisted_13 = {
	key: 0,
	class: "status-timestamp"
};
var _hoisted_14 = {
	key: 0,
	class: "mcp-config-section"
};
var _hoisted_15 = { class: "mcp-config-header" };
var _hoisted_16 = { class: "mcp-config-label" };
var _hoisted_17 = { class: "mcp-config-content" };
var _hoisted_18 = { class: "mcp-config-json" };
var _hoisted_19 = { class: "port-section" };
var _hoisted_20 = {
	for: "port",
	class: "port-label"
};
var _hoisted_21 = ["value"];
var _hoisted_22 = ["disabled"];
var _hoisted_23 = { class: "section" };
var _hoisted_24 = { class: "section-title" };
// entrypoints/popup/App.vue
var App_default = /*#__PURE__*/ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "App",
	setup(__props) {
		const { theme: agentTheme, initTheme } = useAgentTheme();
		const nativeConnectionStatus = ref("unknown");
		const isConnecting = ref(false);
		const nativeServerPort = ref(12306);
		const serverStatus = ref({
			isRunning: false,
			lastUpdated: Date.now()
		});
		const showMcpConfig = computed(() => {
			return nativeConnectionStatus.value === "connected" && serverStatus.value.isRunning;
		});
		const copyButtonText = ref(getMessage("copyConfigButton"));
		const mcpConfigJson = computed(() => {
			const config = { mcpServers: { "streamable-mcp-server": {
				type: "streamable-http",
				url: `http://127.0.0.1:${serverStatus.value.port || nativeServerPort.value}/mcp`
			} } };
			return JSON.stringify(config, null, 2);
		});
		const getStatusClass = () => {
			if (nativeConnectionStatus.value === "connected") {
				if (serverStatus.value.isRunning) return "bg-emerald-500";
				else return "bg-yellow-500";
			} else if (nativeConnectionStatus.value === "disconnected") return "bg-red-500";
			else return "bg-gray-500";
		};
		function openSidepanelAndClose(_x) {
			return _openSidepanelAndClose.apply(this, arguments);
		}
		function _openSidepanelAndClose() {
			_openSidepanelAndClose = _asyncToGenerator(function* (tab) {
				try {
					var _chrome$sidePanel;
					const current = yield chrome.windows.getCurrent();
					if ((_chrome$sidePanel = chrome.sidePanel) === null || _chrome$sidePanel === void 0 ? void 0 : _chrome$sidePanel.setOptions) yield chrome.sidePanel.setOptions({
						path: `sidepanel.html?tab=${tab}`,
						enabled: true
					});
					if (chrome.sidePanel && chrome.sidePanel.open) yield chrome.sidePanel.open({ windowId: current.id });
					window.close();
				} catch (e) {
					console.warn(`Failed to open sidepanel (${tab}):`, e);
				}
			});
			return _openSidepanelAndClose.apply(this, arguments);
		}
		function openTerminalSidepanel() {
			openSidepanelAndClose("terminal");
		}
		function openTroubleshooting() {
			return _openTroubleshooting.apply(this, arguments);
		}
		function _openTroubleshooting() {
			_openTroubleshooting = _asyncToGenerator(function* () {
				try {
					yield chrome.tabs.create({ url: LINKS.TROUBLESHOOTING });
				} catch (_unused) {}
			});
			return _openTroubleshooting.apply(this, arguments);
		}
		const getStatusText = () => {
			if (nativeConnectionStatus.value === "connected") {
				if (serverStatus.value.isRunning) return getMessage("serviceRunningStatus", [(serverStatus.value.port || "Unknown").toString()]);
				else return getMessage("connectedServiceNotStartedStatus");
			} else if (nativeConnectionStatus.value === "disconnected") return getMessage("serviceNotConnectedStatus");
			else return getMessage("detectingStatus");
		};
		const updatePort = function() {
			var _ref = _asyncToGenerator(function* (event) {
				const target = event.target;
				const newPort = Number(target.value);
				nativeServerPort.value = newPort;
				yield savePortPreference(newPort);
			});
			return function updatePort(_x2) {
				return _ref.apply(this, arguments);
			};
		}();
		const checkNativeConnection = function() {
			var _ref2 = _asyncToGenerator(function* () {
				try {
					const response = yield chrome.runtime.sendMessage({ type: "ping_native" });
					nativeConnectionStatus.value = (response === null || response === void 0 ? void 0 : response.connected) ? "connected" : "disconnected";
				} catch (error) {
					console.error("Failed to detect Native connection status:", error);
					nativeConnectionStatus.value = "disconnected";
				}
			});
			return function checkNativeConnection() {
				return _ref2.apply(this, arguments);
			};
		}();
		const checkServerStatus = function() {
			var _ref3 = _asyncToGenerator(function* () {
				try {
					const response = yield chrome.runtime.sendMessage({ type: BACKGROUND_MESSAGE_TYPES.GET_SERVER_STATUS });
					if ((response === null || response === void 0 ? void 0 : response.success) && response.serverStatus) serverStatus.value = response.serverStatus;
					if ((response === null || response === void 0 ? void 0 : response.connected) !== void 0) nativeConnectionStatus.value = response.connected ? "connected" : "disconnected";
				} catch (error) {
					console.error("Failed to check server status:", error);
				}
			});
			return function checkServerStatus() {
				return _ref3.apply(this, arguments);
			};
		}();
		const refreshServerStatus = function() {
			var _ref4 = _asyncToGenerator(function* () {
				try {
					const response = yield chrome.runtime.sendMessage({ type: BACKGROUND_MESSAGE_TYPES.REFRESH_SERVER_STATUS });
					if ((response === null || response === void 0 ? void 0 : response.success) && response.serverStatus) serverStatus.value = response.serverStatus;
					if ((response === null || response === void 0 ? void 0 : response.connected) !== void 0) nativeConnectionStatus.value = response.connected ? "connected" : "disconnected";
				} catch (error) {
					console.error("Failed to refresh server status:", error);
				}
			});
			return function refreshServerStatus() {
				return _ref4.apply(this, arguments);
			};
		}();
		const copyMcpConfig = function() {
			var _ref5 = _asyncToGenerator(function* () {
				try {
					yield navigator.clipboard.writeText(mcpConfigJson.value);
					copyButtonText.value = "✅" + getMessage("configCopiedNotification");
					setTimeout(() => {
						copyButtonText.value = getMessage("copyConfigButton");
					}, 2e3);
				} catch (error) {
					console.error("Failed to copy config:", error);
					copyButtonText.value = "❌" + getMessage("networkErrorMessage");
					setTimeout(() => {
						copyButtonText.value = getMessage("copyConfigButton");
					}, 2e3);
				}
			});
			return function copyMcpConfig() {
				return _ref5.apply(this, arguments);
			};
		}();
		const testNativeConnection = function() {
			var _ref6 = _asyncToGenerator(function* () {
				if (isConnecting.value) return;
				isConnecting.value = true;
				try {
					if (nativeConnectionStatus.value === "connected") {
						yield chrome.runtime.sendMessage({ type: "disconnect_native" });
						nativeConnectionStatus.value = "disconnected";
					} else {
						console.log(`Attempting to connect to port: ${nativeServerPort.value}`);
						const response = yield chrome.runtime.sendMessage({
							type: "connectNative",
							port: nativeServerPort.value
						});
						if (response && response.success) {
							nativeConnectionStatus.value = "connected";
							console.log("Connection successful:", response);
							yield savePortPreference(nativeServerPort.value);
						} else {
							nativeConnectionStatus.value = "disconnected";
							console.error("Connection failed:", response);
						}
					}
				} catch (error) {
					console.error("Connection test failed:", error);
					nativeConnectionStatus.value = "disconnected";
				} finally {
					isConnecting.value = false;
				}
			});
			return function testNativeConnection() {
				return _ref6.apply(this, arguments);
			};
		}();
		const savePortPreference = function() {
			var _ref7 = _asyncToGenerator(function* (port) {
				try {
					yield chrome.storage.local.set({ nativeServerPort: port });
					console.log(`Port preference saved: ${port}`);
				} catch (error) {
					console.error("Failed to save port preference:", error);
				}
			});
			return function savePortPreference(_x3) {
				return _ref7.apply(this, arguments);
			};
		}();
		const loadPortPreference = function() {
			var _ref8 = _asyncToGenerator(function* () {
				try {
					const result = yield chrome.storage.local.get(["nativeServerPort"]);
					if (result.nativeServerPort) {
						nativeServerPort.value = result.nativeServerPort;
						console.log(`Port preference loaded: ${result.nativeServerPort}`);
					}
				} catch (error) {
					console.error("Failed to load port preference:", error);
				}
			});
			return function loadPortPreference() {
				return _ref8.apply(this, arguments);
			};
		}();
		const setupServerStatusListener = () => {
			const onMessage = (message) => {
				if (message.type === BACKGROUND_MESSAGE_TYPES.SERVER_STATUS_CHANGED && message.payload) {
					serverStatus.value = message.payload;
					console.log("Server status updated:", message.payload);
				}
			};
			chrome.runtime.onMessage.addListener(onMessage);
			window.__popup_onMessage = onMessage;
		};
		onMounted(_asyncToGenerator(function* () {
			yield initTheme();
			yield loadPortPreference();
			yield checkNativeConnection();
			yield checkServerStatus();
			setupServerStatusListener();
		}));
		onUnmounted(() => {
			try {
				var _chrome;
				const msgFn = window.__popup_onMessage;
				if (msgFn && ((_chrome = chrome) === null || _chrome === void 0 || (_chrome = _chrome.runtime) === null || _chrome === void 0 || (_chrome = _chrome.onMessage) === null || _chrome === void 0 ? void 0 : _chrome.removeListener)) chrome.runtime.onMessage.removeListener(msgFn);
			} catch (_unused2) {}
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				class: "popup-container agent-theme",
				"data-agent-theme": unref(agentTheme)
			}, [createBaseVNode("div", _hoisted_2, [
				_cache[3] || (_cache[3] = createBaseVNode("div", { class: "header" }, [createBaseVNode("div", { class: "header-content" }, [createBaseVNode("h1", { class: "header-title" }, "GakrCLI in Chrome")])], -1)),
				createBaseVNode("div", _hoisted_3, [createBaseVNode("div", _hoisted_4, [createBaseVNode("h2", _hoisted_5, toDisplayString(unref(getMessage)("nativeServerConfigLabel")), 1), createBaseVNode("div", _hoisted_6, [
					createBaseVNode("div", _hoisted_7, [
						createBaseVNode("div", _hoisted_8, [createBaseVNode("p", _hoisted_9, toDisplayString(unref(getMessage)("runningStatusLabel")), 1), createBaseVNode("button", {
							class: "refresh-status-button",
							onClick: refreshServerStatus,
							title: unref(getMessage)("refreshStatusButton")
						}, [createVNode(unref(RefreshIcon_default), { className: "icon-small" })], 8, _hoisted_10)]),
						createBaseVNode("div", _hoisted_11, [createBaseVNode("span", { class: normalizeClass(["status-dot", getStatusClass()]) }, null, 2), createBaseVNode("span", _hoisted_12, toDisplayString(getStatusText()), 1)]),
						serverStatus.value.lastUpdated ? (openBlock(), createElementBlock("div", _hoisted_13, toDisplayString(unref(getMessage)("lastUpdatedLabel")) + " " + toDisplayString(new Date(serverStatus.value.lastUpdated).toLocaleTimeString()), 1)) : createCommentVNode("", true)
					]),
					showMcpConfig.value ? (openBlock(), createElementBlock("div", _hoisted_14, [createBaseVNode("div", _hoisted_15, [createBaseVNode("p", _hoisted_16, toDisplayString(unref(getMessage)("mcpServerConfigLabel")), 1), createBaseVNode("button", {
						class: "copy-config-button",
						onClick: copyMcpConfig
					}, toDisplayString(copyButtonText.value), 1)]), createBaseVNode("div", _hoisted_17, [createBaseVNode("pre", _hoisted_18, toDisplayString(mcpConfigJson.value), 1)])])) : createCommentVNode("", true),
					createBaseVNode("div", _hoisted_19, [createBaseVNode("label", _hoisted_20, toDisplayString(unref(getMessage)("connectionPortLabel")), 1), createBaseVNode("input", {
						type: "text",
						id: "port",
						value: nativeServerPort.value,
						onInput: updatePort,
						class: "port-input"
					}, null, 40, _hoisted_21)]),
					createBaseVNode("button", {
						class: "connect-button",
						disabled: isConnecting.value,
						onClick: testNativeConnection
					}, [createVNode(unref(BoltIcon_default)), createBaseVNode("span", null, toDisplayString(isConnecting.value ? unref(getMessage)("connectingStatus") : nativeConnectionStatus.value === "connected" ? unref(getMessage)("disconnectButton") : unref(getMessage)("connectButton")), 1)], 8, _hoisted_22)
				])]), createBaseVNode("div", _hoisted_23, [createBaseVNode("h2", _hoisted_24, toDisplayString(unref(getMessage)("managementEntryLabel")), 1), createBaseVNode("div", { class: "entry-card" }, [createBaseVNode("button", {
					class: "entry-item",
					onClick: openTerminalSidepanel
				}, [..._cache[0] || (_cache[0] = [createStaticVNode("<div class=\"entry-icon agent\" data-v-e7cd1ec9><svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" data-v-e7cd1ec9><path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M4 17l6-5-6-5\" data-v-e7cd1ec9></path><path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M12 19h8\" data-v-e7cd1ec9></path></svg></div><div class=\"entry-content\" data-v-e7cd1ec9><span class=\"entry-title\" data-v-e7cd1ec9>AI Assistant</span><span class=\"entry-desc\" data-v-e7cd1ec9>Open the GakrCLI terminal</span></div><svg class=\"entry-arrow\" viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" data-v-e7cd1ec9><path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M9 5l7 7-7 7\" data-v-e7cd1ec9></path></svg>", 3)])])])])]),
				createBaseVNode("div", { class: "footer" }, [createBaseVNode("div", { class: "footer-links" }, [createBaseVNode("button", {
					class: "footer-link",
					onClick: openTroubleshooting,
					title: "Troubleshooting"
				}, [..._cache[1] || (_cache[1] = [createBaseVNode("svg", {
					class: "w-4 h-4",
					fill: "none",
					stroke: "currentColor",
					viewBox: "0 0 24 24"
				}, [createBaseVNode("path", {
					"stroke-linecap": "round",
					"stroke-linejoin": "round",
					"stroke-width": "2",
					d: "M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
				})], -1), createTextVNode(" Docs ", -1)])])]), _cache[2] || (_cache[2] = createBaseVNode("p", { class: "footer-text" }, "GakrCLI in Chrome", -1))])
			])], 8, _hoisted_1);
		};
	}
}), [["__scopeId", "data-v-e7cd1ec9"]]);
// entrypoints/popup/main.ts
preloadAgentTheme().then(() => {
	chrome.runtime.sendMessage({ type: NativeMessageType.ENSURE_NATIVE }).catch(() => {});
	createApp(App_default).mount("#app");
});

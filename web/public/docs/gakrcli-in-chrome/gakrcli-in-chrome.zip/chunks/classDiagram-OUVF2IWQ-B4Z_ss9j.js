import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import "./src-C3sq9HJl.js";
import "./chunk-WYO6CB5R-DF29PLGk.js";
import "./chunk-ICXQ74PX-uHG3Ffj0.js";
import "./chunk-HOUHSVGY-CVL8H-HK.js";
import "./chunk-Q4XR5HBZ-DZCdVpNm.js";
import "./chunk-7BUUIJ7U-C8VFPhS9.js";
import "./chunk-OGEWGWER-uLtBsKke.js";
import "./chunk-32BRIVSS-mQyOQPzM.js";
import "./chunk-XXDRQBXY-CWeuWqam.js";
import "./chunk-VR4S4FIN-C3U7dMKe.js";
import "./chunk-C7G6YPKG-DYyxSEiR.js";
import "./chunk-ZGVPDNZ5-wnE8lhSD.js";
import "./chunk-52WLFC77-Cn5lWL_k.js";
import "./chunk-FWX5IMBZ-CKLEaB0T.js";
import { i as styles_default, n as classDiagram_default, r as classRenderer_v3_unified_default, t as ClassDB } from "./chunk-V7JOEXUC-5C3inbYb.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/classDiagram-OUVF2IWQ.mjs
var diagram = {
	parser: classDiagram_default,
	get db() {
		return new ClassDB();
	},
	renderer: classRenderer_v3_unified_default,
	styles: styles_default,
	init: /* @__PURE__ */ __name((cnf) => {
		if (!cnf.class) cnf.class = {};
		cnf.class.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
	}, "init")
};
//#endregion
export { diagram };

const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["chunks/dagre-VKFMJZFB-B5i8U5kp.js","chunks/_plugin-vue_export-helper-BdaNZm_w.js","chunks/chunk-Y2CYZVJY-CfdURDvj.js","chunks/src-C3sq9HJl.js","chunks/rolldown-runtime-FDOR9p9I.js","chunks/chunk-WYO6CB5R-D3hdW-kf.js","chunks/sidepanel-Dgx6MxOv.js","chunks/_virtual_wxt-html-plugins-BsPm7yBB.js","chunks/message-types-DNiEbw2t.js","chunks/useAgentTheme-DHgIUbEY.js","assets/useAgentTheme-BLMK_VMu.css","assets/sidepanel-D7lEMEP9.css","chunks/chunk-ICXQ74PX-BROveA7q.js","chunks/dist-RJ87k0El.js","chunks/chunk-HOUHSVGY-6mKlY5gd.js","chunks/chunk-Q4XR5HBZ-zk1zulYp.js","chunks/chunk-7BUUIJ7U-C8VFPhS9.js","chunks/chunk-OGEWGWER-CRC47pvB.js","chunks/graphlib-BeRFn2Zg.js","chunks/dagre-DCesMOFZ.js","chunks/map-SQcUXzqS.js","chunks/chunk-RYQCIY6F-DgeY5dqo.js","chunks/chunk-C7G6YPKG-C0Dwy7It.js","chunks/chunk-ZGVPDNZ5-DeHkl6jW.js","chunks/rough.esm-Bw0dQC91.js","chunks/chunk-52WLFC77-Cz74qZ02.js","chunks/line-9dcLtzFN.js","chunks/path-Cd6hffiG.js","chunks/array-75Ih5Qg4.js","chunks/swimlanes-5IMT3BWC-BgqvPcGA.js","chunks/cose-bilkent-JH36ORCC-C-7D8LSH.js","chunks/cytoscape.esm-CjrPWmKD.js"])))=>i.map(i=>d[i]);
import { o as _asyncToGenerator } from "./_plugin-vue_export-helper-BdaNZm_w.js";
import { _ as __vitePreload } from "./sidepanel-Dgx6MxOv.js";
import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import { m as log } from "./src-C3sq9HJl.js";
import { b as getConfig, s as common_default } from "./chunk-WYO6CB5R-D3hdW-kf.js";
import { d as interpolateToCurve } from "./chunk-ICXQ74PX-BROveA7q.js";
import { a as insertNode, i as insertCluster, s as labelHelper } from "./chunk-ZGVPDNZ5-DeHkl6jW.js";
import { a as markers_default, i as insertEdgeLabel, o as positionEdgeLabel, r as insertEdge } from "./chunk-52WLFC77-Cz74qZ02.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/chunk-FWX5IMBZ.mjs
var internalHelpers = {
	common: common_default,
	getConfig,
	insertCluster,
	insertEdge,
	insertEdgeLabel,
	insertMarkers: markers_default,
	insertNode,
	interpolateToCurve,
	labelHelper,
	log,
	positionEdgeLabel
};
var layoutAlgorithms = {};
var registerLayoutLoaders = /* @__PURE__ */ __name((loaders) => {
	for (const loader of loaders) layoutAlgorithms[loader.name] = loader;
}, "registerLayoutLoaders");
(/* @__PURE__ */ __name(() => {
	registerLayoutLoaders([
		{
			name: "dagre",
			loader: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
				return yield __vitePreload(() => import("./dagre-VKFMJZFB-B5i8U5kp.js"), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28]));
			}), "loader")
		},
		{
			name: "swimlane",
			loader: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
				return yield __vitePreload(() => import("./swimlanes-5IMT3BWC-BgqvPcGA.js"), __vite__mapDeps([29,1,6,7,8,9,10,11,2,3,4,5,12,13,14,15,16,17,18,21,20,22,23,24,25,26,27,28]));
			}), "loader")
		},
		...[{
			name: "cose-bilkent",
			loader: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
				return yield __vitePreload(() => import("./cose-bilkent-JH36ORCC-C-7D8LSH.js"), __vite__mapDeps([30,4,1,2,3,31]));
			}), "loader")
		}]
	]);
}, "registerDefaultLayoutLoaders"))();
var render = /* @__PURE__ */ __name(function() {
	var _ref = _asyncToGenerator(function* (data4Layout, svg, positions) {
		if (!(data4Layout.layoutAlgorithm in layoutAlgorithms)) throw new Error(`Unknown layout algorithm: ${data4Layout.layoutAlgorithm}`);
		if (data4Layout.diagramId) for (const node of data4Layout.nodes) {
			const originalDomId = node.domId || node.id;
			node.domId = `${data4Layout.diagramId}-${originalDomId}`;
		}
		const layoutDefinition = layoutAlgorithms[data4Layout.layoutAlgorithm];
		const layoutRenderer = yield layoutDefinition.loader();
		const { theme, themeVariables } = data4Layout.config;
		const { useGradient, gradientStart, gradientStop } = themeVariables;
		const svgId = svg.attr("id");
		svg.append("defs").append("filter").attr("id", `${svgId}-drop-shadow`).attr("height", "130%").attr("width", "130%").append("feDropShadow").attr("dx", "4").attr("dy", "4").attr("stdDeviation", 0).attr("flood-opacity", "0.06").attr("flood-color", `${(theme === null || theme === void 0 ? void 0 : theme.includes("dark")) ? "#FFFFFF" : "#000000"}`);
		svg.append("defs").append("filter").attr("id", `${svgId}-drop-shadow-small`).attr("height", "150%").attr("width", "150%").append("feDropShadow").attr("dx", "2").attr("dy", "2").attr("stdDeviation", 0).attr("flood-opacity", "0.06").attr("flood-color", `${(theme === null || theme === void 0 ? void 0 : theme.includes("dark")) ? "#FFFFFF" : "#000000"}`);
		if (useGradient) {
			const gradient = svg.append("linearGradient").attr("id", svg.attr("id") + "-gradient").attr("gradientUnits", "objectBoundingBox").attr("x1", "0%").attr("y1", "0%").attr("x2", "100%").attr("y2", "0%");
			gradient.append("svg:stop").attr("offset", "0%").attr("stop-color", gradientStart).attr("stop-opacity", 1);
			gradient.append("svg:stop").attr("offset", "100%").attr("stop-color", gradientStop).attr("stop-opacity", 1);
		}
		return layoutRenderer.render(data4Layout, svg, internalHelpers, { algorithm: layoutDefinition.algorithm }, positions);
	});
	return function(_x, _x2, _x3) {
		return _ref.apply(this, arguments);
	};
}(), "render");
var getRegisteredLayoutAlgorithm = /* @__PURE__ */ __name((algorithm = "", { fallback = "dagre" } = {}) => {
	if (algorithm in layoutAlgorithms) return algorithm;
	if (fallback in layoutAlgorithms) {
		log.warn(`Layout algorithm ${algorithm} is not registered. Using ${fallback} as fallback.`);
		return fallback;
	}
	throw new Error(`Both layout algorithms ${algorithm} and ${fallback} are not registered.`);
}, "getRegisteredLayoutAlgorithm");
//#endregion
export { registerLayoutLoaders as n, render as r, getRegisteredLayoutAlgorithm as t };

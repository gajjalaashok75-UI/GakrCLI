import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/sizeCapture-X5ZJPWSS.mjs
var DDLT_SIZE_CAPTURE_VERSION = 1;
function getCaptureGlobal() {
	if (typeof globalThis === "undefined") return;
	return globalThis;
}
__name(getCaptureGlobal, "getCaptureGlobal");
function shouldCaptureSizes() {
	var _getCaptureGlobal;
	return Boolean((_getCaptureGlobal = getCaptureGlobal()) === null || _getCaptureGlobal === void 0 ? void 0 : _getCaptureGlobal.mermaidCaptureSizes);
}
__name(shouldCaptureSizes, "shouldCaptureSizes");
function capturedFromLocation() {
	if (typeof location === "undefined") return "browser-dev";
	return `${location.pathname}${location.search}`;
}
__name(capturedFromLocation, "capturedFromLocation");
function emitCapturedSizes(captured, element) {
	var _ref, _ownerSvg$id, _g$mermaidCapturedSiz;
	const g = getCaptureGlobal();
	if (!g) return;
	const domNode = element.node();
	const ownerSvg = (_ref = domNode && "ownerSVGElement" in domNode ? domNode.ownerSVGElement : null) !== null && _ref !== void 0 ? _ref : domNode;
	const svgId = (_ownerSvg$id = ownerSvg === null || ownerSvg === void 0 ? void 0 : ownerSvg.id) !== null && _ownerSvg$id !== void 0 ? _ownerSvg$id : "(unknown)";
	(_g$mermaidCapturedSiz = g.mermaidCapturedSizes) !== null && _g$mermaidCapturedSiz !== void 0 || (g.mermaidCapturedSizes = []);
	const entry = {
		svgId,
		sizes: captured
	};
	g.mermaidCapturedSizes.push(entry);
	g.mermaidLastCapturedSizes = entry;
}
__name(emitCapturedSizes, "emitCapturedSizes");
function captureNodeSizes(element, data4Layout) {
	const nodes = [];
	for (const node of data4Layout.nodes) {
		var _node$width, _node$height;
		if (node.isGroup) continue;
		nodes.push({
			id: node.id,
			width: (_node$width = node.width) !== null && _node$width !== void 0 ? _node$width : 0,
			height: (_node$height = node.height) !== null && _node$height !== void 0 ? _node$height : 0
		});
	}
	if (nodes.length === 0) return;
	emitCapturedSizes({
		metadata: {
			captureVersion: DDLT_SIZE_CAPTURE_VERSION,
			capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
			capturedFrom: capturedFromLocation()
		},
		nodes
	}, element);
}
__name(captureNodeSizes, "captureNodeSizes");
//#endregion
export { captureNodeSizes, shouldCaptureSizes };

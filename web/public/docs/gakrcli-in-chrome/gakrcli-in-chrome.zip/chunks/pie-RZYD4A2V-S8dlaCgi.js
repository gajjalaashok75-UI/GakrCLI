import "./chunk-KEIR6QF5-Af8e2JZB.js";
import { b as createPieServices, y as PieModule } from "./mermaid-parser.core-98BDf-ly.js";
export { PieModule, createPieServices };

import "./chunk-KEIR6QF5-Af8e2JZB.js";
import { S as createPacketServices, x as PacketModule } from "./mermaid-parser.core-98BDf-ly.js";
export { PacketModule, createPacketServices };

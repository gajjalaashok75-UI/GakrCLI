import { o as _asyncToGenerator } from "./_plugin-vue_export-helper-BdaNZm_w.js";
import { n as parse } from "./mermaid-parser.core-98BDf-ly.js";
import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import { m as log } from "./src-C3sq9HJl.js";
import { c as configureSvgSize } from "./chunk-WYO6CB5R-D3hdW-kf.js";
import { t as selectSvgElement } from "./chunk-VAUOI2AC-BR-opl7u.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/infoDiagram-FWYZ7A6U.mjs
var parser = { parse: /* @__PURE__ */ __name(function() {
	var _ref = _asyncToGenerator(function* (input) {
		const ast = yield parse("info", input);
		log.debug(ast);
	});
	return function(_x) {
		return _ref.apply(this, arguments);
	};
}(), "parse") };
var DEFAULT_INFO_DB = { version: "11.16.0" };
var diagram = {
	parser,
	db: { getVersion: /* @__PURE__ */ __name(() => DEFAULT_INFO_DB.version, "getVersion") },
	renderer: { draw: /* @__PURE__ */ __name((text, id, version) => {
		log.debug("rendering info diagram\n" + text);
		const svg = selectSvgElement(id);
		configureSvgSize(svg, 100, 400, true);
		svg.append("g").append("text").attr("x", 100).attr("y", 40).attr("class", "version").attr("font-size", 32).style("text-anchor", "middle").text(`v${version}`);
	}, "draw") }
};
//#endregion
export { diagram };

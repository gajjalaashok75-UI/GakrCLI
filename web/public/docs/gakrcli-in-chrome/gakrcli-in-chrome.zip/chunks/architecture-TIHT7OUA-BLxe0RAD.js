import "./chunk-KEIR6QF5-Af8e2JZB.js";
import { M as createArchitectureServices, j as ArchitectureModule } from "./mermaid-parser.core-98BDf-ly.js";
export { ArchitectureModule, createArchitectureServices };

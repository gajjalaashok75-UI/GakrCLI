import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import "./src-C3sq9HJl.js";
import "./chunk-WYO6CB5R-DF29PLGk.js";
import "./chunk-ICXQ74PX-uHG3Ffj0.js";
import "./chunk-HOUHSVGY-CVL8H-HK.js";
import "./chunk-Q4XR5HBZ-DZCdVpNm.js";
import "./chunk-7BUUIJ7U-C8VFPhS9.js";
import "./chunk-OGEWGWER-uLtBsKke.js";
import "./chunk-32BRIVSS-mQyOQPzM.js";
import "./chunk-XXDRQBXY-CWeuWqam.js";
import "./chunk-VR4S4FIN-C3U7dMKe.js";
import "./chunk-C7G6YPKG-DYyxSEiR.js";
import "./chunk-ZGVPDNZ5-wnE8lhSD.js";
import "./chunk-52WLFC77-Cn5lWL_k.js";
import "./chunk-FWX5IMBZ-CKLEaB0T.js";
import "./chunk-ZIRB5QZD-wtuBYpin.js";
import { r as styles_default, t as createFlowDiagram } from "./chunk-PUDLZKDR-D9W40qjD.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/swimlanesDiagram-G3AALYLV.mjs
var diagram = createFlowDiagram({
	defaultLayout: "swimlane",
	styles: /* @__PURE__ */ __name((options) => `${styles_default(options)}
  .swimlane.cluster rect {
    stroke: ${options.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`, "getStyles")
});
//#endregion
export { diagram };

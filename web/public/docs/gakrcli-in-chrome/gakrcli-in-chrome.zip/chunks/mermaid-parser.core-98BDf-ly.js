const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["chunks/info-DKCQHKI2-DM1bl4sC.js","chunks/chunk-KEIR6QF5-Af8e2JZB.js","chunks/_plugin-vue_export-helper-BdaNZm_w.js","chunks/packet-7NZHBO7P-0h9vxwII.js","chunks/pie-RZYD4A2V-S8dlaCgi.js","chunks/treeView-QDETBFTQ-B9YRYFLt.js","chunks/architecture-TIHT7OUA-BLxe0RAD.js","chunks/gitGraph-TEB2WS4Q-BaoyL0lz.js","chunks/eventmodeling-45OFAUF4-Cqufw3hH.js","chunks/radar-I7S5WNFK-CwztuQhi.js","chunks/railroad-3IZDKUUU-BfVdyYY-.js","chunks/railroad-ebnf-EBAXGLYW-Bbsqd_LU.js","chunks/railroad-abnf-AHOZXSZD-Ze_cq3cJ.js","chunks/railroad-peg-LSFZ7HO6-BCv4EyE_.js","chunks/treemap-6X3UGDF4-qA3nOStn.js","chunks/wardley-OPB4EBWU-BMd6jhXP.js","chunks/cynefin-VYW2F7L2-D87xMcV-.js"])))=>i.map(i=>d[i]);
import { o as _asyncToGenerator } from "./_plugin-vue_export-helper-BdaNZm_w.js";
import { _ as __vitePreload } from "./sidepanel-Dgx6MxOv.js";
import { C as createDefaultSharedCoreModule, S as createDefaultCoreModule, _ as RailroadPegGrammarGeneratedModule, a as CynefinGrammarGeneratedModule, b as WardleyGrammarGeneratedModule, c as GitGraphGrammarGeneratedModule, d as PacketGrammarGeneratedModule, f as PieGrammarGeneratedModule, g as RailroadGrammarGeneratedModule, h as RailroadEbnfGrammarGeneratedModule, i as CommonValueConverter, l as InfoGrammarGeneratedModule, m as RailroadAbnfGrammarGeneratedModule, n as AbstractMermaidValueConverter, o as EmptyFileSystem, p as RadarGrammarGeneratedModule, r as ArchitectureGrammarGeneratedModule, s as EventModelingGeneratedModule, t as AbstractMermaidTokenBuilder, u as MermaidGeneratedSharedModule, v as TreeViewGrammarGeneratedModule, w as inject, x as __name, y as TreemapGrammarGeneratedModule } from "./chunk-KEIR6QF5-Af8e2JZB.js";
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-MOZMSUNE.mjs
var _Class$15, _Class2$8;
var ArchitectureTokenBuilder = (_Class$15 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["architecture"]);
	}
}, __name(_Class$15, "ArchitectureTokenBuilder"), _Class$15);
var ArchitectureValueConverter = (_Class2$8 = class extends AbstractMermaidValueConverter {
	runCustomConverter(rule, input, _cstNode) {
		if (rule.name === "ARCH_ICON") return input.replace(/[()]/g, "").trim();
		else if (rule.name === "ARCH_TEXT_ICON") return input.replace(/["()]/g, "");
		else if (rule.name === "ARCH_TITLE") {
			let result = input.replace(/^\[|]$/g, "").trim();
			if (result.startsWith("\"") && result.endsWith("\"") || result.startsWith("'") && result.endsWith("'")) {
				result = result.slice(1, -1);
				result = result.replace(/\\"/g, "\"").replace(/\\'/g, "'");
			}
			return result.trim();
		}
	}
}, __name(_Class2$8, "ArchitectureValueConverter"), _Class2$8);
var ArchitectureModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new ArchitectureTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new ArchitectureValueConverter(), "ValueConverter")
} };
function createArchitectureServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const Architecture = inject(createDefaultCoreModule({ shared }), ArchitectureGrammarGeneratedModule, ArchitectureModule);
	shared.ServiceRegistry.register(Architecture);
	return {
		shared,
		Architecture
	};
}
__name(createArchitectureServices, "createArchitectureServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-OSBZ3O6U.mjs
var _Class$14;
var CynefinTokenBuilder = (_Class$14 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["cynefin-beta"]);
	}
}, __name(_Class$14, "CynefinTokenBuilder"), _Class$14);
var CynefinModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new CynefinTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new CommonValueConverter(), "ValueConverter")
} };
function createCynefinServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const Cynefin = inject(createDefaultCoreModule({ shared }), CynefinGrammarGeneratedModule, CynefinModule);
	shared.ServiceRegistry.register(Cynefin);
	return {
		shared,
		Cynefin
	};
}
__name(createCynefinServices, "createCynefinServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-5JV3BV7I.mjs
var _Class$13, _Class2$7;
var EventModelingTokenBuilder = (_Class$13 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["eventmodeling"]);
	}
}, __name(_Class$13, "EventModelingTokenBuilder"), _Class$13);
var COMMAND_TYPES = /* @__PURE__ */ new Set(["cmd", "command"]);
var EVENT_TYPES = /* @__PURE__ */ new Set(["evt", "event"]);
var READMODEL_TYPES = /* @__PURE__ */ new Set(["rmo", "readmodel"]);
var PROCESSOR_TYPES = /* @__PURE__ */ new Set(["pcr", "processor"]);
var UI_TYPES = /* @__PURE__ */ new Set(["ui"]);
function registerValidationChecks$1(services) {
	const validator = services.validation.EventModelingValidator;
	const registry = services.validation.ValidationRegistry;
	if (registry) {
		const checks = {
			EmTimeFrame: validator.checkSourceFrameTypes.bind(validator),
			EmResetFrame: validator.checkSourceFrameTypes.bind(validator)
		};
		registry.register(checks, validator);
	}
}
__name(registerValidationChecks$1, "registerValidationChecks");
var EventModelingValidator = (_Class2$7 = class {
	checkSourceFrameTypes(frame, accept) {
		if (frame.sourceFrames.length === 0) return;
		if (COMMAND_TYPES.has(frame.modelEntityType)) this.validateSources(frame, /* @__PURE__ */ new Set([...UI_TYPES, ...PROCESSOR_TYPES]), "command", "ui or processor", accept);
		else if (EVENT_TYPES.has(frame.modelEntityType)) this.validateSources(frame, COMMAND_TYPES, "event", "command", accept);
		else if (READMODEL_TYPES.has(frame.modelEntityType)) this.validateSources(frame, EVENT_TYPES, "read model", "event", accept);
		else if (PROCESSOR_TYPES.has(frame.modelEntityType)) this.validateSources(frame, READMODEL_TYPES, "processor", "read model", accept);
		else if (UI_TYPES.has(frame.modelEntityType)) this.validateSources(frame, READMODEL_TYPES, "ui", "read model", accept);
	}
	validateSources(frame, allowedSourceTypes, targetLabel, expectedSourceLabel, accept) {
		for (const sourceRef of frame.sourceFrames) {
			const source = sourceRef.ref;
			if (source !== void 0 && !allowedSourceTypes.has(source.modelEntityType)) accept("error", `A ${targetLabel} can only receive input from a ${expectedSourceLabel}, not from '${source.modelEntityType}'.`, {
				node: frame,
				property: "sourceFrames"
			});
		}
	}
}, __name(_Class2$7, "EventModelingValidator"), _Class2$7);
var EventModelingModule = {
	parser: {
		TokenBuilder: /* @__PURE__ */ __name(() => new EventModelingTokenBuilder(), "TokenBuilder"),
		ValueConverter: /* @__PURE__ */ __name(() => new CommonValueConverter(), "ValueConverter")
	},
	validation: { EventModelingValidator: /* @__PURE__ */ __name(() => new EventModelingValidator(), "EventModelingValidator") }
};
function createEventModelingServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const EventModel = inject(createDefaultCoreModule({ shared }), EventModelingGeneratedModule, EventModelingModule);
	shared.ServiceRegistry.register(EventModel);
	registerValidationChecks$1(EventModel);
	return {
		shared,
		EventModel
	};
}
__name(createEventModelingServices, "createEventModelingServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-CYSBUYHQ.mjs
var _Class$12;
var GitGraphTokenBuilder = (_Class$12 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["gitGraph"]);
	}
}, __name(_Class$12, "GitGraphTokenBuilder"), _Class$12);
var GitGraphModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new GitGraphTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new CommonValueConverter(), "ValueConverter")
} };
function createGitGraphServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const GitGraph = inject(createDefaultCoreModule({ shared }), GitGraphGrammarGeneratedModule, GitGraphModule);
	shared.ServiceRegistry.register(GitGraph);
	return {
		shared,
		GitGraph
	};
}
__name(createGitGraphServices, "createGitGraphServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-BIQX33UG.mjs
var _Class$11;
var InfoTokenBuilder = (_Class$11 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["info", "showInfo"]);
	}
}, __name(_Class$11, "InfoTokenBuilder"), _Class$11);
var InfoModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new InfoTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new CommonValueConverter(), "ValueConverter")
} };
function createInfoServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const Info = inject(createDefaultCoreModule({ shared }), InfoGrammarGeneratedModule, InfoModule);
	shared.ServiceRegistry.register(Info);
	return {
		shared,
		Info
	};
}
__name(createInfoServices, "createInfoServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-EMLP6XTP.mjs
var _Class$10;
var PacketTokenBuilder = (_Class$10 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["packet"]);
	}
}, __name(_Class$10, "PacketTokenBuilder"), _Class$10);
var PacketModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new PacketTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new CommonValueConverter(), "ValueConverter")
} };
function createPacketServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const Packet = inject(createDefaultCoreModule({ shared }), PacketGrammarGeneratedModule, PacketModule);
	shared.ServiceRegistry.register(Packet);
	return {
		shared,
		Packet
	};
}
__name(createPacketServices, "createPacketServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-YOTPTUD7.mjs
var _Class$9, _Class2$6;
var PieTokenBuilder = (_Class$9 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["pie", "showData"]);
	}
}, __name(_Class$9, "PieTokenBuilder"), _Class$9);
var PieValueConverter = (_Class2$6 = class extends AbstractMermaidValueConverter {
	runCustomConverter(rule, input, _cstNode) {
		if (rule.name !== "PIE_SECTION_LABEL") return;
		return input.replace(/"/g, "").trim();
	}
}, __name(_Class2$6, "PieValueConverter"), _Class2$6);
var PieModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new PieTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new PieValueConverter(), "ValueConverter")
} };
function createPieServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const Pie = inject(createDefaultCoreModule({ shared }), PieGrammarGeneratedModule, PieModule);
	shared.ServiceRegistry.register(Pie);
	return {
		shared,
		Pie
	};
}
__name(createPieServices, "createPieServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-QBLGF6JB.mjs
var _Class$8;
var RadarTokenBuilder = (_Class$8 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["radar-beta"]);
	}
}, __name(_Class$8, "RadarTokenBuilder"), _Class$8);
var RadarModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new RadarTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new CommonValueConverter(), "ValueConverter")
} };
function createRadarServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const Radar = inject(createDefaultCoreModule({ shared }), RadarGrammarGeneratedModule, RadarModule);
	shared.ServiceRegistry.register(Radar);
	return {
		shared,
		Radar
	};
}
__name(createRadarServices, "createRadarServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-5TONJI2A.mjs
var _Class$7, _Class2$5;
var RailroadTokenBuilder = (_Class$7 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["railroad-beta"]);
	}
}, __name(_Class$7, "RailroadTokenBuilder"), _Class$7);
var decodeEscapedString$2 = /* @__PURE__ */ __name((input) => {
	const content = input.slice(1, -1);
	let value = "";
	for (let index = 0; index < content.length; index++) {
		const character = content[index];
		if (character === "\\" && index + 1 < content.length) {
			index++;
			const escaped = content[index];
			switch (escaped) {
				case "n":
					value += "\n";
					break;
				case "r":
					value += "\r";
					break;
				case "t":
					value += "	";
					break;
				default: value += escaped;
			}
			continue;
		}
		value += character;
	}
	return value;
}, "decodeEscapedString");
var RailroadValueConverter = (_Class2$5 = class extends AbstractMermaidValueConverter {
	runConverter(rule, input, cstNode) {
		const value = super.runConverter(rule, input, cstNode);
		if (rule.name === "TITLE" && typeof value === "string") {
			const trimmedValue = value.trim();
			if (trimmedValue.startsWith("\"") && trimmedValue.endsWith("\"") || trimmedValue.startsWith("'") && trimmedValue.endsWith("'")) return decodeEscapedString$2(trimmedValue);
		}
		return value;
	}
	runCustomConverter(rule, input, _cstNode) {
		if (rule.name === "RR_STRING") return decodeEscapedString$2(input);
	}
}, __name(_Class2$5, "RailroadValueConverter"), _Class2$5);
var RailroadModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new RailroadTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new RailroadValueConverter(), "ValueConverter")
} };
function createRailroadServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const Railroad = inject(createDefaultCoreModule({ shared }), RailroadGrammarGeneratedModule, RailroadModule);
	shared.ServiceRegistry.register(Railroad);
	return {
		shared,
		Railroad
	};
}
__name(createRailroadServices, "createRailroadServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-5HE753X5.mjs
var _Class$6, _Class2$4;
var RailroadAbnfTokenBuilder = (_Class$6 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["railroad-abnf-beta"]);
	}
}, __name(_Class$6, "RailroadAbnfTokenBuilder"), _Class$6);
var RailroadAbnfValueConverter = (_Class2$4 = class extends AbstractMermaidValueConverter {
	runConverter(rule, input, cstNode) {
		const value = super.runConverter(rule, input, cstNode);
		if (rule.name === "TITLE" && typeof value === "string") {
			const trimmedValue = value.trim();
			if (trimmedValue.startsWith("\"") && trimmedValue.endsWith("\"") || trimmedValue.startsWith("'") && trimmedValue.endsWith("'")) return trimmedValue.slice(1, -1);
		}
		return value;
	}
	runCustomConverter(rule, input, _cstNode) {
		if (rule.name === "ABNF_STRING") return input.slice(1, -1);
	}
}, __name(_Class2$4, "RailroadAbnfValueConverter"), _Class2$4);
var RailroadAbnfModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new RailroadAbnfTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new RailroadAbnfValueConverter(), "ValueConverter")
} };
function createRailroadAbnfServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const RailroadAbnf = inject(createDefaultCoreModule({ shared }), RailroadAbnfGrammarGeneratedModule, RailroadAbnfModule);
	shared.ServiceRegistry.register(RailroadAbnf);
	return {
		shared,
		RailroadAbnf
	};
}
__name(createRailroadAbnfServices, "createRailroadAbnfServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-U6XO7XAA.mjs
var _Class$5, _Class2$3;
var RailroadEbnfTokenBuilder = (_Class$5 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["railroad-ebnf-beta"]);
	}
}, __name(_Class$5, "RailroadEbnfTokenBuilder"), _Class$5);
var decodeEscapedString$1 = /* @__PURE__ */ __name((input) => {
	const content = input.slice(1, -1);
	let value = "";
	for (let index = 0; index < content.length; index++) {
		const character = content[index];
		if (character === "\\" && index + 1 < content.length) {
			index++;
			const escaped = content[index];
			switch (escaped) {
				case "n":
					value += "\n";
					break;
				case "r":
					value += "\r";
					break;
				case "t":
					value += "	";
					break;
				default: value += escaped;
			}
			continue;
		}
		value += character;
	}
	return value;
}, "decodeEscapedString");
var RailroadEbnfValueConverter = (_Class2$3 = class extends AbstractMermaidValueConverter {
	runConverter(rule, input, cstNode) {
		const value = super.runConverter(rule, input, cstNode);
		if (rule.name === "TITLE" && typeof value === "string") {
			const trimmedValue = value.trim();
			if (trimmedValue.startsWith("\"") && trimmedValue.endsWith("\"") || trimmedValue.startsWith("'") && trimmedValue.endsWith("'")) return decodeEscapedString$1(trimmedValue);
		}
		return value;
	}
	runCustomConverter(rule, input, _cstNode) {
		if (rule.name === "EBNF_STRING") return decodeEscapedString$1(input);
		if (rule.name === "EBNF_SPECIAL_SEQUENCE") return input.slice(1, -1).trim();
	}
}, __name(_Class2$3, "RailroadEbnfValueConverter"), _Class2$3);
var RailroadEbnfModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new RailroadEbnfTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new RailroadEbnfValueConverter(), "ValueConverter")
} };
function createRailroadEbnfServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const RailroadEbnf = inject(createDefaultCoreModule({ shared }), RailroadEbnfGrammarGeneratedModule, RailroadEbnfModule);
	shared.ServiceRegistry.register(RailroadEbnf);
	return {
		shared,
		RailroadEbnf
	};
}
__name(createRailroadEbnfServices, "createRailroadEbnfServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-JG7HCLWE.mjs
var _Class$4, _Class2$2;
var RailroadPegTokenBuilder = (_Class$4 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["railroad-peg-beta"]);
	}
}, __name(_Class$4, "RailroadPegTokenBuilder"), _Class$4);
var decodeEscapedString = /* @__PURE__ */ __name((input) => {
	const content = input.slice(1, -1);
	let value = "";
	for (let index = 0; index < content.length; index++) {
		const character = content[index];
		if (character === "\\" && index + 1 < content.length) {
			index++;
			const escaped = content[index];
			switch (escaped) {
				case "n":
					value += "\n";
					break;
				case "r":
					value += "\r";
					break;
				case "t":
					value += "	";
					break;
				default: value += escaped;
			}
			continue;
		}
		value += character;
	}
	return value;
}, "decodeEscapedString");
var RailroadPegValueConverter = (_Class2$2 = class extends AbstractMermaidValueConverter {
	runConverter(rule, input, cstNode) {
		const value = super.runConverter(rule, input, cstNode);
		if (rule.name === "TITLE" && typeof value === "string") {
			const trimmedValue = value.trim();
			if (trimmedValue.startsWith("\"") && trimmedValue.endsWith("\"") || trimmedValue.startsWith("'") && trimmedValue.endsWith("'")) return decodeEscapedString(trimmedValue);
		}
		return value;
	}
	runCustomConverter(rule, input, _cstNode) {
		if (rule.name === "PEG_STRING") return decodeEscapedString(input);
	}
}, __name(_Class2$2, "RailroadPegValueConverter"), _Class2$2);
var RailroadPegModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new RailroadPegTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new RailroadPegValueConverter(), "ValueConverter")
} };
function createRailroadPegServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const RailroadPeg = inject(createDefaultCoreModule({ shared }), RailroadPegGrammarGeneratedModule, RailroadPegModule);
	shared.ServiceRegistry.register(RailroadPeg);
	return {
		shared,
		RailroadPeg
	};
}
__name(createRailroadPegServices, "createRailroadPegServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-CQNSW5MT.mjs
var _Class$3, _Class2$1;
var TreeViewValueConverter = (_Class$3 = class extends AbstractMermaidValueConverter {
	runCustomConverter(rule, input, _cstNode) {
		if (rule.name === "INDENTATION") return (input === null || input === void 0 ? void 0 : input.length) || 0;
		if (rule.name === "QUOTED_NAME") return input.substring(1, input.length - 1);
		if (rule.name === "BARE_NAME") return input.replace(/[\t ]+$/, "");
		if (rule.name === "CLASS_ANNOTATION") return input.trim().substring(3).trim();
		if (rule.name === "ICON_ANNOTATION") {
			const trimmed = input.trim();
			return trimmed.substring(5, trimmed.length - 1);
		}
		if (rule.name === "DESC_ANNOTATION") return input.trim().substring(2).trim();
	}
}, __name(_Class$3, "TreeViewValueConverter"), _Class$3);
var TreeViewTokenBuilder = (_Class2$1 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["treeView-beta"]);
	}
}, __name(_Class2$1, "TreeViewTokenBuilder"), _Class2$1);
var TreeViewModule = { parser: {
	TokenBuilder: /* @__PURE__ */ __name(() => new TreeViewTokenBuilder(), "TokenBuilder"),
	ValueConverter: /* @__PURE__ */ __name(() => new TreeViewValueConverter(), "ValueConverter")
} };
function createTreeViewServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const TreeView = inject(createDefaultCoreModule({ shared }), TreeViewGrammarGeneratedModule, TreeViewModule);
	shared.ServiceRegistry.register(TreeView);
	return {
		shared,
		TreeView
	};
}
__name(createTreeViewServices, "createTreeViewServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-R7FJI6CG.mjs
var _Class$2, _Class2, _Class3;
var TreemapTokenBuilder = (_Class$2 = class extends AbstractMermaidTokenBuilder {
	constructor() {
		super(["treemap"]);
	}
}, __name(_Class$2, "TreemapTokenBuilder"), _Class$2);
var classDefRegex = /classDef\s+([A-Z_a-z]\w+)(?:\s+([^\n\r;]*))?;?/;
var TreemapValueConverter = (_Class2 = class extends AbstractMermaidValueConverter {
	runCustomConverter(rule, input, _cstNode) {
		if (rule.name === "NUMBER2") return parseFloat(input.replace(/,/g, ""));
		else if (rule.name === "SEPARATOR") return input.substring(1, input.length - 1);
		else if (rule.name === "STRING2") return input.substring(1, input.length - 1);
		else if (rule.name === "INDENTATION") return input.length;
		else if (rule.name === "ClassDef") {
			if (typeof input !== "string") return input;
			const match = classDefRegex.exec(input);
			if (match) return {
				$type: "ClassDefStatement",
				className: match[1],
				styleText: match[2] || void 0
			};
		}
	}
}, __name(_Class2, "TreemapValueConverter"), _Class2);
function registerValidationChecks(services) {
	const validator = services.validation.TreemapValidator;
	const registry = services.validation.ValidationRegistry;
	if (registry) {
		const checks = { Treemap: validator.checkSingleRoot.bind(validator) };
		registry.register(checks, validator);
	}
}
__name(registerValidationChecks, "registerValidationChecks");
var TreemapValidator = (_Class3 = class {
	/**
	* Validates that a treemap has only one root node.
	* A root node is defined as a node that has no indentation.
	*/
	checkSingleRoot(doc, accept) {
		let rootNodeIndentation;
		for (const row of doc.TreemapRows) {
			if (!row.item) continue;
			if (rootNodeIndentation === void 0 && row.indent === void 0) rootNodeIndentation = 0;
			else if (row.indent === void 0) accept("error", "Multiple root nodes are not allowed in a treemap.", {
				node: row,
				property: "item"
			});
			else if (rootNodeIndentation !== void 0 && rootNodeIndentation >= parseInt(row.indent, 10)) accept("error", "Multiple root nodes are not allowed in a treemap.", {
				node: row,
				property: "item"
			});
		}
	}
}, __name(_Class3, "TreemapValidator"), _Class3);
var TreemapModule = {
	parser: {
		TokenBuilder: /* @__PURE__ */ __name(() => new TreemapTokenBuilder(), "TokenBuilder"),
		ValueConverter: /* @__PURE__ */ __name(() => new TreemapValueConverter(), "ValueConverter")
	},
	validation: { TreemapValidator: /* @__PURE__ */ __name(() => new TreemapValidator(), "TreemapValidator") }
};
function createTreemapServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const Treemap = inject(createDefaultCoreModule({ shared }), TreemapGrammarGeneratedModule, TreemapModule);
	shared.ServiceRegistry.register(Treemap);
	registerValidationChecks(Treemap);
	return {
		shared,
		Treemap
	};
}
__name(createTreemapServices, "createTreemapServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-5FCAYU7R.mjs
var _Class$1;
var WardleyValueConverter = (_Class$1 = class extends AbstractMermaidValueConverter {
	runCustomConverter(rule, input, _cstNode) {
		switch (rule.name.toUpperCase()) {
			case "LINK_LABEL": return input.substring(1).trim();
			default: return;
		}
	}
}, __name(_Class$1, "WardleyValueConverter"), _Class$1);
var WardleyModule = { parser: { ValueConverter: /* @__PURE__ */ __name(() => new WardleyValueConverter(), "ValueConverter") } };
function createWardleyServices(context = EmptyFileSystem) {
	const shared = inject(createDefaultSharedCoreModule(context), MermaidGeneratedSharedModule);
	const Wardley = inject(createDefaultCoreModule({ shared }), WardleyGrammarGeneratedModule, WardleyModule);
	shared.ServiceRegistry.register(Wardley);
	return {
		shared,
		Wardley
	};
}
__name(createWardleyServices, "createWardleyServices");
//#endregion
//#region ../../node_modules/@mermaid-js/parser/dist/mermaid-parser.core.mjs
var _Class;
var parsers = {};
var initializers = {
	info: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createInfoServices: createInfoServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createInfoServices: createInfoServices2 } = yield import("./info-DKCQHKI2-DM1bl4sC.js");
			return { createInfoServices: createInfoServices2 };
		}), __vite__mapDeps([0,1,2]));
		parsers.info = createInfoServices2().Info.parser.LangiumParser;
	}), "info"),
	packet: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createPacketServices: createPacketServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createPacketServices: createPacketServices2 } = yield import("./packet-7NZHBO7P-0h9vxwII.js");
			return { createPacketServices: createPacketServices2 };
		}), __vite__mapDeps([3,1,2]));
		parsers.packet = createPacketServices2().Packet.parser.LangiumParser;
	}), "packet"),
	pie: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createPieServices: createPieServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createPieServices: createPieServices2 } = yield import("./pie-RZYD4A2V-S8dlaCgi.js");
			return { createPieServices: createPieServices2 };
		}), __vite__mapDeps([4,1,2]));
		parsers.pie = createPieServices2().Pie.parser.LangiumParser;
	}), "pie"),
	treeView: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createTreeViewServices: createTreeViewServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createTreeViewServices: createTreeViewServices2 } = yield import("./treeView-QDETBFTQ-B9YRYFLt.js");
			return { createTreeViewServices: createTreeViewServices2 };
		}), __vite__mapDeps([5,1,2]));
		parsers.treeView = createTreeViewServices2().TreeView.parser.LangiumParser;
	}), "treeView"),
	architecture: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createArchitectureServices: createArchitectureServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createArchitectureServices: createArchitectureServices2 } = yield import("./architecture-TIHT7OUA-BLxe0RAD.js");
			return { createArchitectureServices: createArchitectureServices2 };
		}), __vite__mapDeps([6,1,2]));
		parsers.architecture = createArchitectureServices2().Architecture.parser.LangiumParser;
	}), "architecture"),
	gitGraph: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createGitGraphServices: createGitGraphServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createGitGraphServices: createGitGraphServices2 } = yield import("./gitGraph-TEB2WS4Q-BaoyL0lz.js");
			return { createGitGraphServices: createGitGraphServices2 };
		}), __vite__mapDeps([7,1,2]));
		parsers.gitGraph = createGitGraphServices2().GitGraph.parser.LangiumParser;
	}), "gitGraph"),
	eventmodeling: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createEventModelingServices: createEventModelingServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createEventModelingServices: createEventModelingServices2 } = yield import("./eventmodeling-45OFAUF4-Cqufw3hH.js");
			return { createEventModelingServices: createEventModelingServices2 };
		}), __vite__mapDeps([8,1,2]));
		parsers.eventmodeling = createEventModelingServices2().EventModel.parser.LangiumParser;
	}), "eventmodeling"),
	radar: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createRadarServices: createRadarServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createRadarServices: createRadarServices2 } = yield import("./radar-I7S5WNFK-CwztuQhi.js");
			return { createRadarServices: createRadarServices2 };
		}), __vite__mapDeps([9,1,2]));
		parsers.radar = createRadarServices2().Radar.parser.LangiumParser;
	}), "radar"),
	railroad: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createRailroadServices: createRailroadServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createRailroadServices: createRailroadServices2 } = yield import("./railroad-3IZDKUUU-BfVdyYY-.js");
			return { createRailroadServices: createRailroadServices2 };
		}), __vite__mapDeps([10,1,2]));
		parsers.railroad = createRailroadServices2().Railroad.parser.LangiumParser;
	}), "railroad"),
	railroadEbnf: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createRailroadEbnfServices: createRailroadEbnfServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createRailroadEbnfServices: createRailroadEbnfServices2 } = yield import("./railroad-ebnf-EBAXGLYW-Bbsqd_LU.js");
			return { createRailroadEbnfServices: createRailroadEbnfServices2 };
		}), __vite__mapDeps([11,1,2]));
		parsers.railroadEbnf = createRailroadEbnfServices2().RailroadEbnf.parser.LangiumParser;
	}), "railroadEbnf"),
	railroadAbnf: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createRailroadAbnfServices: createRailroadAbnfServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createRailroadAbnfServices: createRailroadAbnfServices2 } = yield import("./railroad-abnf-AHOZXSZD-Ze_cq3cJ.js");
			return { createRailroadAbnfServices: createRailroadAbnfServices2 };
		}), __vite__mapDeps([12,1,2]));
		parsers.railroadAbnf = createRailroadAbnfServices2().RailroadAbnf.parser.LangiumParser;
	}), "railroadAbnf"),
	railroadPeg: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createRailroadPegServices: createRailroadPegServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createRailroadPegServices: createRailroadPegServices2 } = yield import("./railroad-peg-LSFZ7HO6-BCv4EyE_.js");
			return { createRailroadPegServices: createRailroadPegServices2 };
		}), __vite__mapDeps([13,1,2]));
		parsers.railroadPeg = createRailroadPegServices2().RailroadPeg.parser.LangiumParser;
	}), "railroadPeg"),
	treemap: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createTreemapServices: createTreemapServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createTreemapServices: createTreemapServices2 } = yield import("./treemap-6X3UGDF4-qA3nOStn.js");
			return { createTreemapServices: createTreemapServices2 };
		}), __vite__mapDeps([14,1,2]));
		parsers.treemap = createTreemapServices2().Treemap.parser.LangiumParser;
	}), "treemap"),
	wardley: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createWardleyServices: createWardleyServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createWardleyServices: createWardleyServices2 } = yield import("./wardley-OPB4EBWU-BMd6jhXP.js");
			return { createWardleyServices: createWardleyServices2 };
		}), __vite__mapDeps([15,1,2]));
		parsers.wardley = createWardleyServices2().Wardley.parser.LangiumParser;
	}), "wardley"),
	cynefin: /* @__PURE__ */ __name(_asyncToGenerator(function* () {
		const { createCynefinServices: createCynefinServices2 } = yield __vitePreload(_asyncToGenerator(function* () {
			const { createCynefinServices: createCynefinServices2 } = yield import("./cynefin-VYW2F7L2-D87xMcV-.js");
			return { createCynefinServices: createCynefinServices2 };
		}), __vite__mapDeps([16,1,2]));
		parsers.cynefin = createCynefinServices2().Cynefin.parser.LangiumParser;
	}), "cynefin")
};
function parse(_x, _x2) {
	return _parse.apply(this, arguments);
}
function _parse() {
	_parse = _asyncToGenerator(function* (diagramType, text) {
		const initializer = initializers[diagramType];
		if (!initializer) throw new Error(`Unknown diagram type: ${diagramType}`);
		if (!parsers[diagramType]) yield initializer();
		const result = parsers[diagramType].parse(text);
		if (result.lexerErrors.length > 0 || result.parserErrors.length > 0) throw new MermaidParseError(result);
		return result.value;
	});
	return _parse.apply(this, arguments);
}
__name(parse, "parse");
var MermaidParseError = (_Class = class extends Error {
	constructor(result) {
		const lexerErrors = result.lexerErrors.map((err) => {
			return `Lexer error on line ${err.line !== void 0 && !isNaN(err.line) ? err.line : "?"}, column ${err.column !== void 0 && !isNaN(err.column) ? err.column : "?"}: ${err.message}`;
		}).join("\n");
		const parserErrors = result.parserErrors.map((err) => {
			return `Parse error on line ${err.token.startLine !== void 0 && !isNaN(err.token.startLine) ? err.token.startLine : "?"}, column ${err.token.startColumn !== void 0 && !isNaN(err.token.startColumn) ? err.token.startColumn : "?"}: ${err.message}`;
		}).join("\n");
		super(`Parsing failed: ${lexerErrors} ${parserErrors}`);
		this.result = result;
	}
}, __name(_Class, "MermaidParseError"), _Class);
//#endregion
export { createCynefinServices as A, InfoModule as C, EventModelingModule as D, createGitGraphServices as E, createArchitectureServices as M, createEventModelingServices as O, createPacketServices as S, GitGraphModule as T, RadarModule as _, TreemapModule as a, createPieServices as b, createTreeViewServices as c, RailroadEbnfModule as d, createRailroadEbnfServices as f, createRailroadServices as g, RailroadModule as h, createWardleyServices as i, ArchitectureModule as j, CynefinModule as k, RailroadPegModule as l, createRailroadAbnfServices as m, parse as n, createTreemapServices as o, RailroadAbnfModule as p, WardleyModule as r, TreeViewModule as s, MermaidParseError as t, createRailroadPegServices as u, createRadarServices as v, createInfoServices as w, PacketModule as x, PieModule as y };

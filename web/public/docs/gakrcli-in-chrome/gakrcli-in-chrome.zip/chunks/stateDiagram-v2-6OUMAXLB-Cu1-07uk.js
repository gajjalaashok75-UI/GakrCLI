import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
import "./src-C3sq9HJl.js";
import "./chunk-WYO6CB5R-D3hdW-kf.js";
import "./chunk-ICXQ74PX-BROveA7q.js";
import "./chunk-HOUHSVGY-6mKlY5gd.js";
import "./chunk-Q4XR5HBZ-zk1zulYp.js";
import "./chunk-7BUUIJ7U-C8VFPhS9.js";
import "./chunk-OGEWGWER-CRC47pvB.js";
import "./chunk-32BRIVSS-uxbWPu1s.js";
import "./chunk-XXDRQBXY-CWeuWqam.js";
import "./chunk-VR4S4FIN-D9_C6ECh.js";
import "./chunk-C7G6YPKG-C0Dwy7It.js";
import "./chunk-ZGVPDNZ5-DeHkl6jW.js";
import "./chunk-52WLFC77-Cz74qZ02.js";
import "./chunk-FWX5IMBZ-C0t88zp8.js";
import { i as styles_default, n as stateDiagram_default, r as stateRenderer_v3_unified_default, t as StateDB } from "./chunk-EX3LRPZG-DSU3_tKZ.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/stateDiagram-v2-6OUMAXLB.mjs
var diagram = {
	parser: stateDiagram_default,
	get db() {
		return new StateDB(2);
	},
	renderer: stateRenderer_v3_unified_default,
	styles: styles_default,
	init: /* @__PURE__ */ __name((cnf) => {
		if (!cnf.state) cnf.state = {};
		cnf.state.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
	}, "init")
};
//#endregion
export { diagram };

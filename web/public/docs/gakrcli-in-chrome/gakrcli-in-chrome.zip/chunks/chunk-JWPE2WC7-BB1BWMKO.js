import { n as __name } from "./chunk-Y2CYZVJY-CfdURDvj.js";
//#region ../../node_modules/mermaid/dist/chunks/mermaid.core/chunk-JWPE2WC7.mjs
function populateCommonDb(ast, db) {
	if (ast.accDescr) {
		var _db$setAccDescription;
		(_db$setAccDescription = db.setAccDescription) === null || _db$setAccDescription === void 0 || _db$setAccDescription.call(db, ast.accDescr);
	}
	if (ast.accTitle) {
		var _db$setAccTitle;
		(_db$setAccTitle = db.setAccTitle) === null || _db$setAccTitle === void 0 || _db$setAccTitle.call(db, ast.accTitle);
	}
	if (ast.title) {
		var _db$setDiagramTitle;
		(_db$setDiagramTitle = db.setDiagramTitle) === null || _db$setDiagramTitle === void 0 || _db$setDiagramTitle.call(db, ast.title);
	}
}
__name(populateCommonDb, "populateCommonDb");
//#endregion
export { populateCommonDb as t };

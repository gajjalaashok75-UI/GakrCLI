import "./chunk-KEIR6QF5-Af8e2JZB.js";
import { E as createGitGraphServices, T as GitGraphModule } from "./mermaid-parser.core-DhYO2Vvm.js";
export { GitGraphModule, createGitGraphServices };

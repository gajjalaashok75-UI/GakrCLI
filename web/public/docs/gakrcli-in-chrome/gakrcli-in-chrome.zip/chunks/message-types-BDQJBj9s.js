// common/message-types.ts
/**
* Consolidated message type constants for Chrome extension communication
* Note: Native message types are imported from the shared package
*/
var MessageTarget = /* @__PURE__ */ function(MessageTarget) {
	MessageTarget["Offscreen"] = "offscreen";
	MessageTarget["ContentScript"] = "content_script";
	MessageTarget["Background"] = "background";
	return MessageTarget;
}({});
var BACKGROUND_MESSAGE_TYPES = {
	SWITCH_SEMANTIC_MODEL: "switch_semantic_model",
	GET_MODEL_STATUS: "get_model_status",
	UPDATE_MODEL_STATUS: "update_model_status",
	GET_STORAGE_STATS: "get_storage_stats",
	CLEAR_ALL_DATA: "clear_all_data",
	GET_SERVER_STATUS: "get_server_status",
	REFRESH_SERVER_STATUS: "refresh_server_status",
	SERVER_STATUS_CHANGED: "server_status_changed",
	INITIALIZE_SEMANTIC_ENGINE: "initialize_semantic_engine",
	RR_START_RECORDING: "rr_start_recording",
	RR_STOP_RECORDING: "rr_stop_recording",
	RR_PAUSE_RECORDING: "rr_pause_recording",
	RR_RESUME_RECORDING: "rr_resume_recording",
	RR_GET_RECORDING_STATUS: "rr_get_recording_status",
	RR_LIST_FLOWS: "rr_list_flows",
	RR_FLOWS_CHANGED: "rr_flows_changed",
	RR_GET_FLOW: "rr_get_flow",
	RR_DELETE_FLOW: "rr_delete_flow",
	RR_PUBLISH_FLOW: "rr_publish_flow",
	RR_UNPUBLISH_FLOW: "rr_unpublish_flow",
	RR_RUN_FLOW: "rr_run_flow",
	RR_SAVE_FLOW: "rr_save_flow",
	RR_EXPORT_FLOW: "rr_export_flow",
	RR_EXPORT_ALL: "rr_export_all",
	RR_IMPORT_FLOW: "rr_import_flow",
	RR_LIST_RUNS: "rr_list_runs",
	RR_LIST_TRIGGERS: "rr_list_triggers",
	RR_SAVE_TRIGGER: "rr_save_trigger",
	RR_DELETE_TRIGGER: "rr_delete_trigger",
	RR_REFRESH_TRIGGERS: "rr_refresh_triggers",
	RR_SCHEDULE_FLOW: "rr_schedule_flow",
	RR_UNSCHEDULE_FLOW: "rr_unschedule_flow",
	RR_LIST_SCHEDULES: "rr_list_schedules",
	ELEMENT_PICKER_UI_EVENT: "element_picker_ui_event",
	ELEMENT_PICKER_FRAME_EVENT: "element_picker_frame_event"
};
var OFFSCREEN_MESSAGE_TYPES = {
	SIMILARITY_ENGINE_INIT: "similarityEngineInit",
	SIMILARITY_ENGINE_COMPUTE: "similarityEngineCompute",
	SIMILARITY_ENGINE_BATCH_COMPUTE: "similarityEngineBatchCompute",
	SIMILARITY_ENGINE_STATUS: "similarityEngineStatus",
	GIF_ADD_FRAME: "gifAddFrame",
	GIF_FINISH: "gifFinish",
	GIF_RESET: "gifReset"
};
export { MessageTarget as n, OFFSCREEN_MESSAGE_TYPES as r, BACKGROUND_MESSAGE_TYPES as t };

import "./chunk-KEIR6QF5-Af8e2JZB.js";
import { _ as RadarModule, v as createRadarServices } from "./mermaid-parser.core-98BDf-ly.js";
export { RadarModule, createRadarServices };

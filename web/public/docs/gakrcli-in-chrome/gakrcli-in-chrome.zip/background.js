var background = (function() {
	//#region \0rolldown/runtime.js
	var __defProp = Object.defineProperty;
	var __esmMin = (fn, res, err) => () => {
		if (err) throw err[0];
		try {
			return fn && (res = fn(fn = 0)), res;
		} catch (e) {
			throw err = [e], e;
		}
	};
	var __exportAll = (all, no_symbols) => {
		let target = {};
		for (var name in all) __defProp(target, name, {
			get: all[name],
			enumerable: true
		});
		if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
		return target;
	};
	//#endregion
	//#region node_modules/wxt/dist/utils/define-background.mjs
	function defineBackground(arg) {
		if (arg == null || typeof arg === "function") return { main: arg };
		return arg;
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.137.0/helpers/esm/typeof.js
	function _typeof(o) {
		"@babel/helpers - typeof";
		return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
			return typeof o;
		} : function(o) {
			return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
		}, _typeof(o);
	}
	var init_typeof = __esmMin((() => {}));
	//#endregion
	//#region \0@oxc-project+runtime@0.137.0/helpers/esm/toPrimitive.js
	function toPrimitive(t, r) {
		if ("object" != _typeof(t) || !t) return t;
		var e = t[Symbol.toPrimitive];
		if (void 0 !== e) {
			var i = e.call(t, r || "default");
			if ("object" != _typeof(i)) return i;
			throw new TypeError("@@toPrimitive must return a primitive value.");
		}
		return ("string" === r ? String : Number)(t);
	}
	var init_toPrimitive = __esmMin((() => {
		init_typeof();
	}));
	//#endregion
	//#region \0@oxc-project+runtime@0.137.0/helpers/esm/toPropertyKey.js
	function toPropertyKey(t) {
		var i = toPrimitive(t, "string");
		return "symbol" == _typeof(i) ? i : i + "";
	}
	var init_toPropertyKey = __esmMin((() => {
		init_typeof();
		init_toPrimitive();
	}));
	//#endregion
	//#region \0@oxc-project+runtime@0.137.0/helpers/esm/defineProperty.js
	function _defineProperty(e, r, t) {
		return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
			value: t,
			enumerable: !0,
			configurable: !0,
			writable: !0
		}) : e[r] = t, e;
	}
	var init_defineProperty = __esmMin((() => {
		init_toPropertyKey();
	}));
	//#endregion
	//#region \0@oxc-project+runtime@0.137.0/helpers/esm/objectSpread2.js
	init_defineProperty();
	function ownKeys(e, r) {
		var t = Object.keys(e);
		if (Object.getOwnPropertySymbols) {
			var o = Object.getOwnPropertySymbols(e);
			r && (o = o.filter(function(r) {
				return Object.getOwnPropertyDescriptor(e, r).enumerable;
			})), t.push.apply(t, o);
		}
		return t;
	}
	function _objectSpread2(e) {
		for (var r = 1; r < arguments.length; r++) {
			var t = null != arguments[r] ? arguments[r] : {};
			r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
				_defineProperty(e, r, t[r]);
			}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
				Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
			});
		}
		return e;
	}
	//#endregion
	//#region ../mcp-chrome-shared/dist/index.mjs
	var NativeMessageType = /* @__PURE__ */ ((NativeMessageType2) => {
		NativeMessageType2["START"] = "start";
		NativeMessageType2["STARTED"] = "started";
		NativeMessageType2["STOP"] = "stop";
		NativeMessageType2["STOPPED"] = "stopped";
		NativeMessageType2["PING"] = "ping";
		NativeMessageType2["PONG"] = "pong";
		NativeMessageType2["ERROR"] = "error";
		NativeMessageType2["PROCESS_DATA"] = "process_data";
		NativeMessageType2["PROCESS_DATA_RESPONSE"] = "process_data_response";
		NativeMessageType2["CALL_TOOL"] = "call_tool";
		NativeMessageType2["CALL_TOOL_RESPONSE"] = "call_tool_response";
		NativeMessageType2["SERVER_STARTED"] = "server_started";
		NativeMessageType2["SERVER_STOPPED"] = "server_stopped";
		NativeMessageType2["ERROR_FROM_NATIVE_HOST"] = "error_from_native_host";
		NativeMessageType2["CONNECT_NATIVE"] = "connectNative";
		NativeMessageType2["ENSURE_NATIVE"] = "ensure_native";
		NativeMessageType2["PING_NATIVE"] = "ping_native";
		NativeMessageType2["DISCONNECT_NATIVE"] = "disconnect_native";
		return NativeMessageType2;
	})(NativeMessageType || {});
	var TOOL_NAMES = {
		BROWSER: {
			GET_WINDOWS_AND_TABS: "get_windows_and_tabs",
			SEARCH_TABS_CONTENT: "search_tabs_content",
			NAVIGATE: "chrome_navigate",
			SCREENSHOT: "chrome_screenshot",
			CLOSE_TABS: "chrome_close_tabs",
			SWITCH_TAB: "chrome_switch_tab",
			WEB_FETCHER: "chrome_get_web_content",
			CLICK: "chrome_click_element",
			FILL: "chrome_fill_or_select",
			REQUEST_ELEMENT_SELECTION: "chrome_request_element_selection",
			GET_INTERACTIVE_ELEMENTS: "chrome_get_interactive_elements",
			NETWORK_CAPTURE: "chrome_network_capture",
			NETWORK_CAPTURE_START: "chrome_network_capture_start",
			NETWORK_CAPTURE_STOP: "chrome_network_capture_stop",
			NETWORK_REQUEST: "chrome_network_request",
			NETWORK_DEBUGGER_START: "chrome_network_debugger_start",
			NETWORK_DEBUGGER_STOP: "chrome_network_debugger_stop",
			KEYBOARD: "chrome_keyboard",
			HISTORY: "chrome_history",
			BOOKMARK_SEARCH: "chrome_bookmark_search",
			BOOKMARK_ADD: "chrome_bookmark_add",
			BOOKMARK_DELETE: "chrome_bookmark_delete",
			INJECT_SCRIPT: "chrome_inject_script",
			SEND_COMMAND_TO_INJECT_SCRIPT: "chrome_send_command_to_inject_script",
			JAVASCRIPT: "chrome_javascript",
			CONSOLE: "chrome_console",
			FILE_UPLOAD: "chrome_upload_file",
			READ_PAGE: "chrome_read_page",
			COMPUTER: "chrome_computer",
			HANDLE_DIALOG: "chrome_handle_dialog",
			HANDLE_DOWNLOAD: "chrome_handle_download",
			USERSCRIPT: "chrome_userscript",
			PERFORMANCE_START_TRACE: "performance_start_trace",
			PERFORMANCE_STOP_TRACE: "performance_stop_trace",
			PERFORMANCE_ANALYZE_INSIGHT: "performance_analyze_insight",
			GIF_RECORDER: "chrome_gif_recorder"
		},
		RECORD_REPLAY: {
			FLOW_RUN: "record_replay_flow_run",
			LIST_PUBLISHED: "record_replay_list_published"
		}
	};
	TOOL_NAMES.BROWSER.GET_WINDOWS_AND_TABS, TOOL_NAMES.BROWSER.PERFORMANCE_START_TRACE, TOOL_NAMES.BROWSER.PERFORMANCE_STOP_TRACE, TOOL_NAMES.BROWSER.PERFORMANCE_ANALYZE_INSIGHT, TOOL_NAMES.BROWSER.READ_PAGE, TOOL_NAMES.BROWSER.COMPUTER, TOOL_NAMES.BROWSER.NAVIGATE, TOOL_NAMES.BROWSER.SCREENSHOT, TOOL_NAMES.BROWSER.CLOSE_TABS, TOOL_NAMES.BROWSER.SWITCH_TAB, TOOL_NAMES.BROWSER.WEB_FETCHER, TOOL_NAMES.BROWSER.NETWORK_REQUEST, TOOL_NAMES.BROWSER.NETWORK_CAPTURE, TOOL_NAMES.BROWSER.HANDLE_DOWNLOAD, TOOL_NAMES.BROWSER.HISTORY, TOOL_NAMES.BROWSER.BOOKMARK_SEARCH, TOOL_NAMES.BROWSER.BOOKMARK_ADD, TOOL_NAMES.BROWSER.BOOKMARK_DELETE, TOOL_NAMES.BROWSER.JAVASCRIPT, TOOL_NAMES.BROWSER.CLICK, TOOL_NAMES.BROWSER.FILL, TOOL_NAMES.BROWSER.REQUEST_ELEMENT_SELECTION, TOOL_NAMES.BROWSER.KEYBOARD, TOOL_NAMES.BROWSER.CONSOLE, TOOL_NAMES.BROWSER.FILE_UPLOAD, TOOL_NAMES.BROWSER.HANDLE_DIALOG, TOOL_NAMES.BROWSER.GIF_RECORDER;
	//#endregion
	//#region common/message-types.ts
	var MessageTarget = /* @__PURE__ */ function(MessageTarget) {
		MessageTarget["Offscreen"] = "offscreen";
		MessageTarget["ContentScript"] = "content_script";
		MessageTarget["Background"] = "background";
		return MessageTarget;
	}({});
	var BACKGROUND_MESSAGE_TYPES = {
		SWITCH_SEMANTIC_MODEL: "switch_semantic_model",
		GET_MODEL_STATUS: "get_model_status",
		UPDATE_MODEL_STATUS: "update_model_status",
		GET_STORAGE_STATS: "get_storage_stats",
		CLEAR_ALL_DATA: "clear_all_data",
		GET_SERVER_STATUS: "get_server_status",
		REFRESH_SERVER_STATUS: "refresh_server_status",
		SERVER_STATUS_CHANGED: "server_status_changed",
		INITIALIZE_SEMANTIC_ENGINE: "initialize_semantic_engine",
		RR_START_RECORDING: "rr_start_recording",
		RR_STOP_RECORDING: "rr_stop_recording",
		RR_PAUSE_RECORDING: "rr_pause_recording",
		RR_RESUME_RECORDING: "rr_resume_recording",
		RR_GET_RECORDING_STATUS: "rr_get_recording_status",
		RR_LIST_FLOWS: "rr_list_flows",
		RR_FLOWS_CHANGED: "rr_flows_changed",
		RR_GET_FLOW: "rr_get_flow",
		RR_DELETE_FLOW: "rr_delete_flow",
		RR_PUBLISH_FLOW: "rr_publish_flow",
		RR_UNPUBLISH_FLOW: "rr_unpublish_flow",
		RR_RUN_FLOW: "rr_run_flow",
		RR_SAVE_FLOW: "rr_save_flow",
		RR_EXPORT_FLOW: "rr_export_flow",
		RR_EXPORT_ALL: "rr_export_all",
		RR_IMPORT_FLOW: "rr_import_flow",
		RR_LIST_RUNS: "rr_list_runs",
		RR_LIST_TRIGGERS: "rr_list_triggers",
		RR_SAVE_TRIGGER: "rr_save_trigger",
		RR_DELETE_TRIGGER: "rr_delete_trigger",
		RR_REFRESH_TRIGGERS: "rr_refresh_triggers",
		RR_SCHEDULE_FLOW: "rr_schedule_flow",
		RR_UNSCHEDULE_FLOW: "rr_unschedule_flow",
		RR_LIST_SCHEDULES: "rr_list_schedules",
		ELEMENT_MARKER_LIST_ALL: "element_marker_list_all",
		ELEMENT_MARKER_LIST_FOR_URL: "element_marker_list_for_url",
		ELEMENT_MARKER_SAVE: "element_marker_save",
		ELEMENT_MARKER_UPDATE: "element_marker_update",
		ELEMENT_MARKER_DELETE: "element_marker_delete",
		ELEMENT_MARKER_VALIDATE: "element_marker_validate",
		ELEMENT_MARKER_START: "element_marker_start_from_popup",
		ELEMENT_PICKER_UI_EVENT: "element_picker_ui_event",
		ELEMENT_PICKER_FRAME_EVENT: "element_picker_frame_event",
		WEB_EDITOR_TOGGLE: "web_editor_toggle",
		WEB_EDITOR_APPLY: "web_editor_apply",
		WEB_EDITOR_STATUS_QUERY: "web_editor_status_query",
		WEB_EDITOR_APPLY_BATCH: "web_editor_apply_batch",
		WEB_EDITOR_TX_CHANGED: "web_editor_tx_changed",
		WEB_EDITOR_HIGHLIGHT_ELEMENT: "web_editor_highlight_element",
		WEB_EDITOR_REVERT_ELEMENT: "web_editor_revert_element",
		WEB_EDITOR_SELECTION_CHANGED: "web_editor_selection_changed",
		WEB_EDITOR_CLEAR_SELECTION: "web_editor_clear_selection",
		WEB_EDITOR_CANCEL_EXECUTION: "web_editor_cancel_execution",
		WEB_EDITOR_PROPS_REGISTER_EARLY_INJECTION: "web_editor_props_register_early_injection",
		WEB_EDITOR_OPEN_SOURCE: "web_editor_open_source",
		QUICK_PANEL_SEND_TO_AI: "quick_panel_send_to_ai",
		QUICK_PANEL_CANCEL_AI: "quick_panel_cancel_ai",
		QUICK_PANEL_TABS_QUERY: "quick_panel_tabs_query",
		QUICK_PANEL_TAB_ACTIVATE: "quick_panel_tab_activate",
		QUICK_PANEL_TAB_CLOSE: "quick_panel_tab_close"
	};
	var OFFSCREEN_MESSAGE_TYPES = {
		SIMILARITY_ENGINE_INIT: "similarityEngineInit",
		SIMILARITY_ENGINE_COMPUTE: "similarityEngineCompute",
		SIMILARITY_ENGINE_BATCH_COMPUTE: "similarityEngineBatchCompute",
		SIMILARITY_ENGINE_STATUS: "similarityEngineStatus",
		GIF_ADD_FRAME: "gifAddFrame",
		GIF_FINISH: "gifFinish",
		GIF_RESET: "gifReset"
	};
	var TOOL_MESSAGE_TYPES = {
		SCREENSHOT_PREPARE_PAGE_FOR_CAPTURE: "preparePageForCapture",
		SCREENSHOT_GET_PAGE_DETAILS: "getPageDetails",
		SCREENSHOT_GET_ELEMENT_DETAILS: "getElementDetails",
		SCREENSHOT_SCROLL_PAGE: "scrollPage",
		SCREENSHOT_RESET_PAGE_AFTER_CAPTURE: "resetPageAfterCapture",
		WEB_FETCHER_GET_HTML_CONTENT: "getHtmlContent",
		WEB_FETCHER_GET_TEXT_CONTENT: "getTextContent",
		CLICK_ELEMENT: "clickElement",
		FILL_ELEMENT: "fillElement",
		SIMULATE_KEYBOARD: "simulateKeyboard",
		GET_INTERACTIVE_ELEMENTS: "getInteractiveElements",
		GENERATE_ACCESSIBILITY_TREE: "generateAccessibilityTree",
		RESOLVE_REF: "resolveRef",
		ENSURE_REF_FOR_SELECTOR: "ensureRefForSelector",
		VERIFY_FINGERPRINT: "verifyFingerprint",
		DISPATCH_HOVER_FOR_REF: "dispatchHoverForRef",
		NETWORK_SEND_REQUEST: "sendPureNetworkRequest",
		WAIT_FOR_TEXT: "waitForText",
		SIMILARITY_ENGINE_INIT: "similarityEngineInit",
		SIMILARITY_ENGINE_COMPUTE_BATCH: "similarityEngineComputeBatch",
		RR_RECORDER_CONTROL: "rr_recorder_control",
		RR_RECORDER_EVENT: "rr_recorder_event",
		RR_TIMELINE_UPDATE: "rr_timeline_update",
		QUICK_PANEL_AI_EVENT: "quick_panel_ai_event",
		SET_DOM_TRIGGERS: "set_dom_triggers",
		DOM_TRIGGER_FIRED: "dom_trigger_fired",
		COLLECT_VARIABLES: "collectVariables",
		ELEMENT_MARKER_START: "element_marker_start",
		ELEMENT_PICKER_START: "elementPickerStart",
		ELEMENT_PICKER_STOP: "elementPickerStop",
		ELEMENT_PICKER_SET_ACTIVE_REQUEST: "elementPickerSetActiveRequest",
		ELEMENT_PICKER_UI_PING: "elementPickerUiPing",
		ELEMENT_PICKER_UI_SHOW: "elementPickerUiShow",
		ELEMENT_PICKER_UI_UPDATE: "elementPickerUiUpdate",
		ELEMENT_PICKER_UI_HIDE: "elementPickerUiHide"
	};
	//#endregion
	//#region common/constants.ts
	/**
	* Chrome Extension Constants
	* Centralized configuration values and magic constants
	*/
	var NATIVE_HOST = {
		NAME: "com.gakr.chrome.bridge",
		DEFAULT_PORT: 12306
	};
	var TIMEOUTS = {
		DEFAULT_WAIT: 1e3,
		NETWORK_CAPTURE_MAX: 3e4,
		NETWORK_CAPTURE_IDLE: 3e3,
		SCREENSHOT_DELAY: 100,
		KEYBOARD_DELAY: 50,
		CLICK_DELAY: 100
	};
	var LIMITS = {
		MAX_NETWORK_REQUESTS: 100,
		MAX_SEARCH_RESULTS: 50,
		MAX_BOOKMARK_RESULTS: 100,
		MAX_HISTORY_RESULTS: 100,
		SIMILARITY_THRESHOLD: .1,
		VECTOR_DIMENSIONS: 384
	};
	var ERROR_MESSAGES = {
		NATIVE_CONNECTION_FAILED: "Failed to connect to native host",
		NATIVE_DISCONNECTED: "Native connection disconnected",
		SERVER_STATUS_LOAD_FAILED: "Failed to load server status",
		SERVER_STATUS_SAVE_FAILED: "Failed to save server status",
		TOOL_EXECUTION_FAILED: "Tool execution failed",
		INVALID_PARAMETERS: "Invalid parameters provided",
		PERMISSION_DENIED: "Permission denied",
		TAB_NOT_FOUND: "Tab not found",
		ELEMENT_NOT_FOUND: "Element not found",
		NETWORK_ERROR: "Network error occurred"
	};
	var SUCCESS_MESSAGES = {
		TOOL_EXECUTED: "Tool executed successfully",
		CONNECTION_ESTABLISHED: "Connection established",
		SERVER_STARTED: "Server started successfully",
		SERVER_STOPPED: "Server stopped successfully"
	};
	var NETWORK_FILTERS = {
		EXCLUDED_DOMAINS: [
			"google-analytics.com",
			"googletagmanager.com",
			"analytics.google.com",
			"doubleclick.net",
			"googlesyndication.com",
			"googleads.g.doubleclick.net",
			"stats.g.doubleclick.net",
			"adservice.google.com",
			"pagead2.googlesyndication.com",
			"amazon-adsystem.com",
			"bat.bing.com",
			"clarity.ms",
			"connect.facebook.net",
			"facebook.com/tr",
			"analytics.twitter.com",
			"ads-twitter.com",
			"ads.yahoo.com",
			"adroll.com",
			"adnxs.com",
			"criteo.com",
			"quantserve.com",
			"scorecardresearch.com",
			"segment.io",
			"amplitude.com",
			"mixpanel.com",
			"optimizely.com",
			"static.hotjar.com",
			"script.hotjar.com",
			"crazyegg.com",
			"clicktale.net",
			"mouseflow.com",
			"fullstory.com",
			"linkedin.com/px"
		],
		STATIC_RESOURCE_EXTENSIONS: [
			".jpg",
			".jpeg",
			".png",
			".gif",
			".svg",
			".webp",
			".ico",
			".bmp",
			".cur",
			".css",
			".scss",
			".less",
			".js",
			".jsx",
			".ts",
			".tsx",
			".map",
			".woff",
			".woff2",
			".ttf",
			".eot",
			".otf",
			".mp3",
			".mp4",
			".avi",
			".mov",
			".wmv",
			".flv",
			".webm",
			".ogg",
			".wav",
			".pdf",
			".zip",
			".rar",
			".7z",
			".iso",
			".dmg",
			".doc",
			".docx",
			".xls",
			".xlsx",
			".ppt",
			".pptx"
		],
		STATIC_MIME_TYPES_TO_FILTER: [
			"image/",
			"font/",
			"audio/",
			"video/",
			"text/css",
			"text/javascript",
			"application/javascript",
			"application/x-javascript",
			"application/pdf",
			"application/zip",
			"application/octet-stream"
		],
		API_MIME_TYPES: [
			"application/json",
			"application/xml",
			"text/xml",
			"text/plain",
			"text/event-stream",
			"application/x-www-form-urlencoded",
			"application/graphql",
			"application/grpc",
			"application/protobuf",
			"application/x-protobuf",
			"application/x-json",
			"application/ld+json",
			"application/problem+json",
			"application/problem+xml",
			"application/soap+xml",
			"application/vnd.api+json"
		],
		STATIC_RESOURCE_TYPES: [
			"stylesheet",
			"image",
			"font",
			"media",
			"other"
		]
	};
	var STORAGE_KEYS = {
		SERVER_STATUS: "serverStatus",
		NATIVE_SERVER_PORT: "nativeServerPort",
		NATIVE_AUTO_CONNECT_ENABLED: "nativeAutoConnectEnabled",
		SEMANTIC_MODEL: "selectedModel",
		USER_PREFERENCES: "userPreferences",
		VECTOR_INDEX: "vectorIndex",
		USERSCRIPTS: "userscripts",
		USERSCRIPTS_DISABLED: "userscripts_disabled",
		RR_FLOWS: "rr_flows",
		RR_RUNS: "rr_runs",
		RR_PUBLISHED: "rr_published_flows",
		RR_SCHEDULES: "rr_schedules",
		RR_TRIGGERS: "rr_triggers",
		RR_RECORDING_STATE: "rr_recording_state"
	};
	var ExecutionWorld = /* @__PURE__ */ function(ExecutionWorld) {
		ExecutionWorld["ISOLATED"] = "ISOLATED";
		ExecutionWorld["MAIN"] = "MAIN";
		return ExecutionWorld;
	}({});
	//#endregion
	//#region common/tool-handler.ts
	var createErrorResponse = (message = "Unknown error, please try again") => {
		return {
			content: [{
				type: "text",
				text: message
			}],
			isError: true
		};
	};
	//#endregion
	//#region \0@oxc-project+runtime@0.137.0/helpers/esm/asyncToGenerator.js
	function asyncGeneratorStep(n, t, e, r, o, a, c) {
		try {
			var i = n[a](c), u = i.value;
		} catch (n) {
			e(n);
			return;
		}
		i.done ? t(u) : Promise.resolve(u).then(r, o);
	}
	function _asyncToGenerator(n) {
		return function() {
			var t = this, e = arguments;
			return new Promise(function(r, o) {
				var a = n.apply(t, e);
				function _next(n) {
					asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
				}
				function _throw(n) {
					asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
				}
				_next(void 0);
			});
		};
	}
	var init_asyncToGenerator = __esmMin((() => {}));
	//#endregion
	//#region entrypoints/background/tools/base-browser.ts
	init_asyncToGenerator();
	var PING_TIMEOUT_MS = 300;
	/**
	* Base class for browser tool executors
	*/
	var BaseBrowserToolExecutor = class {
		/**
		* Inject content script into tab
		*/
		injectContentScript(tabId, files, injectImmediately = false, world = "ISOLATED", allFrames = false, frameIds) {
			var _this = this;
			return _asyncToGenerator(function* () {
				console.log(`Injecting ${files.join(", ")} into tab ${tabId}`);
				try {
					const pingFrameId = frameIds === null || frameIds === void 0 ? void 0 : frameIds[0];
					const response = yield Promise.race([typeof pingFrameId === "number" ? chrome.tabs.sendMessage(tabId, { action: `${_this.name}_ping` }, { frameId: pingFrameId }) : chrome.tabs.sendMessage(tabId, { action: `${_this.name}_ping` }), new Promise((_, reject) => setTimeout(() => reject(/* @__PURE__ */ new Error(`${_this.name} Ping action to tab ${tabId} timed out`)), PING_TIMEOUT_MS))]);
					if (response && response.status === "pong") {
						console.log(`pong received for action '${_this.name}' in tab ${tabId}. Assuming script is active.`);
						return;
					} else console.warn(`Unexpected ping response in tab ${tabId}:`, response);
				} catch (error) {
					console.error(`ping content script failed: ${error instanceof Error ? error.message : String(error)}`);
				}
				try {
					const target = { tabId };
					if (frameIds && frameIds.length > 0) target.frameIds = frameIds;
					else if (allFrames) target.allFrames = true;
					yield chrome.scripting.executeScript({
						target,
						files,
						injectImmediately,
						world
					});
					console.log(`'${files.join(", ")}' injection successful for tab ${tabId}`);
				} catch (injectionError) {
					const errorMessage = injectionError instanceof Error ? injectionError.message : String(injectionError);
					console.error(`Content script '${files.join(", ")}' injection failed for tab ${tabId}: ${errorMessage}`);
					throw new Error(`${ERROR_MESSAGES.TOOL_EXECUTION_FAILED}: Failed to inject content script in tab ${tabId}: ${errorMessage}`);
				}
			})();
		}
		/**
		* Send message to tab
		*/
		sendMessageToTab(tabId, message, frameId) {
			return _asyncToGenerator(function* () {
				try {
					const response = typeof frameId === "number" ? yield chrome.tabs.sendMessage(tabId, message, { frameId }) : yield chrome.tabs.sendMessage(tabId, message);
					if (response && response.error) throw new Error(String(response.error));
					return response;
				} catch (error) {
					const errorMessage = error instanceof Error ? error.message : String(error);
					console.error(`Error sending message to tab ${tabId} for action ${(message === null || message === void 0 ? void 0 : message.action) || "unknown"}: ${errorMessage}`);
					if (error instanceof Error) throw error;
					throw new Error(errorMessage);
				}
			})();
		}
		/**
		* Try to get an existing tab by id. Returns null when not found.
		*/
		tryGetTab(tabId) {
			return _asyncToGenerator(function* () {
				if (typeof tabId !== "number") return null;
				try {
					return yield chrome.tabs.get(tabId);
				} catch (_unused) {
					return null;
				}
			})();
		}
		/**
		* Get the active tab in the current window. Throws when not found.
		*/
		getActiveTabOrThrow() {
			return _asyncToGenerator(function* () {
				const [active] = yield chrome.tabs.query({
					active: true,
					currentWindow: true
				});
				if (!active || !active.id) throw new Error("Active tab not found");
				return active;
			})();
		}
		/**
		* Optionally focus window and/or activate tab. Defaults preserve current behavior
		* when caller sets activate/focus flags explicitly.
		*/
		ensureFocus(_x) {
			return _asyncToGenerator(function* (tab, options = {}) {
				const activate = options.activate === true;
				if (options.focusWindow === true && typeof tab.windowId === "number") yield chrome.windows.update(tab.windowId, { focused: true });
				if (activate && typeof tab.id === "number") yield chrome.tabs.update(tab.id, { active: true });
			}).apply(this, arguments);
		}
		/**
		* Get the active tab. When windowId provided, search within that window; otherwise currentWindow.
		*/
		getActiveTabInWindow(windowId) {
			return _asyncToGenerator(function* () {
				if (typeof windowId === "number") {
					const tabs = yield chrome.tabs.query({
						active: true,
						windowId
					});
					return tabs && tabs[0] ? tabs[0] : null;
				}
				const tabs = yield chrome.tabs.query({
					active: true,
					currentWindow: true
				});
				return tabs && tabs[0] ? tabs[0] : null;
			})();
		}
		/**
		* Same as getActiveTabInWindow, but throws if not found.
		*/
		getActiveTabOrThrowInWindow(windowId) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				const tab = yield _this2.getActiveTabInWindow(windowId);
				if (!tab || !tab.id) throw new Error("Active tab not found");
				return tab;
			})();
		}
	};
	//#endregion
	//#region utils/cdp-session-manager.ts
	var cdp_session_manager_exports = /* @__PURE__ */ __exportAll({ cdpSessionManager: () => cdpSessionManager });
	var DEBUGGER_PROTOCOL_VERSION, CDPSessionManager, cdpSessionManager;
	var init_cdp_session_manager = __esmMin((() => {
		init_defineProperty();
		init_asyncToGenerator();
		DEBUGGER_PROTOCOL_VERSION = "1.3";
		CDPSessionManager = class {
			constructor() {
				_defineProperty(this, "sessions", /* @__PURE__ */ new Map());
			}
			getState(tabId) {
				return this.sessions.get(tabId);
			}
			setState(tabId, state) {
				this.sessions.set(tabId, state);
			}
			attach(tabId, owner = "unknown") {
				var _this = this;
				return _asyncToGenerator(function* () {
					const state = _this.getState(tabId);
					if (state && state.attachedByUs) {
						state.refCount += 1;
						state.owners.add(owner);
						return;
					}
					const existing = (yield chrome.debugger.getTargets()).find((t) => t.tabId === tabId && t.attached);
					if (existing) {
						if (existing.extensionId === chrome.runtime.id) {
							_this.setState(tabId, {
								refCount: state ? state.refCount + 1 : 1,
								owners: /* @__PURE__ */ new Set([...(state === null || state === void 0 ? void 0 : state.owners) || [], owner]),
								attachedByUs: true
							});
							return;
						}
						throw new Error(`Debugger is already attached to tab ${tabId} by another client (e.g., DevTools/extension)`);
					}
					yield chrome.debugger.attach({ tabId }, DEBUGGER_PROTOCOL_VERSION);
					_this.setState(tabId, {
						refCount: 1,
						owners: /* @__PURE__ */ new Set([owner]),
						attachedByUs: true
					});
				})();
			}
			detach(tabId, owner = "unknown") {
				var _this2 = this;
				return _asyncToGenerator(function* () {
					const state = _this2.getState(tabId);
					if (!state) return;
					if (state.owners.has(owner)) state.owners.delete(owner);
					state.refCount = Math.max(0, state.refCount - 1);
					if (state.refCount > 0) return;
					try {
						if (state.attachedByUs) yield chrome.debugger.detach({ tabId });
					} catch (e) {} finally {
						_this2.sessions.delete(tabId);
					}
				})();
			}
			/**
			* Convenience wrapper: ensures attach before fn, and balanced detach after.
			*/
			withSession(tabId, owner, fn) {
				var _this3 = this;
				return _asyncToGenerator(function* () {
					yield _this3.attach(tabId, owner);
					try {
						return yield fn();
					} finally {
						yield _this3.detach(tabId, owner);
					}
				})();
			}
			/**
			* Send a CDP command. Requires that this manager has attached to the tab.
			* If not attached by us, will attempt a one-shot attach around the call.
			*/
			sendCommand(tabId, method, params) {
				var _this4 = this;
				return _asyncToGenerator(function* () {
					const state = _this4.getState(tabId);
					if (state && state.attachedByUs) return yield chrome.debugger.sendCommand({ tabId }, method, params);
					return yield _this4.withSession(tabId, `send:${method}`, _asyncToGenerator(function* () {
						return yield chrome.debugger.sendCommand({ tabId }, method, params);
					}));
				})();
			}
		};
		cdpSessionManager = new CDPSessionManager();
	}));
	//#endregion
	//#region utils/offscreen-manager.ts
	init_cdp_session_manager();
	init_defineProperty();
	init_asyncToGenerator();
	/**
	* Offscreen Document manager
	* Ensures only one offscreen document is created across the entire extension to avoid conflicts
	*/
	var OffscreenManager = class OffscreenManager {
		constructor() {
			_defineProperty(this, "isCreated", false);
			_defineProperty(this, "isCreating", false);
			_defineProperty(this, "createPromise", null);
		}
		/**
		* Get singleton instance
		*/
		static getInstance() {
			if (!OffscreenManager.instance) OffscreenManager.instance = new OffscreenManager();
			return OffscreenManager.instance;
		}
		/**
		* Ensure offscreen document exists
		*/
		ensureOffscreenDocument() {
			var _this = this;
			return _asyncToGenerator(function* () {
				if (_this.isCreated) return;
				if (_this.isCreating && _this.createPromise) return _this.createPromise;
				_this.isCreating = true;
				_this.createPromise = _this._doCreateOffscreenDocument().finally(() => {
					_this.isCreating = false;
				});
				return _this.createPromise;
			})();
		}
		_doCreateOffscreenDocument() {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				try {
					if (!chrome.offscreen) throw new Error("Offscreen API not available. Chrome 109+ required.");
					const existingContexts = yield chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
					if (existingContexts && existingContexts.length > 0) {
						console.log("OffscreenManager: Offscreen document already exists");
						_this2.isCreated = true;
						return;
					}
					yield chrome.offscreen.createDocument({
						url: "offscreen.html",
						reasons: ["WORKERS"],
						justification: "Need to run semantic similarity engine with workers"
					});
					_this2.isCreated = true;
					console.log("OffscreenManager: Offscreen document created successfully");
				} catch (error) {
					console.error("OffscreenManager: Failed to create offscreen document:", error);
					_this2.isCreated = false;
					throw error;
				}
			})();
		}
		/**
		* Check if offscreen document is created
		*/
		isOffscreenDocumentCreated() {
			return this.isCreated;
		}
		/**
		* Close offscreen document
		*/
		closeOffscreenDocument() {
			var _this3 = this;
			return _asyncToGenerator(function* () {
				try {
					if (chrome.offscreen && _this3.isCreated) {
						yield chrome.offscreen.closeDocument();
						_this3.isCreated = false;
						console.log("OffscreenManager: Offscreen document closed");
					}
				} catch (error) {
					console.error("OffscreenManager: Failed to close offscreen document:", error);
				}
			})();
		}
		/**
		* Reset state (for testing)
		*/
		reset() {
			this.isCreated = false;
			this.isCreating = false;
			this.createPromise = null;
		}
	};
	_defineProperty(OffscreenManager, "instance", null);
	var offscreenManager = OffscreenManager.getInstance();
	//#endregion
	//#region utils/image-utils.ts
	init_asyncToGenerator();
	/**
	* Image processing utility functions
	*/
	/**
	* Create ImageBitmap from data URL (for OffscreenCanvas)
	* @param dataUrl Image data URL
	* @returns Created ImageBitmap object
	*/
	function createImageBitmapFromUrl(_x) {
		return _createImageBitmapFromUrl.apply(this, arguments);
	}
	function _createImageBitmapFromUrl() {
		_createImageBitmapFromUrl = _asyncToGenerator(function* (dataUrl) {
			const blob = yield (yield fetch(dataUrl)).blob();
			return yield createImageBitmap(blob);
		});
		return _createImageBitmapFromUrl.apply(this, arguments);
	}
	/**
	* Stitch multiple image parts (dataURL) onto a single canvas
	* @param parts Array of image parts, each containing dataUrl and y coordinate
	* @param totalWidthPx Total width (pixels)
	* @param totalHeightPx Total height (pixels)
	* @returns Stitched canvas
	*/
	function stitchImages(_x2, _x3, _x4) {
		return _stitchImages.apply(this, arguments);
	}
	function _stitchImages() {
		_stitchImages = _asyncToGenerator(function* (parts, totalWidthPx, totalHeightPx) {
			const canvas = new OffscreenCanvas(totalWidthPx, totalHeightPx);
			const ctx = canvas.getContext("2d");
			if (!ctx) throw new Error("Unable to get canvas context");
			ctx.fillStyle = "#FFFFFF";
			ctx.fillRect(0, 0, canvas.width, canvas.height);
			for (const part of parts) try {
				const img = yield createImageBitmapFromUrl(part.dataUrl);
				const sx = 0;
				const sy = 0;
				const sWidth = img.width;
				let sHeight = img.height;
				const dy = part.y;
				if (dy + sHeight > totalHeightPx) sHeight = totalHeightPx - dy;
				if (sHeight <= 0) continue;
				ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, dy, sWidth, sHeight);
			} catch (error) {
				console.error("Error stitching image part:", error, part);
			}
			return canvas;
		});
		return _stitchImages.apply(this, arguments);
	}
	/**
	* Crop image (from dataURL) to specified rectangle and resize
	* @param originalDataUrl Original image data URL
	* @param cropRectPx Crop rectangle (physical pixels)
	* @param dpr Device pixel ratio
	* @param targetWidthOpt Optional target output width (CSS pixels)
	* @param targetHeightOpt Optional target output height (CSS pixels)
	* @returns Cropped canvas
	*/
	function cropAndResizeImage(_x5, _x6) {
		return _cropAndResizeImage.apply(this, arguments);
	}
	function _cropAndResizeImage() {
		_cropAndResizeImage = _asyncToGenerator(function* (originalDataUrl, cropRectPx, dpr = 1, targetWidthOpt, targetHeightOpt) {
			const img = yield createImageBitmapFromUrl(originalDataUrl);
			let sx = cropRectPx.x;
			let sy = cropRectPx.y;
			let sWidth = cropRectPx.width;
			let sHeight = cropRectPx.height;
			if (sx < 0) {
				sWidth += sx;
				sx = 0;
			}
			if (sy < 0) {
				sHeight += sy;
				sy = 0;
			}
			if (sx + sWidth > img.width) sWidth = img.width - sx;
			if (sy + sHeight > img.height) sHeight = img.height - sy;
			if (sWidth <= 0 || sHeight <= 0) throw new Error("Invalid calculated crop size (<=0). Element may not be visible or fully captured.");
			const finalCanvasWidthPx = targetWidthOpt ? targetWidthOpt * dpr : sWidth;
			const finalCanvasHeightPx = targetHeightOpt ? targetHeightOpt * dpr : sHeight;
			const canvas = new OffscreenCanvas(finalCanvasWidthPx, finalCanvasHeightPx);
			const ctx = canvas.getContext("2d");
			if (!ctx) throw new Error("Unable to get canvas context");
			ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, finalCanvasWidthPx, finalCanvasHeightPx);
			return canvas;
		});
		return _cropAndResizeImage.apply(this, arguments);
	}
	/**
	* Convert canvas to data URL
	* @param canvas Canvas
	* @param format Image format
	* @param quality JPEG quality (0-1)
	* @returns Data URL
	*/
	function canvasToDataURL(_x7) {
		return _canvasToDataURL.apply(this, arguments);
	}
	function _canvasToDataURL() {
		_canvasToDataURL = _asyncToGenerator(function* (canvas, format = "image/png", quality) {
			const blob = yield canvas.convertToBlob({
				type: format,
				quality: format === "image/jpeg" ? quality : void 0
			});
			return new Promise((resolve, reject) => {
				const reader = new FileReader();
				reader.onloadend = () => resolve(reader.result);
				reader.onerror = reject;
				reader.readAsDataURL(blob);
			});
		});
		return _canvasToDataURL.apply(this, arguments);
	}
	/**
	* Compresses an image by scaling it and converting it to a target format with a specific quality.
	* This is the most effective way to reduce image data size for transport or storage.
	*
	* @param {string} imageDataUrl - The original image data URL (e.g., from captureVisibleTab).
	* @param {object} options - Compression options.
	* @param {number} [options.scale=1.0] - The scaling factor for dimensions (e.g., 0.7 for 70%).
	* @param {number} [options.quality=0.8] - The quality for lossy formats like JPEG (0.0 to 1.0).
	* @param {string} [options.format='image/jpeg'] - The target image format.
	* @returns {Promise<{dataUrl: string, mimeType: string}>} A promise that resolves to the compressed image data URL and its MIME type.
	*/
	function compressImage(_x8, _x9) {
		return _compressImage.apply(this, arguments);
	}
	function _compressImage() {
		_compressImage = _asyncToGenerator(function* (imageDataUrl, options) {
			const { scale = 1, quality = .8, format = "image/jpeg" } = options;
			const imageBitmap = yield createImageBitmapFromUrl(imageDataUrl);
			const newWidth = Math.round(imageBitmap.width * scale);
			const newHeight = Math.round(imageBitmap.height * scale);
			const canvas = new OffscreenCanvas(newWidth, newHeight);
			const ctx = canvas.getContext("2d");
			if (!ctx) throw new Error("Failed to get 2D context from OffscreenCanvas");
			ctx.drawImage(imageBitmap, 0, 0, newWidth, newHeight);
			const compressedDataUrl = yield canvas.convertToBlob({
				type: format,
				quality
			});
			return {
				dataUrl: yield new Promise((resolve) => {
					const reader = new FileReader();
					reader.onloadend = () => resolve(reader.result);
					reader.readAsDataURL(compressedDataUrl);
				}),
				mimeType: format
			};
		});
		return _compressImage.apply(this, arguments);
	}
	//#endregion
	//#region entrypoints/background/tools/browser/gif-enhanced-renderer.ts
	var CLICK_ACTIONS = [
		"click",
		"double_click",
		"triple_click",
		"right_click"
	];
	function clamp(value, min, max) {
		return Math.min(max, Math.max(min, value));
	}
	function normalizePositiveNumber(value, fallback, min, max) {
		if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
		return clamp(value, min, max);
	}
	function normalizePositiveInt$3(value, fallback, min, max) {
		if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
		return clamp(Math.floor(value), min, max);
	}
	function normalizeDash(value, fallback) {
		if (!Array.isArray(value)) return fallback;
		const nums = value.filter((n) => typeof n === "number" && Number.isFinite(n) && n > 0);
		return nums.length >= 2 ? nums : fallback;
	}
	function easeOutCubic(t) {
		const x = clamp(t, 0, 1);
		return 1 - Math.pow(1 - x, 3);
	}
	function projectPoint(point, viewportWidth, viewportHeight, outputWidth, outputHeight) {
		if (typeof point.x !== "number" || typeof point.y !== "number" || !Number.isFinite(point.x) || !Number.isFinite(point.y)) return null;
		const vw = viewportWidth > 0 ? viewportWidth : outputWidth;
		const vh = viewportHeight > 0 ? viewportHeight : outputHeight;
		return {
			x: point.x / vw * outputWidth,
			y: point.y / vh * outputHeight
		};
	}
	function buildRoundedRectPath(ctx, x, y, width, height, radius) {
		const r = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
		const x2 = x + width;
		const y2 = y + height;
		ctx.moveTo(x + r, y);
		ctx.arcTo(x2, y, x2, y2, r);
		ctx.arcTo(x2, y2, x, y2, r);
		ctx.arcTo(x, y2, x, y, r);
		ctx.arcTo(x, y, x2, y, r);
	}
	function truncate(text, maxLength) {
		const trimmed = text.trim();
		if (trimmed.length <= maxLength) return trimmed;
		return `${trimmed.slice(0, Math.max(0, maxLength - 1))}…`;
	}
	function resolveActionLabel(action, cfg) {
		const explicit = typeof action.label === "string" ? action.label.trim() : "";
		const isExplicit = explicit.length > 0;
		const mode = cfg.mode;
		const canShowAction = mode === "action" || mode === "both";
		const canShowAnnotation = mode === "annotation" || mode === "both";
		if ((action.type === "annotation" || isExplicit) && canShowAnnotation) {
			const labelText = explicit || (typeof action.text === "string" ? action.text.trim() : "");
			return labelText.length > 0 ? truncate(labelText, cfg.maxLength) : null;
		}
		if (!canShowAction) return null;
		switch (action.type) {
			case "click":
			case "double_click":
			case "triple_click":
			case "right_click":
				if (!cfg.showForClicks) return null;
				return action.type.replace("_", " ").toUpperCase();
			case "drag": return "DRAG";
			case "scroll": return "SCROLL";
			case "hover": return "HOVER";
			case "navigate":
				if (!action.url) return "NAVIGATE";
				try {
					const host = new URL(action.url).hostname;
					return host ? `→ ${host}` : "NAVIGATE";
				} catch (_unused) {
					return "NAVIGATE";
				}
			case "type": {
				const content = typeof action.text === "string" ? action.text : "";
				return content.trim().length > 0 ? `TYPE "${truncate(content, cfg.maxLength)}"` : "TYPE";
			}
			case "key": {
				const content = typeof action.text === "string" ? action.text : "";
				return content.trim().length > 0 ? `KEY [${truncate(content, cfg.maxLength)}]` : "KEY";
			}
			case "fill": {
				const content = typeof action.text === "string" ? action.text : "";
				return content.trim().length > 0 ? `FILL "${truncate(content, cfg.maxLength)}"` : "FILL";
			}
			default: return null;
		}
	}
	function resolveAnchorPoint(action) {
		if (action.type === "drag") return action.endCoordinates || action.coordinates || action.startCoordinates || null;
		return action.coordinates || action.endCoordinates || action.startCoordinates || null;
	}
	function drawClickIndicator(ctx, x, y, progress, type, cfg) {
		const eased = easeOutCubic(clamp(progress, 0, 1));
		const base = cfg.radiusPx;
		const radius = base * (.35 + .95 * eased);
		const alpha = 1 - eased;
		ctx.save();
		ctx.globalAlpha = alpha;
		ctx.lineWidth = cfg.lineWidthPx;
		ctx.strokeStyle = cfg.color;
		ctx.fillStyle = cfg.fillColor;
		ctx.shadowColor = "rgba(0, 0, 0, 0.25)";
		ctx.shadowBlur = 8;
		ctx.beginPath();
		ctx.arc(x, y, radius, 0, Math.PI * 2);
		ctx.stroke();
		ctx.shadowBlur = 0;
		if (type === "double_click" || type === "triple_click") {
			ctx.globalAlpha = 1;
			ctx.fillStyle = cfg.color;
			ctx.font = `700 ${Math.max(10, Math.round(base * .6))}px system-ui, -apple-system, Segoe UI, Roboto, sans-serif`;
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			ctx.fillText(type === "double_click" ? "2×" : "3×", x, y);
		} else {
			ctx.beginPath();
			ctx.arc(x, y, Math.max(2, base * .16), 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.restore();
	}
	function drawArrowHead(ctx, x1, y1, x2, y2, size) {
		const dx = x2 - x1;
		const dy = y2 - y1;
		const len = Math.hypot(dx, dy);
		if (!Number.isFinite(len) || len < 1) return;
		const ux = dx / len;
		const uy = dy / len;
		const px = -uy;
		const py = ux;
		const headLen = size;
		const headWidth = size * .65;
		const backX = x2 - ux * headLen;
		const backY = y2 - uy * headLen;
		ctx.beginPath();
		ctx.moveTo(x2, y2);
		ctx.lineTo(backX + px * headWidth, backY + py * headWidth);
		ctx.lineTo(backX - px * headWidth, backY - py * headWidth);
		ctx.closePath();
		ctx.fill();
	}
	function drawDragPath(ctx, start, end, progress, cfg) {
		const alpha = 1 - easeOutCubic(clamp(progress, 0, 1));
		ctx.save();
		ctx.globalAlpha = alpha;
		ctx.strokeStyle = cfg.color;
		ctx.fillStyle = cfg.color;
		ctx.lineWidth = cfg.lineWidthPx;
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		ctx.setLineDash(cfg.dash);
		ctx.shadowColor = "rgba(0, 0, 0, 0.2)";
		ctx.shadowBlur = 6;
		ctx.beginPath();
		ctx.moveTo(start.x, start.y);
		ctx.lineTo(end.x, end.y);
		ctx.stroke();
		ctx.setLineDash([]);
		ctx.shadowBlur = 0;
		ctx.beginPath();
		ctx.arc(start.x, start.y, cfg.startDotRadiusPx, 0, Math.PI * 2);
		ctx.fill();
		ctx.beginPath();
		ctx.arc(end.x, end.y, cfg.endDotRadiusPx, 0, Math.PI * 2);
		ctx.fill();
		drawArrowHead(ctx, start.x, start.y, end.x, end.y, cfg.arrowSizePx);
		ctx.restore();
	}
	function drawLabelPill(ctx, text, anchor, alpha, cfg, outputWidth, outputHeight) {
		var _anchor$x, _anchor$y;
		ctx.save();
		ctx.globalAlpha = clamp(alpha, 0, 1);
		ctx.font = cfg.font;
		ctx.textAlign = "left";
		ctx.textBaseline = "middle";
		const metrics = ctx.measureText(text);
		const textHeight = (Number.isFinite(metrics.actualBoundingBoxAscent) ? metrics.actualBoundingBoxAscent : 10) + (Number.isFinite(metrics.actualBoundingBoxDescent) ? metrics.actualBoundingBoxDescent : 4);
		const pillWidth = Math.ceil(metrics.width + cfg.paddingX * 2);
		const pillHeight = Math.ceil(textHeight + cfg.paddingY * 2);
		const margin = 4;
		const ax = (_anchor$x = anchor === null || anchor === void 0 ? void 0 : anchor.x) !== null && _anchor$x !== void 0 ? _anchor$x : margin;
		const ay = (_anchor$y = anchor === null || anchor === void 0 ? void 0 : anchor.y) !== null && _anchor$y !== void 0 ? _anchor$y : margin;
		let x = ax + cfg.offsetPx;
		let y = ay - pillHeight / 2;
		if (x + pillWidth > outputWidth - margin) x = ax - cfg.offsetPx - pillWidth;
		if (y < margin) y = ay + cfg.offsetPx;
		if (y + pillHeight > outputHeight - margin) y = outputHeight - margin - pillHeight;
		x = clamp(x, margin, Math.max(margin, outputWidth - margin - pillWidth));
		y = clamp(y, margin, Math.max(margin, outputHeight - margin - pillHeight));
		ctx.fillStyle = cfg.backgroundColor;
		ctx.strokeStyle = cfg.borderColor;
		ctx.lineWidth = 1;
		ctx.beginPath();
		buildRoundedRectPath(ctx, x, y, pillWidth, pillHeight, cfg.radiusPx);
		ctx.fill();
		ctx.stroke();
		ctx.fillStyle = cfg.textColor;
		ctx.fillText(text, x + cfg.paddingX, y + pillHeight / 2);
		ctx.restore();
	}
	function normalizeSchemaInput(raw) {
		var _input$enabled;
		if (raw === true) return { enabled: true };
		if (!raw || typeof raw !== "object") return;
		const input = raw;
		const result = {};
		result.enabled = (_input$enabled = input.enabled) !== null && _input$enabled !== void 0 ? _input$enabled : true;
		const globalDuration = typeof input.durationMs === "number" ? input.durationMs : void 0;
		if (input.clickIndicators === false) result.clickIndicators = { enabled: false };
		else if (input.clickIndicators === true) result.clickIndicators = { enabled: true };
		else if (typeof input.clickIndicators === "object") {
			var _ci$enabled, _ci$animationDuration;
			const ci = input.clickIndicators;
			result.clickIndicators = {
				enabled: (_ci$enabled = ci.enabled) !== null && _ci$enabled !== void 0 ? _ci$enabled : true,
				color: ci.color,
				radiusPx: ci.radius,
				durationMs: (_ci$animationDuration = ci.animationDurationMs) !== null && _ci$animationDuration !== void 0 ? _ci$animationDuration : globalDuration,
				animationFrames: ci.animationFrames,
				animationIntervalMs: ci.animationIntervalMs
			};
		}
		if (input.dragPaths === false) result.dragPaths = { enabled: false };
		else if (input.dragPaths === true) result.dragPaths = { enabled: true };
		else if (typeof input.dragPaths === "object") {
			var _dp$enabled;
			const dp = input.dragPaths;
			result.dragPaths = {
				enabled: (_dp$enabled = dp.enabled) !== null && _dp$enabled !== void 0 ? _dp$enabled : true,
				color: dp.color,
				lineWidthPx: dp.lineWidth,
				dash: dp.lineDash,
				arrowSizePx: dp.arrowSize,
				durationMs: globalDuration
			};
		}
		if (input.labels === false) result.labels = { enabled: false };
		else if (input.labels === true) result.labels = { enabled: true };
		else if (typeof input.labels === "object") {
			var _lb$enabled;
			const lb = input.labels;
			const offset = lb.offset;
			const offsetPx = typeof offset === "number" ? offset : typeof offset === "object" ? offset.x : void 0;
			result.labels = {
				enabled: (_lb$enabled = lb.enabled) !== null && _lb$enabled !== void 0 ? _lb$enabled : true,
				font: lb.font,
				textColor: lb.textColor,
				backgroundColor: lb.bgColor,
				paddingX: typeof lb.padding === "number" ? lb.padding : void 0,
				paddingY: typeof lb.padding === "number" ? lb.padding : void 0,
				radiusPx: lb.borderRadius,
				offsetPx,
				durationMs: globalDuration
			};
		}
		return result;
	}
	function resolveGifEnhancedRenderingConfig(input) {
		var _normalizeSchemaInput, _normalized$enabled, _normalized$clickIndi, _normalized$clickIndi2, _normalized$clickIndi3, _normalized$clickIndi4, _normalized$clickIndi5, _normalized$clickIndi6, _normalized$clickIndi7, _normalized$clickIndi8, _normalized$clickIndi9, _normalized$clickIndi10, _normalized$clickIndi11, _normalized$clickIndi12, _normalized$dragPaths, _normalized$dragPaths2, _normalized$dragPaths3, _normalized$dragPaths4, _normalized$dragPaths5, _normalized$dragPaths6, _normalized$dragPaths7, _normalized$dragPaths8, _normalized$dragPaths9, _normalized$dragPaths10, _normalized$labels$en, _normalized$labels, _normalized$labels$mo, _normalized$labels2, _normalized$labels$sh, _normalized$labels3, _normalized$labels$fo, _normalized$labels4, _normalized$labels5, _normalized$labels6, _normalized$labels$ba, _normalized$labels7, _normalized$labels$bo, _normalized$labels8, _normalized$labels$te, _normalized$labels9, _normalized$labels10, _normalized$labels11, _normalized$labels12, _normalized$labels13;
		const normalized = (_normalizeSchemaInput = normalizeSchemaInput(input)) !== null && _normalizeSchemaInput !== void 0 ? _normalizeSchemaInput : input;
		const enabled = (_normalized$enabled = normalized === null || normalized === void 0 ? void 0 : normalized.enabled) !== null && _normalized$enabled !== void 0 ? _normalized$enabled : false;
		const clickIntervalMs = normalizePositiveInt$3(normalized === null || normalized === void 0 || (_normalized$clickIndi = normalized.clickIndicators) === null || _normalized$clickIndi === void 0 ? void 0 : _normalized$clickIndi.animationIntervalMs, 80, 20, 500);
		const clickDelayCsFallback = Math.max(1, Math.round(clickIntervalMs / 10));
		return {
			enabled,
			clickIndicators: {
				enabled: (_normalized$clickIndi2 = normalized === null || normalized === void 0 || (_normalized$clickIndi3 = normalized.clickIndicators) === null || _normalized$clickIndi3 === void 0 ? void 0 : _normalized$clickIndi3.enabled) !== null && _normalized$clickIndi2 !== void 0 ? _normalized$clickIndi2 : true,
				color: (_normalized$clickIndi4 = normalized === null || normalized === void 0 || (_normalized$clickIndi5 = normalized.clickIndicators) === null || _normalized$clickIndi5 === void 0 ? void 0 : _normalized$clickIndi5.color) !== null && _normalized$clickIndi4 !== void 0 ? _normalized$clickIndi4 : "#FF6A00",
				fillColor: (_normalized$clickIndi6 = normalized === null || normalized === void 0 || (_normalized$clickIndi7 = normalized.clickIndicators) === null || _normalized$clickIndi7 === void 0 ? void 0 : _normalized$clickIndi7.fillColor) !== null && _normalized$clickIndi6 !== void 0 ? _normalized$clickIndi6 : "rgba(255, 106, 0, 0.18)",
				radiusPx: normalizePositiveNumber(normalized === null || normalized === void 0 || (_normalized$clickIndi8 = normalized.clickIndicators) === null || _normalized$clickIndi8 === void 0 ? void 0 : _normalized$clickIndi8.radiusPx, 18, 4, 96),
				lineWidthPx: normalizePositiveNumber(normalized === null || normalized === void 0 || (_normalized$clickIndi9 = normalized.clickIndicators) === null || _normalized$clickIndi9 === void 0 ? void 0 : _normalized$clickIndi9.lineWidthPx, 3, 1, 16),
				durationMs: normalizePositiveInt$3(normalized === null || normalized === void 0 || (_normalized$clickIndi10 = normalized.clickIndicators) === null || _normalized$clickIndi10 === void 0 ? void 0 : _normalized$clickIndi10.durationMs, 520, 120, 5e3),
				animationFrames: normalizePositiveInt$3(normalized === null || normalized === void 0 || (_normalized$clickIndi11 = normalized.clickIndicators) === null || _normalized$clickIndi11 === void 0 ? void 0 : _normalized$clickIndi11.animationFrames, 3, 1, 8),
				animationIntervalMs: clickIntervalMs,
				animationFrameDelayCs: normalizePositiveInt$3(normalized === null || normalized === void 0 || (_normalized$clickIndi12 = normalized.clickIndicators) === null || _normalized$clickIndi12 === void 0 ? void 0 : _normalized$clickIndi12.animationFrameDelayCs, clickDelayCsFallback, 1, 100)
			},
			dragPaths: {
				enabled: (_normalized$dragPaths = normalized === null || normalized === void 0 || (_normalized$dragPaths2 = normalized.dragPaths) === null || _normalized$dragPaths2 === void 0 ? void 0 : _normalized$dragPaths2.enabled) !== null && _normalized$dragPaths !== void 0 ? _normalized$dragPaths : true,
				color: (_normalized$dragPaths3 = normalized === null || normalized === void 0 || (_normalized$dragPaths4 = normalized.dragPaths) === null || _normalized$dragPaths4 === void 0 ? void 0 : _normalized$dragPaths4.color) !== null && _normalized$dragPaths3 !== void 0 ? _normalized$dragPaths3 : "#FF2D55",
				lineWidthPx: normalizePositiveNumber(normalized === null || normalized === void 0 || (_normalized$dragPaths5 = normalized.dragPaths) === null || _normalized$dragPaths5 === void 0 ? void 0 : _normalized$dragPaths5.lineWidthPx, 4, 1, 20),
				durationMs: normalizePositiveInt$3(normalized === null || normalized === void 0 || (_normalized$dragPaths6 = normalized.dragPaths) === null || _normalized$dragPaths6 === void 0 ? void 0 : _normalized$dragPaths6.durationMs, 1e3, 120, 8e3),
				arrowSizePx: normalizePositiveNumber(normalized === null || normalized === void 0 || (_normalized$dragPaths7 = normalized.dragPaths) === null || _normalized$dragPaths7 === void 0 ? void 0 : _normalized$dragPaths7.arrowSizePx, 10, 4, 40),
				dash: normalizeDash(normalized === null || normalized === void 0 || (_normalized$dragPaths8 = normalized.dragPaths) === null || _normalized$dragPaths8 === void 0 ? void 0 : _normalized$dragPaths8.dash, [10, 8]),
				startDotRadiusPx: normalizePositiveNumber(normalized === null || normalized === void 0 || (_normalized$dragPaths9 = normalized.dragPaths) === null || _normalized$dragPaths9 === void 0 ? void 0 : _normalized$dragPaths9.startDotRadiusPx, 4, 2, 24),
				endDotRadiusPx: normalizePositiveNumber(normalized === null || normalized === void 0 || (_normalized$dragPaths10 = normalized.dragPaths) === null || _normalized$dragPaths10 === void 0 ? void 0 : _normalized$dragPaths10.endDotRadiusPx, 5, 2, 24)
			},
			labels: {
				enabled: (_normalized$labels$en = normalized === null || normalized === void 0 || (_normalized$labels = normalized.labels) === null || _normalized$labels === void 0 ? void 0 : _normalized$labels.enabled) !== null && _normalized$labels$en !== void 0 ? _normalized$labels$en : false,
				mode: (_normalized$labels$mo = normalized === null || normalized === void 0 || (_normalized$labels2 = normalized.labels) === null || _normalized$labels2 === void 0 ? void 0 : _normalized$labels2.mode) !== null && _normalized$labels$mo !== void 0 ? _normalized$labels$mo : "both",
				showForClicks: (_normalized$labels$sh = normalized === null || normalized === void 0 || (_normalized$labels3 = normalized.labels) === null || _normalized$labels3 === void 0 ? void 0 : _normalized$labels3.showForClicks) !== null && _normalized$labels$sh !== void 0 ? _normalized$labels$sh : false,
				font: (_normalized$labels$fo = normalized === null || normalized === void 0 || (_normalized$labels4 = normalized.labels) === null || _normalized$labels4 === void 0 ? void 0 : _normalized$labels4.font) !== null && _normalized$labels$fo !== void 0 ? _normalized$labels$fo : "600 13px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif",
				maxLength: normalizePositiveInt$3(normalized === null || normalized === void 0 || (_normalized$labels5 = normalized.labels) === null || _normalized$labels5 === void 0 ? void 0 : _normalized$labels5.maxLength, 48, 8, 200),
				durationMs: normalizePositiveInt$3(normalized === null || normalized === void 0 || (_normalized$labels6 = normalized.labels) === null || _normalized$labels6 === void 0 ? void 0 : _normalized$labels6.durationMs, 1200, 120, 12e3),
				backgroundColor: (_normalized$labels$ba = normalized === null || normalized === void 0 || (_normalized$labels7 = normalized.labels) === null || _normalized$labels7 === void 0 ? void 0 : _normalized$labels7.backgroundColor) !== null && _normalized$labels$ba !== void 0 ? _normalized$labels$ba : "rgba(0, 0, 0, 0.72)",
				borderColor: (_normalized$labels$bo = normalized === null || normalized === void 0 || (_normalized$labels8 = normalized.labels) === null || _normalized$labels8 === void 0 ? void 0 : _normalized$labels8.borderColor) !== null && _normalized$labels$bo !== void 0 ? _normalized$labels$bo : "rgba(255, 255, 255, 0.14)",
				textColor: (_normalized$labels$te = normalized === null || normalized === void 0 || (_normalized$labels9 = normalized.labels) === null || _normalized$labels9 === void 0 ? void 0 : _normalized$labels9.textColor) !== null && _normalized$labels$te !== void 0 ? _normalized$labels$te : "#FFFFFF",
				paddingX: normalizePositiveNumber(normalized === null || normalized === void 0 || (_normalized$labels10 = normalized.labels) === null || _normalized$labels10 === void 0 ? void 0 : _normalized$labels10.paddingX, 10, 2, 40),
				paddingY: normalizePositiveNumber(normalized === null || normalized === void 0 || (_normalized$labels11 = normalized.labels) === null || _normalized$labels11 === void 0 ? void 0 : _normalized$labels11.paddingY, 6, 2, 30),
				radiusPx: normalizePositiveNumber(normalized === null || normalized === void 0 || (_normalized$labels12 = normalized.labels) === null || _normalized$labels12 === void 0 ? void 0 : _normalized$labels12.radiusPx, 10, 0, 30),
				offsetPx: normalizePositiveNumber(normalized === null || normalized === void 0 || (_normalized$labels13 = normalized.labels) === null || _normalized$labels13 === void 0 ? void 0 : _normalized$labels13.offsetPx, 12, 0, 80)
			}
		};
	}
	function resolveCapturePlanForAction(config, action, defaultFrameDelayCs) {
		const base = {
			frames: 1,
			intervalMs: 0,
			delayCs: defaultFrameDelayCs
		};
		if (!config.enabled || !action) return base;
		if (config.clickIndicators.enabled && CLICK_ACTIONS.includes(action.type)) {
			const frames = config.clickIndicators.animationFrames;
			if (frames > 1) return {
				frames,
				intervalMs: config.clickIndicators.animationIntervalMs,
				delayCs: config.clickIndicators.animationFrameDelayCs
			};
		}
		return base;
	}
	function renderGifEnhancedOverlays(params) {
		const { ctx, outputWidth, outputHeight, viewportWidth, viewportHeight, nowMs, events, config } = params;
		if (!config.enabled || events.length === 0) return;
		const clickCfg = config.clickIndicators;
		const dragCfg = config.dragPaths;
		const labelCfg = config.labels;
		for (const event of events) {
			const ageMs = nowMs - event.atMs;
			if (!Number.isFinite(ageMs) || ageMs < 0) continue;
			const action = event.action;
			if (clickCfg.enabled && CLICK_ACTIONS.includes(action.type)) {
				const anchor = resolveAnchorPoint(action);
				if (anchor) {
					const p = projectPoint(anchor, viewportWidth, viewportHeight, outputWidth, outputHeight);
					if (p) drawClickIndicator(ctx, p.x, p.y, ageMs / clickCfg.durationMs, action.type, clickCfg);
				}
			}
			if (dragCfg.enabled && action.type === "drag") {
				const start = action.startCoordinates || null;
				const end = action.endCoordinates || action.coordinates || null;
				if (start && end) {
					const p1 = projectPoint(start, viewportWidth, viewportHeight, outputWidth, outputHeight);
					const p2 = projectPoint(end, viewportWidth, viewportHeight, outputWidth, outputHeight);
					if (p1 && p2) drawDragPath(ctx, p1, p2, ageMs / dragCfg.durationMs, dragCfg);
				}
			}
			const isAnnotation = action.type === "annotation" || typeof action.label === "string";
			if (labelCfg.enabled || isAnnotation) {
				const text = resolveActionLabel(action, labelCfg);
				if (text) {
					const anchor = resolveAnchorPoint(action);
					drawLabelPill(ctx, text, anchor ? projectPoint(anchor, viewportWidth, viewportHeight, outputWidth, outputHeight) : null, 1 - clamp((clamp(ageMs / labelCfg.durationMs, 0, 1) - .75) / .25, 0, 1), labelCfg, outputWidth, outputHeight);
				}
			}
		}
	}
	function pruneActionEventsInPlace(events, nowMs, config) {
		if (events.length === 0) return;
		const hasAnnotations = events.some((e) => e.action.type === "annotation" || typeof e.action.label === "string");
		let maxLifetimeMs = 0;
		if (config.enabled) {
			if (config.clickIndicators.enabled) maxLifetimeMs = Math.max(maxLifetimeMs, config.clickIndicators.durationMs);
			if (config.dragPaths.enabled) maxLifetimeMs = Math.max(maxLifetimeMs, config.dragPaths.durationMs);
			if (config.labels.enabled) maxLifetimeMs = Math.max(maxLifetimeMs, config.labels.durationMs);
		}
		if (hasAnnotations) maxLifetimeMs = Math.max(maxLifetimeMs, config.labels.durationMs);
		if (maxLifetimeMs <= 0) {
			events.length = 0;
			return;
		}
		const cutoff = nowMs - maxLifetimeMs - 250;
		let dropCount = 0;
		while (dropCount < events.length && events[dropCount].atMs < cutoff) dropCount++;
		if (dropCount > 0) events.splice(0, dropCount);
	}
	//#endregion
	//#region entrypoints/background/tools/browser/gif-auto-capture.ts
	/**
	* GIF Auto-Capture Hook System
	*
	* Provides automatic frame capture for GIF recording when browser actions succeed.
	* Tools like chrome_computer and chrome_navigate can trigger frame captures
	* after successful operations, creating smooth recordings of user interactions.
	*
	* Architecture:
	* - Centralized capture manager with per-tab recording state
	* - Hooks can be registered/unregistered per tab
	* - Configurable capture delay for UI stabilization
	* - Enhanced rendering overlays (click indicators, drag paths, labels)
	*/
	init_asyncToGenerator();
	var CDP_SESSION_KEY$2 = "gif-auto-capture";
	var DEFAULT_CAPTURE_DELAY_MS = 150;
	var DEFAULT_WIDTH$1 = 800;
	var DEFAULT_HEIGHT$1 = 600;
	var DEFAULT_FRAME_DELAY_CS = 20;
	var DEFAULT_MAX_COLORS$1 = 256;
	var tabStates = /* @__PURE__ */ new Map();
	function sleep$1(ms) {
		return new Promise((resolve) => setTimeout(resolve, ms));
	}
	function normalizeActionMetadata(action, atMs) {
		var _action$coordinateSpa;
		const normalized = _objectSpread2(_objectSpread2({}, action), {}, {
			timestampMs: atMs,
			coordinateSpace: (_action$coordinateSpa = action.coordinateSpace) !== null && _action$coordinateSpa !== void 0 ? _action$coordinateSpa : "viewport"
		});
		if (normalized.type === "drag") {
			var _normalized$endCoordi;
			const end = (_normalized$endCoordi = normalized.endCoordinates) !== null && _normalized$endCoordi !== void 0 ? _normalized$endCoordi : normalized.coordinates;
			if (end) {
				normalized.endCoordinates = end;
				normalized.coordinates = end;
			}
		}
		return normalized;
	}
	function sendToOffscreen$1(_x) {
		return _sendToOffscreen$1.apply(this, arguments);
	}
	function _sendToOffscreen$1() {
		_sendToOffscreen$1 = _asyncToGenerator(function* (type, payload = {}) {
			yield offscreenManager.ensureOffscreenDocument();
			const response = yield chrome.runtime.sendMessage(_objectSpread2({
				target: MessageTarget.Offscreen,
				type
			}, payload));
			if (!response) throw new Error("No response from offscreen document");
			if (!response.success) throw new Error(response.error || "Unknown offscreen error");
			return response;
		});
		return _sendToOffscreen$1.apply(this, arguments);
	}
	function captureFrameData(_x2, _x3) {
		return _captureFrameData.apply(this, arguments);
	}
	function _captureFrameData() {
		_captureFrameData = _asyncToGenerator(function* (tabId, state) {
			var _metrics$layoutViewpo, _metrics$layoutViewpo2;
			const width = state.config.width;
			const height = state.config.height;
			const ctx = state.ctx;
			const metrics = yield cdpSessionManager.sendCommand(tabId, "Page.getLayoutMetrics", {});
			const viewportWidth = ((_metrics$layoutViewpo = metrics.layoutViewport) === null || _metrics$layoutViewpo === void 0 ? void 0 : _metrics$layoutViewpo.clientWidth) || width;
			const viewportHeight = ((_metrics$layoutViewpo2 = metrics.layoutViewport) === null || _metrics$layoutViewpo2 === void 0 ? void 0 : _metrics$layoutViewpo2.clientHeight) || height;
			state.lastViewportWidth = viewportWidth;
			state.lastViewportHeight = viewportHeight;
			const imageBitmap = yield createImageBitmapFromUrl(`data:image/png;base64,${(yield cdpSessionManager.sendCommand(tabId, "Page.captureScreenshot", {
				format: "png",
				clip: {
					x: 0,
					y: 0,
					width: viewportWidth,
					height: viewportHeight,
					scale: 1
				}
			})).data}`);
			ctx.clearRect(0, 0, width, height);
			ctx.drawImage(imageBitmap, 0, 0, width, height);
			imageBitmap.close();
			if (state.rendering.enabled) {
				const nowMs = Date.now();
				renderGifEnhancedOverlays({
					ctx,
					outputWidth: width,
					outputHeight: height,
					viewportWidth,
					viewportHeight,
					nowMs,
					events: state.actionEvents,
					config: state.rendering
				});
				pruneActionEventsInPlace(state.actionEvents, nowMs, state.rendering);
			}
			return ctx.getImageData(0, 0, width, height).data;
		});
		return _captureFrameData.apply(this, arguments);
	}
	/**
	* Start auto-capture for a tab. This initializes the GIF encoder
	* and prepares for automatic frame capture on tool actions.
	*/
	function startAutoCapture(_x4, _x5) {
		return _startAutoCapture.apply(this, arguments);
	}
	function _startAutoCapture() {
		_startAutoCapture = _asyncToGenerator(function* (tabId, config) {
			var _config$width, _config$height, _config$maxColors, _config$frameDelayCs, _config$captureDelayM, _config$maxFrames;
			if (tabStates.has(tabId)) return {
				success: false,
				error: "Auto-capture already active for this tab"
			};
			const finalConfig = {
				width: (_config$width = config === null || config === void 0 ? void 0 : config.width) !== null && _config$width !== void 0 ? _config$width : DEFAULT_WIDTH$1,
				height: (_config$height = config === null || config === void 0 ? void 0 : config.height) !== null && _config$height !== void 0 ? _config$height : DEFAULT_HEIGHT$1,
				maxColors: (_config$maxColors = config === null || config === void 0 ? void 0 : config.maxColors) !== null && _config$maxColors !== void 0 ? _config$maxColors : DEFAULT_MAX_COLORS$1,
				frameDelayCs: (_config$frameDelayCs = config === null || config === void 0 ? void 0 : config.frameDelayCs) !== null && _config$frameDelayCs !== void 0 ? _config$frameDelayCs : DEFAULT_FRAME_DELAY_CS,
				captureDelayMs: (_config$captureDelayM = config === null || config === void 0 ? void 0 : config.captureDelayMs) !== null && _config$captureDelayM !== void 0 ? _config$captureDelayM : DEFAULT_CAPTURE_DELAY_MS,
				maxFrames: (_config$maxFrames = config === null || config === void 0 ? void 0 : config.maxFrames) !== null && _config$maxFrames !== void 0 ? _config$maxFrames : 100,
				enhancedRendering: config === null || config === void 0 ? void 0 : config.enhancedRendering
			};
			try {
				yield cdpSessionManager.attach(tabId, CDP_SESSION_KEY$2);
				yield sendToOffscreen$1(OFFSCREEN_MESSAGE_TYPES.GIF_RESET, {});
				if (typeof OffscreenCanvas === "undefined") throw new Error("OffscreenCanvas not available");
				const canvas = new OffscreenCanvas(finalConfig.width, finalConfig.height);
				const ctx = canvas.getContext("2d");
				if (!ctx) throw new Error("Failed to get canvas context");
				const state = {
					tabId,
					config: finalConfig,
					rendering: resolveGifEnhancedRenderingConfig(finalConfig.enhancedRendering),
					frameCount: 0,
					startTime: Date.now(),
					canvas,
					ctx,
					pendingCapture: null,
					actions: [],
					actionEvents: [],
					lastViewportWidth: finalConfig.width,
					lastViewportHeight: finalConfig.height
				};
				tabStates.set(tabId, state);
				return { success: true };
			} catch (error) {
				try {
					yield cdpSessionManager.detach(tabId, CDP_SESSION_KEY$2);
				} catch (_unused) {}
				return {
					success: false,
					error: error instanceof Error ? error.message : String(error)
				};
			}
		});
		return _startAutoCapture.apply(this, arguments);
	}
	/**
	* Stop auto-capture and finalize the GIF.
	* Returns the GIF data for saving/downloading.
	*/
	function stopAutoCapture(_x6) {
		return _stopAutoCapture.apply(this, arguments);
	}
	function _stopAutoCapture() {
		_stopAutoCapture = _asyncToGenerator(function* (tabId) {
			const state = tabStates.get(tabId);
			if (!state) return {
				success: false,
				error: "No auto-capture active for this tab"
			};
			try {
				if (state.pendingCapture) yield state.pendingCapture;
				const frameCount = state.frameCount;
				const durationMs = Date.now() - state.startTime;
				const actions = [...state.actions];
				if (frameCount === 0) return {
					success: false,
					error: "No frames captured",
					frameCount: 0,
					durationMs,
					actions
				};
				const response = yield sendToOffscreen$1(OFFSCREEN_MESSAGE_TYPES.GIF_FINISH, {});
				if (!response.gifData || response.gifData.length === 0) return {
					success: false,
					error: "Failed to encode GIF",
					frameCount,
					durationMs,
					actions
				};
				return {
					success: true,
					gifData: new Uint8Array(response.gifData),
					frameCount,
					durationMs,
					actions
				};
			} catch (error) {
				return {
					success: false,
					error: error instanceof Error ? error.message : String(error)
				};
			} finally {
				tabStates.delete(tabId);
				try {
					yield cdpSessionManager.detach(tabId, CDP_SESSION_KEY$2);
				} catch (_unused2) {}
			}
		});
		return _stopAutoCapture.apply(this, arguments);
	}
	/**
	* Check if auto-capture is active for a tab.
	*/
	function isAutoCaptureActive(tabId) {
		return tabStates.has(tabId);
	}
	/**
	* Get current auto-capture status for a tab.
	*/
	function getAutoCaptureStatus(tabId) {
		const state = tabStates.get(tabId);
		if (!state) return { active: false };
		return {
			active: true,
			frameCount: state.frameCount,
			durationMs: Date.now() - state.startTime,
			actionsCount: state.actions.length,
			enhancedRenderingEnabled: state.rendering.enabled
		};
	}
	/**
	* Trigger a frame capture after a successful action.
	* This is the main hook that tools should call.
	*
	* @param tabId - The tab to capture
	* @param action - Optional action metadata for overlay rendering
	* @param immediate - If true, capture immediately without delay
	*/
	function captureFrameOnAction(_x7, _x8) {
		return _captureFrameOnAction.apply(this, arguments);
	}
	function _captureFrameOnAction() {
		_captureFrameOnAction = _asyncToGenerator(function* (tabId, action, immediate = false) {
			const state = tabStates.get(tabId);
			if (!state) return { success: true };
			if (state.frameCount >= state.config.maxFrames) return {
				success: false,
				error: "Max frame limit reached"
			};
			if (state.pendingCapture) try {
				yield state.pendingCapture;
			} catch (_unused3) {}
			const currentState = tabStates.get(tabId);
			if (!currentState) return { success: true };
			const delayMs = immediate ? 0 : currentState.config.captureDelayMs;
			let normalizedAction;
			if (action) {
				const atMs = Date.now() + delayMs;
				normalizedAction = normalizeActionMetadata(action, atMs);
				currentState.actions.push(normalizedAction);
				currentState.actionEvents.push({
					action: normalizedAction,
					atMs
				});
			}
			const plan = resolveCapturePlanForAction(currentState.rendering, normalizedAction, currentState.config.frameDelayCs);
			const capturePromise = _asyncToGenerator(function* () {
				if (delayMs > 0) yield sleep$1(delayMs);
				for (let i = 0; i < plan.frames; i++) {
					const activeState = tabStates.get(tabId);
					if (!activeState) return;
					if (activeState.frameCount >= activeState.config.maxFrames) return;
					try {
						const frameData = yield captureFrameData(tabId, activeState);
						const delayCs = i < plan.frames - 1 ? plan.delayCs : activeState.config.frameDelayCs;
						yield sendToOffscreen$1(OFFSCREEN_MESSAGE_TYPES.GIF_ADD_FRAME, {
							imageData: Array.from(frameData),
							width: activeState.config.width,
							height: activeState.config.height,
							delay: delayCs,
							maxColors: activeState.config.maxColors
						});
						activeState.frameCount += 1;
					} catch (error) {
						console.error("[GIF Auto-Capture] Frame capture failed:", error);
						return;
					}
					if (i < plan.frames - 1 && plan.intervalMs > 0) yield sleep$1(plan.intervalMs);
				}
			})();
			state.pendingCapture = capturePromise;
			try {
				yield capturePromise;
				return {
					success: true,
					frameNumber: state.frameCount
				};
			} catch (error) {
				return {
					success: false,
					error: error instanceof Error ? error.message : String(error)
				};
			} finally {
				const currentState = tabStates.get(tabId);
				if ((currentState === null || currentState === void 0 ? void 0 : currentState.pendingCapture) === capturePromise) currentState.pendingCapture = null;
			}
		});
		return _captureFrameOnAction.apply(this, arguments);
	}
	/**
	* Capture an initial frame immediately (useful for recording start state).
	*/
	function captureInitialFrame(_x9) {
		return _captureInitialFrame.apply(this, arguments);
	}
	function _captureInitialFrame() {
		_captureInitialFrame = _asyncToGenerator(function* (tabId) {
			return captureFrameOnAction(tabId, void 0, true);
		});
		return _captureInitialFrame.apply(this, arguments);
	}
	//#endregion
	//#region entrypoints/background/tools/browser/gif-recorder.ts
	/**
	* GIF Recorder Tool
	*
	* Records browser tab activity as an animated GIF.
	*
	* Features:
	* - Two recording modes:
	*   1. Fixed FPS mode (start): Captures frames at regular intervals
	*   2. Auto-capture mode (auto_start): Captures frames on tool actions
	* - Configurable frame rate, duration, and dimensions
	* - Quality/size optimization options
	* - CDP-based screenshot capture for background recording
	* - Offscreen document encoding via gifenc
	*/
	init_cdp_session_manager();
	init_asyncToGenerator();
	init_defineProperty();
	var DEFAULT_FPS = 5;
	var DEFAULT_DURATION_MS = 5e3;
	var DEFAULT_MAX_FRAMES = 50;
	var DEFAULT_WIDTH = 800;
	var DEFAULT_HEIGHT = 600;
	var DEFAULT_MAX_COLORS = 256;
	var CDP_SESSION_KEY$1 = "gif-recorder";
	var recordingState = null;
	var stopPromise = null;
	var autoCaptureMetadata = null;
	var lastRecordedGif = null;
	var EXPORT_CACHE_LIFETIME_MS = 300 * 1e3;
	function sendToOffscreen(_x) {
		return _sendToOffscreen.apply(this, arguments);
	}
	function _sendToOffscreen() {
		_sendToOffscreen = _asyncToGenerator(function* (type, payload = {}) {
			yield offscreenManager.ensureOffscreenDocument();
			let lastError;
			for (let attempt = 1; attempt <= 3; attempt++) try {
				const response = yield chrome.runtime.sendMessage(_objectSpread2({
					target: MessageTarget.Offscreen,
					type
				}, payload));
				if (!response) throw new Error("No response received from offscreen document");
				if (!response.success) throw new Error(response.error || "Unknown offscreen error");
				return response;
			} catch (error) {
				lastError = error;
				if (attempt < 3) {
					yield new Promise((resolve) => setTimeout(resolve, 50 * attempt));
					continue;
				}
				throw error;
			}
			throw lastError instanceof Error ? lastError : new Error(String(lastError));
		});
		return _sendToOffscreen.apply(this, arguments);
	}
	function captureFrame(_x2, _x3, _x4, _x5) {
		return _captureFrame.apply(this, arguments);
	}
	function _captureFrame() {
		_captureFrame = _asyncToGenerator(function* (tabId, width, height, ctx) {
			var _metrics$layoutViewpo, _metrics$layoutViewpo2;
			const metrics = yield cdpSessionManager.sendCommand(tabId, "Page.getLayoutMetrics", {});
			const viewportWidth = ((_metrics$layoutViewpo = metrics.layoutViewport) === null || _metrics$layoutViewpo === void 0 ? void 0 : _metrics$layoutViewpo.clientWidth) || width;
			const viewportHeight = ((_metrics$layoutViewpo2 = metrics.layoutViewport) === null || _metrics$layoutViewpo2 === void 0 ? void 0 : _metrics$layoutViewpo2.clientHeight) || height;
			const imageBitmap = yield createImageBitmapFromUrl(`data:image/png;base64,${(yield cdpSessionManager.sendCommand(tabId, "Page.captureScreenshot", {
				format: "png",
				clip: {
					x: 0,
					y: 0,
					width: viewportWidth,
					height: viewportHeight,
					scale: 1
				}
			})).data}`);
			ctx.clearRect(0, 0, width, height);
			ctx.drawImage(imageBitmap, 0, 0, width, height);
			imageBitmap.close();
			return ctx.getImageData(0, 0, width, height).data;
		});
		return _captureFrame.apply(this, arguments);
	}
	function captureAndEncodeFrame(_x6) {
		return _captureAndEncodeFrame.apply(this, arguments);
	}
	function _captureAndEncodeFrame() {
		_captureAndEncodeFrame = _asyncToGenerator(function* (state) {
			const frameData = yield captureFrame(state.tabId, state.width, state.height, state.ctx);
			yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_ADD_FRAME, {
				imageData: Array.from(frameData),
				width: state.width,
				height: state.height,
				delay: state.frameDelayCs,
				maxColors: state.maxColors
			});
			if (recordingState === state && state.isRecording && !state.isStopping) state.frameCount += 1;
		});
		return _captureAndEncodeFrame.apply(this, arguments);
	}
	function captureTick(_x7) {
		return _captureTick.apply(this, arguments);
	}
	function _captureTick() {
		_captureTick = _asyncToGenerator(function* (state) {
			if (recordingState !== state || !state.isRecording || state.isStopping) return;
			if (Date.now() - state.startTime >= state.durationMs || state.frameCount >= state.maxFrames) {
				yield stopRecording();
				return;
			}
			const startedAt = Date.now();
			state.captureInProgress = captureAndEncodeFrame(state);
			try {
				yield state.captureInProgress;
			} catch (error) {
				console.error("Frame capture error:", error);
			} finally {
				if (recordingState === state) state.captureInProgress = null;
			}
			if (recordingState !== state || !state.isRecording || state.isStopping) return;
			if (Date.now() - state.startTime >= state.durationMs || state.frameCount >= state.maxFrames) {
				yield stopRecording();
				return;
			}
			const delayMs = Math.max(0, state.frameIntervalMs - (Date.now() - startedAt));
			state.captureTimer = setTimeout(() => {
				captureTick(state).catch((error) => {
					console.error("GIF recorder tick error:", error);
				});
			}, delayMs);
		});
		return _captureTick.apply(this, arguments);
	}
	function startRecording(_x8, _x9, _x10, _x11, _x12, _x13, _x14, _x15) {
		return _startRecording.apply(this, arguments);
	}
	function _startRecording() {
		_startRecording = _asyncToGenerator(function* (tabId, fps, durationMs, maxFrames, width, height, maxColors, filename) {
			if (stopPromise || (recordingState === null || recordingState === void 0 ? void 0 : recordingState.isRecording) || (recordingState === null || recordingState === void 0 ? void 0 : recordingState.isStopping)) return {
				success: false,
				action: "start",
				error: "Recording already in progress"
			};
			try {
				yield cdpSessionManager.attach(tabId, CDP_SESSION_KEY$1);
			} catch (error) {
				return {
					success: false,
					action: "start",
					error: error instanceof Error ? error.message : String(error)
				};
			}
			try {
				yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_RESET, {});
				if (typeof OffscreenCanvas === "undefined") throw new Error("OffscreenCanvas not available in this context");
				const canvas = new OffscreenCanvas(width, height);
				const ctx = canvas.getContext("2d");
				if (!ctx) throw new Error("Failed to get canvas context");
				const frameIntervalMs = Math.round(1e3 / fps);
				const state = {
					isRecording: true,
					isStopping: false,
					tabId,
					width,
					height,
					fps,
					durationMs,
					frameIntervalMs,
					frameDelayCs: Math.max(1, Math.round(100 / fps)),
					maxFrames,
					maxColors,
					frameCount: 0,
					startTime: Date.now(),
					captureTimer: null,
					captureInProgress: null,
					canvas,
					ctx,
					filename
				};
				recordingState = state;
				yield captureAndEncodeFrame(state);
				state.captureTimer = setTimeout(() => {
					captureTick(state).catch((error) => {
						console.error("GIF recorder tick error:", error);
					});
				}, frameIntervalMs);
				return {
					success: true,
					action: "start",
					tabId,
					isRecording: true
				};
			} catch (error) {
				recordingState = null;
				try {
					yield cdpSessionManager.detach(tabId, CDP_SESSION_KEY$1);
				} catch (_unused) {}
				return {
					success: false,
					action: "start",
					error: error instanceof Error ? error.message : String(error)
				};
			}
		});
		return _startRecording.apply(this, arguments);
	}
	function stopRecording() {
		return _stopRecording.apply(this, arguments);
	}
	function _stopRecording() {
		_stopRecording = _asyncToGenerator(function* () {
			if (stopPromise) return stopPromise;
			if (!recordingState || !recordingState.isRecording && !recordingState.isStopping) return {
				success: false,
				action: "stop",
				error: "No recording in progress"
			};
			stopPromise = _asyncToGenerator(function* () {
				const state = recordingState;
				const tabId = state.tabId;
				if (state.captureTimer) {
					clearTimeout(state.captureTimer);
					state.captureTimer = null;
				}
				state.isStopping = true;
				state.isRecording = false;
				try {
					yield state.captureInProgress;
				} catch (_unused2) {}
				try {
					const frameData = yield captureFrame(state.tabId, state.width, state.height, state.ctx);
					yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_ADD_FRAME, {
						imageData: Array.from(frameData),
						width: state.width,
						height: state.height,
						delay: state.frameDelayCs,
						maxColors: state.maxColors
					});
					state.frameCount += 1;
				} catch (error) {
					console.warn("GIF recorder: Final frame capture error (non-fatal):", error);
				}
				const frameCount = state.frameCount;
				const durationMs = Date.now() - state.startTime;
				const filename = state.filename;
				try {
					var _response$byteLength;
					if (frameCount <= 0) {
						try {
							yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_RESET, {});
						} catch (_unused3) {}
						return {
							success: false,
							action: "stop",
							tabId,
							frameCount,
							durationMs,
							error: "No frames captured"
						};
					}
					const response = yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_FINISH, {});
					if (!response.gifData || response.gifData.length === 0) return {
						success: false,
						action: "stop",
						tabId,
						frameCount,
						durationMs,
						error: "No frames captured"
					};
					const gifBytes = new Uint8Array(response.gifData);
					lastRecordedGif = {
						gifData: gifBytes,
						width: state.width,
						height: state.height,
						frameCount,
						durationMs,
						tabId,
						filename,
						mode: "fixed_fps",
						createdAt: Date.now()
					};
					const dataUrl = yield blobToDataUrl(new Blob([gifBytes], { type: "image/gif" }));
					const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
					const outputFilename = (filename === null || filename === void 0 ? void 0 : filename.replace(/[^a-z0-9_-]/gi, "_")) || `recording_${timestamp}`;
					const fullFilename = outputFilename.endsWith(".gif") ? outputFilename : `${outputFilename}.gif`;
					const downloadId = yield chrome.downloads.download({
						url: dataUrl,
						filename: fullFilename,
						saveAs: false
					});
					yield new Promise((resolve) => setTimeout(resolve, 100));
					let fullPath;
					try {
						const [downloadItem] = yield chrome.downloads.search({ id: downloadId });
						fullPath = downloadItem === null || downloadItem === void 0 ? void 0 : downloadItem.filename;
					} catch (_unused4) {}
					return {
						success: true,
						action: "stop",
						tabId,
						frameCount,
						durationMs,
						byteLength: (_response$byteLength = response.byteLength) !== null && _response$byteLength !== void 0 ? _response$byteLength : gifBytes.byteLength,
						downloadId,
						filename: fullFilename,
						fullPath
					};
				} catch (error) {
					return {
						success: false,
						action: "stop",
						error: error instanceof Error ? error.message : String(error)
					};
				} finally {
					try {
						yield cdpSessionManager.detach(tabId, CDP_SESSION_KEY$1);
					} catch (_unused5) {}
					recordingState = null;
				}
			})();
			return yield stopPromise.finally(() => {
				stopPromise = null;
			});
		});
		return _stopRecording.apply(this, arguments);
	}
	function getRecordingStatus() {
		if (!recordingState) return {
			success: true,
			action: "status",
			isRecording: false
		};
		return {
			success: true,
			action: "status",
			isRecording: recordingState.isRecording,
			tabId: recordingState.tabId,
			frameCount: recordingState.frameCount,
			durationMs: Date.now() - recordingState.startTime
		};
	}
	function blobToDataUrl(blob) {
		return new Promise((resolve, reject) => {
			const reader = new FileReader();
			reader.onload = () => resolve(reader.result);
			reader.onerror = () => reject(/* @__PURE__ */ new Error("Failed to read blob"));
			reader.readAsDataURL(blob);
		});
	}
	function normalizePositiveInt$2(value, fallback, max) {
		if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
		const result = Math.max(1, Math.floor(value));
		return max !== void 0 ? Math.min(result, max) : result;
	}
	var GifRecorderTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.GIF_RECORDER);
		}
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const action = args.action;
				const validActions = [
					"start",
					"stop",
					"status",
					"auto_start",
					"capture",
					"clear",
					"export"
				];
				if (!action || !validActions.includes(action)) return createErrorResponse(`Parameter [action] is required and must be one of: ${validActions.join(", ")}`);
				try {
					switch (action) {
						case "start": {
							const tab = yield _this.resolveTargetTab(args.tabId);
							if (!(tab === null || tab === void 0 ? void 0 : tab.id)) return createErrorResponse(typeof args.tabId === "number" ? `Tab not found: ${args.tabId}` : "No active tab found");
							if (_this.isRestrictedUrl(tab.url)) return createErrorResponse("Cannot record special browser pages or web store pages due to security restrictions.");
							if (isAutoCaptureActive(tab.id)) return createErrorResponse("Auto-capture mode is active for this tab. Use action=\"stop\" to stop it first.");
							const fps = normalizePositiveInt$2(args.fps, DEFAULT_FPS, 30);
							const durationMs = normalizePositiveInt$2(args.durationMs, DEFAULT_DURATION_MS, 6e4);
							const maxFrames = normalizePositiveInt$2(args.maxFrames, DEFAULT_MAX_FRAMES, 300);
							const width = normalizePositiveInt$2(args.width, DEFAULT_WIDTH, 1920);
							const height = normalizePositiveInt$2(args.height, DEFAULT_HEIGHT, 1080);
							const maxColors = normalizePositiveInt$2(args.maxColors, DEFAULT_MAX_COLORS, 256);
							const result = yield startRecording(tab.id, fps, durationMs, maxFrames, width, height, maxColors, args.filename);
							if (result.success) result.mode = "fixed_fps";
							return _this.buildResponse(result);
						}
						case "auto_start": {
							const tab = yield _this.resolveTargetTab(args.tabId);
							if (!(tab === null || tab === void 0 ? void 0 : tab.id)) return createErrorResponse(typeof args.tabId === "number" ? `Tab not found: ${args.tabId}` : "No active tab found");
							if (_this.isRestrictedUrl(tab.url)) return createErrorResponse("Cannot record special browser pages or web store pages due to security restrictions.");
							if ((recordingState === null || recordingState === void 0 ? void 0 : recordingState.isRecording) && recordingState.tabId === tab.id) return createErrorResponse("Fixed-FPS recording is active for this tab. Use action=\"stop\" to stop it first.");
							if (isAutoCaptureActive(tab.id)) return createErrorResponse("Auto-capture is already active for this tab.");
							const width = normalizePositiveInt$2(args.width, DEFAULT_WIDTH, 1920);
							const height = normalizePositiveInt$2(args.height, DEFAULT_HEIGHT, 1080);
							const maxColors = normalizePositiveInt$2(args.maxColors, DEFAULT_MAX_COLORS, 256);
							const maxFrames = normalizePositiveInt$2(args.maxFrames, 100, 300);
							const captureDelayMs = normalizePositiveInt$2(args.captureDelayMs, 150, 2e3);
							const frameDelayCs = normalizePositiveInt$2(args.frameDelayCs, 20, 100);
							const startResult = yield startAutoCapture(tab.id, {
								width,
								height,
								maxColors,
								maxFrames,
								captureDelayMs,
								frameDelayCs,
								enhancedRendering: args.enhancedRendering
							});
							if (!startResult.success) return _this.buildResponse({
								success: false,
								action: "auto_start",
								tabId: tab.id,
								error: startResult.error
							});
							autoCaptureMetadata = {
								tabId: tab.id,
								filename: args.filename
							};
							yield captureInitialFrame(tab.id);
							return _this.buildResponse({
								success: true,
								action: "auto_start",
								tabId: tab.id,
								mode: "auto_capture",
								isRecording: true
							});
						}
						case "capture": {
							const tab = yield _this.resolveTargetTab(args.tabId);
							if (!(tab === null || tab === void 0 ? void 0 : tab.id)) return createErrorResponse(typeof args.tabId === "number" ? `Tab not found: ${args.tabId}` : "No active tab found");
							if (!isAutoCaptureActive(tab.id)) return createErrorResponse("Auto-capture is not active for this tab. Use action=\"auto_start\" first.");
							const annotation = typeof args.annotation === "string" && args.annotation.trim().length > 0 ? args.annotation.trim() : void 0;
							const action = annotation ? {
								type: "annotation",
								label: annotation
							} : void 0;
							const captureResult = yield captureFrameOnAction(tab.id, action, true);
							return _this.buildResponse({
								success: captureResult.success,
								action: "capture",
								tabId: tab.id,
								frameCount: captureResult.frameNumber,
								error: captureResult.error
							});
						}
						case "stop": {
							const autoTab = autoCaptureMetadata === null || autoCaptureMetadata === void 0 ? void 0 : autoCaptureMetadata.tabId;
							if (autoTab !== void 0 && isAutoCaptureActive(autoTab)) {
								var _stopResult$frameCoun, _stopResult$durationM, _stopResult$actions2, _stopResult$actions3;
								const stopResult = yield stopAutoCapture(autoTab);
								const filename = autoCaptureMetadata === null || autoCaptureMetadata === void 0 ? void 0 : autoCaptureMetadata.filename;
								autoCaptureMetadata = null;
								if (!stopResult.success || !stopResult.gifData) {
									var _stopResult$actions;
									return _this.buildResponse({
										success: false,
										action: "stop",
										tabId: autoTab,
										mode: "auto_capture",
										frameCount: stopResult.frameCount,
										durationMs: stopResult.durationMs,
										actionsCount: (_stopResult$actions = stopResult.actions) === null || _stopResult$actions === void 0 ? void 0 : _stopResult$actions.length,
										error: stopResult.error || "No GIF data generated"
									});
								}
								lastRecordedGif = {
									gifData: stopResult.gifData,
									width: DEFAULT_WIDTH,
									height: DEFAULT_HEIGHT,
									frameCount: (_stopResult$frameCoun = stopResult.frameCount) !== null && _stopResult$frameCoun !== void 0 ? _stopResult$frameCoun : 0,
									durationMs: (_stopResult$durationM = stopResult.durationMs) !== null && _stopResult$durationM !== void 0 ? _stopResult$durationM : 0,
									tabId: autoTab,
									filename,
									actionsCount: (_stopResult$actions2 = stopResult.actions) === null || _stopResult$actions2 === void 0 ? void 0 : _stopResult$actions2.length,
									mode: "auto_capture",
									createdAt: Date.now()
								};
								const dataUrl = yield blobToDataUrl(new Blob([stopResult.gifData], { type: "image/gif" }));
								const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
								const outputFilename = (filename === null || filename === void 0 ? void 0 : filename.replace(/[^a-z0-9_-]/gi, "_")) || `recording_${timestamp}`;
								const fullFilename = outputFilename.endsWith(".gif") ? outputFilename : `${outputFilename}.gif`;
								const downloadId = yield chrome.downloads.download({
									url: dataUrl,
									filename: fullFilename,
									saveAs: false
								});
								yield new Promise((resolve) => setTimeout(resolve, 100));
								let fullPath;
								try {
									const [downloadItem] = yield chrome.downloads.search({ id: downloadId });
									fullPath = downloadItem === null || downloadItem === void 0 ? void 0 : downloadItem.filename;
								} catch (_unused6) {}
								return _this.buildResponse({
									success: true,
									action: "stop",
									tabId: autoTab,
									mode: "auto_capture",
									frameCount: stopResult.frameCount,
									durationMs: stopResult.durationMs,
									byteLength: stopResult.gifData.byteLength,
									actionsCount: (_stopResult$actions3 = stopResult.actions) === null || _stopResult$actions3 === void 0 ? void 0 : _stopResult$actions3.length,
									downloadId,
									filename: fullFilename,
									fullPath
								});
							}
							const result = yield stopRecording();
							if (result.success) result.mode = "fixed_fps";
							return _this.buildResponse(result);
						}
						case "status": {
							const autoTab = autoCaptureMetadata === null || autoCaptureMetadata === void 0 ? void 0 : autoCaptureMetadata.tabId;
							if (autoTab !== void 0 && isAutoCaptureActive(autoTab)) {
								const status = getAutoCaptureStatus(autoTab);
								return _this.buildResponse({
									success: true,
									action: "status",
									tabId: autoTab,
									isRecording: status.active,
									mode: "auto_capture",
									frameCount: status.frameCount,
									durationMs: status.durationMs,
									actionsCount: status.actionsCount
								});
							}
							const result = getRecordingStatus();
							if (result.isRecording) result.mode = "fixed_fps";
							return _this.buildResponse(result);
						}
						case "clear": {
							let clearedAuto = false;
							let clearedFixedFps = false;
							let clearedCache = false;
							const autoTab = autoCaptureMetadata === null || autoCaptureMetadata === void 0 ? void 0 : autoCaptureMetadata.tabId;
							if (autoTab !== void 0 && isAutoCaptureActive(autoTab)) {
								yield stopAutoCapture(autoTab);
								autoCaptureMetadata = null;
								clearedAuto = true;
							}
							if (recordingState) {
								if (recordingState.captureTimer) {
									clearTimeout(recordingState.captureTimer);
									recordingState.captureTimer = null;
								}
								try {
									yield recordingState.captureInProgress;
								} catch (_unused7) {}
								try {
									yield cdpSessionManager.detach(recordingState.tabId, CDP_SESSION_KEY$1);
								} catch (_unused8) {}
								const wasRecording = recordingState.isRecording || recordingState.isStopping;
								recordingState = null;
								stopPromise = null;
								if (wasRecording) clearedFixedFps = true;
							}
							try {
								yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_RESET, {});
							} catch (_unused9) {}
							if (lastRecordedGif) {
								lastRecordedGif = null;
								clearedCache = true;
							}
							return _this.buildResponse({
								success: true,
								action: "clear",
								clearedAutoCapture: clearedAuto,
								clearedFixedFps,
								clearedCache
							});
						}
						case "export":
							if (!lastRecordedGif) return createErrorResponse("No recorded GIF available for export. Use action=\"stop\" to finish a recording first.");
							if (Date.now() - lastRecordedGif.createdAt > EXPORT_CACHE_LIFETIME_MS) {
								lastRecordedGif = null;
								return createErrorResponse("Cached GIF has expired. Please record a new GIF.");
							}
							if (args.download !== false) {
								var _args$filename;
								const dataUrl = yield blobToDataUrl(new Blob([lastRecordedGif.gifData], { type: "image/gif" }));
								const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
								const filename = (_args$filename = args.filename) !== null && _args$filename !== void 0 ? _args$filename : lastRecordedGif.filename;
								const outputFilename = (filename === null || filename === void 0 ? void 0 : filename.replace(/[^a-z0-9_-]/gi, "_")) || `export_${timestamp}`;
								const fullFilename = outputFilename.endsWith(".gif") ? outputFilename : `${outputFilename}.gif`;
								const downloadId = yield chrome.downloads.download({
									url: dataUrl,
									filename: fullFilename,
									saveAs: false
								});
								yield new Promise((resolve) => setTimeout(resolve, 100));
								let fullPath;
								try {
									const [downloadItem] = yield chrome.downloads.search({ id: downloadId });
									fullPath = downloadItem === null || downloadItem === void 0 ? void 0 : downloadItem.filename;
								} catch (_unused10) {}
								return _this.buildResponse({
									success: true,
									action: "export",
									mode: lastRecordedGif.mode,
									frameCount: lastRecordedGif.frameCount,
									durationMs: lastRecordedGif.durationMs,
									byteLength: lastRecordedGif.gifData.byteLength,
									downloadId,
									filename: fullFilename,
									fullPath
								});
							} else {
								const { coordinates, ref, selector } = args;
								if (!coordinates && !ref && !selector) return createErrorResponse("For drag&drop upload, provide coordinates, ref, or selector to identify the drop target.");
								const tab = yield _this.resolveTargetTab(args.tabId);
								if (!(tab === null || tab === void 0 ? void 0 : tab.id)) return createErrorResponse(typeof args.tabId === "number" ? `Tab not found: ${args.tabId}` : "No active tab found");
								if (_this.isRestrictedUrl(tab.url)) return createErrorResponse("Cannot upload to special browser pages or web store pages.");
								const gifBase64 = btoa(Array.from(lastRecordedGif.gifData).map((b) => String.fromCharCode(b)).join(""));
								let targetX;
								let targetY;
								if (ref) try {
									yield _this.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
									const resolved = yield _this.sendMessageToTab(tab.id, {
										action: TOOL_MESSAGE_TYPES.RESOLVE_REF,
										ref
									});
									if ((resolved === null || resolved === void 0 ? void 0 : resolved.success) && resolved.center) {
										targetX = resolved.center.x;
										targetY = resolved.center.y;
									} else return createErrorResponse(`Could not resolve ref: ${ref}`);
								} catch (err) {
									return createErrorResponse(`Failed to resolve ref: ${err instanceof Error ? err.message : String(err)}`);
								}
								else if (selector) try {
									const [result] = yield chrome.scripting.executeScript({
										target: { tabId: tab.id },
										func: (cssSelector) => {
											const el = document.querySelector(cssSelector);
											if (!el) return null;
											const rect = el.getBoundingClientRect();
											return {
												x: rect.left + rect.width / 2,
												y: rect.top + rect.height / 2
											};
										},
										args: [selector]
									});
									if (result === null || result === void 0 ? void 0 : result.result) {
										targetX = result.result.x;
										targetY = result.result.y;
									} else return createErrorResponse(`Could not find element: ${selector}`);
								} catch (err) {
									return createErrorResponse(`Failed to resolve selector: ${err instanceof Error ? err.message : String(err)}`);
								}
								else if (coordinates) {
									targetX = coordinates.x;
									targetY = coordinates.y;
								}
								if (typeof targetX !== "number" || typeof targetY !== "number") return createErrorResponse("Invalid drop target coordinates.");
								try {
									var _ref, _args$filename2, _result$result;
									const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
									const filename = (_ref = (_args$filename2 = args.filename) !== null && _args$filename2 !== void 0 ? _args$filename2 : lastRecordedGif.filename) !== null && _ref !== void 0 ? _ref : `recording_${timestamp}`;
									const fullFilename = filename.endsWith(".gif") ? filename : `${filename}.gif`;
									const [result] = yield chrome.scripting.executeScript({
										target: { tabId: tab.id },
										func: (base64Data, x, y, fname) => {
											const byteChars = atob(base64Data);
											const byteArray = new Uint8Array(byteChars.length);
											for (let i = 0; i < byteChars.length; i++) byteArray[i] = byteChars.charCodeAt(i);
											const blob = new Blob([byteArray], { type: "image/gif" });
											const file = new File([blob], fname, { type: "image/gif" });
											const target = document.elementFromPoint(x, y);
											if (!target) return {
												success: false,
												error: "No element at drop coordinates"
											};
											const dt = new DataTransfer();
											dt.items.add(file);
											for (const eventType of [
												"dragenter",
												"dragover",
												"drop"
											]) {
												const evt = new DragEvent(eventType, {
													bubbles: true,
													cancelable: true,
													dataTransfer: dt,
													clientX: x,
													clientY: y
												});
												target.dispatchEvent(evt);
											}
											return {
												success: true,
												targetTagName: target.tagName,
												targetId: target.id || void 0
											};
										},
										args: [
											gifBase64,
											targetX,
											targetY,
											fullFilename
										]
									});
									if (!(result === null || result === void 0 || (_result$result = result.result) === null || _result$result === void 0 ? void 0 : _result$result.success)) {
										var _result$result2;
										return createErrorResponse((result === null || result === void 0 || (_result$result2 = result.result) === null || _result$result2 === void 0 ? void 0 : _result$result2.error) || "Drag&drop upload failed");
									}
									return _this.buildResponse({
										success: true,
										action: "export",
										mode: lastRecordedGif.mode,
										frameCount: lastRecordedGif.frameCount,
										durationMs: lastRecordedGif.durationMs,
										byteLength: lastRecordedGif.gifData.byteLength,
										uploadTarget: {
											x: targetX,
											y: targetY,
											tagName: result.result.targetTagName,
											id: result.result.targetId
										}
									});
								} catch (err) {
									return createErrorResponse(`Drag&drop upload failed: ${err instanceof Error ? err.message : String(err)}`);
								}
							}
						default: return createErrorResponse(`Unknown action: ${action}`);
					}
				} catch (error) {
					console.error("GifRecorderTool.execute error:", error);
					return createErrorResponse(`GIF recorder error: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
		isRestrictedUrl(url) {
			if (!url) return false;
			return url.startsWith("chrome://") || url.startsWith("edge://") || url.startsWith("https://chrome.google.com/webstore") || url.startsWith("https://microsoftedge.microsoft.com/");
		}
		resolveTargetTab(tabId) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				if (typeof tabId === "number") return _this2.tryGetTab(tabId);
				try {
					return yield _this2.getActiveTabOrThrow();
				} catch (_unused11) {
					return null;
				}
			})();
		}
		buildResponse(result) {
			return {
				content: [{
					type: "text",
					text: JSON.stringify(result)
				}],
				isError: !result.success
			};
		}
	};
	var gifRecorderTool = new GifRecorderTool();
	//#endregion
	//#region entrypoints/background/tools/browser/common.ts
	init_defineProperty();
	init_asyncToGenerator();
	var DEFAULT_WINDOW_WIDTH = 1280;
	var DEFAULT_WINDOW_HEIGHT = 720;
	/**
	* Tool for navigating to URLs in browser tabs or windows
	*/
	var NavigateTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.NAVIGATE);
		}
		/**
		* Trigger GIF auto-capture after successful navigation
		*/
		triggerAutoCapture(tabId, url) {
			return _asyncToGenerator(function* () {
				if (!isAutoCaptureActive(tabId)) return;
				try {
					yield captureFrameOnAction(tabId, {
						type: "navigate",
						url
					});
				} catch (error) {
					console.warn("[NavigateTool] Auto-capture failed:", error);
				}
			})();
		}
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const { newWindow = false, width, height, url, refresh = false, tabId, background, windowId } = args;
				console.log(`Attempting to ${refresh ? "refresh current tab" : `open URL: ${url}`} with options:`, args);
				try {
					if (refresh) {
						console.log("Refreshing current active tab");
						const targetTab = (yield _this.tryGetTab(tabId)) || (yield _this.getActiveTabOrThrowInWindow(windowId));
						if (!targetTab.id) return createErrorResponse("No target tab found to refresh");
						yield chrome.tabs.reload(targetTab.id);
						console.log(`Refreshed tab ID: ${targetTab.id}`);
						const updatedTab = yield chrome.tabs.get(targetTab.id);
						yield _this.triggerAutoCapture(updatedTab.id, updatedTab.url);
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									success: true,
									message: "Successfully refreshed current tab",
									tabId: updatedTab.id,
									windowId: updatedTab.windowId,
									url: updatedTab.url
								})
							}],
							isError: false
						};
					}
					if (!url) return createErrorResponse("URL parameter is required when refresh is not true");
					if (url === "back" || url === "forward") {
						const targetTab = (yield _this.tryGetTab(tabId)) || (yield _this.getActiveTabOrThrowInWindow(windowId));
						if (!targetTab.id) return createErrorResponse("No target tab found for history navigation");
						yield _this.ensureFocus(targetTab, {
							activate: background !== true,
							focusWindow: background !== true
						});
						if (url === "forward") {
							yield chrome.tabs.goForward(targetTab.id);
							console.log(`Navigated forward in tab ID: ${targetTab.id}`);
						} else {
							yield chrome.tabs.goBack(targetTab.id);
							console.log(`Navigated back in tab ID: ${targetTab.id}`);
						}
						const updatedTab = yield chrome.tabs.get(targetTab.id);
						yield _this.triggerAutoCapture(updatedTab.id, updatedTab.url);
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									success: true,
									message: `Successfully navigated ${url} in browser history`,
									tabId: updatedTab.id,
									windowId: updatedTab.windowId,
									url: updatedTab.url
								})
							}],
							isError: false
						};
					}
					console.log(`Checking if URL is already open: ${url}`);
					const buildUrlPatterns = (input) => {
						const patterns = /* @__PURE__ */ new Set();
						try {
							if (!input.includes("*")) {
								const u = new URL(input);
								const pathWildcard = "/*";
								const hostNoWww = u.host.replace(/^www\./, "");
								const hostWithWww = hostNoWww.startsWith("www.") ? hostNoWww : `www.${hostNoWww}`;
								patterns.add(`${u.protocol}//${u.host}${pathWildcard}`);
								patterns.add(`${u.protocol}//${hostNoWww}${pathWildcard}`);
								patterns.add(`${u.protocol}//${hostWithWww}${pathWildcard}`);
								const altProtocol = u.protocol === "https:" ? "http:" : "https:";
								patterns.add(`${altProtocol}//${u.host}${pathWildcard}`);
								patterns.add(`${altProtocol}//${hostNoWww}${pathWildcard}`);
								patterns.add(`${altProtocol}//${hostWithWww}${pathWildcard}`);
							} else patterns.add(input);
						} catch (_unused) {
							patterns.add(input.endsWith("/") ? `${input}*` : `${input}/*`);
						}
						return Array.from(patterns);
					};
					const urlPatterns = buildUrlPatterns(url);
					const candidateTabs = yield chrome.tabs.query({ url: urlPatterns });
					console.log(`Found ${candidateTabs.length} matching tabs with patterns:`, urlPatterns);
					const pickBestMatch = (target, tabsToPick) => {
						let targetUrl;
						try {
							targetUrl = new URL(target);
						} catch (_unused2) {
							return tabsToPick[0];
						}
						const normalizePath = (p) => {
							if (!p) return "/";
							const withLeading = p.startsWith("/") ? p : `/${p}`;
							return withLeading !== "/" && withLeading.endsWith("/") ? withLeading.slice(0, -1) : withLeading;
						};
						const hostBase = (h) => h.replace(/^www\./, "").toLowerCase();
						normalizePath(targetUrl.pathname) === "/" && targetUrl.search;
						const targetPath = normalizePath(targetUrl.pathname);
						const targetSearch = targetUrl.search || "";
						const targetHostBase = hostBase(targetUrl.host);
						let best = { score: -1 };
						for (const tab of tabsToPick) {
							const tabUrlStr = tab.url || "";
							let tabUrl;
							try {
								tabUrl = new URL(tabUrlStr);
							} catch (_unused3) {
								continue;
							}
							if (hostBase(tabUrl.host) !== targetHostBase) continue;
							const tabPath = normalizePath(tabUrl.pathname);
							const tabSearch = tabUrl.search || "";
							let score = -1;
							const pathEqual = tabPath === targetPath;
							if (pathEqual && (targetSearch ? tabSearch === targetSearch : true)) score = 3;
							else if (pathEqual && !targetSearch) score = 2;
							if (score > best.score) {
								best = {
									tab,
									score
								};
								if (score === 3) break;
							}
						}
						return best.tab;
					};
					const explicitTab = yield _this.tryGetTab(tabId);
					const existingTab = explicitTab || pickBestMatch(url, candidateTabs);
					if ((existingTab === null || existingTab === void 0 ? void 0 : existingTab.id) !== void 0) {
						console.log(`URL already open in Tab ID: ${existingTab.id}, Window ID: ${existingTab.windowId}`);
						if (explicitTab && typeof explicitTab.id === "number") yield chrome.tabs.update(explicitTab.id, { url });
						yield _this.ensureFocus(existingTab, {
							activate: background !== true,
							focusWindow: background !== true
						});
						console.log(`Activated existing Tab ID: ${existingTab.id}`);
						const updatedTab = yield chrome.tabs.get(existingTab.id);
						yield _this.triggerAutoCapture(updatedTab.id, updatedTab.url);
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									success: true,
									message: "Activated existing tab",
									tabId: updatedTab.id,
									windowId: updatedTab.windowId,
									url: updatedTab.url
								})
							}],
							isError: false
						};
					}
					if (newWindow || typeof width === "number" || typeof height === "number") {
						console.log("Opening URL in a new window.");
						const newWindow = yield chrome.windows.create({
							url,
							width: typeof width === "number" ? width : DEFAULT_WINDOW_WIDTH,
							height: typeof height === "number" ? height : DEFAULT_WINDOW_HEIGHT,
							focused: background === true ? false : true
						});
						if (newWindow && newWindow.id !== void 0) {
							var _newWindow$tabs;
							console.log(`URL opened in new Window ID: ${newWindow.id}`);
							const firstTab = (_newWindow$tabs = newWindow.tabs) === null || _newWindow$tabs === void 0 ? void 0 : _newWindow$tabs[0];
							if (firstTab === null || firstTab === void 0 ? void 0 : firstTab.id) yield _this.triggerAutoCapture(firstTab.id, firstTab.url);
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										message: "Opened URL in new window",
										windowId: newWindow.id,
										tabs: newWindow.tabs ? newWindow.tabs.map((tab) => ({
											tabId: tab.id,
											url: tab.url
										})) : []
									})
								}],
								isError: false
							};
						}
					} else {
						console.log("Opening URL in the last active window.");
						let targetWindow = null;
						if (typeof windowId === "number") targetWindow = yield chrome.windows.get(windowId, { populate: false });
						if (!targetWindow) targetWindow = yield chrome.windows.getLastFocused({ populate: false });
						if (targetWindow && targetWindow.id !== void 0) {
							console.log(`Found target Window ID: ${targetWindow.id}`);
							const newTab = yield chrome.tabs.create({
								url,
								windowId: targetWindow.id,
								active: background === true ? false : true
							});
							if (background !== true) yield chrome.windows.update(targetWindow.id, { focused: true });
							console.log(`URL opened in new Tab ID: ${newTab.id} in existing Window ID: ${targetWindow.id}`);
							if (newTab.id) yield _this.triggerAutoCapture(newTab.id, newTab.url);
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										message: "Opened URL in new tab in existing window",
										tabId: newTab.id,
										windowId: targetWindow.id,
										url: newTab.url
									})
								}],
								isError: false
							};
						} else {
							console.warn("No last focused window found, falling back to creating a new window.");
							const fallbackWindow = yield chrome.windows.create({
								url,
								width: DEFAULT_WINDOW_WIDTH,
								height: DEFAULT_WINDOW_HEIGHT,
								focused: true
							});
							if (fallbackWindow && fallbackWindow.id !== void 0) {
								var _fallbackWindow$tabs;
								console.log(`URL opened in fallback new Window ID: ${fallbackWindow.id}`);
								const firstTab = (_fallbackWindow$tabs = fallbackWindow.tabs) === null || _fallbackWindow$tabs === void 0 ? void 0 : _fallbackWindow$tabs[0];
								if (firstTab === null || firstTab === void 0 ? void 0 : firstTab.id) yield _this.triggerAutoCapture(firstTab.id, firstTab.url);
								return {
									content: [{
										type: "text",
										text: JSON.stringify({
											success: true,
											message: "Opened URL in new window",
											windowId: fallbackWindow.id,
											tabs: fallbackWindow.tabs ? fallbackWindow.tabs.map((tab) => ({
												tabId: tab.id,
												url: tab.url
											})) : []
										})
									}],
									isError: false
								};
							}
						}
					}
					return createErrorResponse("Failed to open URL: Unknown error occurred");
				} catch (error) {
					if (chrome.runtime.lastError) {
						console.error(`Chrome API Error: ${chrome.runtime.lastError.message}`, error);
						return createErrorResponse(`Chrome API Error: ${chrome.runtime.lastError.message}`);
					} else {
						console.error("Error in navigate:", error);
						return createErrorResponse(`Error navigating to URL: ${error instanceof Error ? error.message : String(error)}`);
					}
				}
			})();
		}
	};
	var navigateTool = new NavigateTool();
	/**
	* Tool for closing browser tabs
	*/
	var CloseTabsTool = class extends BaseBrowserToolExecutor {
		constructor(..._args2) {
			super(..._args2);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.CLOSE_TABS);
		}
		execute(args) {
			return _asyncToGenerator(function* () {
				const { tabIds, url } = args;
				let urlPattern = url;
				console.log(`Attempting to close tabs with options:`, args);
				try {
					if (urlPattern) {
						console.log(`Searching for tabs with URL: ${url}`);
						try {
							if (!urlPattern.includes("*")) try {
								const u = new URL(urlPattern);
								const basePath = u.pathname || "/";
								const pathWithWildcard = basePath.endsWith("/") ? `${basePath}*` : `${basePath}/*`;
								urlPattern = `${u.protocol}//${u.host}${pathWithWildcard}`;
							} catch (_unused4) {
								urlPattern = urlPattern.endsWith("/") ? `${urlPattern}*` : `${urlPattern}/*`;
							}
						} catch (_unused5) {
							urlPattern = urlPattern.endsWith("*") ? urlPattern : urlPattern.endsWith("/") ? `${urlPattern}*` : `${urlPattern}/*`;
						}
						const tabs = yield chrome.tabs.query({ url: urlPattern });
						if (!tabs || tabs.length === 0) {
							console.log(`No tabs found with URL pattern: ${urlPattern}`);
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: false,
										message: `No tabs found with URL pattern: ${urlPattern}`,
										closedCount: 0
									})
								}],
								isError: false
							};
						}
						console.log(`Found ${tabs.length} tabs with URL pattern: ${urlPattern}`);
						const tabIdsToClose = tabs.map((tab) => tab.id).filter((id) => id !== void 0);
						if (tabIdsToClose.length === 0) return createErrorResponse("Found tabs but could not get their IDs");
						yield chrome.tabs.remove(tabIdsToClose);
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									success: true,
									message: `Closed ${tabIdsToClose.length} tabs with URL: ${url}`,
									closedCount: tabIdsToClose.length,
									closedTabIds: tabIdsToClose
								})
							}],
							isError: false
						};
					}
					if (tabIds && tabIds.length > 0) {
						console.log(`Closing tabs with IDs: ${tabIds.join(", ")}`);
						const validTabIds = (yield Promise.all(tabIds.map(function() {
							var _ref = _asyncToGenerator(function* (tabId) {
								try {
									return yield chrome.tabs.get(tabId);
								} catch (error) {
									console.warn(`Tab with ID ${tabId} not found`);
									return null;
								}
							});
							return function(_x) {
								return _ref.apply(this, arguments);
							};
						}()))).filter((tab) => tab !== null).map((tab) => tab.id).filter((id) => id !== void 0);
						if (validTabIds.length === 0) return {
							content: [{
								type: "text",
								text: JSON.stringify({
									success: false,
									message: "None of the provided tab IDs exist",
									closedCount: 0
								})
							}],
							isError: false
						};
						yield chrome.tabs.remove(validTabIds);
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									success: true,
									message: `Closed ${validTabIds.length} tabs`,
									closedCount: validTabIds.length,
									closedTabIds: validTabIds,
									invalidTabIds: tabIds.filter((id) => !validTabIds.includes(id))
								})
							}],
							isError: false
						};
					}
					console.log("No tabIds or URL provided, closing active tab");
					const [activeTab] = yield chrome.tabs.query({
						active: true,
						currentWindow: true
					});
					if (!activeTab || !activeTab.id) return createErrorResponse("No active tab found");
					yield chrome.tabs.remove(activeTab.id);
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: "Closed active tab",
								closedCount: 1,
								closedTabIds: [activeTab.id]
							})
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in CloseTabsTool.execute:", error);
					return createErrorResponse(`Error closing tabs: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var closeTabsTool = new CloseTabsTool();
	/**
	* Tool for switching the active tab
	*/
	var SwitchTabTool = class extends BaseBrowserToolExecutor {
		constructor(..._args3) {
			super(..._args3);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.SWITCH_TAB);
		}
		execute(args) {
			return _asyncToGenerator(function* () {
				const { tabId, windowId } = args;
				console.log(`Attempting to switch to tab ID: ${tabId} in window ID: ${windowId}`);
				try {
					if (windowId !== void 0) yield chrome.windows.update(windowId, { focused: true });
					yield chrome.tabs.update(tabId, { active: true });
					const updatedTab = yield chrome.tabs.get(tabId);
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: `Successfully switched to tab ID: ${tabId}`,
								tabId: updatedTab.id,
								windowId: updatedTab.windowId,
								url: updatedTab.url
							})
						}],
						isError: false
					};
				} catch (error) {
					if (chrome.runtime.lastError) {
						console.error(`Chrome API Error: ${chrome.runtime.lastError.message}`, error);
						return createErrorResponse(`Chrome API Error: ${chrome.runtime.lastError.message}`);
					} else {
						console.error("Error in SwitchTabTool.execute:", error);
						return createErrorResponse(`Error switching tab: ${error instanceof Error ? error.message : String(error)}`);
					}
				}
			})();
		}
	};
	var switchTabTool = new SwitchTabTool();
	//#endregion
	//#region entrypoints/background/tools/browser/window.ts
	init_defineProperty();
	init_asyncToGenerator();
	var WindowTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.GET_WINDOWS_AND_TABS);
		}
		execute() {
			return _asyncToGenerator(function* () {
				try {
					const windows = yield chrome.windows.getAll({ populate: true });
					let tabCount = 0;
					const structuredWindows = windows.map((window) => {
						var _window$tabs;
						const tabs = ((_window$tabs = window.tabs) === null || _window$tabs === void 0 ? void 0 : _window$tabs.map((tab) => {
							tabCount++;
							return {
								tabId: tab.id || 0,
								url: tab.url || "",
								title: tab.title || "",
								active: tab.active || false
							};
						})) || [];
						return {
							windowId: window.id || 0,
							tabs
						};
					});
					const result = {
						windowCount: windows.length,
						tabCount,
						windows: structuredWindows
					};
					return {
						content: [{
							type: "text",
							text: JSON.stringify(result)
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in WindowTool.execute:", error);
					return createErrorResponse(`Error getting windows and tabs information: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var windowTool = new WindowTool();
	//#endregion
	//#region utils/screenshot-context.ts
	var TTL_MS = 300 * 1e3;
	var contexts = /* @__PURE__ */ new Map();
	var screenshotContextManager = {
		setContext(tabId, ctx) {
			contexts.set(tabId, _objectSpread2(_objectSpread2({}, ctx), {}, { timestamp: Date.now() }));
		},
		getContext(tabId) {
			const ctx = contexts.get(tabId);
			if (!ctx) return void 0;
			if (Date.now() - ctx.timestamp > TTL_MS) {
				contexts.delete(tabId);
				return;
			}
			return ctx;
		},
		clear(tabId) {
			contexts.delete(tabId);
		}
	};
	function scaleCoordinates(x, y, ctx) {
		if (!ctx.screenshotWidth || !ctx.screenshotHeight || !ctx.viewportWidth || !ctx.viewportHeight) return {
			x,
			y
		};
		const sx = x / ctx.screenshotWidth * ctx.viewportWidth;
		const sy = y / ctx.screenshotHeight * ctx.viewportHeight;
		return {
			x: Math.round(sx),
			y: Math.round(sy)
		};
	}
	//#endregion
	//#region entrypoints/background/tools/browser/screenshot.ts
	init_defineProperty();
	init_asyncToGenerator();
	var _chrome$tabs;
	var SCREENSHOT_CONSTANTS = {
		SCROLL_DELAY_MS: 350,
		CAPTURE_STITCH_DELAY_MS: 50,
		MAX_CAPTURE_PARTS: 50,
		MAX_CAPTURE_HEIGHT_PX: 5e4,
		PIXEL_TOLERANCE: 1,
		SCRIPT_INIT_DELAY: 100
	};
	var __MAX_CAP_RATE = (_chrome$tabs = chrome.tabs) === null || _chrome$tabs === void 0 ? void 0 : _chrome$tabs.MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND;
	if (typeof __MAX_CAP_RATE === "number" && __MAX_CAP_RATE > 0) {
		const minIntervalMs = Math.ceil(1e3 / __MAX_CAP_RATE);
		const requiredExtraDelay = Math.max(0, minIntervalMs - SCREENSHOT_CONSTANTS.SCROLL_DELAY_MS);
		SCREENSHOT_CONSTANTS.CAPTURE_STITCH_DELAY_MS = Math.max(requiredExtraDelay, SCREENSHOT_CONSTANTS.CAPTURE_STITCH_DELAY_MS);
	}
	var PAGE_DETAILS_REQUIRED_FIELDS = [
		"totalWidth",
		"totalHeight",
		"viewportWidth",
		"viewportHeight",
		"devicePixelRatio",
		"currentScrollX",
		"currentScrollY"
	];
	/**
	* Validates and asserts that the response from content script contains valid page details
	*/
	function assertValidPageDetails(details) {
		if (!details || typeof details !== "object") throw new Error("Screenshot helper did not respond. The content script may not be injected or cannot run on this page.");
		const candidate = details;
		const invalidFields = PAGE_DETAILS_REQUIRED_FIELDS.filter((field) => typeof candidate[field] !== "number" || !Number.isFinite(candidate[field]));
		if (invalidFields.length > 0) throw new Error(`Screenshot helper returned invalid page details (missing/invalid: ${invalidFields.join(", ")}).`);
		return candidate;
	}
	/**
	* Tool for capturing screenshots of web pages
	*/
	var ScreenshotTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.SCREENSHOT);
		}
		/**
		* Execute screenshot operation
		*/
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				var _tab$url, _tab$url2, _tab$url3, _tab$url4;
				const { name = "screenshot", selector, storeBase64 = false, fullPage = false, savePng = true } = args;
				console.log(`Starting screenshot with options:`, args);
				const tab = (yield _this.tryGetTab(args.tabId)) || (yield _this.getActiveTabOrThrowInWindow(args.windowId));
				if (((_tab$url = tab.url) === null || _tab$url === void 0 ? void 0 : _tab$url.startsWith("chrome://")) || ((_tab$url2 = tab.url) === null || _tab$url2 === void 0 ? void 0 : _tab$url2.startsWith("edge://")) || ((_tab$url3 = tab.url) === null || _tab$url3 === void 0 ? void 0 : _tab$url3.startsWith("https://chrome.google.com/webstore")) || ((_tab$url4 = tab.url) === null || _tab$url4 === void 0 ? void 0 : _tab$url4.startsWith("https://microsoftedge.microsoft.com/"))) return createErrorResponse("Cannot capture special browser pages or web store pages due to security restrictions.");
				let finalImageDataUrl;
				let finalImageWidthCss;
				let finalImageHeightCss;
				const results = {
					base64: null,
					fileSaved: false
				};
				let originalScroll = null;
				let didPreparePage = false;
				let pageDetails;
				try {
					if (args.background === true && !fullPage && !selector) try {
						const tabId = tab.id;
						const { cdpSessionManager } = yield Promise.resolve().then(() => (init_cdp_session_manager(), cdp_session_manager_exports));
						yield cdpSessionManager.withSession(tabId, "screenshot", _asyncToGenerator(function* () {
							const metrics = yield cdpSessionManager.sendCommand(tabId, "Page.getLayoutMetrics", {});
							const viewport = (metrics === null || metrics === void 0 ? void 0 : metrics.layoutViewport) || (metrics === null || metrics === void 0 ? void 0 : metrics.visualViewport) || {
								clientWidth: 800,
								clientHeight: 600,
								pageX: 0,
								pageY: 0
							};
							const shot = yield cdpSessionManager.sendCommand(tabId, "Page.captureScreenshot", { format: "png" });
							const base64Data = typeof (shot === null || shot === void 0 ? void 0 : shot.data) === "string" ? shot.data : "";
							if (!base64Data) throw new Error("CDP Page.captureScreenshot returned empty data");
							finalImageDataUrl = `data:image/png;base64,${base64Data}`;
							finalImageWidthCss = Math.round(viewport.clientWidth || 800);
							finalImageHeightCss = Math.round(viewport.clientHeight || 600);
						}));
					} catch (e) {
						console.warn("CDP viewport capture failed, falling back to helper path:", e);
					}
					if (!finalImageDataUrl) {
						yield _this.injectContentScript(tab.id, ["inject-scripts/screenshot-helper.js"]);
						yield new Promise((resolve) => setTimeout(resolve, SCREENSHOT_CONSTANTS.SCRIPT_INIT_DELAY));
						const prepareResp = yield _this.sendMessageToTab(tab.id, {
							action: TOOL_MESSAGE_TYPES.SCREENSHOT_PREPARE_PAGE_FOR_CAPTURE,
							options: { fullPage }
						});
						if (!prepareResp || prepareResp.success !== true) throw new Error("Screenshot helper did not acknowledge page preparation. The content script may not be injected or cannot run on this page.");
						didPreparePage = true;
						pageDetails = assertValidPageDetails(yield _this.sendMessageToTab(tab.id, { action: TOOL_MESSAGE_TYPES.SCREENSHOT_GET_PAGE_DETAILS }));
						originalScroll = {
							x: pageDetails.currentScrollX,
							y: pageDetails.currentScrollY
						};
						if (fullPage) {
							_this.logInfo("Capturing full page...");
							finalImageDataUrl = yield _this._captureFullPage(tab.id, args, pageDetails);
							if (args.width && args.height) {
								finalImageWidthCss = args.width;
								finalImageHeightCss = args.height;
							} else if (args.width && !args.height) {
								finalImageWidthCss = args.width;
								const ratio = pageDetails.totalHeight / pageDetails.totalWidth;
								finalImageHeightCss = Math.round(args.width * ratio);
							} else if (!args.width && args.height) {
								finalImageHeightCss = args.height;
								const ratio = pageDetails.totalWidth / pageDetails.totalHeight;
								finalImageWidthCss = Math.round(args.height * ratio);
							} else {
								finalImageWidthCss = pageDetails.totalWidth;
								finalImageHeightCss = pageDetails.totalHeight;
							}
						} else if (selector) {
							_this.logInfo(`Capturing element: ${selector}`);
							finalImageDataUrl = yield _this._captureElement(tab.id, args, pageDetails.devicePixelRatio);
							if (args.width && args.height) {
								finalImageWidthCss = args.width;
								finalImageHeightCss = args.height;
							} else {
								finalImageWidthCss = pageDetails.viewportWidth;
								finalImageHeightCss = pageDetails.viewportHeight;
							}
						} else {
							_this.logInfo("Capturing visible area...");
							finalImageDataUrl = yield chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
							finalImageWidthCss = pageDetails.viewportWidth;
							finalImageHeightCss = pageDetails.viewportHeight;
						}
					}
					if (!finalImageDataUrl) throw new Error("Failed to capture image data");
					try {
						if (typeof finalImageWidthCss === "number" && typeof finalImageHeightCss === "number") {
							var _pageDetails$viewport, _pageDetails$viewport2;
							let hostname = "";
							try {
								hostname = tab.url ? new URL(tab.url).hostname : "";
							} catch (_unused) {}
							const viewportWidth = (_pageDetails$viewport = pageDetails === null || pageDetails === void 0 ? void 0 : pageDetails.viewportWidth) !== null && _pageDetails$viewport !== void 0 ? _pageDetails$viewport : finalImageWidthCss;
							const viewportHeight = (_pageDetails$viewport2 = pageDetails === null || pageDetails === void 0 ? void 0 : pageDetails.viewportHeight) !== null && _pageDetails$viewport2 !== void 0 ? _pageDetails$viewport2 : finalImageHeightCss;
							screenshotContextManager.setContext(tab.id, {
								screenshotWidth: finalImageWidthCss,
								screenshotHeight: finalImageHeightCss,
								viewportWidth,
								viewportHeight,
								devicePixelRatio: pageDetails === null || pageDetails === void 0 ? void 0 : pageDetails.devicePixelRatio,
								hostname
							});
						}
					} catch (e) {
						console.warn("Failed to set screenshot context:", e);
					}
					if (storeBase64 === true) {
						const compressed = yield compressImage(finalImageDataUrl, {
							scale: .7,
							quality: .8,
							format: "image/jpeg"
						});
						const base64Data = compressed.dataUrl.replace(/^data:image\/[^;]+;base64,/, "");
						results.base64 = base64Data;
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									base64Data,
									mimeType: compressed.mimeType
								})
							}],
							isError: false
						};
					}
					if (savePng === true) {
						_this.logInfo("Saving PNG...");
						try {
							const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
							const filename = `${name.replace(/[^a-z0-9_-]/gi, "_") || "screenshot"}_${timestamp}.png`;
							const downloadId = yield chrome.downloads.download({
								url: finalImageDataUrl,
								filename,
								saveAs: false
							});
							results.downloadId = downloadId;
							results.filename = filename;
							results.fileSaved = true;
							try {
								yield new Promise((resolve) => setTimeout(resolve, 100));
								const [downloadItem] = yield chrome.downloads.search({ id: downloadId });
								if (downloadItem && downloadItem.filename) results.fullPath = downloadItem.filename;
							} catch (pathError) {
								console.warn("Could not get full file path:", pathError);
							}
						} catch (error) {
							console.error("Error saving PNG file:", error);
							results.saveError = String(error instanceof Error ? error.message : error);
						}
					}
				} catch (error) {
					console.error("Error during screenshot execution:", error);
					return createErrorResponse(`Screenshot error: ${error instanceof Error ? error.message : JSON.stringify(error)}`);
				} finally {
					if (didPreparePage) try {
						const resetMessage = { action: TOOL_MESSAGE_TYPES.SCREENSHOT_RESET_PAGE_AFTER_CAPTURE };
						if (originalScroll) {
							resetMessage.scrollX = originalScroll.x;
							resetMessage.scrollY = originalScroll.y;
						}
						yield _this.sendMessageToTab(tab.id, resetMessage);
					} catch (err) {
						console.warn("Failed to reset page, tab might have closed:", err);
					}
				}
				_this.logInfo("Screenshot completed!");
				return {
					content: [{
						type: "text",
						text: JSON.stringify(_objectSpread2({
							success: true,
							message: `Screenshot [${name}] captured successfully`,
							tabId: tab.id,
							url: tab.url,
							name
						}, results))
					}],
					isError: false
				};
			})();
		}
		/**
		* Log information
		*/
		logInfo(message) {
			console.log(`[Screenshot Tool] ${message}`);
		}
		/**
		* Capture specific element
		*/
		_captureElement(tabId, options, pageDpr) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				const elementDetails = yield _this2.sendMessageToTab(tabId, {
					action: TOOL_MESSAGE_TYPES.SCREENSHOT_GET_ELEMENT_DETAILS,
					selector: options.selector
				});
				const dpr = elementDetails.devicePixelRatio || pageDpr || 1;
				const cropRectPx = {
					x: elementDetails.rect.x * dpr,
					y: elementDetails.rect.y * dpr,
					width: elementDetails.rect.width * dpr,
					height: elementDetails.rect.height * dpr
				};
				yield new Promise((resolve) => setTimeout(resolve, SCREENSHOT_CONSTANTS.SCRIPT_INIT_DELAY));
				const visibleCaptureDataUrl = yield chrome.tabs.captureVisibleTab({ format: "png" });
				if (!visibleCaptureDataUrl) throw new Error("Failed to capture visible tab for element cropping");
				return canvasToDataURL(yield cropAndResizeImage(visibleCaptureDataUrl, cropRectPx, dpr, options.width, options.height));
			})();
		}
		/**
		* Capture full page
		*/
		_captureFullPage(tabId, options, initialPageDetails) {
			var _this3 = this;
			return _asyncToGenerator(function* () {
				const dpr = initialPageDetails.devicePixelRatio;
				const totalWidthCss = options.width || initialPageDetails.totalWidth;
				const totalHeightCss = initialPageDetails.totalHeight;
				const maxHeightPx = options.maxHeight || SCREENSHOT_CONSTANTS.MAX_CAPTURE_HEIGHT_PX;
				const limitedHeightCss = Math.min(totalHeightCss, maxHeightPx / dpr);
				const totalWidthPx = totalWidthCss * dpr;
				const totalHeightPx = limitedHeightCss * dpr;
				_this3.logInfo(`Viewport size: ${initialPageDetails.viewportWidth}x${initialPageDetails.viewportHeight} CSS pixels`);
				_this3.logInfo(`Page dimensions: ${totalWidthCss}x${totalHeightCss} CSS pixels (limited to ${limitedHeightCss} height)`);
				const viewportHeightCss = initialPageDetails.viewportHeight;
				const capturedParts = [];
				let currentScrollYCss = 0;
				let capturedHeightPx = 0;
				let partIndex = 0;
				while (capturedHeightPx < totalHeightPx && partIndex < SCREENSHOT_CONSTANTS.MAX_CAPTURE_PARTS) {
					_this3.logInfo(`Capturing part ${partIndex + 1}... (${Math.round(capturedHeightPx / totalHeightPx * 100)}%)`);
					if (currentScrollYCss > 0) currentScrollYCss = (yield _this3.sendMessageToTab(tabId, {
						action: TOOL_MESSAGE_TYPES.SCREENSHOT_SCROLL_PAGE,
						x: 0,
						y: currentScrollYCss,
						scrollDelay: SCREENSHOT_CONSTANTS.SCROLL_DELAY_MS
					})).newScrollY;
					yield new Promise((resolve) => setTimeout(resolve, SCREENSHOT_CONSTANTS.CAPTURE_STITCH_DELAY_MS));
					const dataUrl = yield chrome.tabs.captureVisibleTab({ format: "png" });
					if (!dataUrl) throw new Error("captureVisibleTab returned empty during full page capture");
					const yOffsetPx = currentScrollYCss * dpr;
					capturedParts.push({
						dataUrl,
						y: yOffsetPx
					});
					const imgForHeight = yield createImageBitmapFromUrl(dataUrl);
					capturedHeightPx = yOffsetPx + Math.min(imgForHeight.height, totalHeightPx - yOffsetPx);
					if (capturedHeightPx >= totalHeightPx - SCREENSHOT_CONSTANTS.PIXEL_TOLERANCE) break;
					currentScrollYCss += viewportHeightCss;
					if (currentScrollYCss > totalHeightCss - viewportHeightCss && currentScrollYCss < totalHeightCss) currentScrollYCss = totalHeightCss - viewportHeightCss;
					partIndex++;
				}
				if (partIndex >= SCREENSHOT_CONSTANTS.MAX_CAPTURE_PARTS) _this3.logInfo(`Reached maximum number of capture parts (${SCREENSHOT_CONSTANTS.MAX_CAPTURE_PARTS}). This may be an infinite scroll page.`);
				if (totalHeightCss > limitedHeightCss) _this3.logInfo(`Page height (${totalHeightCss}px) exceeds maximum capture height (${maxHeightPx / dpr}px). Capturing limited portion.`);
				_this3.logInfo("Stitching image...");
				const finalCanvas = yield stitchImages(capturedParts, totalWidthPx, totalHeightPx);
				let outputCanvas = finalCanvas;
				if (options.width && !options.height) {
					const targetWidthPx = options.width * dpr;
					const targetHeightPx = targetWidthPx * (finalCanvas.height / finalCanvas.width);
					outputCanvas = new OffscreenCanvas(targetWidthPx, targetHeightPx);
					const ctx = outputCanvas.getContext("2d");
					if (ctx) ctx.drawImage(finalCanvas, 0, 0, targetWidthPx, targetHeightPx);
				} else if (options.height && !options.width) {
					const targetHeightPx = options.height * dpr;
					const targetWidthPx = targetHeightPx * (finalCanvas.width / finalCanvas.height);
					outputCanvas = new OffscreenCanvas(targetWidthPx, targetHeightPx);
					const ctx = outputCanvas.getContext("2d");
					if (ctx) ctx.drawImage(finalCanvas, 0, 0, targetWidthPx, targetHeightPx);
				} else if (options.width && options.height) {
					const targetWidthPx = options.width * dpr;
					const targetHeightPx = options.height * dpr;
					outputCanvas = new OffscreenCanvas(targetWidthPx, targetHeightPx);
					const ctx = outputCanvas.getContext("2d");
					if (ctx) ctx.drawImage(finalCanvas, 0, 0, targetWidthPx, targetHeightPx);
				}
				return canvasToDataURL(outputCanvas);
			})();
		}
	};
	var screenshotTool = new ScreenshotTool();
	//#endregion
	//#region entrypoints/background/tools/browser/web-fetcher.ts
	init_defineProperty();
	init_asyncToGenerator();
	var WebFetcherTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.WEB_FETCHER);
		}
		/**
		* Execute web fetcher operation
		*/
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const htmlContent = args.htmlContent === true;
				const textContent = htmlContent ? false : args.textContent !== false;
				const url = args.url;
				const selector = args.selector;
				const explicitTabId = args.tabId;
				const background = args.background === true;
				const windowId = args.windowId;
				console.log(`Starting web fetcher with options:`, {
					htmlContent,
					textContent,
					url,
					selector
				});
				try {
					let tab;
					if (typeof explicitTabId === "number") tab = yield chrome.tabs.get(explicitTabId);
					else if (url) {
						console.log(`Checking if URL is already open: ${url}`);
						const matchingTabs = (yield chrome.tabs.query({})).filter((t) => {
							var _t$url;
							return (((_t$url = t.url) === null || _t$url === void 0 ? void 0 : _t$url.endsWith("/")) ? t.url.slice(0, -1) : t.url) === (url.endsWith("/") ? url.slice(0, -1) : url);
						});
						if (matchingTabs.length > 0) {
							tab = matchingTabs[0];
							console.log(`Found existing tab with URL: ${url}, tab ID: ${tab.id}`);
						} else {
							console.log(`No existing tab found with URL: ${url}, creating new tab`);
							tab = yield chrome.tabs.create({
								url,
								active: background ? false : true
							});
							console.log("Waiting for page to load...");
							yield new Promise((resolve) => setTimeout(resolve, 3e3));
						}
					} else {
						const tabs = typeof windowId === "number" ? yield chrome.tabs.query({
							active: true,
							windowId
						}) : yield chrome.tabs.query({
							active: true,
							currentWindow: true
						});
						if (!tabs[0]) return createErrorResponse("No active tab found");
						tab = tabs[0];
					}
					if (!tab.id) return createErrorResponse("Tab has no ID");
					if (!background) {
						yield chrome.tabs.update(tab.id, { active: true });
						yield chrome.windows.update(tab.windowId, { focused: true });
					}
					const result = {
						success: true,
						url: tab.url,
						title: tab.title
					};
					yield _this.injectContentScript(tab.id, ["inject-scripts/web-fetcher-helper.js"]);
					if (htmlContent) {
						const htmlResponse = yield _this.sendMessageToTab(tab.id, {
							action: TOOL_MESSAGE_TYPES.WEB_FETCHER_GET_HTML_CONTENT,
							selector
						});
						if (htmlResponse.success) result.htmlContent = htmlResponse.htmlContent;
						else {
							console.error("Failed to get HTML content:", htmlResponse.error);
							result.htmlContentError = htmlResponse.error;
						}
					}
					if (textContent) {
						const textResponse = yield _this.sendMessageToTab(tab.id, {
							action: TOOL_MESSAGE_TYPES.WEB_FETCHER_GET_TEXT_CONTENT,
							selector
						});
						if (textResponse.success) {
							result.textContent = textResponse.textContent;
							if (textResponse.article) result.article = {
								title: textResponse.article.title,
								byline: textResponse.article.byline,
								siteName: textResponse.article.siteName,
								excerpt: textResponse.article.excerpt,
								lang: textResponse.article.lang
							};
							if (textResponse.metadata) result.metadata = textResponse.metadata;
						} else {
							console.error("Failed to get text content:", textResponse.error);
							result.textContentError = textResponse.error;
						}
					}
					return {
						content: [{
							type: "text",
							text: JSON.stringify(result)
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in web fetcher:", error);
					return createErrorResponse(`Error fetching web content: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var webFetcherTool = new WebFetcherTool();
	var GetInteractiveElementsTool = class extends BaseBrowserToolExecutor {
		constructor(..._args2) {
			super(..._args2);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.GET_INTERACTIVE_ELEMENTS);
		}
		/**
		* Execute get interactive elements operation
		*/
		execute(args) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				const { textQuery, selector, includeCoordinates = true, types } = args;
				console.log(`Starting get interactive elements with options:`, args);
				try {
					const tabs = yield chrome.tabs.query({
						active: true,
						currentWindow: true
					});
					if (!tabs[0]) return createErrorResponse("No active tab found");
					const tab = tabs[0];
					if (!tab.id) return createErrorResponse("Active tab has no ID");
					yield _this2.injectContentScript(tab.id, ["inject-scripts/interactive-elements-helper.js"]);
					const result = yield _this2.sendMessageToTab(tab.id, {
						action: TOOL_MESSAGE_TYPES.GET_INTERACTIVE_ELEMENTS,
						textQuery,
						selector,
						includeCoordinates,
						types
					});
					if (!result.success) return createErrorResponse(result.error || "Failed to get interactive elements");
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								elements: result.elements,
								count: result.elements.length,
								query: {
									textQuery,
									selector,
									types: types || "all"
								}
							})
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in get interactive elements operation:", error);
					return createErrorResponse(`Error getting interactive elements: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var getInteractiveElementsTool = new GetInteractiveElementsTool();
	//#endregion
	//#region entrypoints/background/tools/browser/interaction.ts
	init_defineProperty();
	init_asyncToGenerator();
	/**
	* Tool for clicking elements on web pages
	*/
	var ClickTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.CLICK);
		}
		/**
		* Execute click operation
		*/
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const { selector, selectorType = "css", coordinates, waitForNavigation = false, timeout = TIMEOUTS.DEFAULT_WAIT * 5, frameId, button, bubbles, cancelable, modifiers } = args;
				console.log(`Starting click operation with options:`, args);
				if (!selector && !coordinates && !args.ref) return createErrorResponse(ERROR_MESSAGES.INVALID_PARAMETERS + ": Provide ref or selector or coordinates");
				try {
					const tab = (yield _this.tryGetTab(args.tabId)) || (yield _this.getActiveTabOrThrowInWindow(args.windowId));
					if (!tab.id) return createErrorResponse(ERROR_MESSAGES.TAB_NOT_FOUND + ": Active tab has no ID");
					let finalRef = args.ref;
					let finalSelector = selector;
					if (selector && selectorType === "xpath") {
						yield _this.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
						try {
							const resolved = yield _this.sendMessageToTab(tab.id, {
								action: TOOL_MESSAGE_TYPES.ENSURE_REF_FOR_SELECTOR,
								selector,
								isXPath: true
							}, frameId);
							if (resolved && resolved.success && resolved.ref) {
								finalRef = resolved.ref;
								finalSelector = void 0;
							} else return createErrorResponse(`Failed to resolve XPath selector: ${(resolved === null || resolved === void 0 ? void 0 : resolved.error) || "unknown error"}`);
						} catch (error) {
							return createErrorResponse(`Error resolving XPath: ${error instanceof Error ? error.message : String(error)}`);
						}
					}
					yield _this.injectContentScript(tab.id, ["inject-scripts/click-helper.js"]);
					const result = yield _this.sendMessageToTab(tab.id, {
						action: TOOL_MESSAGE_TYPES.CLICK_ELEMENT,
						selector: finalSelector,
						coordinates,
						ref: finalRef,
						waitForNavigation,
						timeout,
						double: args.double === true,
						button,
						bubbles,
						cancelable,
						modifiers
					}, frameId);
					let clickMethod;
					if (coordinates) clickMethod = "coordinates";
					else if (finalRef) clickMethod = "ref";
					else if (finalSelector) clickMethod = "selector";
					else clickMethod = "unknown";
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: result.message || "Click operation successful",
								elementInfo: result.elementInfo,
								navigationOccurred: result.navigationOccurred,
								clickMethod
							})
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in click operation:", error);
					return createErrorResponse(`Error performing click: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var clickTool = new ClickTool();
	/**
	* Tool for filling form elements on web pages
	*/
	var FillTool = class extends BaseBrowserToolExecutor {
		constructor(..._args2) {
			super(..._args2);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.FILL);
		}
		/**
		* Execute fill operation
		*/
		execute(args) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				const { selector, selectorType = "css", ref, value, frameId } = args;
				console.log(`Starting fill operation with options:`, args);
				if (!selector && !ref) return createErrorResponse(ERROR_MESSAGES.INVALID_PARAMETERS + ": Provide ref or selector");
				if (value === void 0 || value === null) return createErrorResponse(ERROR_MESSAGES.INVALID_PARAMETERS + ": Value must be provided");
				try {
					const tab = (yield _this2.tryGetTab(args.tabId)) || (yield _this2.getActiveTabOrThrowInWindow(args.windowId));
					if (!tab.id) return createErrorResponse(ERROR_MESSAGES.TAB_NOT_FOUND + ": Active tab has no ID");
					let finalRef = ref;
					let finalSelector = selector;
					if (selector && selectorType === "xpath") {
						yield _this2.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
						try {
							const resolved = yield _this2.sendMessageToTab(tab.id, {
								action: TOOL_MESSAGE_TYPES.ENSURE_REF_FOR_SELECTOR,
								selector,
								isXPath: true
							}, frameId);
							if (resolved && resolved.success && resolved.ref) {
								finalRef = resolved.ref;
								finalSelector = void 0;
							} else return createErrorResponse(`Failed to resolve XPath selector: ${(resolved === null || resolved === void 0 ? void 0 : resolved.error) || "unknown error"}`);
						} catch (error) {
							return createErrorResponse(`Error resolving XPath: ${error instanceof Error ? error.message : String(error)}`);
						}
					}
					yield _this2.injectContentScript(tab.id, ["inject-scripts/fill-helper.js"]);
					const result = yield _this2.sendMessageToTab(tab.id, {
						action: TOOL_MESSAGE_TYPES.FILL_ELEMENT,
						selector: finalSelector,
						ref: finalRef,
						value
					}, frameId);
					if (result && result.error) return createErrorResponse(result.error);
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: result.message || "Fill operation successful",
								elementInfo: result.elementInfo
							})
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in fill operation:", error);
					return createErrorResponse(`Error filling element: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var fillTool = new FillTool();
	//#endregion
	//#region entrypoints/background/tools/browser/element-picker.ts
	/**
	* Element Picker Tool
	*
	* Implements chrome_request_element_selection - a human-in-the-loop tool that allows
	* users to manually select elements on the page when AI cannot reliably locate them.
	*/
	init_defineProperty();
	init_asyncToGenerator();
	var DEFAULT_TIMEOUT_MS$1 = 180 * 1e3;
	var MAX_TIMEOUT_MS = 600 * 1e3;
	var MIN_TIMEOUT_MS = 10 * 1e3;
	function toTrimmedString(value) {
		return typeof value === "string" ? value.trim() : "";
	}
	function normalizeTimeoutMs(value) {
		if (value === void 0 || value === null) return DEFAULT_TIMEOUT_MS$1;
		const n = Number(value);
		if (!Number.isFinite(n) || n <= 0) return DEFAULT_TIMEOUT_MS$1;
		return Math.min(Math.max(Math.floor(n), MIN_TIMEOUT_MS), MAX_TIMEOUT_MS);
	}
	function normalizeRequests(requests) {
		const out = [];
		const seen = /* @__PURE__ */ new Set();
		for (let i = 0; i < requests.length; i++) {
			const r = requests[i] || {};
			const name = toTrimmedString(r.name);
			if (!name) continue;
			const baseId = toTrimmedString(r.id) || `req_${i + 1}`;
			let id = baseId;
			let suffix = 2;
			while (seen.has(id)) id = `${baseId}_${suffix++}`;
			seen.add(id);
			const description = toTrimmedString(r.description);
			out.push({
				id,
				name,
				description: description || void 0
			});
		}
		return out;
	}
	function buildResultItems(requests, pickedById) {
		return requests.map((r) => ({
			id: r.id,
			name: r.name,
			element: pickedById.get(r.id) || null
		}));
	}
	function listMissingRequestIds(requests, pickedById) {
		const missing = [];
		for (const r of requests) if (!pickedById.has(r.id)) missing.push(r.id);
		return missing;
	}
	var ElementPickerTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.REQUEST_ELEMENT_SELECTION);
		}
		/**
		* Inject picker scripts into all frames of the tab.
		*/
		injectPickerScripts(tabId) {
			return _asyncToGenerator(function* () {
				yield chrome.scripting.executeScript({
					target: {
						tabId,
						allFrames: true
					},
					files: ["inject-scripts/element-picker.js"],
					world: "ISOLATED",
					injectImmediately: false
				});
			})();
		}
		/**
		* Call the picker API in all frames via scripting.executeScript.
		*/
		callPickerApi(tabId, method, payload) {
			return _asyncToGenerator(function* () {
				yield chrome.scripting.executeScript({
					target: {
						tabId,
						allFrames: true
					},
					world: "ISOLATED",
					injectImmediately: false,
					func: (methodName, data) => {
						try {
							const api = globalThis.__mcpElementPicker;
							const fn = api && api[methodName];
							if (typeof fn === "function") fn(data);
						} catch (_unused) {}
					},
					args: [method, payload]
				});
			})();
		}
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				var _requests$;
				const rawRequests = Array.isArray(args === null || args === void 0 ? void 0 : args.requests) ? args.requests : [];
				if (rawRequests.length === 0) return createErrorResponse(`${ERROR_MESSAGES.INVALID_PARAMETERS}: requests[] is required`);
				const requests = normalizeRequests(rawRequests);
				if (requests.length === 0) return createErrorResponse(`${ERROR_MESSAGES.INVALID_PARAMETERS}: requests[] must contain at least one non-empty name`);
				const timeoutMs = normalizeTimeoutMs(args === null || args === void 0 ? void 0 : args.timeoutMs);
				const sessionId = `ep_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
				const deadlineTs = Date.now() + timeoutMs;
				let tab;
				try {
					tab = (yield _this.tryGetTab(args === null || args === void 0 ? void 0 : args.tabId)) || (yield _this.getActiveTabOrThrowInWindow(args === null || args === void 0 ? void 0 : args.windowId));
				} catch (error) {
					return createErrorResponse(`${ERROR_MESSAGES.TAB_NOT_FOUND}: ${error instanceof Error ? error.message : String(error)}`);
				}
				if (!tab.id) return createErrorResponse(`${ERROR_MESSAGES.TAB_NOT_FOUND}: Active tab has no ID`);
				const tabId = tab.id;
				try {
					yield _this.ensureFocus(tab, {
						activate: true,
						focusWindow: true
					});
				} catch (_unused2) {}
				const pickedById = /* @__PURE__ */ new Map();
				let activeRequestId = ((_requests$ = requests[0]) === null || _requests$ === void 0 ? void 0 : _requests$.id) || null;
				let uiErrorMessage = null;
				let uiAvailable = true;
				let finished = false;
				let timer = null;
				let resolveResult = null;
				const sendUiUpdate = function() {
					var _ref = _asyncToGenerator(function* () {
						if (!uiAvailable) return;
						try {
							const selections = {};
							for (const r of requests) selections[r.id] = pickedById.get(r.id) || null;
							yield _this.sendMessageToTab(tabId, {
								action: TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_UPDATE,
								sessionId,
								activeRequestId,
								selections,
								deadlineTs,
								errorMessage: uiErrorMessage
							}, 0);
						} catch (_unused3) {
							uiAvailable = false;
						}
					});
					return function sendUiUpdate() {
						return _ref.apply(this, arguments);
					};
				}();
				const setActiveRequest = function() {
					var _ref2 = _asyncToGenerator(function* (requestId) {
						activeRequestId = requestId;
						yield _this.callPickerApi(tabId, "setActiveRequest", {
							sessionId,
							activeRequestId: requestId
						});
						yield sendUiUpdate();
					});
					return function setActiveRequest(_x) {
						return _ref2.apply(this, arguments);
					};
				}();
				const finish = function() {
					var _ref3 = _asyncToGenerator(function* (final) {
						if (finished) return;
						finished = true;
						if (timer !== null) {
							clearTimeout(timer);
							timer = null;
						}
						chrome.runtime.onMessage.removeListener(onRuntimeMessage);
						yield Promise.allSettled([_this.callPickerApi(tabId, "stopSession", { sessionId }), uiAvailable ? _this.sendMessageToTab(tabId, {
							action: TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_HIDE,
							sessionId
						}, 0) : Promise.resolve()]);
						const missing = listMissingRequestIds(requests, pickedById);
						const result = {
							success: final.success,
							sessionId,
							timeoutMs,
							cancelled: final.cancelled,
							timedOut: final.timedOut,
							missingRequestIds: missing.length > 0 ? missing : void 0,
							results: buildResultItems(requests, pickedById)
						};
						resolveResult === null || resolveResult === void 0 || resolveResult(result);
					});
					return function finish(_x2) {
						return _ref3.apply(this, arguments);
					};
				}();
				const onRuntimeMessage = (message, sender, sendResponse) => {
					var _sender$tab;
					if ((sender === null || sender === void 0 || (_sender$tab = sender.tab) === null || _sender$tab === void 0 ? void 0 : _sender$tab.id) !== tabId) return;
					const msg = message;
					if (!msg || msg.sessionId !== sessionId) return;
					if (msg.type === BACKGROUND_MESSAGE_TYPES.ELEMENT_PICKER_FRAME_EVENT) {
						if (msg.event === "cancel") {
							finish({
								success: false,
								cancelled: true
							});
							sendResponse === null || sendResponse === void 0 || sendResponse({ success: true });
							return true;
						}
						if (msg.event === "selected") {
							const requestId = toTrimmedString(msg.requestId);
							const frameId = typeof sender.frameId === "number" ? sender.frameId : 0;
							if (!(requestId && requests.some((r) => r.id === requestId))) {
								sendResponse === null || sendResponse === void 0 || sendResponse({
									success: false,
									error: "Unknown requestId"
								});
								return true;
							}
							const raw = msg.element || {};
							const ref = toTrimmedString(raw.ref);
							if (!ref) {
								sendResponse === null || sendResponse === void 0 || sendResponse({
									success: false,
									error: "Missing element.ref"
								});
								return true;
							}
							const selector = toTrimmedString(raw.selector);
							const rect = raw.rect;
							const center = raw.center;
							const picked = {
								ref,
								selector,
								selectorType: "css",
								rect: rect && typeof rect === "object" ? rect : {
									x: 0,
									y: 0,
									width: 0,
									height: 0
								},
								center: center && typeof center === "object" ? center : {
									x: 0,
									y: 0
								},
								text: typeof raw.text === "string" ? raw.text : void 0,
								tagName: typeof raw.tagName === "string" ? raw.tagName : void 0,
								frameId
							};
							pickedById.set(requestId, picked);
							uiErrorMessage = null;
							const missing = listMissingRequestIds(requests, pickedById);
							const next = missing.length > 0 ? missing[0] : null;
							_asyncToGenerator(function* () {
								try {
									if (next) yield setActiveRequest(next);
									else {
										yield sendUiUpdate();
										if (!uiAvailable) yield finish({ success: true });
									}
								} catch (_unused4) {}
							})();
							sendResponse === null || sendResponse === void 0 || sendResponse({ success: true });
							return true;
						}
					}
					if (msg.type === BACKGROUND_MESSAGE_TYPES.ELEMENT_PICKER_UI_EVENT) {
						if (msg.event === "cancel") {
							finish({
								success: false,
								cancelled: true
							});
							sendResponse === null || sendResponse === void 0 || sendResponse({ success: true });
							return true;
						}
						if (msg.event === "confirm") {
							const missing = listMissingRequestIds(requests, pickedById);
							if (missing.length > 0) {
								uiErrorMessage = `Please select all elements: missing ${missing.join(", ")}`;
								sendUiUpdate();
								sendResponse === null || sendResponse === void 0 || sendResponse({
									success: false,
									error: "missing_selections",
									missing
								});
								return true;
							}
							finish({ success: true });
							sendResponse === null || sendResponse === void 0 || sendResponse({ success: true });
							return true;
						}
						if (msg.event === "set_active_request") {
							const requestId = toTrimmedString(msg.requestId);
							if (!requestId || !requests.some((r) => r.id === requestId)) {
								sendResponse === null || sendResponse === void 0 || sendResponse({
									success: false,
									error: "Unknown requestId"
								});
								return true;
							}
							setActiveRequest(requestId);
							sendResponse === null || sendResponse === void 0 || sendResponse({ success: true });
							return true;
						}
						if (msg.event === "clear_selection") {
							const requestId = toTrimmedString(msg.requestId);
							if (!requestId || !requests.some((r) => r.id === requestId)) {
								sendResponse === null || sendResponse === void 0 || sendResponse({
									success: false,
									error: "Unknown requestId"
								});
								return true;
							}
							pickedById.delete(requestId);
							uiErrorMessage = null;
							setActiveRequest(requestId);
							sendResponse === null || sendResponse === void 0 || sendResponse({ success: true });
							return true;
						}
					}
				};
				try {
					if (!(yield function() {
						var _ref5 = _asyncToGenerator(function* () {
							const pingWithTimeout = function() {
								var _ref4 = _asyncToGenerator(function* (timeoutMs = 500) {
									try {
										const resp = yield Promise.race([_this.sendMessageToTab(tabId, { action: TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_PING }, 0), new Promise((_, reject) => setTimeout(() => reject(/* @__PURE__ */ new Error("Ping timeout")), timeoutMs))]);
										return (resp === null || resp === void 0 ? void 0 : resp.success) === true;
									} catch (_unused5) {
										return false;
									}
								});
								return function pingWithTimeout() {
									return _ref4.apply(this, arguments);
								};
							}();
							if (yield pingWithTimeout()) return true;
							for (const path of ["content-scripts/element-picker.js", "element-picker.js"]) try {
								yield chrome.scripting.executeScript({
									target: {
										tabId,
										frameIds: [0]
									},
									files: [path],
									injectImmediately: true
								});
								yield new Promise((r) => setTimeout(r, 150));
								if (yield pingWithTimeout(300)) return true;
							} catch (e) {
								console.debug(`[ElementPicker] Path ${path} failed:`, e);
							}
							return pingWithTimeout(1e3);
						});
						return function ensureUiReady() {
							return _ref5.apply(this, arguments);
						};
					}()())) {
						console.error("[ElementPicker] UI not available after all attempts");
						return createErrorResponse(`${ERROR_MESSAGES.TOOL_EXECUTION_FAILED}: Element Picker UI is not available. This may happen if: (1) The page blocks content scripts, (2) You're using dev mode - try restarting the dev server or use production build, (3) The page needs to be refreshed.`);
					}
					try {
						const showResp = yield _this.sendMessageToTab(tabId, {
							action: TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_SHOW,
							sessionId,
							requests,
							activeRequestId,
							deadlineTs
						}, 0);
						if ((showResp === null || showResp === void 0 ? void 0 : showResp.success) !== true) throw new Error("UI did not acknowledge show message");
					} catch (e) {
						console.error("[ElementPicker] UI show failed:", e);
						return createErrorResponse(`${ERROR_MESSAGES.TOOL_EXECUTION_FAILED}: Failed to show Element Picker UI. Please refresh the page and try again.`);
					}
					yield _this.injectPickerScripts(tabId);
					yield _this.callPickerApi(tabId, "startSession", {
						sessionId,
						activeRequestId
					});
					chrome.runtime.onMessage.addListener(onRuntimeMessage);
					const resultPromise = new Promise((resolve) => {
						resolveResult = resolve;
					});
					timer = setTimeout(() => {
						finish({
							success: false,
							timedOut: true
						});
					}, timeoutMs);
					sendUiUpdate();
					const result = yield resultPromise;
					return {
						content: [{
							type: "text",
							text: JSON.stringify(result)
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in element picker tool:", error);
					try {
						yield Promise.allSettled([_this.callPickerApi(tabId, "stopSession", { sessionId }), _this.sendMessageToTab(tabId, {
							action: TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_HIDE,
							sessionId
						}, 0)]);
					} catch (_unused6) {}
					return createErrorResponse(`${ERROR_MESSAGES.TOOL_EXECUTION_FAILED}: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var elementPickerTool = new ElementPickerTool();
	//#endregion
	//#region entrypoints/background/tools/browser/network-request.ts
	init_defineProperty();
	init_asyncToGenerator();
	var DEFAULT_NETWORK_REQUEST_TIMEOUT = 3e4;
	/**
	* NetworkRequestTool - Sends network requests based on provided parameters.
	*/
	var NetworkRequestTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.NETWORK_REQUEST);
		}
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const { url, method = "GET", headers = {}, body, timeout = DEFAULT_NETWORK_REQUEST_TIMEOUT } = args;
				console.log(`NetworkRequestTool: Executing with options:`, args);
				if (!url) return createErrorResponse("URL parameter is required.");
				try {
					var _tabs$;
					const tabs = yield chrome.tabs.query({
						active: true,
						currentWindow: true
					});
					if (!((_tabs$ = tabs[0]) === null || _tabs$ === void 0 ? void 0 : _tabs$.id)) return createErrorResponse("No active tab found or tab has no ID.");
					const activeTabId = tabs[0].id;
					yield _this.injectContentScript(activeTabId, ["inject-scripts/network-helper.js"]);
					console.log(`NetworkRequestTool: Sending to content script: URL=${url}, Method=${method}, Headers=${Object.keys(headers).join(",")}, BodyType=${typeof body}`);
					const resultFromContentScript = yield _this.sendMessageToTab(activeTabId, {
						action: TOOL_MESSAGE_TYPES.NETWORK_SEND_REQUEST,
						url,
						method,
						headers,
						body,
						formData: args.formData || null,
						timeout
					});
					console.log(`NetworkRequestTool: Response from content script:`, resultFromContentScript);
					return {
						content: [{
							type: "text",
							text: JSON.stringify(resultFromContentScript)
						}],
						isError: !(resultFromContentScript === null || resultFromContentScript === void 0 ? void 0 : resultFromContentScript.success)
					};
				} catch (error) {
					console.error("NetworkRequestTool: Error sending network request:", error);
					return createErrorResponse(`Error sending network request: ${error.message || String(error)}`);
				}
			})();
		}
	};
	var networkRequestTool = new NetworkRequestTool();
	//#endregion
	//#region entrypoints/background/tools/browser/network-capture-web-request.ts
	init_defineProperty();
	init_asyncToGenerator();
	var STATIC_RESOURCE_EXTENSIONS = [
		".jpg",
		".jpeg",
		".png",
		".gif",
		".svg",
		".webp",
		".ico",
		".bmp",
		".css",
		".scss",
		".less",
		".js",
		".jsx",
		".ts",
		".tsx",
		".woff",
		".woff2",
		".ttf",
		".eot",
		".otf",
		".mp3",
		".mp4",
		".avi",
		".mov",
		".wmv",
		".flv",
		".ogg",
		".wav",
		".pdf",
		".doc",
		".docx",
		".xls",
		".xlsx",
		".ppt",
		".pptx"
	];
	var AD_ANALYTICS_DOMAINS = NETWORK_FILTERS.EXCLUDED_DOMAINS;
	/**
	* Network Capture Start Tool V2 - Uses Chrome webRequest API to start capturing network requests
	*/
	var NetworkCaptureStartTool = class NetworkCaptureStartTool extends BaseBrowserToolExecutor {
		constructor() {
			super();
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.NETWORK_CAPTURE_START);
			_defineProperty(this, "captureData", /* @__PURE__ */ new Map());
			_defineProperty(this, "captureTimers", /* @__PURE__ */ new Map());
			_defineProperty(this, "inactivityTimers", /* @__PURE__ */ new Map());
			_defineProperty(this, "lastActivityTime", /* @__PURE__ */ new Map());
			_defineProperty(this, "requestCounters", /* @__PURE__ */ new Map());
			_defineProperty(this, "listeners", {});
			if (NetworkCaptureStartTool.instance) return NetworkCaptureStartTool.instance;
			NetworkCaptureStartTool.instance = this;
			chrome.tabs.onRemoved.addListener(this.handleTabRemoved.bind(this));
			chrome.tabs.onCreated.addListener(this.handleTabCreated.bind(this));
		}
		/**
		* Handle tab close events
		*/
		handleTabRemoved(tabId) {
			if (this.captureData.has(tabId)) {
				console.log(`NetworkCaptureV2: Tab ${tabId} was closed, cleaning up resources.`);
				this.cleanupCapture(tabId);
			}
		}
		/**
		* Handle tab creation events
		* If a new tab is opened from a tab being captured, automatically start capturing the new tab's requests
		*/
		handleTabCreated(tab) {
			var _this = this;
			return _asyncToGenerator(function* () {
				try {
					if (_this.captureData.size === 0) return;
					const openerTabId = tab.openerTabId;
					if (!openerTabId) return;
					if (!_this.captureData.has(openerTabId)) return;
					const newTabId = tab.id;
					if (!newTabId) return;
					console.log(`NetworkCaptureV2: New tab ${newTabId} created from capturing tab ${openerTabId}, will extend capture to it.`);
					const openerCaptureInfo = _this.captureData.get(openerTabId);
					if (!openerCaptureInfo) return;
					yield new Promise((resolve) => setTimeout(resolve, 500));
					yield _this.startCaptureForTab(newTabId, {
						maxCaptureTime: openerCaptureInfo.maxCaptureTime,
						inactivityTimeout: openerCaptureInfo.inactivityTimeout,
						includeStatic: openerCaptureInfo.includeStatic
					});
					console.log(`NetworkCaptureV2: Successfully extended capture to new tab ${newTabId}`);
				} catch (error) {
					console.error(`NetworkCaptureV2: Error extending capture to new tab:`, error);
				}
			})();
		}
		/**
		* Determine whether a request should be filtered (based on URL)
		* Uses full URL substring match to support patterns like 'facebook.com/tr'
		*/
		shouldFilterRequest(url, includeStatic) {
			const normalizedUrl = String(url || "").toLowerCase();
			if (!normalizedUrl) return false;
			if (AD_ANALYTICS_DOMAINS.some((pattern) => normalizedUrl.includes(pattern))) return true;
			if (!includeStatic) try {
				const path = new URL(url).pathname.toLowerCase();
				if (STATIC_RESOURCE_EXTENSIONS.some((ext) => path.endsWith(ext))) return true;
			} catch (_unused) {
				return false;
			}
			return false;
		}
		/**
		* Filter based on MIME type
		*/
		shouldFilterByMimeType(mimeType, includeStatic) {
			if (!mimeType) return false;
			if (NetworkCaptureStartTool.API_MIME_TYPES.some((type) => mimeType.startsWith(type))) return false;
			if (!includeStatic) {
				if (NetworkCaptureStartTool.STATIC_MIME_TYPES_TO_FILTER.some((type) => mimeType.startsWith(type))) {
					console.log(`NetworkCaptureV2: Filtering static resource by MIME type: ${mimeType}`);
					return true;
				}
				if (mimeType.startsWith("text/")) {
					console.log(`NetworkCaptureV2: Filtering text response: ${mimeType}`);
					return true;
				}
			}
			return false;
		}
		/**
		* Update last activity time and reset inactivity timer
		*/
		updateLastActivityTime(tabId) {
			const captureInfo = this.captureData.get(tabId);
			if (!captureInfo) return;
			this.lastActivityTime.set(tabId, Date.now());
			if (this.inactivityTimers.has(tabId)) clearTimeout(this.inactivityTimers.get(tabId));
			if (captureInfo.inactivityTimeout > 0) this.inactivityTimers.set(tabId, setTimeout(() => this.checkInactivity(tabId), captureInfo.inactivityTimeout));
		}
		/**
		* Check for inactivity
		*/
		checkInactivity(tabId) {
			const captureInfo = this.captureData.get(tabId);
			if (!captureInfo) return;
			const lastActivity = this.lastActivityTime.get(tabId) || captureInfo.startTime;
			const inactiveTime = Date.now() - lastActivity;
			if (inactiveTime >= captureInfo.inactivityTimeout) {
				console.log(`NetworkCaptureV2: No activity for ${inactiveTime}ms, stopping capture for tab ${tabId}`);
				this.stopCaptureByInactivity(tabId);
			} else {
				const remainingTime = captureInfo.inactivityTimeout - inactiveTime;
				this.inactivityTimers.set(tabId, setTimeout(() => this.checkInactivity(tabId), remainingTime));
			}
		}
		/**
		* Stop capture due to inactivity
		*/
		stopCaptureByInactivity(tabId) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				if (!_this2.captureData.get(tabId)) return;
				console.log(`NetworkCaptureV2: Stopping capture due to inactivity for tab ${tabId}`);
				yield _this2.stopCapture(tabId);
			})();
		}
		/**
		* Clean up capture resources
		*/
		cleanupCapture(tabId) {
			if (this.captureTimers.has(tabId)) {
				clearTimeout(this.captureTimers.get(tabId));
				this.captureTimers.delete(tabId);
			}
			if (this.inactivityTimers.has(tabId)) {
				clearTimeout(this.inactivityTimers.get(tabId));
				this.inactivityTimers.delete(tabId);
			}
			this.lastActivityTime.delete(tabId);
			this.captureData.delete(tabId);
			this.requestCounters.delete(tabId);
			console.log(`NetworkCaptureV2: Cleaned up all resources for tab ${tabId}`);
		}
		/**
		* Set up request listeners (idempotent - won't add duplicate listeners)
		*/
		setupListeners() {
			if (this.listeners.onBeforeRequest) return;
			this.listeners.onBeforeRequest = (details) => {
				const captureInfo = this.captureData.get(details.tabId);
				if (!captureInfo) return;
				if (this.shouldFilterRequest(details.url, captureInfo.includeStatic)) return;
				const currentCount = this.requestCounters.get(details.tabId) || 0;
				if (currentCount >= NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE) {
					console.log(`NetworkCaptureV2: Request limit (${NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE}) reached for tab ${details.tabId}, ignoring new request: ${details.url}`);
					captureInfo.limitReached = true;
					return;
				}
				this.requestCounters.set(details.tabId, currentCount + 1);
				this.updateLastActivityTime(details.tabId);
				if (!captureInfo.requests[details.requestId]) {
					captureInfo.requests[details.requestId] = {
						requestId: details.requestId,
						url: details.url,
						method: details.method,
						type: details.type,
						requestTime: details.timeStamp
					};
					if (details.requestBody) {
						const requestBody = this.processRequestBody(details.requestBody);
						if (requestBody) captureInfo.requests[details.requestId].requestBody = requestBody;
					}
					console.log(`NetworkCaptureV2: Captured request ${currentCount + 1}/${NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE} for tab ${details.tabId}: ${details.method} ${details.url}`);
				}
			};
			this.listeners.onSendHeaders = (details) => {
				const captureInfo = this.captureData.get(details.tabId);
				if (!captureInfo || !captureInfo.requests[details.requestId]) return;
				if (details.requestHeaders) {
					const headers = {};
					details.requestHeaders.forEach((header) => {
						headers[header.name] = header.value || "";
					});
					captureInfo.requests[details.requestId].requestHeaders = headers;
				}
			};
			this.listeners.onHeadersReceived = (details) => {
				var _details$responseHead;
				const captureInfo = this.captureData.get(details.tabId);
				if (!captureInfo || !captureInfo.requests[details.requestId]) return;
				const requestInfo = captureInfo.requests[details.requestId];
				requestInfo.status = details.statusCode;
				requestInfo.statusText = details.statusLine;
				requestInfo.responseTime = details.timeStamp;
				requestInfo.mimeType = (_details$responseHead = details.responseHeaders) === null || _details$responseHead === void 0 || (_details$responseHead = _details$responseHead.find((h) => h.name.toLowerCase() === "content-type")) === null || _details$responseHead === void 0 ? void 0 : _details$responseHead.value;
				if (requestInfo.mimeType && this.shouldFilterByMimeType(requestInfo.mimeType, captureInfo.includeStatic)) {
					delete captureInfo.requests[details.requestId];
					const currentCount = this.requestCounters.get(details.tabId) || 0;
					if (currentCount > 0) this.requestCounters.set(details.tabId, currentCount - 1);
					console.log(`NetworkCaptureV2: Filtered request by MIME type (${requestInfo.mimeType}): ${requestInfo.url}`);
					return;
				}
				if (details.responseHeaders) {
					const headers = {};
					details.responseHeaders.forEach((header) => {
						headers[header.name] = header.value || "";
					});
					requestInfo.responseHeaders = headers;
				}
				this.updateLastActivityTime(details.tabId);
			};
			this.listeners.onCompleted = (details) => {
				const captureInfo = this.captureData.get(details.tabId);
				if (!captureInfo || !captureInfo.requests[details.requestId]) return;
				const requestInfo = captureInfo.requests[details.requestId];
				if ("responseSize" in details) requestInfo.responseSize = details.fromCache ? 0 : details.responseSize;
				this.updateLastActivityTime(details.tabId);
			};
			this.listeners.onErrorOccurred = (details) => {
				const captureInfo = this.captureData.get(details.tabId);
				if (!captureInfo || !captureInfo.requests[details.requestId]) return;
				const requestInfo = captureInfo.requests[details.requestId];
				requestInfo.errorText = details.error;
				this.updateLastActivityTime(details.tabId);
			};
			chrome.webRequest.onBeforeRequest.addListener(this.listeners.onBeforeRequest, { urls: ["<all_urls>"] }, ["requestBody"]);
			chrome.webRequest.onSendHeaders.addListener(this.listeners.onSendHeaders, { urls: ["<all_urls>"] }, ["requestHeaders"]);
			chrome.webRequest.onHeadersReceived.addListener(this.listeners.onHeadersReceived, { urls: ["<all_urls>"] }, ["responseHeaders"]);
			chrome.webRequest.onCompleted.addListener(this.listeners.onCompleted, { urls: ["<all_urls>"] });
			chrome.webRequest.onErrorOccurred.addListener(this.listeners.onErrorOccurred, { urls: ["<all_urls>"] });
		}
		/**
		* Remove all request listeners
		* Only remove listeners when all tab captures have stopped
		*/
		removeListeners() {
			if (this.captureData.size > 0) {
				console.log(`NetworkCaptureV2: Still capturing on ${this.captureData.size} tabs, not removing listeners.`);
				return;
			}
			console.log(`NetworkCaptureV2: No more active captures, removing all listeners.`);
			if (this.listeners.onBeforeRequest) chrome.webRequest.onBeforeRequest.removeListener(this.listeners.onBeforeRequest);
			if (this.listeners.onSendHeaders) chrome.webRequest.onSendHeaders.removeListener(this.listeners.onSendHeaders);
			if (this.listeners.onHeadersReceived) chrome.webRequest.onHeadersReceived.removeListener(this.listeners.onHeadersReceived);
			if (this.listeners.onCompleted) chrome.webRequest.onCompleted.removeListener(this.listeners.onCompleted);
			if (this.listeners.onErrorOccurred) chrome.webRequest.onErrorOccurred.removeListener(this.listeners.onErrorOccurred);
			this.listeners = {};
		}
		/**
		* Process request body data
		*/
		processRequestBody(requestBody) {
			if (requestBody.raw && requestBody.raw.length > 0) return "[Binary data]";
			else if (requestBody.formData) return JSON.stringify(requestBody.formData);
		}
		/**
		* Start network request capture for specified tab
		* @param tabId Tab ID
		* @param options Capture options
		*/
		startCaptureForTab(tabId, options) {
			var _this3 = this;
			return _asyncToGenerator(function* () {
				const { maxCaptureTime, inactivityTimeout, includeStatic } = options;
				if (_this3.captureData.has(tabId)) {
					console.log(`NetworkCaptureV2: Already capturing on tab ${tabId}. Stopping previous session.`);
					yield _this3.stopCapture(tabId);
				}
				try {
					const tab = yield chrome.tabs.get(tabId);
					_this3.captureData.set(tabId, {
						tabId,
						tabUrl: tab.url || "",
						tabTitle: tab.title || "",
						startTime: Date.now(),
						requests: {},
						maxCaptureTime,
						inactivityTimeout,
						includeStatic,
						limitReached: false
					});
					_this3.requestCounters.set(tabId, 0);
					_this3.setupListeners();
					_this3.updateLastActivityTime(tabId);
					console.log(`NetworkCaptureV2: Started capture for tab ${tabId} (${tab.url}). Max requests: ${NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE}, Max time: ${maxCaptureTime}ms, Inactivity: ${inactivityTimeout}ms.`);
					if (maxCaptureTime > 0) _this3.captureTimers.set(tabId, setTimeout(_asyncToGenerator(function* () {
						console.log(`NetworkCaptureV2: Max capture time (${maxCaptureTime}ms) reached for tab ${tabId}.`);
						yield _this3.stopCapture(tabId);
					}), maxCaptureTime));
				} catch (error) {
					console.error(`NetworkCaptureV2: Error starting capture for tab ${tabId}:`, error);
					if (_this3.captureData.has(tabId)) _this3.cleanupCapture(tabId);
					throw error;
				}
			})();
		}
		/**
		* Stop capture
		* @param tabId Tab ID
		*/
		stopCapture(tabId) {
			var _this4 = this;
			return _asyncToGenerator(function* () {
				const captureInfo = _this4.captureData.get(tabId);
				if (!captureInfo) {
					console.log(`NetworkCaptureV2: No capture in progress for tab ${tabId}`);
					return {
						success: false,
						message: `No capture in progress for tab ${tabId}`
					};
				}
				try {
					captureInfo.endTime = Date.now();
					const requestsArray = Object.values(captureInfo.requests);
					const commonRequestHeaders = _this4.analyzeCommonHeaders(requestsArray, "requestHeaders");
					const commonResponseHeaders = _this4.analyzeCommonHeaders(requestsArray, "responseHeaders");
					const processedRequests = requestsArray.map((req) => {
						const finalReq = _objectSpread2({}, req);
						if (finalReq.requestHeaders) {
							finalReq.specificRequestHeaders = _this4.filterOutCommonHeaders(finalReq.requestHeaders, commonRequestHeaders);
							delete finalReq.requestHeaders;
						} else finalReq.specificRequestHeaders = {};
						if (finalReq.responseHeaders) {
							finalReq.specificResponseHeaders = _this4.filterOutCommonHeaders(finalReq.responseHeaders, commonResponseHeaders);
							delete finalReq.responseHeaders;
						} else finalReq.specificResponseHeaders = {};
						return finalReq;
					});
					processedRequests.sort((a, b) => (a.requestTime || 0) - (b.requestTime || 0));
					_this4.removeListeners();
					const resultData = {
						captureStartTime: captureInfo.startTime,
						captureEndTime: captureInfo.endTime,
						totalDurationMs: captureInfo.endTime - captureInfo.startTime,
						settingsUsed: {
							maxCaptureTime: captureInfo.maxCaptureTime,
							inactivityTimeout: captureInfo.inactivityTimeout,
							includeStatic: captureInfo.includeStatic,
							maxRequests: NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE
						},
						commonRequestHeaders,
						commonResponseHeaders,
						requests: processedRequests,
						requestCount: processedRequests.length,
						totalRequestsReceived: _this4.requestCounters.get(tabId) || 0,
						requestLimitReached: captureInfo.limitReached || false,
						tabUrl: captureInfo.tabUrl,
						tabTitle: captureInfo.tabTitle
					};
					_this4.cleanupCapture(tabId);
					return {
						success: true,
						data: resultData
					};
				} catch (error) {
					console.error(`NetworkCaptureV2: Error stopping capture for tab ${tabId}:`, error);
					_this4.cleanupCapture(tabId);
					return {
						success: false,
						message: `Error stopping capture: ${error.message || String(error)}`
					};
				}
			})();
		}
		/**
		* Analyze common request or response headers
		*/
		analyzeCommonHeaders(requests, headerType) {
			if (!requests || requests.length === 0) return {};
			const commonHeaders = {};
			const firstRequestWithHeaders = requests.find((req) => req[headerType] && Object.keys(req[headerType] || {}).length > 0);
			if (!firstRequestWithHeaders || !firstRequestWithHeaders[headerType]) return {};
			const headers = firstRequestWithHeaders[headerType];
			const headerNames = Object.keys(headers);
			for (const name of headerNames) {
				const value = headers[name];
				if (requests.every((req) => {
					const reqHeaders = req[headerType];
					return reqHeaders && reqHeaders[name] === value;
				})) commonHeaders[name] = value;
			}
			return commonHeaders;
		}
		/**
		* Filter out common headers
		*/
		filterOutCommonHeaders(headers, commonHeaders) {
			if (!headers || typeof headers !== "object") return {};
			const specificHeaders = {};
			Object.keys(headers).forEach((name) => {
				if (!(name in commonHeaders) || headers[name] !== commonHeaders[name]) specificHeaders[name] = headers[name];
			});
			return specificHeaders;
		}
		execute(args) {
			var _this5 = this;
			return _asyncToGenerator(function* () {
				const { url: targetUrl, maxCaptureTime = 180 * 1e3, inactivityTimeout = 60 * 1e3, includeStatic = false } = args;
				console.log(`NetworkCaptureStartTool: Executing with args:`, args);
				try {
					let tabToOperateOn;
					if (targetUrl) {
						const matchingTabs = yield chrome.tabs.query({ url: targetUrl });
						if (matchingTabs.length > 0) {
							tabToOperateOn = matchingTabs[0];
							console.log(`NetworkCaptureV2: Found existing tab with URL: ${targetUrl}`);
						} else {
							console.log(`NetworkCaptureV2: Creating new tab with URL: ${targetUrl}`);
							tabToOperateOn = yield chrome.tabs.create({
								url: targetUrl,
								active: true
							});
							yield new Promise((resolve) => setTimeout(resolve, 1e3));
						}
					} else {
						const tabs = yield chrome.tabs.query({
							active: true,
							currentWindow: true
						});
						if (!tabs[0]) return createErrorResponse("No active tab found");
						tabToOperateOn = tabs[0];
					}
					if (!(tabToOperateOn === null || tabToOperateOn === void 0 ? void 0 : tabToOperateOn.id)) return createErrorResponse("Failed to identify or create a tab");
					try {
						yield _this5.startCaptureForTab(tabToOperateOn.id, {
							maxCaptureTime,
							inactivityTimeout,
							includeStatic
						});
					} catch (error) {
						return createErrorResponse(`Failed to start capture for tab ${tabToOperateOn.id}: ${error.message || String(error)}`);
					}
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: "Network capture V2 started successfully, waiting for stop command.",
								tabId: tabToOperateOn.id,
								url: tabToOperateOn.url,
								maxCaptureTime,
								inactivityTimeout,
								includeStatic,
								maxRequests: NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE
							})
						}],
						isError: false
					};
				} catch (error) {
					console.error("NetworkCaptureStartTool: Critical error:", error);
					return createErrorResponse(`Error in NetworkCaptureStartTool: ${error.message || String(error)}`);
				}
			})();
		}
	};
	_defineProperty(NetworkCaptureStartTool, "instance", null);
	_defineProperty(NetworkCaptureStartTool, "MAX_REQUESTS_PER_CAPTURE", LIMITS.MAX_NETWORK_REQUESTS);
	_defineProperty(NetworkCaptureStartTool, "STATIC_MIME_TYPES_TO_FILTER", [
		"image/",
		"font/",
		"audio/",
		"video/",
		"text/css",
		"text/javascript",
		"application/javascript",
		"application/x-javascript",
		"application/pdf",
		"application/zip",
		"application/octet-stream"
	]);
	_defineProperty(NetworkCaptureStartTool, "API_MIME_TYPES", [
		"application/json",
		"application/xml",
		"text/xml",
		"application/x-www-form-urlencoded",
		"application/graphql",
		"application/grpc",
		"application/protobuf",
		"application/x-protobuf",
		"application/x-json",
		"application/ld+json",
		"application/problem+json",
		"application/problem+xml",
		"application/soap+xml",
		"application/vnd.api+json"
	]);
	/**
	* Network capture stop tool V2 - Stop webRequest API capture and return results
	*/
	var NetworkCaptureStopTool = class NetworkCaptureStopTool extends BaseBrowserToolExecutor {
		constructor() {
			super();
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.NETWORK_CAPTURE_STOP);
			if (NetworkCaptureStopTool.instance) return NetworkCaptureStopTool.instance;
			NetworkCaptureStopTool.instance = this;
		}
		execute() {
			return _asyncToGenerator(function* () {
				console.log(`NetworkCaptureStopTool: Executing`);
				try {
					var _activeTabs$, _stopResult$data, _stopResult$data2, _stopResult$data3, _stopResult$data4, _stopResult$data5, _stopResult$data6, _stopResult$data7, _stopResult$data8, _stopResult$data9, _stopResult$data10, _stopResult$data11, _stopResult$data12, _stopResult$data13;
					const startTool = NetworkCaptureStartTool.instance;
					if (!startTool) return createErrorResponse("Network capture V2 start tool instance not found");
					const ongoingCaptures = Array.from(startTool.captureData.keys());
					console.log(`NetworkCaptureStopTool: Found ${ongoingCaptures.length} ongoing captures: ${ongoingCaptures.join(", ")}`);
					if (ongoingCaptures.length === 0) return createErrorResponse("No active network captures found in any tab.");
					const activeTabId = (_activeTabs$ = (yield chrome.tabs.query({
						active: true,
						currentWindow: true
					}))[0]) === null || _activeTabs$ === void 0 ? void 0 : _activeTabs$.id;
					let primaryTabId;
					if (activeTabId && startTool.captureData.has(activeTabId)) {
						primaryTabId = activeTabId;
						console.log(`NetworkCaptureStopTool: Active tab ${activeTabId} is capturing, will stop it first.`);
					} else if (ongoingCaptures.length === 1) {
						primaryTabId = ongoingCaptures[0];
						console.log(`NetworkCaptureStopTool: Only one tab ${primaryTabId} is capturing, stopping it.`);
					} else {
						primaryTabId = ongoingCaptures[0];
						console.log(`NetworkCaptureStopTool: Multiple tabs capturing, active tab not among them. Stopping tab ${primaryTabId} first.`);
					}
					const stopResult = yield startTool.stopCapture(primaryTabId);
					if (!stopResult.success) return createErrorResponse(stopResult.message || `Failed to stop network capture for tab ${primaryTabId}`);
					if (ongoingCaptures.length > 1) {
						const otherTabIds = ongoingCaptures.filter((id) => id !== primaryTabId);
						console.log(`NetworkCaptureStopTool: Stopping ${otherTabIds.length} additional captures: ${otherTabIds.join(", ")}`);
						for (const tabId of otherTabIds) try {
							yield startTool.stopCapture(tabId);
						} catch (error) {
							console.error(`NetworkCaptureStopTool: Error stopping capture on tab ${tabId}:`, error);
						}
					}
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: `Capture complete. ${((_stopResult$data = stopResult.data) === null || _stopResult$data === void 0 ? void 0 : _stopResult$data.requestCount) || 0} requests captured.`,
								tabId: primaryTabId,
								tabUrl: ((_stopResult$data2 = stopResult.data) === null || _stopResult$data2 === void 0 ? void 0 : _stopResult$data2.tabUrl) || "N/A",
								tabTitle: ((_stopResult$data3 = stopResult.data) === null || _stopResult$data3 === void 0 ? void 0 : _stopResult$data3.tabTitle) || "Unknown Tab",
								requestCount: ((_stopResult$data4 = stopResult.data) === null || _stopResult$data4 === void 0 ? void 0 : _stopResult$data4.requestCount) || 0,
								commonRequestHeaders: ((_stopResult$data5 = stopResult.data) === null || _stopResult$data5 === void 0 ? void 0 : _stopResult$data5.commonRequestHeaders) || {},
								commonResponseHeaders: ((_stopResult$data6 = stopResult.data) === null || _stopResult$data6 === void 0 ? void 0 : _stopResult$data6.commonResponseHeaders) || {},
								requests: ((_stopResult$data7 = stopResult.data) === null || _stopResult$data7 === void 0 ? void 0 : _stopResult$data7.requests) || [],
								captureStartTime: (_stopResult$data8 = stopResult.data) === null || _stopResult$data8 === void 0 ? void 0 : _stopResult$data8.captureStartTime,
								captureEndTime: (_stopResult$data9 = stopResult.data) === null || _stopResult$data9 === void 0 ? void 0 : _stopResult$data9.captureEndTime,
								totalDurationMs: (_stopResult$data10 = stopResult.data) === null || _stopResult$data10 === void 0 ? void 0 : _stopResult$data10.totalDurationMs,
								settingsUsed: ((_stopResult$data11 = stopResult.data) === null || _stopResult$data11 === void 0 ? void 0 : _stopResult$data11.settingsUsed) || {},
								totalRequestsReceived: ((_stopResult$data12 = stopResult.data) === null || _stopResult$data12 === void 0 ? void 0 : _stopResult$data12.totalRequestsReceived) || 0,
								requestLimitReached: ((_stopResult$data13 = stopResult.data) === null || _stopResult$data13 === void 0 ? void 0 : _stopResult$data13.requestLimitReached) || false,
								remainingCaptures: Array.from(startTool.captureData.keys())
							})
						}],
						isError: false
					};
				} catch (error) {
					console.error("NetworkCaptureStopTool: Critical error:", error);
					return createErrorResponse(`Error in NetworkCaptureStopTool: ${error.message || String(error)}`);
				}
			})();
		}
	};
	_defineProperty(NetworkCaptureStopTool, "instance", null);
	var networkCaptureStartTool = new NetworkCaptureStartTool();
	var networkCaptureStopTool = new NetworkCaptureStopTool();
	//#endregion
	//#region entrypoints/background/tools/browser/network-capture-debugger.ts
	init_cdp_session_manager();
	init_defineProperty();
	init_asyncToGenerator();
	var MAX_RESPONSE_BODY_SIZE_BYTES = 1 * 1024 * 1024;
	var DEFAULT_MAX_CAPTURE_TIME_MS = 180 * 1e3;
	var DEFAULT_INACTIVITY_TIMEOUT_MS = 60 * 1e3;
	/**
	* Network capture start tool - uses Chrome Debugger API to start capturing network requests
	*/
	var NetworkDebuggerStartTool = class NetworkDebuggerStartTool extends BaseBrowserToolExecutor {
		constructor() {
			super();
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.NETWORK_DEBUGGER_START);
			_defineProperty(this, "captureData", /* @__PURE__ */ new Map());
			_defineProperty(this, "captureTimers", /* @__PURE__ */ new Map());
			_defineProperty(this, "inactivityTimers", /* @__PURE__ */ new Map());
			_defineProperty(this, "lastActivityTime", /* @__PURE__ */ new Map());
			_defineProperty(this, "pendingResponseBodies", /* @__PURE__ */ new Map());
			_defineProperty(this, "requestCounters", /* @__PURE__ */ new Map());
			if (NetworkDebuggerStartTool.instance) return NetworkDebuggerStartTool.instance;
			NetworkDebuggerStartTool.instance = this;
			chrome.debugger.onEvent.addListener(this.handleDebuggerEvent.bind(this));
			chrome.debugger.onDetach.addListener(this.handleDebuggerDetach.bind(this));
			chrome.tabs.onRemoved.addListener(this.handleTabRemoved.bind(this));
			chrome.tabs.onCreated.addListener(this.handleTabCreated.bind(this));
		}
		handleTabRemoved(tabId) {
			if (this.captureData.has(tabId)) {
				console.log(`NetworkDebuggerStartTool: Tab ${tabId} was closed, cleaning up resources.`);
				this.cleanupCapture(tabId);
			}
		}
		/**
		* Handle tab creation events
		* If a new tab is opened from a tab that is currently capturing, automatically start capturing the new tab's requests
		*/
		handleTabCreated(tab) {
			var _this = this;
			return _asyncToGenerator(function* () {
				try {
					if (_this.captureData.size === 0) return;
					const openerTabId = tab.openerTabId;
					if (!openerTabId) return;
					if (!_this.captureData.has(openerTabId)) return;
					const newTabId = tab.id;
					if (!newTabId) return;
					console.log(`NetworkDebuggerStartTool: New tab ${newTabId} created from capturing tab ${openerTabId}, will extend capture to it.`);
					const openerCaptureInfo = _this.captureData.get(openerTabId);
					if (!openerCaptureInfo) return;
					yield new Promise((resolve) => setTimeout(resolve, 500));
					yield _this.startCaptureForTab(newTabId, {
						maxCaptureTime: openerCaptureInfo.maxCaptureTime,
						inactivityTimeout: openerCaptureInfo.inactivityTimeout,
						includeStatic: openerCaptureInfo.includeStatic
					});
					console.log(`NetworkDebuggerStartTool: Successfully extended capture to new tab ${newTabId}`);
				} catch (error) {
					console.error(`NetworkDebuggerStartTool: Error extending capture to new tab:`, error);
				}
			})();
		}
		/**
		* Start network request capture for specified tab
		* @param tabId Tab ID
		* @param options Capture options
		*/
		startCaptureForTab(tabId, options) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				const { maxCaptureTime, inactivityTimeout, includeStatic } = options;
				if (_this2.captureData.has(tabId)) {
					console.log(`NetworkDebuggerStartTool: Already capturing on tab ${tabId}. Stopping previous session.`);
					yield _this2.stopCapture(tabId);
				}
				try {
					const tab = yield chrome.tabs.get(tabId);
					yield cdpSessionManager.attach(tabId, "network-capture");
					try {
						yield cdpSessionManager.sendCommand(tabId, "Network.enable");
					} catch (error) {
						yield cdpSessionManager.detach(tabId, "network-capture").catch((e) => console.warn("Error detaching after failed enable:", e));
						throw error;
					}
					_this2.captureData.set(tabId, {
						startTime: Date.now(),
						tabUrl: tab.url,
						tabTitle: tab.title,
						maxCaptureTime,
						inactivityTimeout,
						includeStatic,
						requests: {},
						limitReached: false
					});
					_this2.requestCounters.set(tabId, 0);
					_this2.updateLastActivityTime(tabId);
					console.log(`NetworkDebuggerStartTool: Started capture for tab ${tabId} (${tab.url}). Max requests: ${NetworkDebuggerStartTool.MAX_REQUESTS_PER_CAPTURE}, Max time: ${maxCaptureTime}ms, Inactivity: ${inactivityTimeout}ms.`);
					if (maxCaptureTime > 0) _this2.captureTimers.set(tabId, setTimeout(_asyncToGenerator(function* () {
						console.log(`NetworkDebuggerStartTool: Max capture time (${maxCaptureTime}ms) reached for tab ${tabId}.`);
						yield _this2.stopCapture(tabId, true);
					}), maxCaptureTime));
				} catch (error) {
					console.error(`NetworkDebuggerStartTool: Error starting capture for tab ${tabId}:`, error);
					if (_this2.captureData.has(tabId)) {
						yield cdpSessionManager.detach(tabId, "network-capture").catch((e) => console.warn("Cleanup detach error:", e));
						_this2.cleanupCapture(tabId);
					}
					throw error;
				}
			})();
		}
		handleDebuggerEvent(source, method, params) {
			if (!source.tabId) return;
			const tabId = source.tabId;
			if (!this.captureData.get(tabId)) return;
			this.updateLastActivityTime(tabId);
			switch (method) {
				case "Network.requestWillBeSent":
					this.handleRequestWillBeSent(tabId, params);
					break;
				case "Network.responseReceived":
					this.handleResponseReceived(tabId, params);
					break;
				case "Network.loadingFinished":
					this.handleLoadingFinished(tabId, params);
					break;
				case "Network.loadingFailed":
					this.handleLoadingFailed(tabId, params);
					break;
			}
		}
		handleDebuggerDetach(source, reason) {
			if (source.tabId && this.captureData.has(source.tabId)) {
				console.log(`NetworkDebuggerStartTool: Debugger detached from tab ${source.tabId}, reason: ${reason}. Cleaning up.`);
				this.cleanupCapture(source.tabId);
			}
		}
		updateLastActivityTime(tabId) {
			this.lastActivityTime.set(tabId, Date.now());
			const captureInfo = this.captureData.get(tabId);
			if (captureInfo && captureInfo.inactivityTimeout > 0) {
				if (this.inactivityTimers.has(tabId)) clearTimeout(this.inactivityTimers.get(tabId));
				this.inactivityTimers.set(tabId, setTimeout(() => this.checkInactivity(tabId), captureInfo.inactivityTimeout));
			}
		}
		checkInactivity(tabId) {
			const captureInfo = this.captureData.get(tabId);
			if (!captureInfo) return;
			const lastActivity = this.lastActivityTime.get(tabId) || captureInfo.startTime;
			const inactiveTime = Date.now() - lastActivity;
			if (inactiveTime >= captureInfo.inactivityTimeout) {
				console.log(`NetworkDebuggerStartTool: No activity for ${inactiveTime}ms (threshold: ${captureInfo.inactivityTimeout}ms), stopping capture for tab ${tabId}`);
				this.stopCaptureByInactivity(tabId);
			} else {
				const remainingTime = Math.max(0, captureInfo.inactivityTimeout - inactiveTime);
				this.inactivityTimers.set(tabId, setTimeout(() => this.checkInactivity(tabId), remainingTime));
			}
		}
		stopCaptureByInactivity(tabId) {
			var _this3 = this;
			return _asyncToGenerator(function* () {
				if (!_this3.captureData.get(tabId)) return;
				console.log(`NetworkDebuggerStartTool: Stopping capture due to inactivity for tab ${tabId}.`);
				yield _this3.stopCapture(tabId, true);
			})();
		}
		/**
		* Check if URL should be filtered based on EXCLUDED_DOMAINS patterns.
		* Uses full URL substring match to support patterns like 'facebook.com/tr'.
		*/
		shouldFilterRequestByUrl(url) {
			const normalizedUrl = String(url || "").toLowerCase();
			if (!normalizedUrl) return false;
			return NETWORK_FILTERS.EXCLUDED_DOMAINS.some((pattern) => normalizedUrl.includes(pattern));
		}
		shouldFilterRequestByExtension(url, includeStatic) {
			if (includeStatic) return false;
			try {
				const path = new URL(url).pathname.toLowerCase();
				return NETWORK_FILTERS.STATIC_RESOURCE_EXTENSIONS.some((ext) => path.endsWith(ext));
			} catch (_unused) {
				return false;
			}
		}
		shouldFilterByMimeType(mimeType, includeStatic) {
			if (!mimeType) return false;
			if (NETWORK_FILTERS.API_MIME_TYPES.some((apiMime) => mimeType.startsWith(apiMime))) return false;
			if (!includeStatic) return NETWORK_FILTERS.STATIC_MIME_TYPES_TO_FILTER.some((staticMime) => mimeType.startsWith(staticMime));
			return false;
		}
		handleRequestWillBeSent(tabId, params) {
			const captureInfo = this.captureData.get(tabId);
			if (!captureInfo) return;
			const { requestId, request, timestamp, type, loaderId, frameId } = params;
			if (this.shouldFilterRequestByUrl(request.url) || this.shouldFilterRequestByExtension(request.url, captureInfo.includeStatic)) return;
			if ((this.requestCounters.get(tabId) || 0) >= NetworkDebuggerStartTool.MAX_REQUESTS_PER_CAPTURE) {
				captureInfo.limitReached = true;
				return;
			}
			if (!captureInfo.requests[requestId]) {
				captureInfo.requests[requestId] = {
					requestId,
					url: request.url,
					method: request.method,
					requestHeaders: request.headers,
					requestTime: timestamp * 1e3,
					type: type || "Other",
					status: "pending",
					loaderId,
					frameId
				};
				if (request.postData) captureInfo.requests[requestId].requestBody = request.postData;
			} else {
				const existingRequest = captureInfo.requests[requestId];
				existingRequest.url = request.url;
				existingRequest.requestTime = timestamp * 1e3;
				if (request.headers) existingRequest.requestHeaders = request.headers;
				if (request.postData) existingRequest.requestBody = request.postData;
				else delete existingRequest.requestBody;
			}
		}
		handleResponseReceived(tabId, params) {
			const captureInfo = this.captureData.get(tabId);
			if (!captureInfo) return;
			const { requestId, response, timestamp, type } = params;
			const requestInfo = captureInfo.requests[requestId];
			if (!requestInfo) return;
			if (this.shouldFilterByMimeType(response.mimeType, captureInfo.includeStatic)) {
				delete captureInfo.requests[requestId];
				return;
			}
			const currentStoredCount = Object.keys(captureInfo.requests).length;
			this.requestCounters.set(tabId, currentStoredCount);
			requestInfo.status = response.status === 0 ? "pending" : "complete";
			requestInfo.statusCode = response.status;
			requestInfo.statusText = response.statusText;
			requestInfo.responseHeaders = response.headers;
			requestInfo.mimeType = response.mimeType;
			requestInfo.responseTime = timestamp * 1e3;
			if (type) requestInfo.type = type;
		}
		handleLoadingFinished(tabId, params) {
			var _this4 = this;
			return _asyncToGenerator(function* () {
				const captureInfo = _this4.captureData.get(tabId);
				if (!captureInfo) return;
				const { requestId, encodedDataLength } = params;
				const requestInfo = captureInfo.requests[requestId];
				if (!requestInfo) return;
				requestInfo.encodedDataLength = encodedDataLength;
				if (requestInfo.status === "pending") requestInfo.status = "complete";
				if (_this4.shouldCaptureResponseBody(requestInfo)) try {
					const responseBodyData = yield _this4.getResponseBody(tabId, requestId);
					if (responseBodyData) {
						if (responseBodyData.body && responseBodyData.body.length > MAX_RESPONSE_BODY_SIZE_BYTES) requestInfo.responseBody = responseBodyData.body.substring(0, MAX_RESPONSE_BODY_SIZE_BYTES) + `\n\n... [Response truncated, total size: ${responseBodyData.body.length} bytes] ...`;
						else requestInfo.responseBody = responseBodyData.body;
						requestInfo.base64Encoded = responseBodyData.base64Encoded;
					}
				} catch (error) {
					requestInfo.errorText = (requestInfo.errorText || "") + ` Failed to get body: ${error instanceof Error ? error.message : String(error)}`;
				}
			})();
		}
		shouldCaptureResponseBody(requestInfo) {
			const mimeType = requestInfo.mimeType || "";
			if (NETWORK_FILTERS.API_MIME_TYPES.some((type) => mimeType.startsWith(type))) return true;
			const url = requestInfo.url.toLowerCase();
			if (/\/(api|service|rest|graphql|query|data|rpc|v[0-9]+)\//i.test(url) || url.includes(".json") || url.includes("json=") || url.includes("format=json")) {
				if (mimeType && NETWORK_FILTERS.STATIC_MIME_TYPES_TO_FILTER.some((staticMime) => mimeType.startsWith(staticMime))) return false;
				return true;
			}
			return false;
		}
		handleLoadingFailed(tabId, params) {
			const captureInfo = this.captureData.get(tabId);
			if (!captureInfo) return;
			const { requestId, errorText, canceled, type } = params;
			const requestInfo = captureInfo.requests[requestId];
			if (!requestInfo) return;
			requestInfo.status = "error";
			requestInfo.errorText = errorText;
			requestInfo.canceled = canceled;
			if (type) requestInfo.type = type;
		}
		getResponseBody(tabId, requestId) {
			var _this5 = this;
			return _asyncToGenerator(function* () {
				const pendingKey = `${tabId}_${requestId}`;
				if (_this5.pendingResponseBodies.has(pendingKey)) return _this5.pendingResponseBodies.get(pendingKey);
				const responseBodyPromise = _asyncToGenerator(function* () {
					try {
						return yield cdpSessionManager.sendCommand(tabId, "Network.getResponseBody", { requestId });
					} finally {
						_this5.pendingResponseBodies.delete(pendingKey);
					}
				})();
				_this5.pendingResponseBodies.set(pendingKey, responseBodyPromise);
				return responseBodyPromise;
			})();
		}
		cleanupCapture(tabId) {
			if (this.captureTimers.has(tabId)) {
				clearTimeout(this.captureTimers.get(tabId));
				this.captureTimers.delete(tabId);
			}
			if (this.inactivityTimers.has(tabId)) {
				clearTimeout(this.inactivityTimers.get(tabId));
				this.inactivityTimers.delete(tabId);
			}
			this.lastActivityTime.delete(tabId);
			this.captureData.delete(tabId);
			this.requestCounters.delete(tabId);
			const keysToDelete = [];
			this.pendingResponseBodies.forEach((_, key) => {
				if (key.startsWith(`${tabId}_`)) keysToDelete.push(key);
			});
			keysToDelete.forEach((key) => this.pendingResponseBodies.delete(key));
			console.log(`NetworkDebuggerStartTool: Cleaned up resources for tab ${tabId}.`);
		}
		stopCapture(tabId, isAutoStop = false) {
			var _this6 = this;
			return _asyncToGenerator(function* () {
				const captureInfo = _this6.captureData.get(tabId);
				if (!captureInfo) return {
					success: false,
					message: "No capture in progress for this tab."
				};
				console.log(`NetworkDebuggerStartTool: Stopping capture for tab ${tabId}. Auto-stop: ${isAutoStop}`);
				try {
					try {
						yield cdpSessionManager.sendCommand(tabId, "Network.disable");
					} catch (e) {
						console.warn(`NetworkDebuggerStartTool: Error disabling network for tab ${tabId} (possibly already detached):`, e);
					}
					try {
						yield cdpSessionManager.detach(tabId, "network-capture");
					} catch (e) {
						console.warn(`NetworkDebuggerStartTool: Error detaching debugger for tab ${tabId} (possibly already detached):`, e);
					}
				} catch (error) {
					console.error("NetworkDebuggerStartTool: Error during debugger interaction in stopCapture:", error);
				}
				const allRequests = Object.values(captureInfo.requests);
				const commonRequestHeaders = _this6.analyzeCommonHeaders(allRequests, "requestHeaders");
				const commonResponseHeaders = _this6.analyzeCommonHeaders(allRequests, "responseHeaders");
				const processedRequests = allRequests.map((req) => {
					const finalReq = _objectSpread2({}, req);
					if (finalReq.requestHeaders) {
						finalReq.specificRequestHeaders = _this6.filterOutCommonHeaders(finalReq.requestHeaders, commonRequestHeaders);
						delete finalReq.requestHeaders;
					} else finalReq.specificRequestHeaders = {};
					if (finalReq.responseHeaders) {
						finalReq.specificResponseHeaders = _this6.filterOutCommonHeaders(finalReq.responseHeaders, commonResponseHeaders);
						delete finalReq.responseHeaders;
					} else finalReq.specificResponseHeaders = {};
					return finalReq;
				});
				processedRequests.sort((a, b) => (a.requestTime || 0) - (b.requestTime || 0));
				const resultData = {
					captureStartTime: captureInfo.startTime,
					captureEndTime: Date.now(),
					totalDurationMs: Date.now() - captureInfo.startTime,
					commonRequestHeaders,
					commonResponseHeaders,
					requests: processedRequests,
					requestCount: processedRequests.length,
					totalRequestsReceivedBeforeLimit: captureInfo.limitReached ? NetworkDebuggerStartTool.MAX_REQUESTS_PER_CAPTURE : processedRequests.length,
					requestLimitReached: !!captureInfo.limitReached,
					stoppedBy: isAutoStop ? _this6.lastActivityTime.get(tabId) ? "inactivity_timeout" : "max_capture_time" : "user_request",
					tabUrl: captureInfo.tabUrl,
					tabTitle: captureInfo.tabTitle
				};
				console.log(`NetworkDebuggerStartTool: Capture stopped for tab ${tabId}. ${resultData.requestCount} requests processed. Limit reached: ${resultData.requestLimitReached}. Stopped by: ${resultData.stoppedBy}`);
				_this6.cleanupCapture(tabId);
				return {
					success: true,
					message: `Capture stopped. ${resultData.requestCount} requests.`,
					data: resultData
				};
			})();
		}
		analyzeCommonHeaders(requests, headerTypeKey) {
			if (!requests || requests.length === 0) return {};
			const headerValueCounts = /* @__PURE__ */ new Map();
			let requestsWithHeadersCount = 0;
			for (const req of requests) {
				const headers = req[headerTypeKey];
				if (headers && Object.keys(headers).length > 0) {
					requestsWithHeadersCount++;
					for (const name in headers) {
						const lowerName = name.toLowerCase();
						const value = headers[name];
						if (!headerValueCounts.has(lowerName)) headerValueCounts.set(lowerName, /* @__PURE__ */ new Map());
						const values = headerValueCounts.get(lowerName);
						values.set(value, (values.get(value) || 0) + 1);
					}
				}
			}
			if (requestsWithHeadersCount === 0) return {};
			const commonHeaders = {};
			headerValueCounts.forEach((values, name) => {
				values.forEach((count, value) => {
					if (count === requestsWithHeadersCount) {
						let originalName = name;
						for (const req of requests) {
							const hdrs = req[headerTypeKey];
							if (hdrs) {
								const foundName = Object.keys(hdrs).find((k) => k.toLowerCase() === name);
								if (foundName) {
									originalName = foundName;
									break;
								}
							}
						}
						commonHeaders[originalName] = value;
					}
				});
			});
			return commonHeaders;
		}
		filterOutCommonHeaders(headers, commonHeaders) {
			if (!headers || typeof headers !== "object") return {};
			const specificHeaders = {};
			const commonHeadersLower = {};
			Object.keys(commonHeaders).forEach((commonName) => {
				commonHeadersLower[commonName.toLowerCase()] = commonHeaders[commonName];
			});
			Object.keys(headers).forEach((name) => {
				const lowerName = name.toLowerCase();
				if (!(lowerName in commonHeadersLower) || headers[name] !== commonHeadersLower[lowerName]) specificHeaders[name] = headers[name];
			});
			return specificHeaders;
		}
		execute(args) {
			var _this7 = this;
			return _asyncToGenerator(function* () {
				const { url: targetUrl, maxCaptureTime = DEFAULT_MAX_CAPTURE_TIME_MS, inactivityTimeout = DEFAULT_INACTIVITY_TIMEOUT_MS, includeStatic = false } = args;
				console.log(`NetworkDebuggerStartTool: Executing with args: url=${targetUrl}, maxTime=${maxCaptureTime}, inactivityTime=${inactivityTimeout}, includeStatic=${includeStatic}`);
				let tabToOperateOn;
				try {
					if (targetUrl) {
						var _existingTabs$;
						const existingTabs = yield chrome.tabs.query({ url: targetUrl.startsWith("http") ? targetUrl : `*://*/*${targetUrl}*` });
						if (existingTabs.length > 0 && ((_existingTabs$ = existingTabs[0]) === null || _existingTabs$ === void 0 ? void 0 : _existingTabs$.id)) {
							tabToOperateOn = existingTabs[0];
							yield chrome.windows.update(tabToOperateOn.windowId, { focused: true });
							yield chrome.tabs.update(tabToOperateOn.id, { active: true });
						} else {
							tabToOperateOn = yield chrome.tabs.create({
								url: targetUrl,
								active: true
							});
							yield new Promise((resolve) => setTimeout(resolve, 500));
						}
					} else {
						var _activeTabs$;
						const activeTabs = yield chrome.tabs.query({
							active: true,
							currentWindow: true
						});
						if (activeTabs.length > 0 && ((_activeTabs$ = activeTabs[0]) === null || _activeTabs$ === void 0 ? void 0 : _activeTabs$.id)) tabToOperateOn = activeTabs[0];
						else return createErrorResponse("No active tab found and no URL provided.");
					}
					if (!(tabToOperateOn === null || tabToOperateOn === void 0 ? void 0 : tabToOperateOn.id)) return createErrorResponse("Failed to identify or create a target tab.");
					const tabId = tabToOperateOn.id;
					try {
						yield _this7.startCaptureForTab(tabId, {
							maxCaptureTime,
							inactivityTimeout,
							includeStatic
						});
					} catch (error) {
						return createErrorResponse(`Failed to start capture for tab ${tabId}: ${error.message || String(error)}`);
					}
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: `Network capture started on tab ${tabId}. Waiting for stop command or timeout.`,
								tabId,
								url: tabToOperateOn.url,
								maxCaptureTime,
								inactivityTimeout,
								includeStatic,
								maxRequests: NetworkDebuggerStartTool.MAX_REQUESTS_PER_CAPTURE
							})
						}],
						isError: false
					};
				} catch (error) {
					console.error("NetworkDebuggerStartTool: Critical error during execute:", error);
					const tabIdToClean = tabToOperateOn === null || tabToOperateOn === void 0 ? void 0 : tabToOperateOn.id;
					if (tabIdToClean && _this7.captureData.has(tabIdToClean)) {
						yield cdpSessionManager.detach(tabIdToClean, "network-capture").catch((e) => console.warn("Cleanup detach error:", e));
						_this7.cleanupCapture(tabIdToClean);
					}
					return createErrorResponse(`Error in NetworkDebuggerStartTool: ${error.message || String(error)}`);
				}
			})();
		}
	};
	_defineProperty(NetworkDebuggerStartTool, "MAX_REQUESTS_PER_CAPTURE", 100);
	_defineProperty(NetworkDebuggerStartTool, "instance", null);
	/**
	* Network capture stop tool - stops capture and returns results for the active tab
	*/
	var NetworkDebuggerStopTool = class NetworkDebuggerStopTool extends BaseBrowserToolExecutor {
		constructor() {
			super();
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.NETWORK_DEBUGGER_STOP);
			if (NetworkDebuggerStopTool.instance) return NetworkDebuggerStopTool.instance;
			NetworkDebuggerStopTool.instance = this;
		}
		execute() {
			var _this8 = this;
			return _asyncToGenerator(function* () {
				var _activeTabs$2;
				console.log(`NetworkDebuggerStopTool: Executing command.`);
				const startTool = NetworkDebuggerStartTool.instance;
				if (!startTool) return createErrorResponse("NetworkDebuggerStartTool instance not available. Cannot stop capture.");
				const ongoingCaptures = Array.from(startTool["captureData"].keys());
				console.log(`NetworkDebuggerStopTool: Found ${ongoingCaptures.length} ongoing captures: ${ongoingCaptures.join(", ")}`);
				if (ongoingCaptures.length === 0) return createErrorResponse("No active network captures found in any tab.");
				const activeTabId = (_activeTabs$2 = (yield chrome.tabs.query({
					active: true,
					currentWindow: true
				}))[0]) === null || _activeTabs$2 === void 0 ? void 0 : _activeTabs$2.id;
				let primaryTabId;
				if (activeTabId && startTool["captureData"].has(activeTabId)) {
					primaryTabId = activeTabId;
					console.log(`NetworkDebuggerStopTool: Active tab ${activeTabId} is capturing, will stop it first.`);
				} else if (ongoingCaptures.length === 1) {
					primaryTabId = ongoingCaptures[0];
					console.log(`NetworkDebuggerStopTool: Only one tab ${primaryTabId} is capturing, stopping it.`);
				} else {
					primaryTabId = ongoingCaptures[0];
					console.log(`NetworkDebuggerStopTool: Multiple tabs capturing, active tab not among them. Stopping tab ${primaryTabId} first.`);
				}
				const result = yield _this8.performStop(startTool, primaryTabId);
				if (ongoingCaptures.length > 1) {
					const otherTabIds = ongoingCaptures.filter((id) => id !== primaryTabId);
					console.log(`NetworkDebuggerStopTool: Stopping ${otherTabIds.length} additional captures: ${otherTabIds.join(", ")}`);
					for (const tabId of otherTabIds) try {
						yield startTool.stopCapture(tabId);
					} catch (error) {
						console.error(`NetworkDebuggerStopTool: Error stopping capture on tab ${tabId}:`, error);
					}
				}
				return result;
			})();
		}
		performStop(startTool, tabId) {
			return _asyncToGenerator(function* () {
				console.log(`NetworkDebuggerStopTool: Attempting to stop capture for tab ${tabId}.`);
				const stopResult = yield startTool.stopCapture(tabId);
				if (!(stopResult === null || stopResult === void 0 ? void 0 : stopResult.success)) return createErrorResponse((stopResult === null || stopResult === void 0 ? void 0 : stopResult.message) || `Failed to stop network capture for tab ${tabId}. It might not have been capturing.`);
				const resultData = stopResult.data || {};
				const remainingCaptures = Array.from(startTool["captureData"].keys());
				if (resultData.requests && Array.isArray(resultData.requests)) resultData.requests.sort((a, b) => (a.requestTime || 0) - (b.requestTime || 0));
				return {
					content: [{
						type: "text",
						text: JSON.stringify({
							success: true,
							message: `Capture for tab ${tabId} (${resultData.tabUrl || "N/A"}) stopped. ${resultData.requestCount || 0} requests captured.`,
							tabId,
							tabUrl: resultData.tabUrl || "N/A",
							tabTitle: resultData.tabTitle || "Unknown Tab",
							requestCount: resultData.requestCount || 0,
							commonRequestHeaders: resultData.commonRequestHeaders || {},
							commonResponseHeaders: resultData.commonResponseHeaders || {},
							requests: resultData.requests || [],
							captureStartTime: resultData.captureStartTime,
							captureEndTime: resultData.captureEndTime,
							totalDurationMs: resultData.totalDurationMs,
							settingsUsed: resultData.settingsUsed || {},
							remainingCaptures,
							totalRequestsReceived: resultData.totalRequestsReceived || resultData.requestCount || 0,
							requestLimitReached: resultData.requestLimitReached || false
						})
					}],
					isError: false
				};
			})();
		}
	};
	_defineProperty(NetworkDebuggerStopTool, "instance", null);
	var networkDebuggerStartTool = new NetworkDebuggerStartTool();
	var networkDebuggerStopTool = new NetworkDebuggerStopTool();
	//#endregion
	//#region entrypoints/background/tools/browser/network-capture.ts
	init_defineProperty();
	init_asyncToGenerator();
	/**
	* Extract text content from ToolResult
	*/
	function getFirstText(result) {
		var _result$content;
		const first = (_result$content = result.content) === null || _result$content === void 0 ? void 0 : _result$content[0];
		return first && first.type === "text" ? first.text : void 0;
	}
	/**
	* Decorate JSON result with additional fields
	*/
	function decorateJsonResult(result, extra) {
		const text = getFirstText(result);
		if (typeof text !== "string") return result;
		try {
			const parsed = JSON.parse(text);
			if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return _objectSpread2(_objectSpread2({}, result), {}, { content: [{
				type: "text",
				text: JSON.stringify(_objectSpread2(_objectSpread2({}, parsed), extra))
			}] });
		} catch (_unused) {}
		return result;
	}
	/**
	* Check if debugger-based capture is active
	*/
	function isDebuggerCaptureActive() {
		const captureData = networkDebuggerStartTool.captureData;
		return captureData instanceof Map && captureData.size > 0;
	}
	/**
	* Check if webRequest-based capture is active
	*/
	function isWebRequestCaptureActive() {
		return networkCaptureStartTool.captureData.size > 0;
	}
	/**
	* Unified Network Capture Tool
	*
	* Provides a single entry point for network capture, automatically selecting
	* the appropriate backend based on the `needResponseBody` parameter:
	* - needResponseBody=false (default): uses webRequest API (lightweight, no debugger conflict)
	* - needResponseBody=true: uses Debugger API (captures response body, may conflict with DevTools)
	*/
	var NetworkCaptureTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.NETWORK_CAPTURE);
		}
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const action = args === null || args === void 0 ? void 0 : args.action;
				if (action !== "start" && action !== "stop") return createErrorResponse("Parameter [action] is required and must be one of: start, stop");
				const wantBody = (args === null || args === void 0 ? void 0 : args.needResponseBody) === true;
				const debuggerActive = isDebuggerCaptureActive();
				const webActive = isWebRequestCaptureActive();
				if (action === "start") return _this.handleStart(args, wantBody, debuggerActive, webActive);
				return _this.handleStop(args, debuggerActive, webActive);
			})();
		}
		handleStart(args, wantBody, debuggerActive, webActive) {
			return _asyncToGenerator(function* () {
				if (debuggerActive || webActive) return createErrorResponse(`Network capture is already active in ${debuggerActive ? "debugger" : "webRequest"} mode. Stop it before starting a new capture.`);
				const delegate = wantBody ? networkDebuggerStartTool : networkCaptureStartTool;
				const backend = wantBody ? "debugger" : "webRequest";
				return decorateJsonResult(yield delegate.execute({
					url: args.url,
					maxCaptureTime: args.maxCaptureTime,
					inactivityTimeout: args.inactivityTimeout,
					includeStatic: args.includeStatic
				}), {
					backend,
					needResponseBody: wantBody
				});
			})();
		}
		handleStop(args, debuggerActive, webActive) {
			return _asyncToGenerator(function* () {
				let backendToStop = null;
				if ((args === null || args === void 0 ? void 0 : args.needResponseBody) === true) backendToStop = debuggerActive ? "debugger" : null;
				else if ((args === null || args === void 0 ? void 0 : args.needResponseBody) === false) backendToStop = webActive ? "webRequest" : null;
				if (!backendToStop) {
					if (debuggerActive) backendToStop = "debugger";
					else if (webActive) backendToStop = "webRequest";
				}
				if (!backendToStop) return createErrorResponse("No active network captures found in any tab.");
				return decorateJsonResult(yield (backendToStop === "debugger" ? networkDebuggerStopTool : networkCaptureStopTool).execute(), {
					backend: backendToStop,
					needResponseBody: backendToStop === "debugger"
				});
			})();
		}
	};
	var networkCaptureTool = new NetworkCaptureTool();
	//#endregion
	//#region entrypoints/background/tools/browser/keyboard.ts
	init_defineProperty();
	init_asyncToGenerator();
	/**
	* Tool for simulating keyboard input on web pages
	*/
	var KeyboardTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.KEYBOARD);
		}
		/**
		* Execute keyboard operation
		*/
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const { keys, selector, selectorType = "css", delay = TIMEOUTS.KEYBOARD_DELAY } = args;
				console.log(`Starting keyboard operation with options:`, args);
				if (!keys) return createErrorResponse(ERROR_MESSAGES.INVALID_PARAMETERS + ": Keys parameter must be provided");
				try {
					const tab = (yield _this.tryGetTab(args.tabId)) || (yield _this.getActiveTabOrThrowInWindow(args.windowId));
					if (!tab.id) return createErrorResponse(ERROR_MESSAGES.TAB_NOT_FOUND + ": Active tab has no ID");
					let finalSelector = selector;
					let refForFocus = void 0;
					yield _this.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
					if (selector && selectorType === "xpath") try {
						const ensured = yield _this.sendMessageToTab(tab.id, {
							action: TOOL_MESSAGE_TYPES.ENSURE_REF_FOR_SELECTOR,
							selector,
							isXPath: true
						});
						if (!ensured || !ensured.success || !ensured.ref) return createErrorResponse(`Failed to resolve XPath selector: ${(ensured === null || ensured === void 0 ? void 0 : ensured.error) || "unknown error"}`);
						refForFocus = ensured.ref;
						const resolved = yield _this.sendMessageToTab(tab.id, {
							action: TOOL_MESSAGE_TYPES.RESOLVE_REF,
							ref: ensured.ref
						});
						if (resolved && resolved.success && resolved.selector) {
							finalSelector = resolved.selector;
							refForFocus = void 0;
						}
					} catch (error) {
						return createErrorResponse(`Error resolving XPath: ${error instanceof Error ? error.message : String(error)}`);
					}
					if (refForFocus) {
						const focusResult = yield _this.sendMessageToTab(tab.id, {
							action: "focusByRef",
							ref: refForFocus
						});
						if (focusResult && !focusResult.success) return createErrorResponse(`Failed to focus element by ref: ${focusResult.error || "unknown error"}`);
						finalSelector = void 0;
					}
					const frameIds = typeof args.frameId === "number" ? [args.frameId] : void 0;
					yield _this.injectContentScript(tab.id, ["inject-scripts/keyboard-helper.js"], false, "ISOLATED", false, frameIds);
					const result = yield _this.sendMessageToTab(tab.id, {
						action: TOOL_MESSAGE_TYPES.SIMULATE_KEYBOARD,
						keys,
						selector: finalSelector,
						delay
					}, args.frameId);
					if (result.error) return createErrorResponse(result.error);
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: result.message || "Keyboard operation successful",
								targetElement: result.targetElement,
								results: result.results
							})
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in keyboard operation:", error);
					return createErrorResponse(`Error simulating keyboard events: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var keyboardTool = new KeyboardTool();
	//#endregion
	//#region node_modules/date-fns/constants.js
	/**
	* @constant
	* @name daysInYear
	* @summary Days in 1 year.
	*
	* @description
	* How many days in a year.
	*
	* One years equals 365.2425 days according to the formula:
	*
	* > Leap year occurs every 4 years, except for years that are divisible by 100 and not divisible by 400.
	* > 1 mean year = (365+1/4-1/100+1/400) days = 365.2425 days
	*/
	var daysInYear = 365.2425;
	-(Math.pow(10, 8) * 24 * 60 * 60 * 1e3);
	/**
	* @constant
	* @name millisecondsInWeek
	* @summary Milliseconds in 1 week.
	*/
	var millisecondsInWeek = 6048e5;
	/**
	* @constant
	* @name millisecondsInDay
	* @summary Milliseconds in 1 day.
	*/
	var millisecondsInDay = 864e5;
	/**
	* @constant
	* @name millisecondsInMinute
	* @summary Milliseconds in 1 minute
	*/
	var millisecondsInMinute = 6e4;
	/**
	* @constant
	* @name millisecondsInHour
	* @summary Milliseconds in 1 hour
	*/
	var millisecondsInHour = 36e5;
	/**
	* @constant
	* @name secondsInDay
	* @summary Seconds in 1 day.
	*/
	var secondsInDay = 3600 * 24;
	secondsInDay * 7;
	secondsInDay * daysInYear / 12 * 3;
	/**
	* @constant
	* @name constructFromSymbol
	* @summary Symbol enabling Date extensions to inherit properties from the reference date.
	*
	* The symbol is used to enable the `constructFrom` function to construct a date
	* using a reference date and a value. It allows to transfer extra properties
	* from the reference date to the new date. It's useful for extensions like
	* [`TZDate`](https://github.com/date-fns/tz) that accept a time zone as
	* a constructor argument.
	*/
	var constructFromSymbol = Symbol.for("constructDateFrom");
	//#endregion
	//#region node_modules/date-fns/constructFrom.js
	/**
	* @name constructFrom
	* @category Generic Helpers
	* @summary Constructs a date using the reference date and the value
	*
	* @description
	* The function constructs a new date using the constructor from the reference
	* date and the given value. It helps to build generic functions that accept
	* date extensions.
	*
	* It defaults to `Date` if the passed reference date is a number or a string.
	*
	* Starting from v3.7.0, it allows to construct a date using `[Symbol.for("constructDateFrom")]`
	* enabling to transfer extra properties from the reference date to the new date.
	* It's useful for extensions like [`TZDate`](https://github.com/date-fns/tz)
	* that accept a time zone as a constructor argument.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	*
	* @param date - The reference date to take constructor from
	* @param value - The value to create the date
	*
	* @returns Date initialized using the given date and value
	*
	* @example
	* import { constructFrom } from "./constructFrom/date-fns";
	*
	* // A function that clones a date preserving the original type
	* function cloneDate<DateType extends Date>(date: DateType): DateType {
	*   return constructFrom(
	*     date, // Use constructor from the given date
	*     date.getTime() // Use the date value to create a new date
	*   );
	* }
	*/
	function constructFrom(date, value) {
		if (typeof date === "function") return date(value);
		if (date && typeof date === "object" && constructFromSymbol in date) return date[constructFromSymbol](value);
		if (date instanceof Date) return new date.constructor(value);
		return new Date(value);
	}
	//#endregion
	//#region node_modules/date-fns/toDate.js
	/**
	* @name toDate
	* @category Common Helpers
	* @summary Convert the given argument to an instance of Date.
	*
	* @description
	* Convert the given argument to an instance of Date.
	*
	* If the argument is an instance of Date, the function returns its clone.
	*
	* If the argument is a number, it is treated as a timestamp.
	*
	* If the argument is none of the above, the function returns Invalid Date.
	*
	* Starting from v3.7.0, it clones a date using `[Symbol.for("constructDateFrom")]`
	* enabling to transfer extra properties from the reference date to the new date.
	* It's useful for extensions like [`TZDate`](https://github.com/date-fns/tz)
	* that accept a time zone as a constructor argument.
	*
	* **Note**: *all* Date arguments passed to any *date-fns* function is processed by `toDate`.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param argument - The value to convert
	*
	* @returns The parsed date in the local time zone
	*
	* @example
	* // Clone the date:
	* const result = toDate(new Date(2014, 1, 11, 11, 30, 30))
	* //=> Tue Feb 11 2014 11:30:30
	*
	* @example
	* // Convert the timestamp to date:
	* const result = toDate(1392098430000)
	* //=> Tue Feb 11 2014 11:30:30
	*/
	function toDate(argument, context) {
		return constructFrom(context || argument, argument);
	}
	//#endregion
	//#region node_modules/date-fns/addDays.js
	/**
	* The {@link addDays} function options.
	*/
	/**
	* @name addDays
	* @category Day Helpers
	* @summary Add the specified number of days to the given date.
	*
	* @description
	* Add the specified number of days to the given date.
	*
	* **You don't need date-fns\***:
	*
	* Temporal has a built-in `add` method on all its classes:
	*
	* - [`Temporal.Instant.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/Instant/add)
	* - [`Temporal.PlainDate.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/PlainDate/add)
	* - [`Temporal.PlainDateTime.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/PlainDateTime/add)
	* - [`Temporal.PlainTime.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/PlainTime/add)
	* - [`Temporal.PlainYearMonth.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/PlainYearMonth/add)
	* - [`Temporal.ZonedDateTime.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/ZonedDateTime/add)
	*
	* \* **Not really**, see: https://date-fns.org/you-dont-need-date-fns
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The date to be changed
	* @param amount - The amount of days to be added.
	* @param options - An object with options
	*
	* @returns The new date with the days added
	*
	* @example
	* // Add 10 days to 1 September 2014:
	* const result = addDays(new Date(2014, 8, 1), 10)
	* //=> Thu Sep 11 2014 00:00:00
	*
	* @example
	* // Using Temporal:
	* // Add 10 days to 1 September 2014:
	* Temporal.PlainDate.from("2014-09-01").add({ days: 10 }).toString();
	* //=> "2014-09-11"
	*/
	function addDays(date, amount, options) {
		const _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
		if (isNaN(amount)) return constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, NaN);
		if (!amount) return _date;
		_date.setDate(_date.getDate() + amount);
		return _date;
	}
	//#endregion
	//#region node_modules/date-fns/addMonths.js
	/**
	* The {@link addMonths} function options.
	*/
	/**
	* @name addMonths
	* @category Month Helpers
	* @summary Add the specified number of months to the given date.
	*
	* @description
	* Add the specified number of months to the given date.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The date to be changed
	* @param amount - The amount of months to be added.
	* @param options - The options object
	*
	* @returns The new date with the months added
	*
	* @example
	* // Add 5 months to 1 September 2014:
	* const result = addMonths(new Date(2014, 8, 1), 5)
	* //=> Sun Feb 01 2015 00:00:00
	*
	* // Add one month to 30 January 2023:
	* const result = addMonths(new Date(2023, 0, 30), 1)
	* //=> Tue Feb 28 2023 00:00:00
	*/
	function addMonths(date, amount, options) {
		const _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
		if (isNaN(amount)) return constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, NaN);
		if (!amount) return _date;
		const dayOfMonth = _date.getDate();
		const endOfDesiredMonth = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, _date.getTime());
		endOfDesiredMonth.setMonth(_date.getMonth() + amount + 1, 0);
		if (dayOfMonth >= endOfDesiredMonth.getDate()) return endOfDesiredMonth;
		else {
			_date.setFullYear(endOfDesiredMonth.getFullYear(), endOfDesiredMonth.getMonth(), dayOfMonth);
			return _date;
		}
	}
	//#endregion
	//#region node_modules/date-fns/addWeeks.js
	/**
	* The {@link addWeeks} function options.
	*/
	/**
	* @name addWeeks
	* @category Week Helpers
	* @summary Add the specified number of weeks to the given date.
	*
	* @description
	* Add the specified number of weeks to the given date.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The date to be changed
	* @param amount - The amount of weeks to be added.
	* @param options - An object with options
	*
	* @returns The new date with the weeks added
	*
	* @example
	* // Add 4 weeks to 1 September 2014:
	* const result = addWeeks(new Date(2014, 8, 1), 4)
	* //=> Mon Sep 29 2014 00:00:00
	*/
	function addWeeks(date, amount, options) {
		return addDays(date, amount * 7, options);
	}
	//#endregion
	//#region node_modules/date-fns/addYears.js
	/**
	* The {@link addYears} function options.
	*/
	/**
	* @name addYears
	* @category Year Helpers
	* @summary Add the specified number of years to the given date.
	*
	* @description
	* Add the specified number of years to the given date.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type.
	*
	* @param date - The date to be changed
	* @param amount - The amount of years to be added.
	* @param options - The options
	*
	* @returns The new date with the years added
	*
	* @example
	* // Add 5 years to 1 September 2014:
	* const result = addYears(new Date(2014, 8, 1), 5)
	* //=> Sun Sep 01 2019 00:00:00
	*/
	function addYears(date, amount, options) {
		return addMonths(date, amount * 12, options);
	}
	//#endregion
	//#region node_modules/date-fns/constructNow.js
	/**
	* @name constructNow
	* @category Generic Helpers
	* @summary Constructs a new current date using the passed value constructor.
	* @pure false
	*
	* @description
	* The function constructs a new current date using the constructor from
	* the reference date. It helps to build generic functions that accept date
	* extensions and use the current date.
	*
	* It defaults to `Date` if the passed reference date is a number or a string.
	*
	* @param date - The reference date to take constructor from
	*
	* @returns Current date initialized using the given date constructor
	*
	* @example
	* import { constructNow, isSameDay } from 'date-fns'
	*
	* function isToday<DateType extends Date>(
	*   date: DateArg<DateType>,
	* ): boolean {
	*   // If we were to use `new Date()` directly, the function would  behave
	*   // differently in different timezones and return false for the same date.
	*   return isSameDay(date, constructNow(date));
	* }
	*/
	function constructNow(date) {
		return constructFrom(date, Date.now());
	}
	//#endregion
	//#region node_modules/date-fns/_lib/getTimezoneOffsetInMilliseconds.js
	/**
	* Google Chrome as of 67.0.3396.87 introduced timezones with offset that includes seconds.
	* They usually appear for dates that denote time before the timezones were introduced
	* (e.g. for 'Europe/Prague' timezone the offset is GMT+00:57:44 before 1 October 1891
	* and GMT+01:00:00 after that date)
	*
	* Date#getTimezoneOffset returns the offset in minutes and would return 57 for the example above,
	* which would lead to incorrect calculations.
	*
	* This function returns the timezone offset in milliseconds that takes seconds in account.
	*/
	function getTimezoneOffsetInMilliseconds(date) {
		const _date = toDate(date);
		const utcDate = new Date(Date.UTC(_date.getFullYear(), _date.getMonth(), _date.getDate(), _date.getHours(), _date.getMinutes(), _date.getSeconds(), _date.getMilliseconds()));
		utcDate.setUTCFullYear(_date.getFullYear());
		return +date - +utcDate;
	}
	//#endregion
	//#region node_modules/date-fns/_lib/normalizeDates.js
	function normalizeDates(context, ...dates) {
		const normalize = constructFrom.bind(null, context || dates.find((date) => typeof date === "object"));
		return dates.map(normalize);
	}
	//#endregion
	//#region node_modules/date-fns/startOfDay.js
	/**
	* The {@link startOfDay} function options.
	*/
	/**
	* @name startOfDay
	* @category Day Helpers
	* @summary Return the start of a day for the given date.
	*
	* @description
	* Return the start of a day for the given date.
	* The result will be in the local timezone.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The original date
	* @param options - The options
	*
	* @returns The start of a day
	*
	* @example
	* // The start of a day for 2 September 2014 11:55:00:
	* const result = startOfDay(new Date(2014, 8, 2, 11, 55, 0))
	* //=> Tue Sep 02 2014 00:00:00
	*/
	function startOfDay(date, options) {
		const _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
		_date.setHours(0, 0, 0, 0);
		return _date;
	}
	//#endregion
	//#region node_modules/date-fns/differenceInCalendarDays.js
	/**
	* The {@link differenceInCalendarDays} function options.
	*/
	/**
	* @name differenceInCalendarDays
	* @category Day Helpers
	* @summary Get the number of calendar days between the given dates.
	*
	* @description
	* Get the number of calendar days between the given dates. This means that the times are removed
	* from the dates and then the difference in days is calculated.
	*
	* @param laterDate - The later date
	* @param earlierDate - The earlier date
	* @param options - The options object
	*
	* @returns The number of calendar days
	*
	* @example
	* // How many calendar days are between
	* // 2 July 2011 23:00:00 and 2 July 2012 00:00:00?
	* const result = differenceInCalendarDays(
	*   new Date(2012, 6, 2, 0, 0),
	*   new Date(2011, 6, 2, 23, 0)
	* )
	* //=> 366
	* // How many calendar days are between
	* // 2 July 2011 23:59:00 and 3 July 2011 00:01:00?
	* const result = differenceInCalendarDays(
	*   new Date(2011, 6, 3, 0, 1),
	*   new Date(2011, 6, 2, 23, 59)
	* )
	* //=> 1
	*/
	function differenceInCalendarDays(laterDate, earlierDate, options) {
		const [laterDate_, earlierDate_] = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate);
		const laterStartOfDay = startOfDay(laterDate_);
		const earlierStartOfDay = startOfDay(earlierDate_);
		const laterTimestamp = +laterStartOfDay - getTimezoneOffsetInMilliseconds(laterStartOfDay);
		const earlierTimestamp = +earlierStartOfDay - getTimezoneOffsetInMilliseconds(earlierStartOfDay);
		return Math.round((laterTimestamp - earlierTimestamp) / millisecondsInDay);
	}
	//#endregion
	//#region node_modules/date-fns/locale/en-US/_lib/formatDistance.js
	var formatDistanceLocale = {
		lessThanXSeconds: {
			one: "less than a second",
			other: "less than {{count}} seconds"
		},
		xSeconds: {
			one: "1 second",
			other: "{{count}} seconds"
		},
		halfAMinute: "half a minute",
		lessThanXMinutes: {
			one: "less than a minute",
			other: "less than {{count}} minutes"
		},
		xMinutes: {
			one: "1 minute",
			other: "{{count}} minutes"
		},
		aboutXHours: {
			one: "about 1 hour",
			other: "about {{count}} hours"
		},
		xHours: {
			one: "1 hour",
			other: "{{count}} hours"
		},
		xDays: {
			one: "1 day",
			other: "{{count}} days"
		},
		aboutXWeeks: {
			one: "about 1 week",
			other: "about {{count}} weeks"
		},
		xWeeks: {
			one: "1 week",
			other: "{{count}} weeks"
		},
		aboutXMonths: {
			one: "about 1 month",
			other: "about {{count}} months"
		},
		xMonths: {
			one: "1 month",
			other: "{{count}} months"
		},
		aboutXYears: {
			one: "about 1 year",
			other: "about {{count}} years"
		},
		xYears: {
			one: "1 year",
			other: "{{count}} years"
		},
		overXYears: {
			one: "over 1 year",
			other: "over {{count}} years"
		},
		almostXYears: {
			one: "almost 1 year",
			other: "almost {{count}} years"
		}
	};
	var formatDistance = (token, count, options) => {
		let result;
		const tokenValue = formatDistanceLocale[token];
		if (typeof tokenValue === "string") result = tokenValue;
		else if (count === 1) result = tokenValue.one;
		else result = tokenValue.other.replace("{{count}}", count.toString());
		if (options === null || options === void 0 ? void 0 : options.addSuffix) if (options.comparison && options.comparison > 0) return "in " + result;
		else return result + " ago";
		return result;
	};
	//#endregion
	//#region node_modules/date-fns/locale/_lib/buildFormatLongFn.js
	function buildFormatLongFn(args) {
		return (options = {}) => {
			const width = options.width ? String(options.width) : args.defaultWidth;
			return args.formats[width] || args.formats[args.defaultWidth];
		};
	}
	var formatLong = {
		date: buildFormatLongFn({
			formats: {
				full: "EEEE, MMMM do, y",
				long: "MMMM do, y",
				medium: "MMM d, y",
				short: "MM/dd/yyyy"
			},
			defaultWidth: "full"
		}),
		time: buildFormatLongFn({
			formats: {
				full: "h:mm:ss a zzzz",
				long: "h:mm:ss a z",
				medium: "h:mm:ss a",
				short: "h:mm a"
			},
			defaultWidth: "full"
		}),
		dateTime: buildFormatLongFn({
			formats: {
				full: "{{date}} 'at' {{time}}",
				long: "{{date}} 'at' {{time}}",
				medium: "{{date}}, {{time}}",
				short: "{{date}}, {{time}}"
			},
			defaultWidth: "full"
		})
	};
	//#endregion
	//#region node_modules/date-fns/locale/en-US/_lib/formatRelative.js
	var formatRelativeLocale = {
		lastWeek: "'last' eeee 'at' p",
		yesterday: "'yesterday at' p",
		today: "'today at' p",
		tomorrow: "'tomorrow at' p",
		nextWeek: "eeee 'at' p",
		other: "P"
	};
	var formatRelative = (token, _date, _baseDate, _options) => formatRelativeLocale[token];
	//#endregion
	//#region node_modules/date-fns/locale/_lib/buildLocalizeFn.js
	/**
	* The localize function argument callback which allows to convert raw value to
	* the actual type.
	*
	* @param value - The value to convert
	*
	* @returns The converted value
	*/
	/**
	* The map of localized values for each width.
	*/
	/**
	* The index type of the locale unit value. It types conversion of units of
	* values that don't start at 0 (i.e. quarters).
	*/
	/**
	* Converts the unit value to the tuple of values.
	*/
	/**
	* The tuple of localized era values. The first element represents BC,
	* the second element represents AD.
	*/
	/**
	* The tuple of localized quarter values. The first element represents Q1.
	*/
	/**
	* The tuple of localized day values. The first element represents Sunday.
	*/
	/**
	* The tuple of localized month values. The first element represents January.
	*/
	function buildLocalizeFn(args) {
		return (value, options) => {
			const context = (options === null || options === void 0 ? void 0 : options.context) ? String(options.context) : "standalone";
			let valuesArray;
			if (context === "formatting" && args.formattingValues) {
				const defaultWidth = args.defaultFormattingWidth || args.defaultWidth;
				const width = (options === null || options === void 0 ? void 0 : options.width) ? String(options.width) : defaultWidth;
				valuesArray = args.formattingValues[width] || args.formattingValues[defaultWidth];
			} else {
				const defaultWidth = args.defaultWidth;
				const width = (options === null || options === void 0 ? void 0 : options.width) ? String(options.width) : args.defaultWidth;
				valuesArray = args.values[width] || args.values[defaultWidth];
			}
			const index = args.argumentCallback ? args.argumentCallback(value) : value;
			return valuesArray[index];
		};
	}
	//#endregion
	//#region node_modules/date-fns/locale/en-US/_lib/localize.js
	var eraValues = {
		narrow: ["B", "A"],
		abbreviated: ["BC", "AD"],
		wide: ["Before Christ", "Anno Domini"]
	};
	var quarterValues = {
		narrow: [
			"1",
			"2",
			"3",
			"4"
		],
		abbreviated: [
			"Q1",
			"Q2",
			"Q3",
			"Q4"
		],
		wide: [
			"1st quarter",
			"2nd quarter",
			"3rd quarter",
			"4th quarter"
		]
	};
	var monthValues = {
		narrow: [
			"J",
			"F",
			"M",
			"A",
			"M",
			"J",
			"J",
			"A",
			"S",
			"O",
			"N",
			"D"
		],
		abbreviated: [
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec"
		],
		wide: [
			"January",
			"February",
			"March",
			"April",
			"May",
			"June",
			"July",
			"August",
			"September",
			"October",
			"November",
			"December"
		]
	};
	var dayValues = {
		narrow: [
			"S",
			"M",
			"T",
			"W",
			"T",
			"F",
			"S"
		],
		short: [
			"Su",
			"Mo",
			"Tu",
			"We",
			"Th",
			"Fr",
			"Sa"
		],
		abbreviated: [
			"Sun",
			"Mon",
			"Tue",
			"Wed",
			"Thu",
			"Fri",
			"Sat"
		],
		wide: [
			"Sunday",
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday",
			"Saturday"
		]
	};
	var dayPeriodValues = {
		narrow: {
			am: "a",
			pm: "p",
			midnight: "mi",
			noon: "n",
			morning: "morning",
			afternoon: "afternoon",
			evening: "evening",
			night: "night"
		},
		abbreviated: {
			am: "AM",
			pm: "PM",
			midnight: "midnight",
			noon: "noon",
			morning: "morning",
			afternoon: "afternoon",
			evening: "evening",
			night: "night"
		},
		wide: {
			am: "a.m.",
			pm: "p.m.",
			midnight: "midnight",
			noon: "noon",
			morning: "morning",
			afternoon: "afternoon",
			evening: "evening",
			night: "night"
		}
	};
	var formattingDayPeriodValues = {
		narrow: {
			am: "a",
			pm: "p",
			midnight: "mi",
			noon: "n",
			morning: "in the morning",
			afternoon: "in the afternoon",
			evening: "in the evening",
			night: "at night"
		},
		abbreviated: {
			am: "AM",
			pm: "PM",
			midnight: "midnight",
			noon: "noon",
			morning: "in the morning",
			afternoon: "in the afternoon",
			evening: "in the evening",
			night: "at night"
		},
		wide: {
			am: "a.m.",
			pm: "p.m.",
			midnight: "midnight",
			noon: "noon",
			morning: "in the morning",
			afternoon: "in the afternoon",
			evening: "in the evening",
			night: "at night"
		}
	};
	var ordinalNumber = (dirtyNumber, _options) => {
		const number = Number(dirtyNumber);
		const rem100 = number % 100;
		if (rem100 > 20 || rem100 < 10) switch (rem100 % 10) {
			case 1: return number + "st";
			case 2: return number + "nd";
			case 3: return number + "rd";
		}
		return number + "th";
	};
	var localize = {
		ordinalNumber,
		era: buildLocalizeFn({
			values: eraValues,
			defaultWidth: "wide"
		}),
		quarter: buildLocalizeFn({
			values: quarterValues,
			defaultWidth: "wide",
			argumentCallback: (quarter) => quarter - 1
		}),
		month: buildLocalizeFn({
			values: monthValues,
			defaultWidth: "wide"
		}),
		day: buildLocalizeFn({
			values: dayValues,
			defaultWidth: "wide"
		}),
		dayPeriod: buildLocalizeFn({
			values: dayPeriodValues,
			defaultWidth: "wide",
			formattingValues: formattingDayPeriodValues,
			defaultFormattingWidth: "wide"
		})
	};
	//#endregion
	//#region node_modules/date-fns/locale/_lib/buildMatchFn.js
	function buildMatchFn(args) {
		return (string, options = {}) => {
			const width = options.width;
			const matchPattern = width && args.matchPatterns[width] || args.matchPatterns[args.defaultMatchWidth];
			const matchResult = string.match(matchPattern);
			if (!matchResult) return null;
			const matchedString = matchResult[0];
			const parsePatterns = width && args.parsePatterns[width] || args.parsePatterns[args.defaultParseWidth];
			const key = Array.isArray(parsePatterns) ? findIndex(parsePatterns, (pattern) => pattern.test(matchedString)) : findKey(parsePatterns, (pattern) => pattern.test(matchedString));
			let value;
			value = args.valueCallback ? args.valueCallback(key) : key;
			value = options.valueCallback ? options.valueCallback(value) : value;
			const rest = string.slice(matchedString.length);
			return {
				value,
				rest
			};
		};
	}
	function findKey(object, predicate) {
		for (const key in object) if (Object.prototype.hasOwnProperty.call(object, key) && predicate(object[key])) return key;
	}
	function findIndex(array, predicate) {
		for (let key = 0; key < array.length; key++) if (predicate(array[key])) return key;
	}
	//#endregion
	//#region node_modules/date-fns/locale/_lib/buildMatchPatternFn.js
	function buildMatchPatternFn(args) {
		return (string, options = {}) => {
			const matchResult = string.match(args.matchPattern);
			if (!matchResult) return null;
			const matchedString = matchResult[0];
			const parseResult = string.match(args.parsePattern);
			if (!parseResult) return null;
			let value = args.valueCallback ? args.valueCallback(parseResult[0]) : parseResult[0];
			value = options.valueCallback ? options.valueCallback(value) : value;
			const rest = string.slice(matchedString.length);
			return {
				value,
				rest
			};
		};
	}
	//#endregion
	//#region node_modules/date-fns/locale/en-US.js
	/**
	* @category Locales
	* @summary English locale (United States).
	* @language English
	* @iso-639-2 eng
	* @author Sasha Koss [@kossnocorp](https://github.com/kossnocorp)
	* @author Lesha Koss [@leshakoss](https://github.com/leshakoss)
	*/
	var enUS = {
		code: "en-US",
		formatDistance,
		formatLong,
		formatRelative,
		localize,
		match: {
			ordinalNumber: buildMatchPatternFn({
				matchPattern: /^(\d+)(th|st|nd|rd)?/i,
				parsePattern: /\d+/i,
				valueCallback: (value) => parseInt(value, 10)
			}),
			era: buildMatchFn({
				matchPatterns: {
					narrow: /^(b|a)/i,
					abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
					wide: /^(before christ|before common era|anno domini|common era)/i
				},
				defaultMatchWidth: "wide",
				parsePatterns: { any: [/^b/i, /^(a|c)/i] },
				defaultParseWidth: "any"
			}),
			quarter: buildMatchFn({
				matchPatterns: {
					narrow: /^[1234]/i,
					abbreviated: /^q[1234]/i,
					wide: /^[1234](th|st|nd|rd)? quarter/i
				},
				defaultMatchWidth: "wide",
				parsePatterns: { any: [
					/1/i,
					/2/i,
					/3/i,
					/4/i
				] },
				defaultParseWidth: "any",
				valueCallback: (index) => index + 1
			}),
			month: buildMatchFn({
				matchPatterns: {
					narrow: /^[jfmasond]/i,
					abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
					wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
				},
				defaultMatchWidth: "wide",
				parsePatterns: {
					narrow: [
						/^j/i,
						/^f/i,
						/^m/i,
						/^a/i,
						/^m/i,
						/^j/i,
						/^j/i,
						/^a/i,
						/^s/i,
						/^o/i,
						/^n/i,
						/^d/i
					],
					any: [
						/^ja/i,
						/^f/i,
						/^mar/i,
						/^ap/i,
						/^may/i,
						/^jun/i,
						/^jul/i,
						/^au/i,
						/^s/i,
						/^o/i,
						/^n/i,
						/^d/i
					]
				},
				defaultParseWidth: "any"
			}),
			day: buildMatchFn({
				matchPatterns: {
					narrow: /^[smtwf]/i,
					short: /^(su|mo|tu|we|th|fr|sa)/i,
					abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
					wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
				},
				defaultMatchWidth: "wide",
				parsePatterns: {
					narrow: [
						/^s/i,
						/^m/i,
						/^t/i,
						/^w/i,
						/^t/i,
						/^f/i,
						/^s/i
					],
					any: [
						/^su/i,
						/^m/i,
						/^tu/i,
						/^w/i,
						/^th/i,
						/^f/i,
						/^sa/i
					]
				},
				defaultParseWidth: "any"
			}),
			dayPeriod: buildMatchFn({
				matchPatterns: {
					narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
					any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
				},
				defaultMatchWidth: "any",
				parsePatterns: { any: {
					am: /^a/i,
					pm: /^p/i,
					midnight: /^mi/i,
					noon: /^no/i,
					morning: /morning/i,
					afternoon: /afternoon/i,
					evening: /evening/i,
					night: /night/i
				} },
				defaultParseWidth: "any"
			})
		},
		options: {
			weekStartsOn: 0,
			firstWeekContainsDate: 1
		}
	};
	//#endregion
	//#region node_modules/date-fns/_lib/defaultOptions.js
	var defaultOptions = {};
	function getDefaultOptions() {
		return defaultOptions;
	}
	//#endregion
	//#region node_modules/date-fns/startOfYear.js
	/**
	* The {@link startOfYear} function options.
	*/
	/**
	* @name startOfYear
	* @category Year Helpers
	* @summary Return the start of a year for the given date.
	*
	* @description
	* Return the start of a year for the given date.
	* The result will be in the local timezone.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The original date
	* @param options - The options
	*
	* @returns The start of a year
	*
	* @example
	* // The start of a year for 2 September 2014 11:55:00:
	* const result = startOfYear(new Date(2014, 8, 2, 11, 55, 00))
	* //=> Wed Jan 01 2014 00:00:00
	*/
	function startOfYear(date, options) {
		const date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
		date_.setFullYear(date_.getFullYear(), 0, 1);
		date_.setHours(0, 0, 0, 0);
		return date_;
	}
	//#endregion
	//#region node_modules/date-fns/getDayOfYear.js
	/**
	* The {@link getDayOfYear} function options.
	*/
	/**
	* @name getDayOfYear
	* @category Day Helpers
	* @summary Get the day of the year of the given date.
	*
	* @description
	* Get the day of the year of the given date.
	*
	* @param date - The given date
	* @param options - The options
	*
	* @returns The day of year
	*
	* @example
	* // Which day of the year is 2 July 2014?
	* const result = getDayOfYear(new Date(2014, 6, 2))
	* //=> 183
	*/
	function getDayOfYear(date, options) {
		const _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
		return differenceInCalendarDays(_date, startOfYear(_date)) + 1;
	}
	//#endregion
	//#region node_modules/date-fns/startOfWeek.js
	/**
	* The {@link startOfWeek} function options.
	*/
	/**
	* @name startOfWeek
	* @category Week Helpers
	* @summary Return the start of a week for the given date.
	*
	* @description
	* Return the start of a week for the given date.
	* The result will be in the local timezone.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The original date
	* @param options - An object with options
	*
	* @returns The start of a week
	*
	* @example
	* // The start of a week for 2 September 2014 11:55:00:
	* const result = startOfWeek(new Date(2014, 8, 2, 11, 55, 0))
	* //=> Sun Aug 31 2014 00:00:00
	*
	* @example
	* // If the week starts on Monday, the start of the week for 2 September 2014 11:55:00:
	* const result = startOfWeek(new Date(2014, 8, 2, 11, 55, 0), { weekStartsOn: 1 })
	* //=> Mon Sep 01 2014 00:00:00
	*/
	function startOfWeek(date, options) {
		var _ref, _ref2, _ref3, _options$weekStartsOn, _options$locale, _defaultOptions$local;
		const defaultOptions = getDefaultOptions();
		const weekStartsOn = (_ref = (_ref2 = (_ref3 = (_options$weekStartsOn = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn !== void 0 ? _options$weekStartsOn : options === null || options === void 0 || (_options$locale = options.locale) === null || _options$locale === void 0 || (_options$locale = _options$locale.options) === null || _options$locale === void 0 ? void 0 : _options$locale.weekStartsOn) !== null && _ref3 !== void 0 ? _ref3 : defaultOptions.weekStartsOn) !== null && _ref2 !== void 0 ? _ref2 : (_defaultOptions$local = defaultOptions.locale) === null || _defaultOptions$local === void 0 || (_defaultOptions$local = _defaultOptions$local.options) === null || _defaultOptions$local === void 0 ? void 0 : _defaultOptions$local.weekStartsOn) !== null && _ref !== void 0 ? _ref : 0;
		const _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
		const day = _date.getDay();
		const diff = (day < weekStartsOn ? 7 : 0) + day - weekStartsOn;
		_date.setDate(_date.getDate() - diff);
		_date.setHours(0, 0, 0, 0);
		return _date;
	}
	//#endregion
	//#region node_modules/date-fns/startOfISOWeek.js
	/**
	* The {@link startOfISOWeek} function options.
	*/
	/**
	* @name startOfISOWeek
	* @category ISO Week Helpers
	* @summary Return the start of an ISO week for the given date.
	*
	* @description
	* Return the start of an ISO week for the given date.
	* The result will be in the local timezone.
	*
	* ISO week-numbering year: http://en.wikipedia.org/wiki/ISO_week_date
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The original date
	* @param options - An object with options
	*
	* @returns The start of an ISO week
	*
	* @example
	* // The start of an ISO week for 2 September 2014 11:55:00:
	* const result = startOfISOWeek(new Date(2014, 8, 2, 11, 55, 0))
	* //=> Mon Sep 01 2014 00:00:00
	*/
	function startOfISOWeek(date, options) {
		return startOfWeek(date, _objectSpread2(_objectSpread2({}, options), {}, { weekStartsOn: 1 }));
	}
	//#endregion
	//#region node_modules/date-fns/getISOWeekYear.js
	/**
	* The {@link getISOWeekYear} function options.
	*/
	/**
	* @name getISOWeekYear
	* @category ISO Week-Numbering Year Helpers
	* @summary Get the ISO week-numbering year of the given date.
	*
	* @description
	* Get the ISO week-numbering year of the given date,
	* which always starts 3 days before the year's first Thursday.
	*
	* ISO week-numbering year: http://en.wikipedia.org/wiki/ISO_week_date
	*
	* @param date - The given date
	*
	* @returns The ISO week-numbering year
	*
	* @example
	* // Which ISO-week numbering year is 2 January 2005?
	* const result = getISOWeekYear(new Date(2005, 0, 2))
	* //=> 2004
	*/
	function getISOWeekYear(date, options) {
		const _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
		const year = _date.getFullYear();
		const fourthOfJanuaryOfNextYear = constructFrom(_date, 0);
		fourthOfJanuaryOfNextYear.setFullYear(year + 1, 0, 4);
		fourthOfJanuaryOfNextYear.setHours(0, 0, 0, 0);
		const startOfNextYear = startOfISOWeek(fourthOfJanuaryOfNextYear);
		const fourthOfJanuaryOfThisYear = constructFrom(_date, 0);
		fourthOfJanuaryOfThisYear.setFullYear(year, 0, 4);
		fourthOfJanuaryOfThisYear.setHours(0, 0, 0, 0);
		const startOfThisYear = startOfISOWeek(fourthOfJanuaryOfThisYear);
		if (_date.getTime() >= startOfNextYear.getTime()) return year + 1;
		else if (_date.getTime() >= startOfThisYear.getTime()) return year;
		else return year - 1;
	}
	//#endregion
	//#region node_modules/date-fns/startOfISOWeekYear.js
	/**
	* The {@link startOfISOWeekYear} function options.
	*/
	/**
	* @name startOfISOWeekYear
	* @category ISO Week-Numbering Year Helpers
	* @summary Return the start of an ISO week-numbering year for the given date.
	*
	* @description
	* Return the start of an ISO week-numbering year,
	* which always starts 3 days before the year's first Thursday.
	* The result will be in the local timezone.
	*
	* ISO week-numbering year: http://en.wikipedia.org/wiki/ISO_week_date
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The original date
	* @param options - An object with options
	*
	* @returns The start of an ISO week-numbering year
	*
	* @example
	* // The start of an ISO week-numbering year for 2 July 2005:
	* const result = startOfISOWeekYear(new Date(2005, 6, 2))
	* //=> Mon Jan 03 2005 00:00:00
	*/
	function startOfISOWeekYear(date, options) {
		const year = getISOWeekYear(date, options);
		const fourthOfJanuary = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
		fourthOfJanuary.setFullYear(year, 0, 4);
		fourthOfJanuary.setHours(0, 0, 0, 0);
		return startOfISOWeek(fourthOfJanuary);
	}
	//#endregion
	//#region node_modules/date-fns/getISOWeek.js
	/**
	* The {@link getISOWeek} function options.
	*/
	/**
	* @name getISOWeek
	* @category ISO Week Helpers
	* @summary Get the ISO week of the given date.
	*
	* @description
	* Get the ISO week of the given date.
	*
	* ISO week-numbering year: http://en.wikipedia.org/wiki/ISO_week_date
	*
	* @param date - The given date
	* @param options - The options
	*
	* @returns The ISO week
	*
	* @example
	* // Which week of the ISO-week numbering year is 2 January 2005?
	* const result = getISOWeek(new Date(2005, 0, 2))
	* //=> 53
	*/
	function getISOWeek(date, options) {
		const _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
		const diff = +startOfISOWeek(_date) - +startOfISOWeekYear(_date);
		return Math.round(diff / millisecondsInWeek) + 1;
	}
	//#endregion
	//#region node_modules/date-fns/getWeekYear.js
	/**
	* The {@link getWeekYear} function options.
	*/
	/**
	* @name getWeekYear
	* @category Week-Numbering Year Helpers
	* @summary Get the local week-numbering year of the given date.
	*
	* @description
	* Get the local week-numbering year of the given date.
	* The exact calculation depends on the values of
	* `options.weekStartsOn` (which is the index of the first day of the week)
	* and `options.firstWeekContainsDate` (which is the day of January, which is always in
	* the first week of the week-numbering year)
	*
	* Week numbering: https://en.wikipedia.org/wiki/Week#The_ISO_week_date_system
	*
	* @param date - The given date
	* @param options - An object with options.
	*
	* @returns The local week-numbering year
	*
	* @example
	* // Which week numbering year is 26 December 2004 with the default settings?
	* const result = getWeekYear(new Date(2004, 11, 26))
	* //=> 2005
	*
	* @example
	* // Which week numbering year is 26 December 2004 if week starts on Saturday?
	* const result = getWeekYear(new Date(2004, 11, 26), { weekStartsOn: 6 })
	* //=> 2004
	*
	* @example
	* // Which week numbering year is 26 December 2004 if the first week contains 4 January?
	* const result = getWeekYear(new Date(2004, 11, 26), { firstWeekContainsDate: 4 })
	* //=> 2004
	*/
	function getWeekYear(date, options) {
		var _ref, _ref2, _ref3, _options$firstWeekCon, _options$locale, _defaultOptions$local;
		const _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
		const year = _date.getFullYear();
		const defaultOptions = getDefaultOptions();
		const firstWeekContainsDate = (_ref = (_ref2 = (_ref3 = (_options$firstWeekCon = options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) !== null && _options$firstWeekCon !== void 0 ? _options$firstWeekCon : options === null || options === void 0 || (_options$locale = options.locale) === null || _options$locale === void 0 || (_options$locale = _options$locale.options) === null || _options$locale === void 0 ? void 0 : _options$locale.firstWeekContainsDate) !== null && _ref3 !== void 0 ? _ref3 : defaultOptions.firstWeekContainsDate) !== null && _ref2 !== void 0 ? _ref2 : (_defaultOptions$local = defaultOptions.locale) === null || _defaultOptions$local === void 0 || (_defaultOptions$local = _defaultOptions$local.options) === null || _defaultOptions$local === void 0 ? void 0 : _defaultOptions$local.firstWeekContainsDate) !== null && _ref !== void 0 ? _ref : 1;
		const firstWeekOfNextYear = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
		firstWeekOfNextYear.setFullYear(year + 1, 0, firstWeekContainsDate);
		firstWeekOfNextYear.setHours(0, 0, 0, 0);
		const startOfNextYear = startOfWeek(firstWeekOfNextYear, options);
		const firstWeekOfThisYear = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
		firstWeekOfThisYear.setFullYear(year, 0, firstWeekContainsDate);
		firstWeekOfThisYear.setHours(0, 0, 0, 0);
		const startOfThisYear = startOfWeek(firstWeekOfThisYear, options);
		if (+_date >= +startOfNextYear) return year + 1;
		else if (+_date >= +startOfThisYear) return year;
		else return year - 1;
	}
	//#endregion
	//#region node_modules/date-fns/startOfWeekYear.js
	/**
	* The {@link startOfWeekYear} function options.
	*/
	/**
	* @name startOfWeekYear
	* @category Week-Numbering Year Helpers
	* @summary Return the start of a local week-numbering year for the given date.
	*
	* @description
	* Return the start of a local week-numbering year.
	* The exact calculation depends on the values of
	* `options.weekStartsOn` (which is the index of the first day of the week)
	* and `options.firstWeekContainsDate` (which is the day of January, which is always in
	* the first week of the week-numbering year)
	*
	* Week numbering: https://en.wikipedia.org/wiki/Week#The_ISO_week_date_system
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type.
	*
	* @param date - The original date
	* @param options - An object with options
	*
	* @returns The start of a week-numbering year
	*
	* @example
	* // The start of an a week-numbering year for 2 July 2005 with default settings:
	* const result = startOfWeekYear(new Date(2005, 6, 2))
	* //=> Sun Dec 26 2004 00:00:00
	*
	* @example
	* // The start of a week-numbering year for 2 July 2005
	* // if Monday is the first day of week
	* // and 4 January is always in the first week of the year:
	* const result = startOfWeekYear(new Date(2005, 6, 2), {
	*   weekStartsOn: 1,
	*   firstWeekContainsDate: 4
	* })
	* //=> Mon Jan 03 2005 00:00:00
	*/
	function startOfWeekYear(date, options) {
		var _ref, _ref2, _ref3, _options$firstWeekCon, _options$locale, _defaultOptions$local;
		const defaultOptions = getDefaultOptions();
		const firstWeekContainsDate = (_ref = (_ref2 = (_ref3 = (_options$firstWeekCon = options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) !== null && _options$firstWeekCon !== void 0 ? _options$firstWeekCon : options === null || options === void 0 || (_options$locale = options.locale) === null || _options$locale === void 0 || (_options$locale = _options$locale.options) === null || _options$locale === void 0 ? void 0 : _options$locale.firstWeekContainsDate) !== null && _ref3 !== void 0 ? _ref3 : defaultOptions.firstWeekContainsDate) !== null && _ref2 !== void 0 ? _ref2 : (_defaultOptions$local = defaultOptions.locale) === null || _defaultOptions$local === void 0 || (_defaultOptions$local = _defaultOptions$local.options) === null || _defaultOptions$local === void 0 ? void 0 : _defaultOptions$local.firstWeekContainsDate) !== null && _ref !== void 0 ? _ref : 1;
		const year = getWeekYear(date, options);
		const firstWeek = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
		firstWeek.setFullYear(year, 0, firstWeekContainsDate);
		firstWeek.setHours(0, 0, 0, 0);
		return startOfWeek(firstWeek, options);
	}
	//#endregion
	//#region node_modules/date-fns/getWeek.js
	/**
	* The {@link getWeek} function options.
	*/
	/**
	* @name getWeek
	* @category Week Helpers
	* @summary Get the local week index of the given date.
	*
	* @description
	* Get the local week index of the given date.
	* The exact calculation depends on the values of
	* `options.weekStartsOn` (which is the index of the first day of the week)
	* and `options.firstWeekContainsDate` (which is the day of January, which is always in
	* the first week of the week-numbering year)
	*
	* Week numbering: https://en.wikipedia.org/wiki/Week#The_ISO_week_date_system
	*
	* @param date - The given date
	* @param options - An object with options
	*
	* @returns The week
	*
	* @example
	* // Which week of the local week numbering year is 2 January 2005 with default options?
	* const result = getWeek(new Date(2005, 0, 2))
	* //=> 2
	*
	* @example
	* // Which week of the local week numbering year is 2 January 2005,
	* // if Monday is the first day of the week,
	* // and the first week of the year always contains 4 January?
	* const result = getWeek(new Date(2005, 0, 2), {
	*   weekStartsOn: 1,
	*   firstWeekContainsDate: 4
	* })
	* //=> 53
	*/
	function getWeek(date, options) {
		const _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
		const diff = +startOfWeek(_date, options) - +startOfWeekYear(_date, options);
		return Math.round(diff / millisecondsInWeek) + 1;
	}
	//#endregion
	//#region node_modules/date-fns/_lib/addLeadingZeros.js
	function addLeadingZeros(number, targetLength) {
		return (number < 0 ? "-" : "") + Math.abs(number).toString().padStart(targetLength, "0");
	}
	//#endregion
	//#region node_modules/date-fns/_lib/format/lightFormatters.js
	var lightFormatters = {
		y(date, token) {
			const signedYear = date.getFullYear();
			const year = signedYear > 0 ? signedYear : 1 - signedYear;
			return addLeadingZeros(token === "yy" ? year % 100 : year, token.length);
		},
		M(date, token) {
			const month = date.getMonth();
			return token === "M" ? String(month + 1) : addLeadingZeros(month + 1, 2);
		},
		d(date, token) {
			return addLeadingZeros(date.getDate(), token.length);
		},
		a(date, token) {
			const dayPeriodEnumValue = date.getHours() / 12 >= 1 ? "pm" : "am";
			switch (token) {
				case "a":
				case "aa": return dayPeriodEnumValue.toUpperCase();
				case "aaa": return dayPeriodEnumValue;
				case "aaaaa": return dayPeriodEnumValue[0];
				default: return dayPeriodEnumValue === "am" ? "a.m." : "p.m.";
			}
		},
		h(date, token) {
			return addLeadingZeros(date.getHours() % 12 || 12, token.length);
		},
		H(date, token) {
			return addLeadingZeros(date.getHours(), token.length);
		},
		m(date, token) {
			return addLeadingZeros(date.getMinutes(), token.length);
		},
		s(date, token) {
			return addLeadingZeros(date.getSeconds(), token.length);
		},
		S(date, token) {
			const numberOfDigits = token.length;
			const milliseconds = date.getMilliseconds();
			return addLeadingZeros(Math.trunc(milliseconds * Math.pow(10, numberOfDigits - 3)), token.length);
		}
	};
	//#endregion
	//#region node_modules/date-fns/_lib/format/formatters.js
	var dayPeriodEnum = {
		am: "am",
		pm: "pm",
		midnight: "midnight",
		noon: "noon",
		morning: "morning",
		afternoon: "afternoon",
		evening: "evening",
		night: "night"
	};
	var formatters = {
		G: function(date, token, localize) {
			const era = date.getFullYear() > 0 ? 1 : 0;
			switch (token) {
				case "G":
				case "GG":
				case "GGG": return localize.era(era, { width: "abbreviated" });
				case "GGGGG": return localize.era(era, { width: "narrow" });
				default: return localize.era(era, { width: "wide" });
			}
		},
		y: function(date, token, localize) {
			if (token === "yo") {
				const signedYear = date.getFullYear();
				const year = signedYear > 0 ? signedYear : 1 - signedYear;
				return localize.ordinalNumber(year, { unit: "year" });
			}
			return lightFormatters.y(date, token);
		},
		Y: function(date, token, localize, options) {
			const signedWeekYear = getWeekYear(date, options);
			const weekYear = signedWeekYear > 0 ? signedWeekYear : 1 - signedWeekYear;
			if (token === "YY") return addLeadingZeros(weekYear % 100, 2);
			if (token === "Yo") return localize.ordinalNumber(weekYear, { unit: "year" });
			return addLeadingZeros(weekYear, token.length);
		},
		R: function(date, token) {
			return addLeadingZeros(getISOWeekYear(date), token.length);
		},
		u: function(date, token) {
			return addLeadingZeros(date.getFullYear(), token.length);
		},
		Q: function(date, token, localize) {
			const quarter = Math.ceil((date.getMonth() + 1) / 3);
			switch (token) {
				case "Q": return String(quarter);
				case "QQ": return addLeadingZeros(quarter, 2);
				case "Qo": return localize.ordinalNumber(quarter, { unit: "quarter" });
				case "QQQ": return localize.quarter(quarter, {
					width: "abbreviated",
					context: "formatting"
				});
				case "QQQQQ": return localize.quarter(quarter, {
					width: "narrow",
					context: "formatting"
				});
				default: return localize.quarter(quarter, {
					width: "wide",
					context: "formatting"
				});
			}
		},
		q: function(date, token, localize) {
			const quarter = Math.ceil((date.getMonth() + 1) / 3);
			switch (token) {
				case "q": return String(quarter);
				case "qq": return addLeadingZeros(quarter, 2);
				case "qo": return localize.ordinalNumber(quarter, { unit: "quarter" });
				case "qqq": return localize.quarter(quarter, {
					width: "abbreviated",
					context: "standalone"
				});
				case "qqqqq": return localize.quarter(quarter, {
					width: "narrow",
					context: "standalone"
				});
				default: return localize.quarter(quarter, {
					width: "wide",
					context: "standalone"
				});
			}
		},
		M: function(date, token, localize) {
			const month = date.getMonth();
			switch (token) {
				case "M":
				case "MM": return lightFormatters.M(date, token);
				case "Mo": return localize.ordinalNumber(month + 1, { unit: "month" });
				case "MMM": return localize.month(month, {
					width: "abbreviated",
					context: "formatting"
				});
				case "MMMMM": return localize.month(month, {
					width: "narrow",
					context: "formatting"
				});
				default: return localize.month(month, {
					width: "wide",
					context: "formatting"
				});
			}
		},
		L: function(date, token, localize) {
			const month = date.getMonth();
			switch (token) {
				case "L": return String(month + 1);
				case "LL": return addLeadingZeros(month + 1, 2);
				case "Lo": return localize.ordinalNumber(month + 1, { unit: "month" });
				case "LLL": return localize.month(month, {
					width: "abbreviated",
					context: "standalone"
				});
				case "LLLLL": return localize.month(month, {
					width: "narrow",
					context: "standalone"
				});
				default: return localize.month(month, {
					width: "wide",
					context: "standalone"
				});
			}
		},
		w: function(date, token, localize, options) {
			const week = getWeek(date, options);
			if (token === "wo") return localize.ordinalNumber(week, { unit: "week" });
			return addLeadingZeros(week, token.length);
		},
		I: function(date, token, localize) {
			const isoWeek = getISOWeek(date);
			if (token === "Io") return localize.ordinalNumber(isoWeek, { unit: "week" });
			return addLeadingZeros(isoWeek, token.length);
		},
		d: function(date, token, localize) {
			if (token === "do") return localize.ordinalNumber(date.getDate(), { unit: "date" });
			return lightFormatters.d(date, token);
		},
		D: function(date, token, localize) {
			const dayOfYear = getDayOfYear(date);
			if (token === "Do") return localize.ordinalNumber(dayOfYear, { unit: "dayOfYear" });
			return addLeadingZeros(dayOfYear, token.length);
		},
		E: function(date, token, localize) {
			const dayOfWeek = date.getDay();
			switch (token) {
				case "E":
				case "EE":
				case "EEE": return localize.day(dayOfWeek, {
					width: "abbreviated",
					context: "formatting"
				});
				case "EEEEE": return localize.day(dayOfWeek, {
					width: "narrow",
					context: "formatting"
				});
				case "EEEEEE": return localize.day(dayOfWeek, {
					width: "short",
					context: "formatting"
				});
				default: return localize.day(dayOfWeek, {
					width: "wide",
					context: "formatting"
				});
			}
		},
		e: function(date, token, localize, options) {
			const dayOfWeek = date.getDay();
			const localDayOfWeek = (dayOfWeek - options.weekStartsOn + 8) % 7 || 7;
			switch (token) {
				case "e": return String(localDayOfWeek);
				case "ee": return addLeadingZeros(localDayOfWeek, 2);
				case "eo": return localize.ordinalNumber(localDayOfWeek, { unit: "day" });
				case "eee": return localize.day(dayOfWeek, {
					width: "abbreviated",
					context: "formatting"
				});
				case "eeeee": return localize.day(dayOfWeek, {
					width: "narrow",
					context: "formatting"
				});
				case "eeeeee": return localize.day(dayOfWeek, {
					width: "short",
					context: "formatting"
				});
				default: return localize.day(dayOfWeek, {
					width: "wide",
					context: "formatting"
				});
			}
		},
		c: function(date, token, localize, options) {
			const dayOfWeek = date.getDay();
			const localDayOfWeek = (dayOfWeek - options.weekStartsOn + 8) % 7 || 7;
			switch (token) {
				case "c": return String(localDayOfWeek);
				case "cc": return addLeadingZeros(localDayOfWeek, token.length);
				case "co": return localize.ordinalNumber(localDayOfWeek, { unit: "day" });
				case "ccc": return localize.day(dayOfWeek, {
					width: "abbreviated",
					context: "standalone"
				});
				case "ccccc": return localize.day(dayOfWeek, {
					width: "narrow",
					context: "standalone"
				});
				case "cccccc": return localize.day(dayOfWeek, {
					width: "short",
					context: "standalone"
				});
				default: return localize.day(dayOfWeek, {
					width: "wide",
					context: "standalone"
				});
			}
		},
		i: function(date, token, localize) {
			const dayOfWeek = date.getDay();
			const isoDayOfWeek = dayOfWeek === 0 ? 7 : dayOfWeek;
			switch (token) {
				case "i": return String(isoDayOfWeek);
				case "ii": return addLeadingZeros(isoDayOfWeek, token.length);
				case "io": return localize.ordinalNumber(isoDayOfWeek, { unit: "day" });
				case "iii": return localize.day(dayOfWeek, {
					width: "abbreviated",
					context: "formatting"
				});
				case "iiiii": return localize.day(dayOfWeek, {
					width: "narrow",
					context: "formatting"
				});
				case "iiiiii": return localize.day(dayOfWeek, {
					width: "short",
					context: "formatting"
				});
				default: return localize.day(dayOfWeek, {
					width: "wide",
					context: "formatting"
				});
			}
		},
		a: function(date, token, localize) {
			const dayPeriodEnumValue = date.getHours() / 12 >= 1 ? "pm" : "am";
			switch (token) {
				case "a":
				case "aa": return localize.dayPeriod(dayPeriodEnumValue, {
					width: "abbreviated",
					context: "formatting"
				});
				case "aaa": return localize.dayPeriod(dayPeriodEnumValue, {
					width: "abbreviated",
					context: "formatting"
				}).toLowerCase();
				case "aaaaa": return localize.dayPeriod(dayPeriodEnumValue, {
					width: "narrow",
					context: "formatting"
				});
				default: return localize.dayPeriod(dayPeriodEnumValue, {
					width: "wide",
					context: "formatting"
				});
			}
		},
		b: function(date, token, localize) {
			const hours = date.getHours();
			let dayPeriodEnumValue;
			if (hours === 12) dayPeriodEnumValue = dayPeriodEnum.noon;
			else if (hours === 0) dayPeriodEnumValue = dayPeriodEnum.midnight;
			else dayPeriodEnumValue = hours / 12 >= 1 ? "pm" : "am";
			switch (token) {
				case "b":
				case "bb": return localize.dayPeriod(dayPeriodEnumValue, {
					width: "abbreviated",
					context: "formatting"
				});
				case "bbb": return localize.dayPeriod(dayPeriodEnumValue, {
					width: "abbreviated",
					context: "formatting"
				}).toLowerCase();
				case "bbbbb": return localize.dayPeriod(dayPeriodEnumValue, {
					width: "narrow",
					context: "formatting"
				});
				default: return localize.dayPeriod(dayPeriodEnumValue, {
					width: "wide",
					context: "formatting"
				});
			}
		},
		B: function(date, token, localize) {
			const hours = date.getHours();
			let dayPeriodEnumValue;
			if (hours >= 17) dayPeriodEnumValue = dayPeriodEnum.evening;
			else if (hours >= 12) dayPeriodEnumValue = dayPeriodEnum.afternoon;
			else if (hours >= 4) dayPeriodEnumValue = dayPeriodEnum.morning;
			else dayPeriodEnumValue = dayPeriodEnum.night;
			switch (token) {
				case "B":
				case "BB":
				case "BBB": return localize.dayPeriod(dayPeriodEnumValue, {
					width: "abbreviated",
					context: "formatting"
				});
				case "BBBBB": return localize.dayPeriod(dayPeriodEnumValue, {
					width: "narrow",
					context: "formatting"
				});
				default: return localize.dayPeriod(dayPeriodEnumValue, {
					width: "wide",
					context: "formatting"
				});
			}
		},
		h: function(date, token, localize) {
			if (token === "ho") {
				let hours = date.getHours() % 12;
				if (hours === 0) hours = 12;
				return localize.ordinalNumber(hours, { unit: "hour" });
			}
			return lightFormatters.h(date, token);
		},
		H: function(date, token, localize) {
			if (token === "Ho") return localize.ordinalNumber(date.getHours(), { unit: "hour" });
			return lightFormatters.H(date, token);
		},
		K: function(date, token, localize) {
			const hours = date.getHours() % 12;
			if (token === "Ko") return localize.ordinalNumber(hours, { unit: "hour" });
			return addLeadingZeros(hours, token.length);
		},
		k: function(date, token, localize) {
			let hours = date.getHours();
			if (hours === 0) hours = 24;
			if (token === "ko") return localize.ordinalNumber(hours, { unit: "hour" });
			return addLeadingZeros(hours, token.length);
		},
		m: function(date, token, localize) {
			if (token === "mo") return localize.ordinalNumber(date.getMinutes(), { unit: "minute" });
			return lightFormatters.m(date, token);
		},
		s: function(date, token, localize) {
			if (token === "so") return localize.ordinalNumber(date.getSeconds(), { unit: "second" });
			return lightFormatters.s(date, token);
		},
		S: function(date, token) {
			return lightFormatters.S(date, token);
		},
		X: function(date, token, _localize) {
			const timezoneOffset = date.getTimezoneOffset();
			if (timezoneOffset === 0) return "Z";
			switch (token) {
				case "X": return formatTimezoneWithOptionalMinutes(timezoneOffset);
				case "XXXX":
				case "XX": return formatTimezone(timezoneOffset);
				default: return formatTimezone(timezoneOffset, ":");
			}
		},
		x: function(date, token, _localize) {
			const timezoneOffset = date.getTimezoneOffset();
			switch (token) {
				case "x": return formatTimezoneWithOptionalMinutes(timezoneOffset);
				case "xxxx":
				case "xx": return formatTimezone(timezoneOffset);
				default: return formatTimezone(timezoneOffset, ":");
			}
		},
		O: function(date, token, _localize) {
			const timezoneOffset = date.getTimezoneOffset();
			switch (token) {
				case "O":
				case "OO":
				case "OOO": return "GMT" + formatTimezoneShort(timezoneOffset, ":");
				default: return "GMT" + formatTimezone(timezoneOffset, ":");
			}
		},
		z: function(date, token, _localize) {
			const timezoneOffset = date.getTimezoneOffset();
			switch (token) {
				case "z":
				case "zz":
				case "zzz": return "GMT" + formatTimezoneShort(timezoneOffset, ":");
				default: return "GMT" + formatTimezone(timezoneOffset, ":");
			}
		},
		t: function(date, token, _localize) {
			return addLeadingZeros(Math.trunc(+date / 1e3), token.length);
		},
		T: function(date, token, _localize) {
			return addLeadingZeros(+date, token.length);
		}
	};
	function formatTimezoneShort(offset, delimiter = "") {
		const sign = offset > 0 ? "-" : "+";
		const absOffset = Math.abs(offset);
		const hours = Math.trunc(absOffset / 60);
		const minutes = absOffset % 60;
		if (minutes === 0) return sign + String(hours);
		return sign + String(hours) + delimiter + addLeadingZeros(minutes, 2);
	}
	function formatTimezoneWithOptionalMinutes(offset, delimiter) {
		if (offset % 60 === 0) return (offset > 0 ? "-" : "+") + addLeadingZeros(Math.abs(offset) / 60, 2);
		return formatTimezone(offset, delimiter);
	}
	function formatTimezone(offset, delimiter = "") {
		const sign = offset > 0 ? "-" : "+";
		const absOffset = Math.abs(offset);
		const hours = addLeadingZeros(Math.trunc(absOffset / 60), 2);
		const minutes = addLeadingZeros(absOffset % 60, 2);
		return sign + hours + delimiter + minutes;
	}
	//#endregion
	//#region node_modules/date-fns/_lib/format/longFormatters.js
	var dateLongFormatter = (pattern, formatLong) => {
		switch (pattern) {
			case "P": return formatLong.date({ width: "short" });
			case "PP": return formatLong.date({ width: "medium" });
			case "PPP": return formatLong.date({ width: "long" });
			default: return formatLong.date({ width: "full" });
		}
	};
	var timeLongFormatter = (pattern, formatLong) => {
		switch (pattern) {
			case "p": return formatLong.time({ width: "short" });
			case "pp": return formatLong.time({ width: "medium" });
			case "ppp": return formatLong.time({ width: "long" });
			default: return formatLong.time({ width: "full" });
		}
	};
	var dateTimeLongFormatter = (pattern, formatLong) => {
		const matchResult = pattern.match(/(P+)(p+)?/) || [];
		const datePattern = matchResult[1];
		const timePattern = matchResult[2];
		if (!timePattern) return dateLongFormatter(pattern, formatLong);
		let dateTimeFormat;
		switch (datePattern) {
			case "P":
				dateTimeFormat = formatLong.dateTime({ width: "short" });
				break;
			case "PP":
				dateTimeFormat = formatLong.dateTime({ width: "medium" });
				break;
			case "PPP":
				dateTimeFormat = formatLong.dateTime({ width: "long" });
				break;
			default:
				dateTimeFormat = formatLong.dateTime({ width: "full" });
				break;
		}
		return dateTimeFormat.replace("{{date}}", dateLongFormatter(datePattern, formatLong)).replace("{{time}}", timeLongFormatter(timePattern, formatLong));
	};
	var longFormatters = {
		p: timeLongFormatter,
		P: dateTimeLongFormatter
	};
	//#endregion
	//#region node_modules/date-fns/_lib/protectedTokens.js
	var dayOfYearTokenRE = /^D+$/;
	var weekYearTokenRE = /^Y+$/;
	var throwTokens = [
		"D",
		"DD",
		"YY",
		"YYYY"
	];
	function isProtectedDayOfYearToken(token) {
		return dayOfYearTokenRE.test(token);
	}
	function isProtectedWeekYearToken(token) {
		return weekYearTokenRE.test(token);
	}
	function warnOrThrowProtectedError(token, format, input) {
		const _message = message(token, format, input);
		console.warn(_message);
		if (throwTokens.includes(token)) throw new RangeError(_message);
	}
	function message(token, format, input) {
		const subject = token[0] === "Y" ? "years" : "days of the month";
		return `Use \`${token.toLowerCase()}\` instead of \`${token}\` (in \`${format}\`) for formatting ${subject} to the input \`${input}\`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md`;
	}
	//#endregion
	//#region node_modules/date-fns/isDate.js
	/**
	* @name isDate
	* @category Common Helpers
	* @summary Is the given value a date?
	*
	* @description
	* Returns true if the given value is an instance of Date. The function works for dates transferred across iframes.
	*
	* @param value - The value to check
	*
	* @returns True if the given value is a date
	*
	* @example
	* // For a valid date:
	* const result = isDate(new Date())
	* //=> true
	*
	* @example
	* // For an invalid date:
	* const result = isDate(new Date(NaN))
	* //=> true
	*
	* @example
	* // For some value:
	* const result = isDate('2014-02-31')
	* //=> false
	*
	* @example
	* // For an object:
	* const result = isDate({})
	* //=> false
	*/
	function isDate(value) {
		return value instanceof Date || typeof value === "object" && Object.prototype.toString.call(value) === "[object Date]";
	}
	//#endregion
	//#region node_modules/date-fns/isValid.js
	/**
	* @name isValid
	* @category Common Helpers
	* @summary Is the given date valid?
	*
	* @description
	* Returns false if argument is Invalid Date and true otherwise.
	* Argument is converted to Date using `toDate`. See [toDate](https://date-fns.org/docs/toDate)
	* Invalid Date is a Date, whose time value is NaN.
	*
	* Time value of Date: http://es5.github.io/#x15.9.1.1
	*
	* @param date - The date to check
	*
	* @returns The date is valid
	*
	* @example
	* // For the valid date:
	* const result = isValid(new Date(2014, 1, 31))
	* //=> true
	*
	* @example
	* // For the value, convertible into a date:
	* const result = isValid(1393804800000)
	* //=> true
	*
	* @example
	* // For the invalid date:
	* const result = isValid(new Date(''))
	* //=> false
	*/
	function isValid(date) {
		return !(!isDate(date) && typeof date !== "number" || isNaN(+toDate(date)));
	}
	//#endregion
	//#region node_modules/date-fns/format.js
	var formattingTokensRegExp = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g;
	var longFormattingTokensRegExp = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g;
	var escapedStringRegExp = /^'([^]*?)'?$/;
	var doubleQuoteRegExp = /''/g;
	var unescapedLatinCharacterRegExp = /[a-zA-Z]/;
	/**
	* The {@link format} function options.
	*/
	/**
	* @name format
	* @alias formatDate
	* @category Common Helpers
	* @summary Format the date.
	*
	* @description
	* Return the formatted date string in the given format. The result may vary by locale.
	*
	* > ⚠️ Please note that the `format` tokens differ from Moment.js and other libraries.
	* > See: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
	*
	* The characters wrapped between two single quotes characters (') are escaped.
	* Two single quotes in a row, whether inside or outside a quoted sequence, represent a 'real' single quote.
	* (see the last example)
	*
	* Format of the string is based on Unicode Technical Standard #35:
	* https://www.unicode.org/reports/tr35/tr35-dates.html#Date_Field_Symbol_Table
	* with a few additions (see note 7 below the table).
	*
	* Accepted patterns:
	* | Unit                            | Pattern | Result examples                   | Notes |
	* |---------------------------------|---------|-----------------------------------|-------|
	* | Era                             | G..GGG  | AD, BC                            |       |
	* |                                 | GGGG    | Anno Domini, Before Christ        | 2     |
	* |                                 | GGGGG   | A, B                              |       |
	* | Calendar year                   | y       | 44, 1, 1900, 2017                 | 5     |
	* |                                 | yo      | 44th, 1st, 0th, 17th              | 5,7   |
	* |                                 | yy      | 44, 01, 00, 17                    | 5     |
	* |                                 | yyy     | 044, 001, 1900, 2017              | 5     |
	* |                                 | yyyy    | 0044, 0001, 1900, 2017            | 5     |
	* |                                 | yyyyy   | ...                               | 3,5   |
	* | Local week-numbering year       | Y       | 44, 1, 1900, 2017                 | 5     |
	* |                                 | Yo      | 44th, 1st, 1900th, 2017th         | 5,7   |
	* |                                 | YY      | 44, 01, 00, 17                    | 5,8   |
	* |                                 | YYY     | 044, 001, 1900, 2017              | 5     |
	* |                                 | YYYY    | 0044, 0001, 1900, 2017            | 5,8   |
	* |                                 | YYYYY   | ...                               | 3,5   |
	* | ISO week-numbering year         | R       | -43, 0, 1, 1900, 2017             | 5,7   |
	* |                                 | RR      | -43, 00, 01, 1900, 2017           | 5,7   |
	* |                                 | RRR     | -043, 000, 001, 1900, 2017        | 5,7   |
	* |                                 | RRRR    | -0043, 0000, 0001, 1900, 2017     | 5,7   |
	* |                                 | RRRRR   | ...                               | 3,5,7 |
	* | Extended year                   | u       | -43, 0, 1, 1900, 2017             | 5     |
	* |                                 | uu      | -43, 01, 1900, 2017               | 5     |
	* |                                 | uuu     | -043, 001, 1900, 2017             | 5     |
	* |                                 | uuuu    | -0043, 0001, 1900, 2017           | 5     |
	* |                                 | uuuuu   | ...                               | 3,5   |
	* | Quarter (formatting)            | Q       | 1, 2, 3, 4                        |       |
	* |                                 | Qo      | 1st, 2nd, 3rd, 4th                | 7     |
	* |                                 | QQ      | 01, 02, 03, 04                    |       |
	* |                                 | QQQ     | Q1, Q2, Q3, Q4                    |       |
	* |                                 | QQQQ    | 1st quarter, 2nd quarter, ...     | 2     |
	* |                                 | QQQQQ   | 1, 2, 3, 4                        | 4     |
	* | Quarter (stand-alone)           | q       | 1, 2, 3, 4                        |       |
	* |                                 | qo      | 1st, 2nd, 3rd, 4th                | 7     |
	* |                                 | qq      | 01, 02, 03, 04                    |       |
	* |                                 | qqq     | Q1, Q2, Q3, Q4                    |       |
	* |                                 | qqqq    | 1st quarter, 2nd quarter, ...     | 2     |
	* |                                 | qqqqq   | 1, 2, 3, 4                        | 4     |
	* | Month (formatting)              | M       | 1, 2, ..., 12                     |       |
	* |                                 | Mo      | 1st, 2nd, ..., 12th               | 7     |
	* |                                 | MM      | 01, 02, ..., 12                   |       |
	* |                                 | MMM     | Jan, Feb, ..., Dec                |       |
	* |                                 | MMMM    | January, February, ..., December  | 2     |
	* |                                 | MMMMM   | J, F, ..., D                      |       |
	* | Month (stand-alone)             | L       | 1, 2, ..., 12                     |       |
	* |                                 | Lo      | 1st, 2nd, ..., 12th               | 7     |
	* |                                 | LL      | 01, 02, ..., 12                   |       |
	* |                                 | LLL     | Jan, Feb, ..., Dec                |       |
	* |                                 | LLLL    | January, February, ..., December  | 2     |
	* |                                 | LLLLL   | J, F, ..., D                      |       |
	* | Local week of year              | w       | 1, 2, ..., 53                     |       |
	* |                                 | wo      | 1st, 2nd, ..., 53th               | 7     |
	* |                                 | ww      | 01, 02, ..., 53                   |       |
	* | ISO week of year                | I       | 1, 2, ..., 53                     | 7     |
	* |                                 | Io      | 1st, 2nd, ..., 53th               | 7     |
	* |                                 | II      | 01, 02, ..., 53                   | 7     |
	* | Day of month                    | d       | 1, 2, ..., 31                     |       |
	* |                                 | do      | 1st, 2nd, ..., 31st               | 7     |
	* |                                 | dd      | 01, 02, ..., 31                   |       |
	* | Day of year                     | D       | 1, 2, ..., 365, 366               | 9     |
	* |                                 | Do      | 1st, 2nd, ..., 365th, 366th       | 7     |
	* |                                 | DD      | 01, 02, ..., 365, 366             | 9     |
	* |                                 | DDD     | 001, 002, ..., 365, 366           |       |
	* |                                 | DDDD    | ...                               | 3     |
	* | Day of week (formatting)        | E..EEE  | Mon, Tue, Wed, ..., Sun           |       |
	* |                                 | EEEE    | Monday, Tuesday, ..., Sunday      | 2     |
	* |                                 | EEEEE   | M, T, W, T, F, S, S               |       |
	* |                                 | EEEEEE  | Mo, Tu, We, Th, Fr, Sa, Su        |       |
	* | ISO day of week (formatting)    | i       | 1, 2, 3, ..., 7                   | 7     |
	* |                                 | io      | 1st, 2nd, ..., 7th                | 7     |
	* |                                 | ii      | 01, 02, ..., 07                   | 7     |
	* |                                 | iii     | Mon, Tue, Wed, ..., Sun           | 7     |
	* |                                 | iiii    | Monday, Tuesday, ..., Sunday      | 2,7   |
	* |                                 | iiiii   | M, T, W, T, F, S, S               | 7     |
	* |                                 | iiiiii  | Mo, Tu, We, Th, Fr, Sa, Su        | 7     |
	* | Local day of week (formatting)  | e       | 2, 3, 4, ..., 1                   |       |
	* |                                 | eo      | 2nd, 3rd, ..., 1st                | 7     |
	* |                                 | ee      | 02, 03, ..., 01                   |       |
	* |                                 | eee     | Mon, Tue, Wed, ..., Sun           |       |
	* |                                 | eeee    | Monday, Tuesday, ..., Sunday      | 2     |
	* |                                 | eeeee   | M, T, W, T, F, S, S               |       |
	* |                                 | eeeeee  | Mo, Tu, We, Th, Fr, Sa, Su        |       |
	* | Local day of week (stand-alone) | c       | 2, 3, 4, ..., 1                   |       |
	* |                                 | co      | 2nd, 3rd, ..., 1st                | 7     |
	* |                                 | cc      | 02, 03, ..., 01                   |       |
	* |                                 | ccc     | Mon, Tue, Wed, ..., Sun           |       |
	* |                                 | cccc    | Monday, Tuesday, ..., Sunday      | 2     |
	* |                                 | ccccc   | M, T, W, T, F, S, S               |       |
	* |                                 | cccccc  | Mo, Tu, We, Th, Fr, Sa, Su        |       |
	* | AM, PM                          | a..aa   | AM, PM                            |       |
	* |                                 | aaa     | am, pm                            |       |
	* |                                 | aaaa    | a.m., p.m.                        | 2     |
	* |                                 | aaaaa   | a, p                              |       |
	* | AM, PM, noon, midnight          | b..bb   | AM, PM, noon, midnight            |       |
	* |                                 | bbb     | am, pm, noon, midnight            |       |
	* |                                 | bbbb    | a.m., p.m., noon, midnight        | 2     |
	* |                                 | bbbbb   | a, p, n, mi                       |       |
	* | Flexible day period             | B..BBB  | at night, in the morning, ...     |       |
	* |                                 | BBBB    | at night, in the morning, ...     | 2     |
	* |                                 | BBBBB   | at night, in the morning, ...     |       |
	* | Hour [1-12]                     | h       | 1, 2, ..., 11, 12                 |       |
	* |                                 | ho      | 1st, 2nd, ..., 11th, 12th         | 7     |
	* |                                 | hh      | 01, 02, ..., 11, 12               |       |
	* | Hour [0-23]                     | H       | 0, 1, 2, ..., 23                  |       |
	* |                                 | Ho      | 0th, 1st, 2nd, ..., 23rd          | 7     |
	* |                                 | HH      | 00, 01, 02, ..., 23               |       |
	* | Hour [0-11]                     | K       | 1, 2, ..., 11, 0                  |       |
	* |                                 | Ko      | 1st, 2nd, ..., 11th, 0th          | 7     |
	* |                                 | KK      | 01, 02, ..., 11, 00               |       |
	* | Hour [1-24]                     | k       | 24, 1, 2, ..., 23                 |       |
	* |                                 | ko      | 24th, 1st, 2nd, ..., 23rd         | 7     |
	* |                                 | kk      | 24, 01, 02, ..., 23               |       |
	* | Minute                          | m       | 0, 1, ..., 59                     |       |
	* |                                 | mo      | 0th, 1st, ..., 59th               | 7     |
	* |                                 | mm      | 00, 01, ..., 59                   |       |
	* | Second                          | s       | 0, 1, ..., 59                     |       |
	* |                                 | so      | 0th, 1st, ..., 59th               | 7     |
	* |                                 | ss      | 00, 01, ..., 59                   |       |
	* | Fraction of second              | S       | 0, 1, ..., 9                      |       |
	* |                                 | SS      | 00, 01, ..., 99                   |       |
	* |                                 | SSS     | 000, 001, ..., 999                |       |
	* |                                 | SSSS    | ...                               | 3     |
	* | Timezone (ISO-8601 w/ Z)        | X       | -08, +0530, Z                     |       |
	* |                                 | XX      | -0800, +0530, Z                   |       |
	* |                                 | XXX     | -08:00, +05:30, Z                 |       |
	* |                                 | XXXX    | -0800, +0530, Z, +123456          | 2     |
	* |                                 | XXXXX   | -08:00, +05:30, Z, +12:34:56      |       |
	* | Timezone (ISO-8601 w/o Z)       | x       | -08, +0530, +00                   |       |
	* |                                 | xx      | -0800, +0530, +0000               |       |
	* |                                 | xxx     | -08:00, +05:30, +00:00            | 2     |
	* |                                 | xxxx    | -0800, +0530, +0000, +123456      |       |
	* |                                 | xxxxx   | -08:00, +05:30, +00:00, +12:34:56 |       |
	* | Timezone (GMT)                  | O...OOO | GMT-8, GMT+5:30, GMT+0            |       |
	* |                                 | OOOO    | GMT-08:00, GMT+05:30, GMT+00:00   | 2     |
	* | Timezone (specific non-locat.)  | z...zzz | GMT-8, GMT+5:30, GMT+0            | 6     |
	* |                                 | zzzz    | GMT-08:00, GMT+05:30, GMT+00:00   | 2,6   |
	* | Seconds timestamp               | t       | 512969520                         | 7     |
	* |                                 | tt      | ...                               | 3,7   |
	* | Milliseconds timestamp          | T       | 512969520900                      | 7     |
	* |                                 | TT      | ...                               | 3,7   |
	* | Long localized date             | P       | 04/29/1453                        | 7     |
	* |                                 | PP      | Apr 29, 1453                      | 7     |
	* |                                 | PPP     | April 29th, 1453                  | 7     |
	* |                                 | PPPP    | Friday, April 29th, 1453          | 2,7   |
	* | Long localized time             | p       | 12:00 AM                          | 7     |
	* |                                 | pp      | 12:00:00 AM                       | 7     |
	* |                                 | ppp     | 12:00:00 AM GMT+2                 | 7     |
	* |                                 | pppp    | 12:00:00 AM GMT+02:00             | 2,7   |
	* | Combination of date and time    | Pp      | 04/29/1453, 12:00 AM              | 7     |
	* |                                 | PPpp    | Apr 29, 1453, 12:00:00 AM         | 7     |
	* |                                 | PPPppp  | April 29th, 1453 at ...           | 7     |
	* |                                 | PPPPpppp| Friday, April 29th, 1453 at ...   | 2,7   |
	* Notes:
	* 1. "Formatting" units (e.g. formatting quarter) in the default en-US locale
	*    are the same as "stand-alone" units, but are different in some languages.
	*    "Formatting" units are declined according to the rules of the language
	*    in the context of a date. "Stand-alone" units are always nominative singular:
	*
	*    `format(new Date(2017, 10, 6), 'do LLLL', {locale: cs}) //=> '6. listopad'`
	*
	*    `format(new Date(2017, 10, 6), 'do MMMM', {locale: cs}) //=> '6. listopadu'`
	*
	* 2. Any sequence of the identical letters is a pattern, unless it is escaped by
	*    the single quote characters (see below).
	*    If the sequence is longer than listed in table (e.g. `EEEEEEEEEEE`)
	*    the output will be the same as default pattern for this unit, usually
	*    the longest one (in case of ISO weekdays, `EEEE`). Default patterns for units
	*    are marked with "2" in the last column of the table.
	*
	*    `format(new Date(2017, 10, 6), 'MMM') //=> 'Nov'`
	*
	*    `format(new Date(2017, 10, 6), 'MMMM') //=> 'November'`
	*
	*    `format(new Date(2017, 10, 6), 'MMMMM') //=> 'N'`
	*
	*    `format(new Date(2017, 10, 6), 'MMMMMM') //=> 'November'`
	*
	*    `format(new Date(2017, 10, 6), 'MMMMMMM') //=> 'November'`
	*
	* 3. Some patterns could be unlimited length (such as `yyyyyyyy`).
	*    The output will be padded with zeros to match the length of the pattern.
	*
	*    `format(new Date(2017, 10, 6), 'yyyyyyyy') //=> '00002017'`
	*
	* 4. `QQQQQ` and `qqqqq` could be not strictly numerical in some locales.
	*    These tokens represent the shortest form of the quarter.
	*
	* 5. The main difference between `y` and `u` patterns are B.C. years:
	*
	*    | Year | `y` | `u` |
	*    |------|-----|-----|
	*    | AC 1 |   1 |   1 |
	*    | BC 1 |   1 |   0 |
	*    | BC 2 |   2 |  -1 |
	*
	*    Also `yy` always returns the last two digits of a year,
	*    while `uu` pads single digit years to 2 characters and returns other years unchanged:
	*
	*    | Year | `yy` | `uu` |
	*    |------|------|------|
	*    | 1    |   01 |   01 |
	*    | 14   |   14 |   14 |
	*    | 376  |   76 |  376 |
	*    | 1453 |   53 | 1453 |
	*
	*    The same difference is true for local and ISO week-numbering years (`Y` and `R`),
	*    except local week-numbering years are dependent on `options.weekStartsOn`
	*    and `options.firstWeekContainsDate` (compare [getISOWeekYear](https://date-fns.org/docs/getISOWeekYear)
	*    and [getWeekYear](https://date-fns.org/docs/getWeekYear)).
	*
	* 6. Specific non-location timezones are currently unavailable in `date-fns`,
	*    so right now these tokens fall back to GMT timezones.
	*
	* 7. These patterns are not in the Unicode Technical Standard #35:
	*    - `i`: ISO day of week
	*    - `I`: ISO week of year
	*    - `R`: ISO week-numbering year
	*    - `t`: seconds timestamp
	*    - `T`: milliseconds timestamp
	*    - `o`: ordinal number modifier
	*    - `P`: long localized date
	*    - `p`: long localized time
	*
	* 8. `YY` and `YYYY` tokens represent week-numbering years but they are often confused with years.
	*    You should enable `options.useAdditionalWeekYearTokens` to use them. See: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
	*
	* 9. `D` and `DD` tokens represent days of the year but they are often confused with days of the month.
	*    You should enable `options.useAdditionalDayOfYearTokens` to use them. See: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
	*
	* @param date - The original date
	* @param format - The string of tokens
	* @param options - An object with options
	*
	* @returns The formatted date string
	*
	* @throws `date` must not be Invalid Date
	* @throws `options.locale` must contain `localize` property
	* @throws `options.locale` must contain `formatLong` property
	* @throws use `yyyy` instead of `YYYY` for formatting years using [format provided] to the input [input provided]; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
	* @throws use `yy` instead of `YY` for formatting years using [format provided] to the input [input provided]; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
	* @throws use `d` instead of `D` for formatting days of the month using [format provided] to the input [input provided]; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
	* @throws use `dd` instead of `DD` for formatting days of the month using [format provided] to the input [input provided]; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
	* @throws format string contains an unescaped latin alphabet character
	*
	* @example
	* // Represent 11 February 2014 in middle-endian format:
	* const result = format(new Date(2014, 1, 11), 'MM/dd/yyyy')
	* //=> '02/11/2014'
	*
	* @example
	* // Represent 2 July 2014 in Esperanto:
	* import { eoLocale } from 'date-fns/locale/eo'
	* const result = format(new Date(2014, 6, 2), "do 'de' MMMM yyyy", {
	*   locale: eoLocale
	* })
	* //=> '2-a de julio 2014'
	*
	* @example
	* // Escape string by single quote characters:
	* const result = format(new Date(2014, 6, 2, 15), "h 'o''clock'")
	* //=> "3 o'clock"
	*/
	function format(date, formatStr, options) {
		var _ref, _options$locale, _ref2, _ref3, _ref4, _options$firstWeekCon, _options$locale2, _defaultOptions$local, _ref5, _ref6, _ref7, _options$weekStartsOn, _options$locale3, _defaultOptions$local2;
		const defaultOptions = getDefaultOptions();
		const locale = (_ref = (_options$locale = options === null || options === void 0 ? void 0 : options.locale) !== null && _options$locale !== void 0 ? _options$locale : defaultOptions.locale) !== null && _ref !== void 0 ? _ref : enUS;
		const firstWeekContainsDate = (_ref2 = (_ref3 = (_ref4 = (_options$firstWeekCon = options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) !== null && _options$firstWeekCon !== void 0 ? _options$firstWeekCon : options === null || options === void 0 || (_options$locale2 = options.locale) === null || _options$locale2 === void 0 || (_options$locale2 = _options$locale2.options) === null || _options$locale2 === void 0 ? void 0 : _options$locale2.firstWeekContainsDate) !== null && _ref4 !== void 0 ? _ref4 : defaultOptions.firstWeekContainsDate) !== null && _ref3 !== void 0 ? _ref3 : (_defaultOptions$local = defaultOptions.locale) === null || _defaultOptions$local === void 0 || (_defaultOptions$local = _defaultOptions$local.options) === null || _defaultOptions$local === void 0 ? void 0 : _defaultOptions$local.firstWeekContainsDate) !== null && _ref2 !== void 0 ? _ref2 : 1;
		const weekStartsOn = (_ref5 = (_ref6 = (_ref7 = (_options$weekStartsOn = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn !== void 0 ? _options$weekStartsOn : options === null || options === void 0 || (_options$locale3 = options.locale) === null || _options$locale3 === void 0 || (_options$locale3 = _options$locale3.options) === null || _options$locale3 === void 0 ? void 0 : _options$locale3.weekStartsOn) !== null && _ref7 !== void 0 ? _ref7 : defaultOptions.weekStartsOn) !== null && _ref6 !== void 0 ? _ref6 : (_defaultOptions$local2 = defaultOptions.locale) === null || _defaultOptions$local2 === void 0 || (_defaultOptions$local2 = _defaultOptions$local2.options) === null || _defaultOptions$local2 === void 0 ? void 0 : _defaultOptions$local2.weekStartsOn) !== null && _ref5 !== void 0 ? _ref5 : 0;
		const originalDate = toDate(date, options === null || options === void 0 ? void 0 : options.in);
		if (!isValid(originalDate)) throw new RangeError("Invalid time value");
		let parts = formatStr.match(longFormattingTokensRegExp).map((substring) => {
			const firstCharacter = substring[0];
			if (firstCharacter === "p" || firstCharacter === "P") {
				const longFormatter = longFormatters[firstCharacter];
				return longFormatter(substring, locale.formatLong);
			}
			return substring;
		}).join("").match(formattingTokensRegExp).map((substring) => {
			if (substring === "''") return {
				isToken: false,
				value: "'"
			};
			const firstCharacter = substring[0];
			if (firstCharacter === "'") return {
				isToken: false,
				value: cleanEscapedString(substring)
			};
			if (formatters[firstCharacter]) return {
				isToken: true,
				value: substring
			};
			if (firstCharacter.match(unescapedLatinCharacterRegExp)) throw new RangeError("Format string contains an unescaped latin alphabet character `" + firstCharacter + "`");
			return {
				isToken: false,
				value: substring
			};
		});
		if (locale.localize.preprocessor) parts = locale.localize.preprocessor(originalDate, parts);
		const formatterOptions = {
			firstWeekContainsDate,
			weekStartsOn,
			locale
		};
		return parts.map((part) => {
			if (!part.isToken) return part.value;
			const token = part.value;
			if (!(options === null || options === void 0 ? void 0 : options.useAdditionalWeekYearTokens) && isProtectedWeekYearToken(token) || !(options === null || options === void 0 ? void 0 : options.useAdditionalDayOfYearTokens) && isProtectedDayOfYearToken(token)) warnOrThrowProtectedError(token, formatStr, String(date));
			const formatter = formatters[token[0]];
			return formatter(originalDate, token, locale.localize, formatterOptions);
		}).join("");
	}
	function cleanEscapedString(input) {
		const matched = input.match(escapedStringRegExp);
		if (!matched) return input;
		return matched[1].replace(doubleQuoteRegExp, "'");
	}
	//#endregion
	//#region node_modules/date-fns/parseISO.js
	/**
	* The {@link parseISO} function options.
	*/
	/**
	* @name parseISO
	* @category Common Helpers
	* @summary Parse ISO string
	*
	* @description
	* Parse the given string in ISO 8601 format and return an instance of Date.
	*
	* Function accepts complete ISO 8601 formats as well as partial implementations.
	* ISO 8601: http://en.wikipedia.org/wiki/ISO_8601
	*
	* If the argument isn't a string, the function cannot parse the string or
	* the values are invalid, it returns Invalid Date.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param argument - The value to convert
	* @param options - An object with options
	*
	* @returns The parsed date in the local time zone
	*
	* @example
	* // Convert string '2014-02-11T11:30:30' to date:
	* const result = parseISO('2014-02-11T11:30:30')
	* //=> Tue Feb 11 2014 11:30:30
	*
	* @example
	* // Convert string '+02014101' to date,
	* // if the additional number of digits in the extended year format is 1:
	* const result = parseISO('+02014101', { additionalDigits: 1 })
	* //=> Fri Apr 11 2014 00:00:00
	*/
	function parseISO(argument, options) {
		var _options$additionalDi;
		const invalidDate = () => constructFrom(options === null || options === void 0 ? void 0 : options.in, NaN);
		const additionalDigits = (_options$additionalDi = options === null || options === void 0 ? void 0 : options.additionalDigits) !== null && _options$additionalDi !== void 0 ? _options$additionalDi : 2;
		const dateStrings = splitDateString(argument);
		let date;
		if (dateStrings.date) {
			const parseYearResult = parseYear(dateStrings.date, additionalDigits);
			date = parseDate(parseYearResult.restDateString, parseYearResult.year);
		}
		if (!date || isNaN(+date)) return invalidDate();
		const timestamp = +date;
		let time = 0;
		let offset;
		if (dateStrings.time) {
			time = parseTime(dateStrings.time);
			if (isNaN(time)) return invalidDate();
		}
		if (dateStrings.timezone) {
			offset = parseTimezone(dateStrings.timezone);
			if (isNaN(offset)) return invalidDate();
		} else {
			const tmpDate = new Date(timestamp + time);
			const result = toDate(0, options === null || options === void 0 ? void 0 : options.in);
			result.setFullYear(tmpDate.getUTCFullYear(), tmpDate.getUTCMonth(), tmpDate.getUTCDate());
			result.setHours(tmpDate.getUTCHours(), tmpDate.getUTCMinutes(), tmpDate.getUTCSeconds(), tmpDate.getUTCMilliseconds());
			return result;
		}
		return toDate(timestamp + time + offset, options === null || options === void 0 ? void 0 : options.in);
	}
	var patterns = {
		dateTimeDelimiter: /[T ]/,
		timeZoneDelimiter: /[Z ]/i,
		timezone: /([Z+-].*)$/
	};
	var dateRegex = /^-?(?:(\d{3})|(\d{2})(?:-?(\d{2}))?|W(\d{2})(?:-?(\d{1}))?|)$/;
	var timeRegex = /^(\d{2}(?:[.,]\d*)?)(?::?(\d{2}(?:[.,]\d*)?))?(?::?(\d{2}(?:[.,]\d*)?))?$/;
	var timezoneRegex = /^([+-])(\d{2})(?::?(\d{2}))?$/;
	function splitDateString(dateString) {
		const dateStrings = {};
		const array = dateString.split(patterns.dateTimeDelimiter);
		let timeString;
		if (array.length > 2) return dateStrings;
		if (/:/.test(array[0])) timeString = array[0];
		else {
			dateStrings.date = array[0];
			timeString = array[1];
			if (patterns.timeZoneDelimiter.test(dateStrings.date)) {
				dateStrings.date = dateString.split(patterns.timeZoneDelimiter)[0];
				timeString = dateString.substr(dateStrings.date.length, dateString.length);
			}
		}
		if (timeString) {
			const token = patterns.timezone.exec(timeString);
			if (token) {
				dateStrings.time = timeString.replace(token[1], "");
				dateStrings.timezone = token[1];
			} else dateStrings.time = timeString;
		}
		return dateStrings;
	}
	function parseYear(dateString, additionalDigits) {
		const regex = new RegExp("^(?:(\\d{4}|[+-]\\d{" + (4 + additionalDigits) + "})|(\\d{2}|[+-]\\d{" + (2 + additionalDigits) + "})$)");
		const captures = dateString.match(regex);
		if (!captures) return {
			year: NaN,
			restDateString: ""
		};
		const year = captures[1] ? parseInt(captures[1]) : null;
		const century = captures[2] ? parseInt(captures[2]) : null;
		return {
			year: century === null ? year : century * 100,
			restDateString: dateString.slice((captures[1] || captures[2]).length)
		};
	}
	function parseDate(dateString, year) {
		if (year === null) return /* @__PURE__ */ new Date(NaN);
		const captures = dateString.match(dateRegex);
		if (!captures) return /* @__PURE__ */ new Date(NaN);
		const isWeekDate = !!captures[4];
		const dayOfYear = parseDateUnit(captures[1]);
		const month = parseDateUnit(captures[2]) - 1;
		const day = parseDateUnit(captures[3]);
		const week = parseDateUnit(captures[4]);
		const dayOfWeek = parseDateUnit(captures[5]) - 1;
		if (isWeekDate) {
			if (!validateWeekDate(year, week, dayOfWeek)) return /* @__PURE__ */ new Date(NaN);
			return dayOfISOWeekYear(year, week, dayOfWeek);
		} else {
			const date = /* @__PURE__ */ new Date(0);
			if (!validateDate(year, month, day) || !validateDayOfYearDate(year, dayOfYear)) return /* @__PURE__ */ new Date(NaN);
			date.setUTCFullYear(year, month, Math.max(dayOfYear, day));
			return date;
		}
	}
	function parseDateUnit(value) {
		return value ? parseInt(value) : 1;
	}
	function parseTime(timeString) {
		const captures = timeString.match(timeRegex);
		if (!captures) return NaN;
		const hours = parseTimeUnit(captures[1]);
		const minutes = parseTimeUnit(captures[2]);
		const seconds = parseTimeUnit(captures[3]);
		if (!validateTime(hours, minutes, seconds)) return NaN;
		return hours * millisecondsInHour + minutes * millisecondsInMinute + seconds * 1e3;
	}
	function parseTimeUnit(value) {
		return value && parseFloat(value.replace(",", ".")) || 0;
	}
	function parseTimezone(timezoneString) {
		if (timezoneString === "Z") return 0;
		const captures = timezoneString.match(timezoneRegex);
		if (!captures) return 0;
		const sign = captures[1] === "+" ? -1 : 1;
		const hours = parseInt(captures[2]);
		const minutes = captures[3] && parseInt(captures[3]) || 0;
		if (!validateTimezone(hours, minutes)) return NaN;
		return sign * (hours * millisecondsInHour + minutes * millisecondsInMinute);
	}
	function dayOfISOWeekYear(isoWeekYear, week, day) {
		const date = /* @__PURE__ */ new Date(0);
		date.setUTCFullYear(isoWeekYear, 0, 4);
		const fourthOfJanuaryDay = date.getUTCDay() || 7;
		const diff = (week - 1) * 7 + day + 1 - fourthOfJanuaryDay;
		date.setUTCDate(date.getUTCDate() + diff);
		return date;
	}
	var daysInMonths = [
		31,
		null,
		31,
		30,
		31,
		30,
		31,
		31,
		30,
		31,
		30,
		31
	];
	function isLeapYearIndex(year) {
		return year % 400 === 0 || year % 4 === 0 && year % 100 !== 0;
	}
	function validateDate(year, month, date) {
		return month >= 0 && month <= 11 && date >= 1 && date <= (daysInMonths[month] || (isLeapYearIndex(year) ? 29 : 28));
	}
	function validateDayOfYearDate(year, dayOfYear) {
		return dayOfYear >= 1 && dayOfYear <= (isLeapYearIndex(year) ? 366 : 365);
	}
	function validateWeekDate(_year, week, day) {
		return week >= 1 && week <= 53 && day >= 0 && day <= 6;
	}
	function validateTime(hours, minutes, seconds) {
		if (hours === 24) return minutes === 0 && seconds === 0;
		return seconds >= 0 && seconds < 60 && minutes >= 0 && minutes < 60 && hours >= 0 && hours < 25;
	}
	function validateTimezone(_hours, minutes) {
		return minutes >= 0 && minutes <= 59;
	}
	//#endregion
	//#region node_modules/date-fns/startOfToday.js
	/**
	* The {@link startOfToday} function options.
	*/
	/**
	* @name startOfToday
	* @category Day Helpers
	* @summary Return the start of today.
	* @pure false
	*
	* @description
	* Return the start of today.
	*
	* @typeParam ContextDate - The `Date` type of the context function.
	*
	* @param options - An object with options
	*
	* @returns The start of today
	*
	* @example
	* // If today is 6 October 2014:
	* const result = startOfToday()
	* //=> Mon Oct 6 2014 00:00:00
	*/
	function startOfToday(options) {
		return startOfDay(Date.now(), options);
	}
	//#endregion
	//#region node_modules/date-fns/startOfYesterday.js
	/**
	* The {@link startOfYesterday} function options.
	*/
	/**
	* @name startOfYesterday
	* @category Day Helpers
	* @summary Return the start of yesterday.
	* @pure false
	*
	* @typeParam ContextDate - The `Date` type of the context function.
	*
	* @param options - An object with options
	*
	* @description
	* Return the start of yesterday.
	*
	* @returns The start of yesterday
	*
	* @example
	* // If today is 6 October 2014:
	* const result = startOfYesterday()
	* //=> Sun Oct 5 2014 00:00:00
	*/
	function startOfYesterday(options) {
		const now = constructNow(options === null || options === void 0 ? void 0 : options.in);
		const year = now.getFullYear();
		const month = now.getMonth();
		const day = now.getDate();
		const date = constructNow(options === null || options === void 0 ? void 0 : options.in);
		date.setFullYear(year, month, day - 1);
		date.setHours(0, 0, 0, 0);
		return date;
	}
	//#endregion
	//#region node_modules/date-fns/subDays.js
	/**
	* The {@link subDays} function options.
	*/
	/**
	* @name subDays
	* @category Day Helpers
	* @summary Subtract the specified number of days from the given date.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The date to be changed
	* @param amount - The amount of days to be subtracted.
	* @param options - An object with options
	*
	* @returns The new date with the days subtracted
	*
	* @example
	* // Subtract 10 days from 1 September 2014:
	* const result = subDays(new Date(2014, 8, 1), 10)
	* //=> Fri Aug 22 2014 00:00:00
	*/
	function subDays(date, amount, options) {
		return addDays(date, -amount, options);
	}
	//#endregion
	//#region node_modules/date-fns/subMonths.js
	/**
	* The subMonths function options.
	*/
	/**
	* @name subMonths
	* @category Month Helpers
	* @summary Subtract the specified number of months from the given date.
	*
	* @description
	* Subtract the specified number of months from the given date.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The date to be changed
	* @param amount - The amount of months to be subtracted.
	* @param options - An object with options
	*
	* @returns The new date with the months subtracted
	*
	* @example
	* // Subtract 5 months from 1 February 2015:
	* const result = subMonths(new Date(2015, 1, 1), 5)
	* //=> Mon Sep 01 2014 00:00:00
	*/
	function subMonths(date, amount, options) {
		return addMonths(date, -amount, options);
	}
	//#endregion
	//#region node_modules/date-fns/subWeeks.js
	/**
	* The {@link subWeeks} function options.
	*/
	/**
	* @name subWeeks
	* @category Week Helpers
	* @summary Subtract the specified number of weeks from the given date.
	*
	* @description
	* Subtract the specified number of weeks from the given date.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The date to be changed
	* @param amount - The amount of weeks to be subtracted.
	* @param options - An object with options
	*
	* @returns The new date with the weeks subtracted
	*
	* @example
	* // Subtract 4 weeks from 1 September 2014:
	* const result = subWeeks(new Date(2014, 8, 1), 4)
	* //=> Mon Aug 04 2014 00:00:00
	*/
	function subWeeks(date, amount, options) {
		return addWeeks(date, -amount, options);
	}
	//#endregion
	//#region node_modules/date-fns/subYears.js
	/**
	* The {@link subYears} function options.
	*/
	/**
	* @name subYears
	* @category Year Helpers
	* @summary Subtract the specified number of years from the given date.
	*
	* @description
	* Subtract the specified number of years from the given date.
	*
	* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
	* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
	*
	* @param date - The date to be changed
	* @param amount - The amount of years to be subtracted.
	* @param options - An object with options
	*
	* @returns The new date with the years subtracted
	*
	* @example
	* // Subtract 5 years from 1 September 2014:
	* const result = subYears(new Date(2014, 8, 1), 5)
	* //=> Tue Sep 01 2009 00:00:00
	*/
	function subYears(date, amount, options) {
		return addYears(date, -amount, options);
	}
	//#endregion
	//#region entrypoints/background/tools/browser/history.ts
	init_defineProperty();
	init_asyncToGenerator();
	var HistoryTool = class HistoryTool extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.HISTORY);
		}
		/**
		* Parse a date string into milliseconds since epoch.
		* Returns null if the date string is invalid.
		* Supports:
		*  - ISO date strings (e.g., "2023-10-31", "2023-10-31T14:30:00.000Z")
		*  - Relative times: "1 day ago", "2 weeks ago", "3 months ago", "1 year ago"
		*  - Special keywords: "now", "today", "yesterday"
		*/
		parseDateString(dateStr) {
			if (!dateStr) return null;
			const now = /* @__PURE__ */ new Date();
			const lowerDateStr = dateStr.toLowerCase().trim();
			if (lowerDateStr === "now") return now.getTime();
			if (lowerDateStr === "today") return startOfToday().getTime();
			if (lowerDateStr === "yesterday") return startOfYesterday().getTime();
			const relativeMatch = lowerDateStr.match(/^(\d+)\s+(day|days|week|weeks|month|months|year|years)\s+ago$/);
			if (relativeMatch) {
				const amount = parseInt(relativeMatch[1], 10);
				const unit = relativeMatch[2];
				let resultDate;
				if (unit.startsWith("day")) resultDate = subDays(now, amount);
				else if (unit.startsWith("week")) resultDate = subWeeks(now, amount);
				else if (unit.startsWith("month")) resultDate = subMonths(now, amount);
				else if (unit.startsWith("year")) resultDate = subYears(now, amount);
				else return null;
				return resultDate.getTime();
			}
			let parsedDate = parseISO(dateStr);
			if (isValid(parsedDate)) return parsedDate.getTime();
			parsedDate = new Date(dateStr);
			if (isValid(parsedDate) && dateStr.includes(parsedDate.getFullYear().toString())) return parsedDate.getTime();
			console.warn(`Could not parse date string: ${dateStr}`);
			return null;
		}
		/**
		* Format a timestamp as a human-readable date string
		*/
		formatDate(timestamp) {
			return format(timestamp, "yyyy-MM-dd HH:mm:ss");
		}
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				try {
					console.log("Executing HistoryTool with args:", args);
					const { text = "", maxResults = 100, excludeCurrentTabs = false } = args;
					const now = Date.now();
					let startTimeMs;
					let endTimeMs;
					if (args.startTime) {
						const parsedStart = _this.parseDateString(args.startTime);
						if (parsedStart === null) return createErrorResponse(`Invalid format for start time: "${args.startTime}". Supported formats: ISO (YYYY-MM-DD), "today", "yesterday", "X days/weeks/months/years ago".`);
						startTimeMs = parsedStart;
					} else startTimeMs = now - HistoryTool.ONE_DAY_MS;
					if (args.endTime) {
						const parsedEnd = _this.parseDateString(args.endTime);
						if (parsedEnd === null) return createErrorResponse(`Invalid format for end time: "${args.endTime}". Supported formats: ISO (YYYY-MM-DD), "today", "yesterday", "X days/weeks/months/years ago".`);
						endTimeMs = parsedEnd;
					} else endTimeMs = now;
					if (startTimeMs > endTimeMs) return createErrorResponse("Start time cannot be after end time.");
					console.log(`Searching history from ${_this.formatDate(startTimeMs)} to ${_this.formatDate(endTimeMs)} for query "${text}"`);
					const historyItems = yield chrome.history.search({
						text,
						startTime: startTimeMs,
						endTime: endTimeMs,
						maxResults
					});
					console.log(`Found ${historyItems.length} history items before filtering current tabs.`);
					let filteredItems = historyItems;
					if (excludeCurrentTabs && historyItems.length > 0) {
						const currentTabs = yield chrome.tabs.query({});
						const openUrls = /* @__PURE__ */ new Set();
						currentTabs.forEach((tab) => {
							if (tab.url) openUrls.add(tab.url);
						});
						if (openUrls.size > 0) {
							filteredItems = historyItems.filter((item) => !(item.url && openUrls.has(item.url)));
							console.log(`Filtered out ${historyItems.length - filteredItems.length} items that are currently open. ${filteredItems.length} items remaining.`);
						}
					}
					const result = {
						items: filteredItems.map((item) => ({
							id: item.id,
							url: item.url,
							title: item.title,
							lastVisitTime: item.lastVisitTime,
							visitCount: item.visitCount,
							typedCount: item.typedCount
						})),
						totalCount: filteredItems.length,
						timeRange: {
							startTime: startTimeMs,
							endTime: endTimeMs,
							startTimeFormatted: _this.formatDate(startTimeMs),
							endTimeFormatted: _this.formatDate(endTimeMs)
						}
					};
					if (text) result.query = text;
					return {
						content: [{
							type: "text",
							text: JSON.stringify(result, null, 2)
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in HistoryTool.execute:", error);
					return createErrorResponse(`Error retrieving browsing history: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	_defineProperty(HistoryTool, "ONE_DAY_MS", 1440 * 60 * 1e3);
	var historyTool = new HistoryTool();
	//#endregion
	//#region utils/i18n.ts
	/**
	* Chrome Extension i18n utility
	* Provides safe access to chrome.i18n.getMessage with fallbacks
	*/
	var fallbackMessages = {
		extensionName: "chrome-mcp-server",
		extensionDescription: "Exposes browser capabilities with your own chrome",
		nativeServerConfigLabel: "Native Server Configuration",
		semanticEngineLabel: "Semantic Engine",
		embeddingModelLabel: "Embedding Model",
		indexDataManagementLabel: "Index Data Management",
		modelCacheManagementLabel: "Model Cache Management",
		statusLabel: "Status",
		runningStatusLabel: "Running Status",
		connectionStatusLabel: "Connection Status",
		lastUpdatedLabel: "Last Updated:",
		connectButton: "Connect",
		disconnectButton: "Disconnect",
		connectingStatus: "Connecting...",
		connectedStatus: "Connected",
		disconnectedStatus: "Disconnected",
		detectingStatus: "Detecting...",
		serviceRunningStatus: "Service Running (Port: {0})",
		serviceNotConnectedStatus: "Service Not Connected",
		connectedServiceNotStartedStatus: "Connected, Service Not Started",
		mcpServerConfigLabel: "MCP Server Configuration",
		connectionPortLabel: "Connection Port",
		refreshStatusButton: "Refresh Status",
		copyConfigButton: "Copy Configuration",
		retryButton: "Retry",
		cancelButton: "Cancel",
		confirmButton: "Confirm",
		saveButton: "Save",
		closeButton: "Close",
		resetButton: "Reset",
		initializingStatus: "Initializing...",
		processingStatus: "Processing...",
		loadingStatus: "Loading...",
		clearingStatus: "Clearing...",
		cleaningStatus: "Cleaning...",
		downloadingStatus: "Downloading...",
		semanticEngineReadyStatus: "Semantic Engine Ready",
		semanticEngineInitializingStatus: "Semantic Engine Initializing...",
		semanticEngineInitFailedStatus: "Semantic Engine Initialization Failed",
		semanticEngineNotInitStatus: "Semantic Engine Not Initialized",
		initSemanticEngineButton: "Initialize Semantic Engine",
		reinitializeButton: "Reinitialize",
		downloadingModelStatus: "Downloading Model... {0}%",
		switchingModelStatus: "Switching Model...",
		modelLoadedStatus: "Model Loaded",
		modelFailedStatus: "Model Failed to Load",
		lightweightModelDescription: "Lightweight Multilingual Model",
		betterThanSmallDescription: "Slightly larger than e5-small, but better performance",
		multilingualModelDescription: "Multilingual Semantic Model",
		fastPerformance: "Fast",
		balancedPerformance: "Balanced",
		accuratePerformance: "Accurate",
		networkErrorMessage: "Network connection error, please check network and retry",
		modelCorruptedErrorMessage: "Model file corrupted or incomplete, please retry download",
		unknownErrorMessage: "Unknown error, please check if your network can access HuggingFace",
		permissionDeniedErrorMessage: "Permission denied",
		timeoutErrorMessage: "Operation timed out",
		indexedPagesLabel: "Indexed Pages",
		indexSizeLabel: "Index Size",
		activeTabsLabel: "Active Tabs",
		vectorDocumentsLabel: "Vector Documents",
		cacheSizeLabel: "Cache Size",
		cacheEntriesLabel: "Cache Entries",
		clearAllDataButton: "Clear All Data",
		clearAllCacheButton: "Clear All Cache",
		cleanExpiredCacheButton: "Clean Expired Cache",
		exportDataButton: "Export Data",
		importDataButton: "Import Data",
		confirmClearDataTitle: "Confirm Clear Data",
		settingsTitle: "Settings",
		aboutTitle: "About",
		helpTitle: "Help",
		clearDataWarningMessage: "This operation will clear all indexed webpage content and vector data, including:",
		clearDataList1: "All webpage text content index",
		clearDataList2: "Vector embedding data",
		clearDataList3: "Search history and cache",
		clearDataIrreversibleWarning: "This operation is irreversible! After clearing, you need to browse webpages again to rebuild the index.",
		confirmClearButton: "Confirm Clear",
		cacheDetailsLabel: "Cache Details",
		noCacheDataMessage: "No cache data",
		loadingCacheInfoStatus: "Loading cache information...",
		processingCacheStatus: "Processing cache...",
		expiredLabel: "Expired",
		bookmarksBarLabel: "Bookmarks Bar",
		newTabLabel: "New Tab",
		currentPageLabel: "Current Page",
		menuLabel: "Menu",
		navigationLabel: "Navigation",
		mainContentLabel: "Main Content",
		languageSelectorLabel: "Language",
		themeLabel: "Theme",
		lightTheme: "Light",
		darkTheme: "Dark",
		autoTheme: "Auto",
		advancedSettingsLabel: "Advanced Settings",
		debugModeLabel: "Debug Mode",
		verboseLoggingLabel: "Verbose Logging",
		successNotification: "Operation completed successfully",
		warningNotification: "Warning: Please review before proceeding",
		infoNotification: "Information",
		configCopiedNotification: "Configuration copied to clipboard",
		dataClearedNotification: "Data cleared successfully",
		bytesUnit: "bytes",
		kilobytesUnit: "KB",
		megabytesUnit: "MB",
		gigabytesUnit: "GB",
		itemsUnit: "items",
		pagesUnit: "pages",
		nativeServerConfig: "Native Server Configuration",
		runningStatus: "Running Status",
		refreshStatus: "Refresh Status",
		lastUpdated: "Last Updated:",
		mcpServerConfig: "MCP Server Configuration",
		connectionPort: "Connection Port",
		connecting: "Connecting...",
		disconnect: "Disconnect",
		connect: "Connect",
		semanticEngine: "Semantic Engine",
		embeddingModel: "Embedding Model",
		retry: "Retry",
		indexDataManagement: "Index Data Management",
		clearing: "Clearing...",
		clearAllData: "Clear All Data",
		copyConfig: "Copy Configuration",
		serviceRunning: "Service Running (Port: {0})",
		connectedServiceNotStarted: "Connected, Service Not Started",
		serviceNotConnected: "Service Not Connected",
		detecting: "Detecting...",
		lightweightModel: "Lightweight Multilingual Model",
		betterThanSmall: "Slightly larger than e5-small, but better performance",
		multilingualModel: "Multilingual Semantic Model",
		fast: "Fast",
		balanced: "Balanced",
		accurate: "Accurate",
		semanticEngineReady: "Semantic Engine Ready",
		semanticEngineInitializing: "Semantic Engine Initializing...",
		semanticEngineInitFailed: "Semantic Engine Initialization Failed",
		semanticEngineNotInit: "Semantic Engine Not Initialized",
		downloadingModel: "Downloading Model... {0}%",
		switchingModel: "Switching Model...",
		networkError: "Network connection error, please check network and retry",
		modelCorrupted: "Model file corrupted or incomplete, please retry download",
		unknownError: "Unknown error, please check if your network can access HuggingFace",
		reinitialize: "Reinitialize",
		initializing: "Initializing...",
		initSemanticEngine: "Initialize Semantic Engine",
		indexedPages: "Indexed Pages",
		indexSize: "Index Size",
		activeTabs: "Active Tabs",
		vectorDocuments: "Vector Documents",
		confirmClearData: "Confirm Clear Data",
		clearDataWarning: "This operation will clear all indexed webpage content and vector data, including:",
		clearDataIrreversible: "This operation is irreversible! After clearing, you need to browse webpages again to rebuild the index.",
		confirmClear: "Confirm Clear",
		cancel: "Cancel",
		confirm: "Confirm",
		processing: "Processing...",
		modelCacheManagement: "Model Cache Management",
		cacheSize: "Cache Size",
		cacheEntries: "Cache Entries",
		cacheDetails: "Cache Details",
		noCacheData: "No cache data",
		loadingCacheInfo: "Loading cache information...",
		processingCache: "Processing cache...",
		cleaning: "Cleaning...",
		cleanExpiredCache: "Clean Expired Cache",
		clearAllCache: "Clear All Cache",
		expired: "Expired",
		bookmarksBar: "Bookmarks Bar"
	};
	/**
	* Safe i18n message getter with fallback support
	* @param key Message key
	* @param substitutions Optional substitution values
	* @returns Localized message or fallback
	*/
	function getMessage(key, substitutions) {
		try {
			if (typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage) {
				const message = chrome.i18n.getMessage(key, substitutions);
				if (message) return message;
			}
		} catch (error) {
			console.warn(`Failed to get i18n message for key "${key}":`, error);
		}
		let fallback = fallbackMessages[key] || key;
		if (substitutions && substitutions.length > 0) substitutions.forEach((value, index) => {
			fallback = fallback.replace(`{${index}}`, value);
		});
		return fallback;
	}
	//#endregion
	//#region entrypoints/background/tools/browser/bookmark.ts
	init_asyncToGenerator();
	init_defineProperty();
	/**
	* Get the complete folder path of a bookmark
	* @param bookmarkNodeId ID of the bookmark or folder
	* @returns Returns folder path string (e.g., "Bookmarks Bar > Folder A > Subfolder B")
	*/
	function getBookmarkFolderPath(_x) {
		return _getBookmarkFolderPath.apply(this, arguments);
	}
	function _getBookmarkFolderPath() {
		_getBookmarkFolderPath = _asyncToGenerator(function* (bookmarkNodeId) {
			const pathParts = [];
			try {
				const initialNodes = yield chrome.bookmarks.get(bookmarkNodeId);
				if (initialNodes.length > 0 && initialNodes[0]) {
					let pathNodeId = initialNodes[0].parentId;
					while (pathNodeId) {
						const parentNodes = yield chrome.bookmarks.get(pathNodeId);
						if (parentNodes.length === 0) break;
						const parentNode = parentNodes[0];
						if (parentNode.title) pathParts.unshift(parentNode.title);
						if (!parentNode.parentId) break;
						pathNodeId = parentNode.parentId;
					}
				}
			} catch (error) {
				console.error(`Error getting bookmark path for node ID ${bookmarkNodeId}:`, error);
				return pathParts.join(" > ") || "Error getting path";
			}
			return pathParts.join(" > ");
		});
		return _getBookmarkFolderPath.apply(this, arguments);
	}
	/**
	* Find bookmark folder by ID or path string
	* If it's an ID, validate it
	* If it's a path string, try to parse it
	* @param pathOrId Path string (e.g., "Work/Projects") or folder ID
	* @returns Returns folder node, or null if not found
	*/
	function findFolderByPathOrId(_x2) {
		return _findFolderByPathOrId.apply(this, arguments);
	}
	function _findFolderByPathOrId() {
		_findFolderByPathOrId = _asyncToGenerator(function* (pathOrId) {
			try {
				const nodes = yield chrome.bookmarks.get(pathOrId);
				if (nodes && nodes.length > 0 && !nodes[0].url) return nodes[0];
			} catch (e) {}
			const pathParts = pathOrId.split("/").map((p) => p.trim()).filter((p) => p.length > 0);
			if (pathParts.length === 0) return null;
			let currentNodes = yield chrome.bookmarks.getChildren("0");
			let foundFolder = null;
			for (let i = 0; i < pathParts.length; i++) {
				const part = pathParts[i];
				foundFolder = null;
				let matchedNodeThisLevel = null;
				for (const node of currentNodes) if (!node.url && node.title.toLowerCase() === part.toLowerCase()) {
					matchedNodeThisLevel = node;
					break;
				}
				if (matchedNodeThisLevel) if (i === pathParts.length - 1) foundFolder = matchedNodeThisLevel;
				else currentNodes = yield chrome.bookmarks.getChildren(matchedNodeThisLevel.id);
				else return null;
			}
			return foundFolder;
		});
		return _findFolderByPathOrId.apply(this, arguments);
	}
	/**
	* Create folder path (if it doesn't exist)
	* @param folderPath Folder path string (e.g., "Work/Projects/Subproject")
	* @param parentId Optional parent folder ID, defaults to "Bookmarks Bar"
	* @returns Returns the created or found final folder node
	*/
	function createFolderPath(_x3, _x4) {
		return _createFolderPath.apply(this, arguments);
	}
	function _createFolderPath() {
		_createFolderPath = _asyncToGenerator(function* (folderPath, parentId) {
			const pathParts = folderPath.split("/").map((p) => p.trim()).filter((p) => p.length > 0);
			if (pathParts.length === 0) throw new Error("Folder path cannot be empty");
			let currentParentId = parentId || "";
			if (!currentParentId) {
				const bookmarkBarFolder = (yield chrome.bookmarks.getChildren("0")).find((node) => !node.url && (node.title === getMessage("bookmarksBarLabel") || node.title === "Bookmarks bar" || node.title === "Bookmarks Bar"));
				currentParentId = (bookmarkBarFolder === null || bookmarkBarFolder === void 0 ? void 0 : bookmarkBarFolder.id) || "1";
			}
			let currentFolder = null;
			for (const folderName of pathParts) {
				const existingFolder = (yield chrome.bookmarks.getChildren(currentParentId)).find((child) => !child.url && child.title.toLowerCase() === folderName.toLowerCase());
				if (existingFolder) {
					currentFolder = existingFolder;
					currentParentId = existingFolder.id;
				} else {
					currentFolder = yield chrome.bookmarks.create({
						parentId: currentParentId,
						title: folderName
					});
					currentParentId = currentFolder.id;
				}
			}
			if (!currentFolder) throw new Error("Failed to create folder path");
			return currentFolder;
		});
		return _createFolderPath.apply(this, arguments);
	}
	/**
	* Flatten bookmark tree (or node array) to bookmark list (excluding folders)
	* @param nodes Bookmark tree nodes to flatten
	* @returns Returns actual bookmark node array (nodes with URLs)
	*/
	function flattenBookmarkNodesToBookmarks(nodes) {
		const result = [];
		const stack = [...nodes];
		while (stack.length > 0) {
			const node = stack.pop();
			if (!node) continue;
			if (node.url) result.push(node);
			if (node.children) for (let i = node.children.length - 1; i >= 0; i--) stack.push(node.children[i]);
		}
		return result;
	}
	/**
	* Find bookmarks by URL and title
	* @param url Bookmark URL
	* @param title Optional bookmark title for auxiliary matching
	* @returns Returns array of matching bookmarks
	*/
	function findBookmarksByUrl(_x5, _x6) {
		return _findBookmarksByUrl.apply(this, arguments);
	}
	function _findBookmarksByUrl() {
		_findBookmarksByUrl = _asyncToGenerator(function* (url, title) {
			const searchResults = yield chrome.bookmarks.search({ url });
			if (!title) return searchResults;
			const titleLower = title.toLowerCase();
			return searchResults.filter((bookmark) => bookmark.title && bookmark.title.toLowerCase().includes(titleLower));
		});
		return _findBookmarksByUrl.apply(this, arguments);
	}
	/**
	* Bookmark search tool
	* Used to search bookmarks in Chrome browser
	*/
	var BookmarkSearchTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.BOOKMARK_SEARCH);
		}
		/**
		* Execute bookmark search
		*/
		execute(args) {
			return _asyncToGenerator(function* () {
				const { query = "", maxResults = 50, folderPath } = args;
				console.log(`BookmarkSearchTool: Searching bookmarks, keywords: "${query}", folder path: "${folderPath}"`);
				try {
					let bookmarksToSearch = [];
					let targetFolderNode = null;
					if (folderPath) {
						targetFolderNode = yield findFolderByPathOrId(folderPath);
						if (!targetFolderNode) return createErrorResponse(`Specified folder not found: "${folderPath}"`);
						const subTree = yield chrome.bookmarks.getSubTree(targetFolderNode.id);
						bookmarksToSearch = subTree.length > 0 ? flattenBookmarkNodesToBookmarks(subTree[0].children || []) : [];
					}
					let filteredBookmarks;
					if (query) if (targetFolderNode) {
						const lowerCaseQuery = query.toLowerCase();
						filteredBookmarks = bookmarksToSearch.filter((bookmark) => bookmark.title && bookmark.title.toLowerCase().includes(lowerCaseQuery) || bookmark.url && bookmark.url.toLowerCase().includes(lowerCaseQuery));
					} else {
						filteredBookmarks = yield chrome.bookmarks.search({ query });
						filteredBookmarks = filteredBookmarks.filter((item) => !!item.url);
					}
					else {
						if (!targetFolderNode) bookmarksToSearch = flattenBookmarkNodesToBookmarks(yield chrome.bookmarks.getTree());
						filteredBookmarks = bookmarksToSearch;
					}
					const limitedResults = filteredBookmarks.slice(0, maxResults);
					const resultsWithPath = yield Promise.all(limitedResults.map(function() {
						var _ref = _asyncToGenerator(function* (bookmark) {
							const path = yield getBookmarkFolderPath(bookmark.id);
							return {
								id: bookmark.id,
								title: bookmark.title,
								url: bookmark.url,
								dateAdded: bookmark.dateAdded,
								folderPath: path
							};
						});
						return function(_x7) {
							return _ref.apply(this, arguments);
						};
					}()));
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								totalResults: resultsWithPath.length,
								query: query || null,
								folderSearched: targetFolderNode ? targetFolderNode.title || targetFolderNode.id : "All bookmarks",
								bookmarks: resultsWithPath
							}, null, 2)
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error searching bookmarks:", error);
					return createErrorResponse(`Error searching bookmarks: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	/**
	* Bookmark add tool
	* Used to add new bookmarks to Chrome browser
	*/
	var BookmarkAddTool = class extends BaseBrowserToolExecutor {
		constructor(..._args2) {
			super(..._args2);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.BOOKMARK_ADD);
		}
		/**
		* Execute add bookmark operation
		*/
		execute(args) {
			return _asyncToGenerator(function* () {
				const { url, title, parentId, createFolder = false } = args;
				console.log(`BookmarkAddTool: Adding bookmark, options:`, args);
				try {
					let bookmarkUrl = url;
					let bookmarkTitle = title;
					if (!bookmarkUrl) {
						const tabs = yield chrome.tabs.query({
							active: true,
							currentWindow: true
						});
						if (!tabs[0] || !tabs[0].url) return createErrorResponse("No active tab with valid URL found, and no URL provided");
						bookmarkUrl = tabs[0].url;
						if (!bookmarkTitle) bookmarkTitle = tabs[0].title || bookmarkUrl;
					}
					if (!bookmarkUrl) return createErrorResponse("URL is required to create bookmark");
					let actualParentId = void 0;
					if (parentId) {
						let folderNode = yield findFolderByPathOrId(parentId);
						if (!folderNode && createFolder) try {
							folderNode = yield createFolderPath(parentId);
						} catch (createError) {
							return createErrorResponse(`Failed to create folder path: ${createError instanceof Error ? createError.message : String(createError)}`);
						}
						if (folderNode) actualParentId = folderNode.id;
						else try {
							const nodes = yield chrome.bookmarks.get(parentId);
							if (nodes && nodes.length > 0 && !nodes[0].url) actualParentId = nodes[0].id;
							else return createErrorResponse(`Specified parent folder (ID/path: "${parentId}") not found or is not a folder${createFolder ? ", and creation failed" : ". You can set createFolder=true to auto-create folders"}`);
						} catch (e) {
							return createErrorResponse(`Specified parent folder (ID/path: "${parentId}") not found or invalid${createFolder ? ", and creation failed" : ". You can set createFolder=true to auto-create folders"}`);
						}
					} else {
						const bookmarkBarFolder = (yield chrome.bookmarks.getChildren("0")).find((node) => !node.url && (node.title === getMessage("bookmarksBarLabel") || node.title === "Bookmarks bar" || node.title === "Bookmarks Bar"));
						actualParentId = (bookmarkBarFolder === null || bookmarkBarFolder === void 0 ? void 0 : bookmarkBarFolder.id) || "1";
					}
					const newBookmark = yield chrome.bookmarks.create({
						parentId: actualParentId,
						title: bookmarkTitle || bookmarkUrl,
						url: bookmarkUrl
					});
					const path = yield getBookmarkFolderPath(newBookmark.id);
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: "Bookmark added successfully",
								bookmark: {
									id: newBookmark.id,
									title: newBookmark.title,
									url: newBookmark.url,
									dateAdded: newBookmark.dateAdded,
									folderPath: path
								},
								folderCreated: createFolder && parentId ? "Folder created if necessary" : false
							}, null, 2)
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error adding bookmark:", error);
					const errorMessage = error instanceof Error ? error.message : String(error);
					if (errorMessage.includes("Can't bookmark URLs of type")) return createErrorResponse(`Error adding bookmark: Cannot bookmark this type of URL (e.g., chrome:// system pages). ${errorMessage}`);
					return createErrorResponse(`Error adding bookmark: ${errorMessage}`);
				}
			})();
		}
	};
	/**
	* Bookmark delete tool
	* Used to delete bookmarks in Chrome browser
	*/
	var BookmarkDeleteTool = class extends BaseBrowserToolExecutor {
		constructor(..._args3) {
			super(..._args3);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.BOOKMARK_DELETE);
		}
		/**
		* Execute delete bookmark operation
		*/
		execute(args) {
			return _asyncToGenerator(function* () {
				const { bookmarkId, url, title } = args;
				console.log(`BookmarkDeleteTool: Deleting bookmark, options:`, args);
				if (!bookmarkId && !url) return createErrorResponse("Must provide bookmark ID or URL to delete bookmark");
				try {
					let bookmarksToDelete = [];
					if (bookmarkId) try {
						const nodes = yield chrome.bookmarks.get(bookmarkId);
						if (nodes && nodes.length > 0 && nodes[0].url) bookmarksToDelete = nodes;
						else return createErrorResponse(`Bookmark with ID "${bookmarkId}" not found, or the ID does not correspond to a bookmark`);
					} catch (error) {
						return createErrorResponse(`Invalid bookmark ID: "${bookmarkId}"`);
					}
					else if (url) {
						bookmarksToDelete = yield findBookmarksByUrl(url, title);
						if (bookmarksToDelete.length === 0) return createErrorResponse(`No bookmark found with URL "${url}"${title ? ` (title contains: "${title}")` : ""}`);
					}
					const deletedBookmarks = [];
					const errors = [];
					for (const bookmark of bookmarksToDelete) try {
						const path = yield getBookmarkFolderPath(bookmark.id);
						yield chrome.bookmarks.remove(bookmark.id);
						deletedBookmarks.push({
							id: bookmark.id,
							title: bookmark.title,
							url: bookmark.url,
							folderPath: path
						});
					} catch (error) {
						const errorMsg = error instanceof Error ? error.message : String(error);
						errors.push(`Failed to delete bookmark "${bookmark.title}" (ID: ${bookmark.id}): ${errorMsg}`);
					}
					if (deletedBookmarks.length === 0) return createErrorResponse(`Failed to delete bookmarks: ${errors.join("; ")}`);
					const result = {
						success: true,
						message: `Successfully deleted ${deletedBookmarks.length} bookmark(s)`,
						deletedBookmarks
					};
					if (errors.length > 0) {
						result.partialSuccess = true;
						result.errors = errors;
					}
					return {
						content: [{
							type: "text",
							text: JSON.stringify(result, null, 2)
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error deleting bookmark:", error);
					return createErrorResponse(`Error deleting bookmark: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var bookmarkSearchTool = new BookmarkSearchTool();
	var bookmarkAddTool = new BookmarkAddTool();
	var bookmarkDeleteTool = new BookmarkDeleteTool();
	//#endregion
	//#region entrypoints/background/tools/browser/inject-script.ts
	init_defineProperty();
	init_asyncToGenerator();
	var injectedTabs = /* @__PURE__ */ new Map();
	var InjectScriptTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.INJECT_SCRIPT);
		}
		execute(args) {
			return _asyncToGenerator(function* () {
				try {
					const { url, type, jsScript, tabId, windowId, background } = args;
					let tab;
					if (!type || !jsScript) return createErrorResponse("Param [type] and [jsScript] is required");
					if (typeof tabId === "number") tab = yield chrome.tabs.get(tabId);
					else if (url) {
						console.log(`Checking if URL is already open: ${url}`);
						const matchingTabs = (yield chrome.tabs.query({})).filter((t) => {
							var _t$url;
							return (((_t$url = t.url) === null || _t$url === void 0 ? void 0 : _t$url.endsWith("/")) ? t.url.slice(0, -1) : t.url) === (url.endsWith("/") ? url.slice(0, -1) : url);
						});
						if (matchingTabs.length > 0) {
							tab = matchingTabs[0];
							console.log(`Found existing tab with URL: ${url}, tab ID: ${tab.id}`);
						} else {
							console.log(`No existing tab found with URL: ${url}, creating new tab`);
							tab = yield chrome.tabs.create({
								url,
								active: background === true ? false : true,
								windowId
							});
							console.log("Waiting for page to load...");
							yield new Promise((resolve) => setTimeout(resolve, 3e3));
						}
					} else {
						const tabs = typeof windowId === "number" ? yield chrome.tabs.query({
							active: true,
							windowId
						}) : yield chrome.tabs.query({
							active: true,
							currentWindow: true
						});
						if (!tabs[0]) return createErrorResponse("No active tab found");
						tab = tabs[0];
					}
					if (!tab.id) return createErrorResponse("Tab has no ID");
					if (background !== true) {
						yield chrome.tabs.update(tab.id, { active: true });
						yield chrome.windows.update(tab.windowId, { focused: true });
					}
					const res = yield handleInject(tab.id, _objectSpread2({}, args));
					return {
						content: [{
							type: "text",
							text: JSON.stringify(res)
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in InjectScriptTool.execute:", error);
					return createErrorResponse(`Inject script error: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var SendCommandToInjectScriptTool = class extends BaseBrowserToolExecutor {
		constructor(..._args2) {
			super(..._args2);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.SEND_COMMAND_TO_INJECT_SCRIPT);
		}
		execute(args) {
			return _asyncToGenerator(function* () {
				try {
					const { tabId, eventName, payload } = args;
					if (!eventName) return createErrorResponse("Param [eventName] is required");
					if (tabId) {
						if (!(yield isTabExists(tabId))) return createErrorResponse("The tab:[tabId] is not exists");
					}
					let finalTabId = tabId;
					if (finalTabId === void 0) {
						const tabs = yield chrome.tabs.query({ active: true });
						if (!tabs[0]) return createErrorResponse("No active tab found");
						finalTabId = tabs[0].id;
					}
					if (!finalTabId) return createErrorResponse("No active tab found");
					if (!injectedTabs.has(finalTabId)) throw new Error("No script injected in this tab.");
					const result = yield chrome.tabs.sendMessage(finalTabId, {
						action: eventName,
						payload,
						targetWorld: injectedTabs.get(finalTabId).type
					});
					return {
						content: [{
							type: "text",
							text: JSON.stringify(result)
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in InjectScriptTool.execute:", error);
					return createErrorResponse(`Inject script error: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	function isTabExists(_x) {
		return _isTabExists.apply(this, arguments);
	}
	function _isTabExists() {
		_isTabExists = _asyncToGenerator(function* (tabId) {
			try {
				yield chrome.tabs.get(tabId);
				return true;
			} catch (error) {
				return false;
			}
		});
		return _isTabExists.apply(this, arguments);
	}
	/**
	* @description Handles the injection of user scripts into a specific tab.
	* @param {number} tabId - The ID of the target tab.
	* @param {object} scriptConfig - The configuration object for the script.
	*/
	function handleInject(_x2, _x3) {
		return _handleInject.apply(this, arguments);
	}
	function _handleInject() {
		_handleInject = _asyncToGenerator(function* (tabId, scriptConfig) {
			if (injectedTabs.has(tabId)) {
				console.log(`Tab ${tabId} already has injections. Cleaning up first.`);
				yield handleCleanup(tabId);
			}
			const { type, jsScript } = scriptConfig;
			if (type === ExecutionWorld.MAIN) {
				yield chrome.scripting.executeScript({
					target: { tabId },
					files: ["inject-scripts/inject-bridge.js"],
					world: ExecutionWorld.ISOLATED
				});
				yield chrome.scripting.executeScript({
					target: { tabId },
					func: (code) => new Function(code)(),
					args: [jsScript],
					world: ExecutionWorld.MAIN
				});
			} else yield chrome.scripting.executeScript({
				target: { tabId },
				func: (code) => new Function(code)(),
				args: [jsScript],
				world: ExecutionWorld.ISOLATED
			});
			injectedTabs.set(tabId, scriptConfig);
			console.log(`Scripts successfully injected into tab ${tabId}.`);
			return { injected: true };
		});
		return _handleInject.apply(this, arguments);
	}
	/**
	* @description Triggers the cleanup process in a specific tab.
	* @param {number} tabId - The ID of the target tab.
	*/
	function handleCleanup(_x4) {
		return _handleCleanup.apply(this, arguments);
	}
	function _handleCleanup() {
		_handleCleanup = _asyncToGenerator(function* (tabId) {
			if (!injectedTabs.has(tabId)) return;
			chrome.tabs.sendMessage(tabId, { type: "chrome-mcp:cleanup" }).catch((err) => console.warn(`Could not send cleanup message to tab ${tabId}. It might have been closed.`));
			injectedTabs.delete(tabId);
			console.log(`Cleanup signal sent to tab ${tabId}. State cleared.`);
		});
		return _handleCleanup.apply(this, arguments);
	}
	var injectScriptTool = new InjectScriptTool();
	var sendCommandToInjectScriptTool = new SendCommandToInjectScriptTool();
	chrome.tabs.onRemoved.addListener((tabId) => {
		if (injectedTabs.has(tabId)) {
			console.log(`Tab ${tabId} closed. Cleaning up state.`);
			injectedTabs.delete(tabId);
		}
	});
	//#endregion
	//#region utils/output-sanitizer.ts
	/**
	* Output Sanitizer - output redaction and length limiting utility
	*
	* Provides safe handling of JavaScript execution results:
	* 1. Sensitive info redaction (cookie/token/password etc.)
	* 2. Output length limit (default 50KB)
	* 3. Deep object serialization
	*/
	var DEFAULT_MAX_OUTPUT_BYTES = 50 * 1024;
	var DEFAULT_MAX_DEPTH = 6;
	var DEFAULT_MAX_ARRAY_LENGTH = 200;
	var DEFAULT_MAX_OBJECT_KEYS = 200;
	var DEFAULT_MAX_STRING_LENGTH = 1e4;
	var SENSITIVE_KEY_MARKERS = [
		"cookie",
		"setcookie",
		"authorization",
		"proxyauthorization",
		"bearer",
		"token",
		"accesstoken",
		"refreshtoken",
		"idtoken",
		"password",
		"passwd",
		"pwd",
		"secret",
		"clientsecret",
		"apikey",
		"session",
		"sessionid",
		"sid",
		"csrf",
		"xsrf",
		"credential",
		"privatekey",
		"accesskey",
		"auth",
		"oauth"
	];
	/**
	* Sanitize and limit any value
	*/
	function sanitizeAndLimitOutput(value, options = {}) {
		const maxBytes = normalizePositiveInt$1(options.maxBytes, DEFAULT_MAX_OUTPUT_BYTES);
		const { value: sanitizedValue, redacted } = sanitizeValue(value, {
			maxDepth: normalizePositiveInt$1(options.maxDepth, DEFAULT_MAX_DEPTH),
			maxArrayLength: normalizePositiveInt$1(options.maxArrayLength, DEFAULT_MAX_ARRAY_LENGTH),
			maxObjectKeys: normalizePositiveInt$1(options.maxObjectKeys, DEFAULT_MAX_OBJECT_KEYS),
			maxStringLength: normalizePositiveInt$1(options.maxStringLength, DEFAULT_MAX_STRING_LENGTH)
		});
		const truncated = truncateTextBytes(formatValueForOutput(sanitizedValue), maxBytes);
		return {
			text: truncated.text,
			truncated: truncated.truncated,
			redacted,
			originalBytes: truncated.originalBytes
		};
	}
	/**
	* Sanitize sensitive information from strings
	* References mcp-tools.js sanitization logic, adds Base64/Hex/cookie-query detection
	*/
	function sanitizeText(text) {
		let out = text;
		let redacted = false;
		const replace = (re, replacement) => {
			const next = out.replace(re, replacement);
			if (next !== out) {
				out = next;
				redacted = true;
			}
		};
		if (out.includes("=") && (out.includes(";") || out.includes("&"))) {
			if (looksLikeCookieString(out)) return {
				text: "[BLOCKED: Cookie/query string data]",
				redacted: true
			};
			if (looksLikeQueryString(out)) return {
				text: "[BLOCKED: Cookie/query string data]",
				redacted: true
			};
		}
		if (/^[A-Za-z0-9+/]{20,}={0,2}$/.test(out)) return {
			text: "[BLOCKED: Base64 encoded data]",
			redacted: true
		};
		if (/^[a-f0-9]{32,}$/i.test(out)) return {
			text: "[BLOCKED: Hex credential]",
			redacted: true
		};
		replace(/\bBearer\s+([A-Za-z0-9._~+/=-]+)\b/gi, "Bearer <redacted>");
		replace(/\b[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g, "<redacted_jwt>");
		replace(/(^|[?&])(access_token|refresh_token|id_token|token|api_key|apikey|password|passwd|pwd|secret|session|sid|credential|auth|oauth)=([^&#\s]+)/gi, (_m, p1, p2) => `${p1}${p2}=<redacted>`);
		replace(/\b(authorization|cookie|set-cookie|x-api-key|api_key|apikey|password|passwd|pwd|secret|token|access_token|refresh_token|id_token|session|sid|credential|private_key|oauth)\b\s*[:=]\s*([^\s,;"']+)/gi, (_m, key) => `${key}=<redacted>`);
		replace(/\b[A-Za-z0-9+/]{40,}={0,2}\b/g, "<redacted_base64>");
		replace(/\b[a-f0-9]{40,}\b/gi, "<redacted_hex>");
		return {
			text: out,
			redacted
		};
	}
	/**
	* Detect if string looks like a query string (key=value&key2=value2)
	*/
	function looksLikeQueryString(text) {
		const s = (text || "").trim();
		if (!s || !s.includes("=") || !s.includes("&")) return false;
		const parts = s.split("&");
		if (parts.length < 2) return false;
		let pairs = 0;
		for (const part of parts) if (part.indexOf("=") > 0) pairs += 1;
		return pairs >= 2;
	}
	function sanitizeValue(value, limits) {
		const { maxDepth, maxArrayLength, maxObjectKeys, maxStringLength } = limits;
		const seen = /* @__PURE__ */ new WeakMap();
		let redacted = false;
		const walk = (v, depth) => {
			if (depth < 0) return "[MaxDepth]";
			if (typeof v === "string") {
				const sanitized = sanitizeText(v);
				if (sanitized.redacted) redacted = true;
				let s = sanitized.text;
				if (s.length > maxStringLength) s = `${s.slice(0, maxStringLength)}... [truncated ${s.length - maxStringLength} chars]`;
				return s;
			}
			if (v === null || typeof v === "number" || typeof v === "boolean" || typeof v === "bigint" || typeof v === "undefined") return v;
			if (typeof v === "symbol") return v.toString();
			if (typeof v === "function") return `[Function${v.name ? `: ${v.name}` : ""}]`;
			if (typeof v !== "object") return String(v);
			const obj = v;
			if (seen.has(obj)) return "[Circular]";
			if (Array.isArray(obj)) {
				const out = [];
				seen.set(obj, out);
				const len = Math.min(obj.length, maxArrayLength);
				for (let i = 0; i < len; i++) out.push(walk(obj[i], depth - 1));
				if (obj.length > maxArrayLength) out.push("[...truncated]");
				return out;
			}
			const out = {};
			seen.set(obj, out);
			const keys = Object.keys(obj);
			const len = Math.min(keys.length, maxObjectKeys);
			for (let i = 0; i < len; i++) {
				const key = keys[i];
				if (isSensitiveKey(key)) {
					out[key] = "<redacted>";
					redacted = true;
					continue;
				}
				out[key] = walk(obj[key], depth - 1);
			}
			if (keys.length > maxObjectKeys) out.__truncated__ = true;
			return out;
		};
		return {
			value: walk(value, maxDepth),
			redacted
		};
	}
	function isSensitiveKey(key) {
		const normalized = normalizeKey(key);
		return SENSITIVE_KEY_MARKERS.some((marker) => normalized.includes(marker));
	}
	function normalizeKey(key) {
		return (key || "").toLowerCase().replace(/[^a-z0-9]/g, "");
	}
	/**
	* Detect if string looks like a cookie string (key=value; key2=value2)
	*/
	function looksLikeCookieString(text) {
		const s = (text || "").trim();
		if (!s) return false;
		if (!s.includes("=") || !s.includes(";")) return false;
		const parts = s.split(";");
		if (parts.length < 2) return false;
		let pairs = 0;
		for (const part of parts) if (part.indexOf("=") > 0) pairs += 1;
		return pairs >= 2;
	}
	function formatValueForOutput(value) {
		if (typeof value === "string") return value;
		if (typeof value === "undefined") return "undefined";
		try {
			return safeJsonStringify(value);
		} catch (_unused) {
			return String(value);
		}
	}
	function safeJsonStringify(value) {
		const seen = /* @__PURE__ */ new WeakSet();
		return JSON.stringify(value, (_key, val) => {
			if (typeof val === "bigint") return `${val.toString()}n`;
			if (typeof val === "symbol") return val.toString();
			if (typeof val === "function") return `[Function${val.name ? `: ${val.name}` : ""}]`;
			if (val && typeof val === "object") {
				if (seen.has(val)) return "[Circular]";
				seen.add(val);
			}
			return val;
		});
	}
	function truncateTextBytes(text, maxBytes) {
		const originalBytes = byteLength(text);
		if (originalBytes <= maxBytes) return {
			text,
			truncated: false,
			originalBytes
		};
		const suffix = `\n... [truncated to ${maxBytes} bytes; original ${originalBytes} bytes]`;
		const suffixBytes = byteLength(suffix);
		const budget = Math.max(0, maxBytes - suffixBytes);
		let lo = 0;
		let hi = text.length;
		while (lo < hi) {
			const mid = Math.ceil((lo + hi) / 2);
			if (byteLength(text.slice(0, mid)) <= budget) lo = mid;
			else hi = mid - 1;
		}
		return {
			text: text.slice(0, lo) + suffix,
			truncated: true,
			originalBytes
		};
	}
	function byteLength(text) {
		try {
			return new TextEncoder().encode(text).length;
		} catch (_unused2) {
			return text.length;
		}
	}
	function normalizePositiveInt$1(value, fallback) {
		return Math.max(1, typeof value === "number" && Number.isFinite(value) ? Math.floor(value) : fallback);
	}
	//#endregion
	//#region entrypoints/background/tools/browser/javascript.ts
	/**
	* JavaScript Tool - CDP Runtime.evaluate with fallback
	*
	* Execute JavaScript in the browser tab and return the result.
	* - Primary: CDP Runtime.evaluate (supports awaitPromise + returnByValue)
	* - Fallback: chrome.scripting.executeScript (when debugger is busy)
	*
	* Features:
	* - Async code support (top-level await via async wrapper)
	* - Output sanitization (sensitive data redaction)
	* - Output truncation (configurable max bytes)
	* - Timeout handling
	* - Detailed error classification
	*/
	init_cdp_session_manager();
	init_asyncToGenerator();
	init_defineProperty();
	var DEFAULT_TIMEOUT_MS = 15e3;
	var CDP_SESSION_KEY = "javascript";
	var TimeoutError = class extends Error {
		constructor(timeoutMs) {
			super(`Execution timed out after ${timeoutMs}ms`);
			this.name = "TimeoutError";
		}
	};
	function normalizePositiveInt(value, fallback) {
		if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
		return Math.max(1, Math.floor(value));
	}
	function withTimeout(promise, timeoutMs) {
		return new Promise((resolve, reject) => {
			const timer = setTimeout(() => {
				reject(new TimeoutError(timeoutMs));
			}, timeoutMs);
			promise.then(resolve).catch(reject).finally(() => clearTimeout(timer));
		});
	}
	function isTimeoutError(error) {
		return error instanceof Error && error.name === "TimeoutError";
	}
	function isDebuggerConflictError$1(error) {
		const message = error instanceof Error ? error.message : String(error);
		return /Debugger is already attached|Another debugger is already attached|Cannot attach to this target/i.test(message);
	}
	/**
	* Wrap user code in an async IIFE to support top-level await and return statements.
	*/
	function wrapUserCode(code) {
		return `(async () => {\n${code}\n})()`;
	}
	function extractReturnValue(remoteObject) {
		if (!remoteObject) return void 0;
		if ("value" in remoteObject) return remoteObject.value;
		if ("unserializableValue" in remoteObject) return remoteObject.unserializableValue;
		if (typeof remoteObject.description === "string") return remoteObject.description;
	}
	function parseExceptionDetails(details) {
		var _details$exception$cl, _details$exception, _details$exception$de, _details$exception2, _details$exception$va, _details$exception3, _details$text;
		const exceptionClassName = (_details$exception$cl = (_details$exception = details.exception) === null || _details$exception === void 0 ? void 0 : _details$exception.className) !== null && _details$exception$cl !== void 0 ? _details$exception$cl : "";
		const exceptionDescription = (_details$exception$de = (_details$exception2 = details.exception) === null || _details$exception2 === void 0 ? void 0 : _details$exception2.description) !== null && _details$exception$de !== void 0 ? _details$exception$de : "";
		const exceptionValue = (_details$exception$va = (_details$exception3 = details.exception) === null || _details$exception3 === void 0 ? void 0 : _details$exception3.value) !== null && _details$exception$va !== void 0 ? _details$exception$va : "";
		const text = (_details$text = details.text) !== null && _details$text !== void 0 ? _details$text : "";
		const rawMessage = exceptionDescription || exceptionValue || text || "JavaScript execution failed";
		const message = sanitizeText(rawMessage).text;
		return {
			kind: exceptionClassName === "SyntaxError" || /SyntaxError/i.test(rawMessage) ? "syntax_error" : "runtime_error",
			message,
			details: {
				url: details.url,
				lineNumber: details.lineNumber,
				columnNumber: details.columnNumber
			}
		};
	}
	function executeViaCdp(_x, _x2, _x3) {
		return _executeViaCdp.apply(this, arguments);
	}
	function _executeViaCdp() {
		_executeViaCdp = _asyncToGenerator(function* (tabId, code, options) {
			try {
				const expression = wrapUserCode(code);
				const response = yield withTimeout(cdpSessionManager.withSession(tabId, CDP_SESSION_KEY, _asyncToGenerator(function* () {
					return yield cdpSessionManager.sendCommand(tabId, "Runtime.evaluate", {
						expression,
						returnByValue: true,
						awaitPromise: true,
						timeout: options.timeoutMs
					});
				})), options.timeoutMs + 1e3);
				if (response === null || response === void 0 ? void 0 : response.exceptionDetails) return {
					ok: false,
					engine: "cdp",
					error: parseExceptionDetails(response.exceptionDetails)
				};
				const sanitized = sanitizeAndLimitOutput(extractReturnValue(response === null || response === void 0 ? void 0 : response.result), { maxBytes: options.maxOutputBytes });
				return {
					ok: true,
					engine: "cdp",
					output: sanitized.text,
					truncated: sanitized.truncated,
					redacted: sanitized.redacted
				};
			} catch (error) {
				if (isTimeoutError(error)) return {
					ok: false,
					engine: "cdp",
					error: {
						kind: "timeout",
						message: error.message
					}
				};
				if (isDebuggerConflictError$1(error)) return {
					ok: false,
					engine: "cdp",
					error: {
						kind: "debugger_conflict",
						message: sanitizeText(error instanceof Error ? error.message : String(error)).text
					}
				};
				return {
					ok: false,
					engine: "cdp",
					error: {
						kind: "cdp_error",
						message: sanitizeText(error instanceof Error ? error.message : String(error)).text
					}
				};
			}
		});
		return _executeViaCdp.apply(this, arguments);
	}
	function executeViaScripting(_x5, _x6, _x7) {
		return _executeViaScripting.apply(this, arguments);
	}
	function _executeViaScripting() {
		_executeViaScripting = _asyncToGenerator(function* (tabId, code, options) {
			const innerExecute = function() {
				var _ref2 = _asyncToGenerator(function* () {
					const results = yield chrome.scripting.executeScript({
						target: { tabId },
						world: "ISOLATED",
						func: function() {
							var _ref = _asyncToGenerator(function* (userCode) {
								try {
									const AsyncFunction = Object.getPrototypeOf(_asyncToGenerator(function* () {})).constructor;
									return {
										ok: true,
										value: yield new AsyncFunction(userCode)()
									};
								} catch (err) {
									var _error$name, _error$message, _error$stack;
									const error = err;
									return {
										ok: false,
										error: {
											name: (_error$name = error === null || error === void 0 ? void 0 : error.name) !== null && _error$name !== void 0 ? _error$name : void 0,
											message: (_error$message = error === null || error === void 0 ? void 0 : error.message) !== null && _error$message !== void 0 ? _error$message : String(err),
											stack: (_error$stack = error === null || error === void 0 ? void 0 : error.stack) !== null && _error$stack !== void 0 ? _error$stack : void 0
										}
									};
								}
							});
							return function func(_x4) {
								return _ref.apply(this, arguments);
							};
						}(),
						args: [code]
					});
					const firstFrame = results === null || results === void 0 ? void 0 : results[0];
					const result = firstFrame === null || firstFrame === void 0 ? void 0 : firstFrame.result;
					if (!result || typeof result !== "object") return {
						ok: false,
						engine: "scripting",
						error: {
							kind: "scripting_error",
							message: "No result returned from executeScript"
						}
					};
					if (!result.ok) {
						var _result$error$message, _result$error, _result$error2, _result$error3;
						const rawMessage = (_result$error$message = (_result$error = result.error) === null || _result$error === void 0 ? void 0 : _result$error.message) !== null && _result$error$message !== void 0 ? _result$error$message : "JavaScript execution failed";
						const rawStack = (_result$error2 = result.error) === null || _result$error2 === void 0 ? void 0 : _result$error2.stack;
						const message = sanitizeText(rawMessage).text;
						const sanitizedStack = rawStack ? sanitizeText(rawStack).text : void 0;
						return {
							ok: false,
							engine: "scripting",
							error: {
								kind: ((_result$error3 = result.error) === null || _result$error3 === void 0 ? void 0 : _result$error3.name) === "SyntaxError" || /SyntaxError/i.test(rawMessage) ? "syntax_error" : "runtime_error",
								message: sanitizedStack ? `${message}\n${sanitizedStack}` : message
							}
						};
					}
					const sanitized = sanitizeAndLimitOutput(result.value, { maxBytes: options.maxOutputBytes });
					return {
						ok: true,
						engine: "scripting",
						output: sanitized.text,
						truncated: sanitized.truncated,
						redacted: sanitized.redacted
					};
				});
				return function innerExecute() {
					return _ref2.apply(this, arguments);
				};
			}();
			try {
				return yield withTimeout(innerExecute(), options.timeoutMs);
			} catch (error) {
				if (isTimeoutError(error)) return {
					ok: false,
					engine: "scripting",
					error: {
						kind: "timeout",
						message: error.message
					}
				};
				return {
					ok: false,
					engine: "scripting",
					error: {
						kind: "scripting_error",
						message: sanitizeText(error instanceof Error ? error.message : String(error)).text
					}
				};
			}
		});
		return _executeViaScripting.apply(this, arguments);
	}
	var JavaScriptTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.JAVASCRIPT);
		}
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const startTime = performance.now();
				try {
					const code = typeof (args === null || args === void 0 ? void 0 : args.code) === "string" ? args.code.trim() : "";
					if (!code) return createErrorResponse("Parameter [code] is required");
					const tab = yield _this.resolveTargetTab(args.tabId);
					if (!tab) return createErrorResponse(typeof args.tabId === "number" ? `Tab not found: ${args.tabId}` : "No active tab found");
					if (!tab.id) return createErrorResponse("Tab has no ID");
					const tabId = tab.id;
					const options = {
						timeoutMs: normalizePositiveInt(args.timeoutMs, DEFAULT_TIMEOUT_MS),
						maxOutputBytes: normalizePositiveInt(args.maxOutputBytes, DEFAULT_MAX_OUTPUT_BYTES)
					};
					const warnings = [];
					const cdpResult = yield executeViaCdp(tabId, code, options);
					if (cdpResult.ok) return _this.buildSuccessResponse(tabId, cdpResult, startTime);
					if (cdpResult.error.kind !== "debugger_conflict") return _this.buildErrorResponse(tabId, cdpResult, startTime);
					warnings.push("Debugger is busy (DevTools or another extension attached). Falling back to chrome.scripting.executeScript (runs in ISOLATED world, not page context).");
					const scriptingResult = yield executeViaScripting(tabId, code, options);
					if (scriptingResult.ok) return _this.buildSuccessResponse(tabId, scriptingResult, startTime, warnings);
					return _this.buildErrorResponse(tabId, scriptingResult, startTime, warnings);
				} catch (error) {
					console.error("JavaScriptTool.execute error:", error);
					return createErrorResponse(`JavaScript tool error: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
		resolveTargetTab(tabId) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				if (typeof tabId === "number") return _this2.tryGetTab(tabId);
				try {
					return yield _this2.getActiveTabOrThrow();
				} catch (_unused) {
					return null;
				}
			})();
		}
		buildSuccessResponse(tabId, result, startTime, warnings) {
			const payload = {
				success: true,
				tabId,
				engine: result.engine,
				result: result.output,
				truncated: result.truncated || void 0,
				redacted: result.redacted || void 0,
				warnings: (warnings === null || warnings === void 0 ? void 0 : warnings.length) ? warnings : void 0,
				metrics: { elapsedMs: Math.round(performance.now() - startTime) }
			};
			return {
				content: [{
					type: "text",
					text: JSON.stringify(payload)
				}],
				isError: false
			};
		}
		buildErrorResponse(tabId, result, startTime, warnings) {
			const payload = {
				success: false,
				tabId,
				engine: result.engine,
				error: result.error,
				warnings: (warnings === null || warnings === void 0 ? void 0 : warnings.length) ? warnings : void 0,
				metrics: { elapsedMs: Math.round(performance.now() - startTime) }
			};
			return {
				content: [{
					type: "text",
					text: JSON.stringify(payload)
				}],
				isError: true
			};
		}
	};
	var javascriptTool = new JavaScriptTool();
	//#endregion
	//#region entrypoints/background/tools/browser/console-buffer.ts
	init_cdp_session_manager();
	init_defineProperty();
	init_asyncToGenerator();
	/**
	* ConsoleBuffer - Persistent console log buffer manager
	*
	* Maintains a rolling buffer per tab, continuously collecting console events.
	* Automatically clears the buffer when the tab navigates to a new domain,
	* preventing log mixing across different sites.
	*/
	var DEFAULT_MAX_BUFFER_MESSAGES = 2e3;
	var DEFAULT_MAX_BUFFER_EXCEPTIONS = 500;
	function extractHostname(url) {
		if (!url) return "";
		try {
			return new URL(url).hostname;
		} catch (_unused) {
			return "";
		}
	}
	function isErrorLevel$1(level) {
		const normalized = (level || "").toLowerCase();
		return normalized === "error" || normalized === "assert";
	}
	function matchesPattern$1(pattern, text) {
		pattern.lastIndex = 0;
		return pattern.test(text);
	}
	function formatConsoleArgs(args) {
		if (!args || args.length === 0) return "";
		return args.map((arg) => {
			var _a$value, _a$value2;
			const a = arg;
			if (a.type === "string") return a.value || "";
			if (a.type === "number") return String((_a$value = a.value) !== null && _a$value !== void 0 ? _a$value : "");
			if (a.type === "boolean") return String((_a$value2 = a.value) !== null && _a$value2 !== void 0 ? _a$value2 : "");
			if (a.type === "object") return a.description || "[Object]";
			if (a.type === "undefined") return "undefined";
			if (a.type === "function") return a.description || "[Function]";
			return a.description || a.value || String(arg);
		}).join(" ");
	}
	/**
	* Extract safe preview data from CDP RemoteObject, discarding objectId to avoid memory leaks
	*/
	function extractArgPreview(arg) {
		const a = arg;
		if (!a || typeof a !== "object") return arg;
		const preview = { type: a.type };
		if ("value" in a) preview.value = a.value;
		if ("unserializableValue" in a) preview.unserializableValue = a.unserializableValue;
		if ("description" in a) preview.description = a.description;
		if ("subtype" in a) preview.subtype = a.subtype;
		if ("className" in a) preview.className = a.className;
		return preview;
	}
	function safeTimestamp(value) {
		if (typeof value === "number" && Number.isFinite(value)) return value;
		return Date.now();
	}
	function safeString(value) {
		return typeof value === "string" ? value : "";
	}
	function safeNumber(value) {
		return typeof value === "number" ? value : void 0;
	}
	var ConsoleBuffer = class ConsoleBuffer {
		constructor() {
			_defineProperty(this, "buffers", /* @__PURE__ */ new Map());
			_defineProperty(this, "starting", /* @__PURE__ */ new Map());
			if (ConsoleBuffer.instance) return ConsoleBuffer.instance;
			ConsoleBuffer.instance = this;
			chrome.debugger.onEvent.addListener(this.handleDebuggerEvent.bind(this));
			chrome.debugger.onDetach.addListener(this.handleDebuggerDetach.bind(this));
			chrome.tabs.onRemoved.addListener(this.handleTabRemoved.bind(this));
			chrome.tabs.onUpdated.addListener(this.handleTabUpdated.bind(this));
		}
		/**
		* Check if the specified tab is currently capturing in buffer mode
		*/
		isCapturing(tabId) {
			return this.buffers.has(tabId);
		}
		/**
		* Ensure buffer capture has started for the specified tab
		*/
		ensureStarted(tabId) {
			var _this = this;
			return _asyncToGenerator(function* () {
				if (_this.buffers.has(tabId)) return;
				const existing = _this.starting.get(tabId);
				if (existing) return existing;
				const promise = _this.startCapture(tabId).finally(() => {
					_this.starting.delete(tabId);
				});
				_this.starting.set(tabId, promise);
				return promise;
			})();
		}
		/**
		* Clear the buffer for the specified tab
		*/
		clear(tabId, reason = "manual") {
			const state = this.buffers.get(tabId);
			if (!state) return null;
			const clearedMessages = state.messages.length;
			const clearedExceptions = state.exceptions.length;
			state.messages.length = 0;
			state.exceptions.length = 0;
			state.droppedMessageCount = 0;
			state.droppedExceptionCount = 0;
			state.captureStartTime = Date.now();
			console.log(`ConsoleBuffer: Cleared buffer for tab ${tabId} (reason=${reason}). ${clearedMessages} messages, ${clearedExceptions} exceptions.`);
			return {
				clearedMessages,
				clearedExceptions
			};
		}
		/**
		* Read buffer contents for the specified tab
		*/
		read(tabId, options = {}) {
			const state = this.buffers.get(tabId);
			if (!state) return null;
			const { pattern, onlyErrors = false, limit, includeExceptions = true } = options;
			const totalBufferedMessages = state.messages.length;
			const totalBufferedExceptions = state.exceptions.length;
			let messages = state.messages;
			if (onlyErrors) messages = messages.filter((m) => isErrorLevel$1(m.level));
			if (pattern) messages = messages.filter((m) => matchesPattern$1(pattern, m.text || ""));
			messages = [...messages].sort((a, b) => a.timestamp - b.timestamp);
			let messageLimitReached = false;
			const normalizedLimit = typeof limit === "number" && Number.isFinite(limit) ? Math.max(0, Math.floor(limit)) : null;
			if (normalizedLimit !== null && messages.length > normalizedLimit) {
				messageLimitReached = true;
				messages = messages.slice(messages.length - normalizedLimit);
			}
			let exceptions = [];
			if (includeExceptions) {
				exceptions = state.exceptions;
				if (pattern) exceptions = exceptions.filter((e) => matchesPattern$1(pattern, e.text || ""));
				exceptions = [...exceptions].sort((a, b) => a.timestamp - b.timestamp);
			}
			const now = Date.now();
			return {
				tabId,
				tabUrl: state.tabUrl,
				tabTitle: state.tabTitle,
				captureStartTime: state.captureStartTime,
				captureEndTime: now,
				totalDurationMs: now - state.captureStartTime,
				messages,
				exceptions,
				totalBufferedMessages,
				totalBufferedExceptions,
				messageCount: messages.length,
				exceptionCount: exceptions.length,
				messageLimitReached,
				droppedMessageCount: state.droppedMessageCount,
				droppedExceptionCount: state.droppedExceptionCount
			};
		}
		startCapture(tabId) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				const tab = yield chrome.tabs.get(tabId);
				const url = tab.url || "";
				const state = {
					tabId,
					tabUrl: url,
					tabTitle: tab.title || "",
					hostname: extractHostname(url),
					captureStartTime: Date.now(),
					messages: [],
					exceptions: [],
					droppedMessageCount: 0,
					droppedExceptionCount: 0
				};
				_this2.buffers.set(tabId, state);
				try {
					yield cdpSessionManager.attach(tabId, "console-buffer");
					yield cdpSessionManager.sendCommand(tabId, "Runtime.enable");
					yield cdpSessionManager.sendCommand(tabId, "Log.enable");
				} catch (error) {
					_this2.buffers.delete(tabId);
					yield cdpSessionManager.detach(tabId, "console-buffer").catch(() => {});
					throw error;
				}
			})();
		}
		handleTabRemoved(tabId) {
			if (!this.buffers.has(tabId)) return;
			this.stopCapture(tabId, "tab_closed");
		}
		handleTabUpdated(tabId, changeInfo, tab) {
			var _changeInfo$url;
			const state = this.buffers.get(tabId);
			if (!state) return;
			const nextUrl = (_changeInfo$url = changeInfo.url) !== null && _changeInfo$url !== void 0 ? _changeInfo$url : tab.url;
			const nextTitle = tab.title;
			if (typeof nextUrl === "string") {
				const nextHost = extractHostname(nextUrl);
				if (nextHost !== state.hostname) {
					this.clear(tabId, "domain_changed");
					state.hostname = nextHost;
				}
				state.tabUrl = nextUrl;
			}
			if (typeof nextTitle === "string") state.tabTitle = nextTitle;
		}
		handleDebuggerDetach(source, reason) {
			if (typeof source.tabId !== "number") return;
			if (!this.buffers.has(source.tabId)) return;
			console.log(`ConsoleBuffer: Debugger detached from tab ${source.tabId} (reason=${reason}), cleaning up.`);
			this.buffers.delete(source.tabId);
			this.starting.delete(source.tabId);
			cdpSessionManager.detach(source.tabId, "console-buffer").catch(() => {});
		}
		handleDebuggerEvent(source, method, params) {
			const tabId = source.tabId;
			if (typeof tabId !== "number") return;
			const state = this.buffers.get(tabId);
			if (!state) return;
			const p = params;
			if (method === "Log.entryAdded" && (p === null || p === void 0 ? void 0 : p.entry)) {
				const entry = p.entry;
				state.messages.push({
					timestamp: safeTimestamp(entry.timestamp),
					level: safeString(entry.level) || "log",
					text: safeString(entry.text),
					source: safeString(entry.source),
					url: safeString(entry.url),
					lineNumber: safeNumber(entry.lineNumber),
					stackTrace: entry.stackTrace
				});
				this.trimMessages(state);
				return;
			}
			if (method === "Runtime.consoleAPICalled" && p) {
				var _stackTrace$callFrame;
				const stackTrace = p.stackTrace;
				const callFrame = stackTrace === null || stackTrace === void 0 || (_stackTrace$callFrame = stackTrace.callFrames) === null || _stackTrace$callFrame === void 0 ? void 0 : _stackTrace$callFrame[0];
				const rawArgs = p.args || [];
				state.messages.push({
					timestamp: safeTimestamp(p.timestamp),
					level: safeString(p.type) || "log",
					text: formatConsoleArgs(rawArgs),
					source: "console-api",
					url: safeString(callFrame === null || callFrame === void 0 ? void 0 : callFrame.url),
					lineNumber: safeNumber(callFrame === null || callFrame === void 0 ? void 0 : callFrame.lineNumber),
					stackTrace,
					args: rawArgs.map(extractArgPreview)
				});
				this.trimMessages(state);
				return;
			}
			if (method === "Runtime.exceptionThrown" && (p === null || p === void 0 ? void 0 : p.exceptionDetails)) {
				const exceptionDetails = p.exceptionDetails;
				const exception = exceptionDetails.exception;
				state.exceptions.push({
					timestamp: Date.now(),
					text: safeString(exceptionDetails.text) || safeString(exception === null || exception === void 0 ? void 0 : exception.description) || "Unknown exception",
					url: safeString(exceptionDetails.url),
					lineNumber: safeNumber(exceptionDetails.lineNumber),
					columnNumber: safeNumber(exceptionDetails.columnNumber),
					stackTrace: exceptionDetails.stackTrace
				});
				this.trimExceptions(state);
			}
		}
		trimMessages(state) {
			const overflow = state.messages.length - DEFAULT_MAX_BUFFER_MESSAGES;
			if (overflow <= 0) return;
			state.messages.splice(0, overflow);
			state.droppedMessageCount += overflow;
		}
		trimExceptions(state) {
			const overflow = state.exceptions.length - DEFAULT_MAX_BUFFER_EXCEPTIONS;
			if (overflow <= 0) return;
			state.exceptions.splice(0, overflow);
			state.droppedExceptionCount += overflow;
		}
		stopCapture(tabId, reason) {
			var _this3 = this;
			return _asyncToGenerator(function* () {
				if (!_this3.buffers.has(tabId)) return;
				_this3.buffers.delete(tabId);
				_this3.starting.delete(tabId);
				try {
					yield cdpSessionManager.sendCommand(tabId, "Runtime.disable");
				} catch (_unused2) {}
				try {
					yield cdpSessionManager.sendCommand(tabId, "Log.disable");
				} catch (_unused3) {}
				yield cdpSessionManager.detach(tabId, "console-buffer").catch(() => {});
				console.log(`ConsoleBuffer: Stopped buffer for tab ${tabId} (reason=${reason}).`);
			})();
		}
	};
	_defineProperty(ConsoleBuffer, "instance", null);
	var consoleBuffer = new ConsoleBuffer();
	//#endregion
	//#region entrypoints/background/tools/browser/console.ts
	init_cdp_session_manager();
	init_defineProperty();
	init_asyncToGenerator();
	var DEFAULT_MAX_MESSAGES = 100;
	function normalizeLimit(value, fallback) {
		return Math.max(0, typeof value === "number" && Number.isFinite(value) ? Math.floor(value) : fallback);
	}
	function parseRegexPattern(pattern) {
		if (typeof pattern !== "string") return void 0;
		const trimmed = pattern.trim();
		if (!trimmed) return void 0;
		const match = trimmed.match(/^\/(.+)\/([gimsuy]*)$/);
		try {
			return match ? new RegExp(match[1], match[2]) : new RegExp(trimmed);
		} catch (e) {
			const msg = e instanceof Error ? e.message : String(e);
			throw new Error(`Invalid regex pattern: ${msg}`);
		}
	}
	function matchesPattern(pattern, text) {
		pattern.lastIndex = 0;
		return pattern.test(text);
	}
	function isErrorLevel(level) {
		const normalized = (level || "").toLowerCase();
		return normalized === "error" || normalized === "assert";
	}
	function applyResultFilters(result, options) {
		const { pattern, onlyErrors = false, includeExceptions } = options;
		let messages = result.messages;
		if (onlyErrors) messages = messages.filter((m) => isErrorLevel(m.level));
		if (pattern) messages = messages.filter((m) => matchesPattern(pattern, m.text || ""));
		let exceptions = includeExceptions ? result.exceptions : [];
		if (includeExceptions && pattern) exceptions = exceptions.filter((e) => matchesPattern(pattern, e.text || ""));
		return _objectSpread2(_objectSpread2({}, result), {}, {
			messages,
			exceptions,
			messageCount: messages.length,
			exceptionCount: exceptions.length
		});
	}
	function isDebuggerConflictError(error) {
		const msg = (error instanceof Error ? error.message : String(error)).toLowerCase();
		return msg.includes("debugger is already attached") || msg.includes("another client");
	}
	function formatDebuggerConflictMessage(tabId, originalMessage) {
		return `Failed to attach Chrome Debugger to tab ${tabId}: another debugger client is already attached (likely DevTools or another extension). Close DevTools for this tab or disable the conflicting extension, then retry. Original error: ${originalMessage}`;
	}
	/**
	* Tool for capturing console output from browser tabs
	*/
	var ConsoleTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.CONSOLE);
		}
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const { url, tabId, windowId, background = false, includeExceptions = true, maxMessages = DEFAULT_MAX_MESSAGES, mode = "snapshot", buffer, clear = false, clearAfterRead = false, pattern, onlyErrors = false, limit } = args;
				let targetTab;
				let targetTabId;
				let compiledPattern;
				try {
					compiledPattern = parseRegexPattern(pattern);
				} catch (e) {
					return createErrorResponse(e instanceof Error ? e.message : String(e));
				}
				try {
					if (typeof tabId === "number") {
						const t = yield chrome.tabs.get(tabId);
						if (!(t === null || t === void 0 ? void 0 : t.id)) return createErrorResponse("Failed to identify target tab.");
						targetTab = t;
					} else if (url) targetTab = yield _this.navigateToUrl(url, background === true, windowId);
					else {
						const [activeTab] = typeof windowId === "number" ? yield chrome.tabs.query({
							active: true,
							windowId
						}) : yield chrome.tabs.query({
							active: true,
							currentWindow: true
						});
						if (!(activeTab === null || activeTab === void 0 ? void 0 : activeTab.id)) return createErrorResponse("No active tab found and no URL provided.");
						targetTab = activeTab;
					}
					if (!(targetTab === null || targetTab === void 0 ? void 0 : targetTab.id)) return createErrorResponse("Failed to identify target tab.");
					targetTabId = targetTab.id;
					const resolvedMode = mode === "buffer" || buffer === true ? "buffer" : "snapshot";
					const normalizedMaxMessages = normalizeLimit(maxMessages, DEFAULT_MAX_MESSAGES);
					const effectiveLimit = typeof limit === "number" ? normalizeLimit(limit, normalizedMaxMessages) : normalizedMaxMessages;
					if (resolvedMode === "buffer") {
						try {
							yield consoleBuffer.ensureStarted(targetTabId);
						} catch (error) {
							const msg = error instanceof Error ? error.message : String(error);
							if (isDebuggerConflictError(error)) return createErrorResponse(formatDebuggerConflictMessage(targetTabId, msg));
							throw error;
						}
						let clearedBefore = null;
						if (clear === true) clearedBefore = consoleBuffer.clear(targetTabId, "manual");
						const read = consoleBuffer.read(targetTabId, {
							pattern: compiledPattern,
							onlyErrors,
							limit: effectiveLimit,
							includeExceptions
						});
						if (!read) return createErrorResponse("Console buffer is not available for this tab.");
						let clearedAfter = null;
						if (clearAfterRead === true) clearedAfter = consoleBuffer.clear(targetTabId, "manual");
						let clearedSummary = "";
						if (clearedBefore) clearedSummary += ` Cleared ${clearedBefore.clearedMessages} messages and ${clearedBefore.clearedExceptions} exceptions before reading.`;
						if (clearedAfter) clearedSummary += ` Cleared ${clearedAfter.clearedMessages} messages and ${clearedAfter.clearedExceptions} exceptions after reading.`;
						const result = {
							success: true,
							message: `Console buffer read for tab ${targetTabId}.` + clearedSummary + ` Returned ${read.messageCount} messages and ${read.exceptionCount} exceptions.`,
							tabId: targetTabId,
							tabUrl: read.tabUrl || "",
							tabTitle: read.tabTitle || "",
							captureStartTime: read.captureStartTime,
							captureEndTime: read.captureEndTime,
							totalDurationMs: read.totalDurationMs,
							messages: read.messages,
							exceptions: read.exceptions,
							messageCount: read.messageCount,
							exceptionCount: read.exceptionCount,
							messageLimitReached: read.messageLimitReached,
							droppedMessageCount: read.droppedMessageCount,
							droppedExceptionCount: read.droppedExceptionCount
						};
						return {
							content: [{
								type: "text",
								text: JSON.stringify(result)
							}],
							isError: false
						};
					}
					const filtered = applyResultFilters(yield _this.captureConsoleMessages(targetTabId, {
						includeExceptions,
						maxMessages: effectiveLimit
					}), {
						pattern: compiledPattern,
						onlyErrors,
						includeExceptions
					});
					return {
						content: [{
							type: "text",
							text: JSON.stringify(filtered)
						}],
						isError: false
					};
				} catch (error) {
					console.error("ConsoleTool: Critical error during execute:", error);
					const msg = error instanceof Error ? error.message : String(error);
					if (typeof targetTabId === "number" && isDebuggerConflictError(error)) return createErrorResponse(formatDebuggerConflictMessage(targetTabId, msg));
					return createErrorResponse(`Error in ConsoleTool: ${msg}`);
				}
			})();
		}
		navigateToUrl(url, background = false, windowId) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				var _existingTabs$;
				const existingTabs = yield chrome.tabs.query({ url });
				if (existingTabs.length > 0 && ((_existingTabs$ = existingTabs[0]) === null || _existingTabs$ === void 0 ? void 0 : _existingTabs$.id)) {
					const tab = existingTabs[0];
					if (!background) {
						yield chrome.tabs.update(tab.id, { active: true });
						yield chrome.windows.update(tab.windowId, { focused: true });
					}
					return tab;
				} else {
					const createInfo = {
						url,
						active: background ? false : true
					};
					if (typeof windowId === "number") createInfo.windowId = windowId;
					const newTab = yield chrome.tabs.create(createInfo);
					yield _this2.waitForTabReady(newTab.id);
					return newTab;
				}
			})();
		}
		waitForTabReady(tabId) {
			return _asyncToGenerator(function* () {
				return new Promise((resolve) => {
					const checkTab = function() {
						var _ref = _asyncToGenerator(function* () {
							try {
								if ((yield chrome.tabs.get(tabId)).status === "complete") resolve();
								else setTimeout(checkTab, 100);
							} catch (error) {
								resolve();
							}
						});
						return function checkTab() {
							return _ref.apply(this, arguments);
						};
					}();
					checkTab();
				});
			})();
		}
		formatConsoleArgs(args) {
			if (!args || args.length === 0) return "";
			return args.map((arg) => {
				if (arg.type === "string") return arg.value || "";
				else if (arg.type === "number") return String(arg.value || "");
				else if (arg.type === "boolean") return String(arg.value || "");
				else if (arg.type === "object") return arg.description || "[Object]";
				else if (arg.type === "undefined") return "undefined";
				else if (arg.type === "function") return arg.description || "[Function]";
				else return arg.description || arg.value || String(arg);
			}).join(" ");
		}
		captureConsoleMessages(tabId, options) {
			var _this3 = this;
			return _asyncToGenerator(function* () {
				const { includeExceptions, maxMessages } = options;
				const startTime = Date.now();
				const messages = [];
				const exceptions = [];
				let limitReached = false;
				try {
					const tab = yield chrome.tabs.get(tabId);
					yield cdpSessionManager.attach(tabId, "console");
					const collectedMessages = [];
					const collectedExceptions = [];
					const eventListener = (source, method, params) => {
						if (source.tabId !== tabId) return;
						if (method === "Log.entryAdded" && (params === null || params === void 0 ? void 0 : params.entry)) collectedMessages.push(params.entry);
						else if (method === "Runtime.consoleAPICalled" && params) {
							var _params$stackTrace, _params$stackTrace2;
							const logEntry = {
								timestamp: params.timestamp,
								level: params.type || "log",
								text: _this3.formatConsoleArgs(params.args || []),
								source: "console-api",
								url: (_params$stackTrace = params.stackTrace) === null || _params$stackTrace === void 0 || (_params$stackTrace = _params$stackTrace.callFrames) === null || _params$stackTrace === void 0 || (_params$stackTrace = _params$stackTrace[0]) === null || _params$stackTrace === void 0 ? void 0 : _params$stackTrace.url,
								lineNumber: (_params$stackTrace2 = params.stackTrace) === null || _params$stackTrace2 === void 0 || (_params$stackTrace2 = _params$stackTrace2.callFrames) === null || _params$stackTrace2 === void 0 || (_params$stackTrace2 = _params$stackTrace2[0]) === null || _params$stackTrace2 === void 0 ? void 0 : _params$stackTrace2.lineNumber,
								stackTrace: params.stackTrace,
								args: params.args
							};
							collectedMessages.push(logEntry);
						} else if (method === "Runtime.exceptionThrown" && includeExceptions && (params === null || params === void 0 ? void 0 : params.exceptionDetails)) collectedExceptions.push(params.exceptionDetails);
					};
					chrome.debugger.onEvent.addListener(eventListener);
					try {
						yield cdpSessionManager.sendCommand(tabId, "Runtime.enable");
						yield cdpSessionManager.sendCommand(tabId, "Log.enable");
						yield new Promise((resolve) => setTimeout(resolve, 2e3));
						const serializeArg = function() {
							var _ref2 = _asyncToGenerator(function* (arg) {
								try {
									if (!arg) return arg;
									if (Object.prototype.hasOwnProperty.call(arg, "unserializableValue")) return arg.unserializableValue;
									if (Object.prototype.hasOwnProperty.call(arg, "value")) return arg.value;
									if (arg.objectId) {
										var _resp$result$value, _resp$result;
										const resp = yield cdpSessionManager.sendCommand(tabId, "Runtime.callFunctionOn", {
											objectId: arg.objectId,
											functionDeclaration: "function(maxDepth, maxProps){\n  const seen=new WeakSet();\n  function S(v,d){\n    try{\n      if(d<0) return \"[MaxDepth]\";\n      if(v===null) return null;\n      const t=typeof v;\n      if(t!==\"object\"){\n        if(t===\"bigint\") return v.toString()+\"n\";\n        return v;\n      }\n      if(seen.has(v)) return \"[Circular]\";\n      seen.add(v);\n      if(Array.isArray(v)){\n        const out=[];\n        for(let i=0;i<v.length;i++){\n          if(i>=maxProps){ out.push(\"[...truncated]\"); break; }\n          out.push(S(v[i], d-1));\n        }\n        return out;\n      }\n      if(v instanceof Date) return {__type:\"Date\", value:v.toISOString()};\n      if(v instanceof RegExp) return {__type:\"RegExp\", value:String(v)};\n      if(v instanceof Map){\n        const out={__type:\"Map\", entries:[]}; let c=0;\n        for(const [k,val] of v.entries()){\n          if(c++>=maxProps){ out.entries.push([\"[...truncated]\",\"[...truncated]\"]); break; }\n          out.entries.push([S(k,d-1), S(val,d-1)]);\n        }\n        return out;\n      }\n      if(v instanceof Set){\n        const out={__type:\"Set\", values:[]}; let c=0;\n        for(const val of v.values()){\n          if(c++>=maxProps){ out.values.push(\"[...truncated]\"); break; }\n          out.values.push(S(val,d-1));\n        }\n        return out;\n      }\n      const out={}; let c=0;\n      for(const key in v){\n        if(c++>=maxProps){ out.__truncated__=true; break; }\n        try{ out[key]=S(v[key], d-1); }catch(e){ out[key]=\"[Thrown]\"; }\n      }\n      return out;\n    }catch(e){ return \"[Unserializable]\" }\n  }\n  return S(this, maxDepth);\n}",
											arguments: [{ value: 3 }, { value: 100 }],
											silent: true,
											returnByValue: true
										});
										return (_resp$result$value = resp === null || resp === void 0 || (_resp$result = resp.result) === null || _resp$result === void 0 ? void 0 : _resp$result.value) !== null && _resp$result$value !== void 0 ? _resp$result$value : "[Unavailable]";
									}
									return "[Unknown]";
								} catch (e) {
									return "[SerializeError]";
								}
							});
							return function serializeArg(_x) {
								return _ref2.apply(this, arguments);
							};
						}();
						for (const entry of collectedMessages) {
							if (messages.length >= maxMessages) {
								limitReached = true;
								break;
							}
							const message = {
								timestamp: entry.timestamp,
								level: entry.level || "log",
								text: entry.text || "",
								source: entry.source,
								url: entry.url,
								lineNumber: entry.lineNumber
							};
							if (entry.stackTrace) message.stackTrace = entry.stackTrace;
							if (entry.args && Array.isArray(entry.args)) {
								message.args = entry.args;
								const serialized = [];
								for (const a of entry.args) serialized.push(yield serializeArg(a));
								message.argsSerialized = serialized;
							}
							messages.push(message);
						}
						for (const exceptionDetails of collectedExceptions) {
							var _exceptionDetails$exc;
							const exception = {
								timestamp: Date.now(),
								text: exceptionDetails.text || ((_exceptionDetails$exc = exceptionDetails.exception) === null || _exceptionDetails$exc === void 0 ? void 0 : _exceptionDetails$exc.description) || "Unknown exception",
								url: exceptionDetails.url,
								lineNumber: exceptionDetails.lineNumber,
								columnNumber: exceptionDetails.columnNumber
							};
							if (exceptionDetails.stackTrace) exception.stackTrace = exceptionDetails.stackTrace;
							exceptions.push(exception);
						}
					} finally {
						chrome.debugger.onEvent.removeListener(eventListener);
						if (!consoleBuffer.isCapturing(tabId)) {
							try {
								yield cdpSessionManager.sendCommand(tabId, "Runtime.disable");
							} catch (e) {
								console.warn(`ConsoleTool: Error disabling Runtime for tab ${tabId}:`, e);
							}
							try {
								yield cdpSessionManager.sendCommand(tabId, "Log.disable");
							} catch (e) {
								console.warn(`ConsoleTool: Error disabling Log for tab ${tabId}:`, e);
							}
						}
						try {
							yield cdpSessionManager.detach(tabId, "console");
						} catch (e) {
							console.warn(`ConsoleTool: Error detaching debugger for tab ${tabId}:`, e);
						}
					}
					const endTime = Date.now();
					messages.sort((a, b) => a.timestamp - b.timestamp);
					exceptions.sort((a, b) => a.timestamp - b.timestamp);
					return {
						success: true,
						message: `Console capture completed for tab ${tabId}. ${messages.length} messages, ${exceptions.length} exceptions captured.`,
						tabId,
						tabUrl: tab.url || "",
						tabTitle: tab.title || "",
						captureStartTime: startTime,
						captureEndTime: endTime,
						totalDurationMs: endTime - startTime,
						messages,
						exceptions,
						messageCount: messages.length,
						exceptionCount: exceptions.length,
						messageLimitReached: limitReached,
						droppedMessageCount: 0,
						droppedExceptionCount: 0
					};
				} catch (error) {
					console.error(`ConsoleTool: Error capturing console messages for tab ${tabId}:`, error);
					throw error;
				}
			})();
		}
	};
	var consoleTool = new ConsoleTool();
	//#endregion
	//#region entrypoints/background/tools/browser/file-upload.ts
	init_cdp_session_manager();
	init_defineProperty();
	init_asyncToGenerator();
	/**
	* Tool for uploading files to web forms using Chrome DevTools Protocol
	* Similar to Playwright's setInputFiles implementation
	*/
	var FileUploadTool = class extends BaseBrowserToolExecutor {
		constructor() {
			super();
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.FILE_UPLOAD);
		}
		/**
		* Execute file upload operation using Chrome DevTools Protocol
		*/
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const { selector, filePath, fileUrl, base64Data, fileName, multiple = false } = args;
				console.log(`Starting file upload operation with options:`, args);
				if (!selector) return createErrorResponse("Selector is required for file upload");
				if (!filePath && !fileUrl && !base64Data) return createErrorResponse("One of filePath, fileUrl, or base64Data must be provided");
				try {
					const tab = (yield _this.tryGetTab(args.tabId)) || (yield _this.getActiveTabOrThrowInWindow(args.windowId));
					if (!tab.id) return createErrorResponse("No active tab found");
					const tabId = tab.id;
					let files = [];
					if (filePath) files = [filePath];
					else if (fileUrl || base64Data) {
						const tempFilePath = yield _this.prepareFileFromRemote({
							fileUrl,
							base64Data,
							fileName: fileName || "uploaded-file"
						});
						if (!tempFilePath) return createErrorResponse("Failed to prepare file for upload");
						files = [tempFilePath];
					}
					yield cdpSessionManager.withSession(tabId, "file-upload", _asyncToGenerator(function* () {
						yield cdpSessionManager.sendCommand(tabId, "DOM.enable", {});
						yield cdpSessionManager.sendCommand(tabId, "Runtime.enable", {});
						const { root } = yield cdpSessionManager.sendCommand(tabId, "DOM.getDocument", {
							depth: -1,
							pierce: true
						});
						const { nodeId } = yield cdpSessionManager.sendCommand(tabId, "DOM.querySelector", {
							nodeId: root.nodeId,
							selector
						});
						if (!nodeId || nodeId === 0) throw new Error(`Element with selector "${selector}" not found`);
						const { node } = yield cdpSessionManager.sendCommand(tabId, "DOM.describeNode", { nodeId });
						if (node.nodeName !== "INPUT") throw new Error(`Element with selector "${selector}" is not an input element`);
						const attributes = node.attributes || [];
						let isFileInput = false;
						for (let i = 0; i < attributes.length; i += 2) if (attributes[i] === "type" && attributes[i + 1] === "file") {
							isFileInput = true;
							break;
						}
						if (!isFileInput) throw new Error(`Element with selector "${selector}" is not a file input (type="file")`);
						yield cdpSessionManager.sendCommand(tabId, "DOM.setFileInputFiles", {
							nodeId,
							files
						});
						yield cdpSessionManager.sendCommand(tabId, "Runtime.evaluate", { expression: `
            (function() {
              const element = document.querySelector('${selector.replace(/'/g, "\\'")}');
              if (element) {
                const event = new Event('change', { bubbles: true });
                element.dispatchEvent(event);
                return true;
              }
              return false;
            })()
          ` });
					}));
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: "File(s) uploaded successfully",
								files,
								selector,
								fileCount: files.length
							})
						}],
						isError: false
					};
				} catch (error) {
					console.error("Error in file upload operation:", error);
					return createErrorResponse(`Error uploading file: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
		/**
		* Prepare file from URL or base64 data using native messaging host
		*/
		prepareFileFromRemote(options) {
			return _asyncToGenerator(function* () {
				const { fileUrl, base64Data, fileName } = options;
				return new Promise((resolve) => {
					const requestId = `file-upload-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
					const timeout = setTimeout(() => {
						console.error("File preparation request timed out");
						resolve(null);
					}, 3e4);
					const handleMessage = (message) => {
						if (message.type === "file_operation_response" && message.responseToRequestId === requestId) {
							var _message$payload, _message$payload2;
							clearTimeout(timeout);
							chrome.runtime.onMessage.removeListener(handleMessage);
							if (((_message$payload = message.payload) === null || _message$payload === void 0 ? void 0 : _message$payload.success) && ((_message$payload2 = message.payload) === null || _message$payload2 === void 0 ? void 0 : _message$payload2.filePath)) resolve(message.payload.filePath);
							else {
								var _message$payload3;
								console.error("Native host failed to prepare file:", message.error || ((_message$payload3 = message.payload) === null || _message$payload3 === void 0 ? void 0 : _message$payload3.error));
								resolve(null);
							}
						}
					};
					chrome.runtime.onMessage.addListener(handleMessage);
					chrome.runtime.sendMessage({
						type: "forward_to_native",
						message: {
							type: "file_operation",
							requestId,
							payload: {
								action: "prepareFile",
								fileUrl,
								base64Data,
								fileName
							}
						}
					}).catch((error) => {
						console.error("Error sending message to background:", error);
						clearTimeout(timeout);
						chrome.runtime.onMessage.removeListener(handleMessage);
						resolve(null);
					});
				});
			})();
		}
	};
	var fileUploadTool = new FileUploadTool();
	//#endregion
	//#region utils/indexeddb-client.ts
	init_defineProperty();
	init_asyncToGenerator();
	var IndexedDbClient = class {
		constructor(name, version, onUpgrade) {
			_defineProperty(this, "name", void 0);
			_defineProperty(this, "version", void 0);
			_defineProperty(this, "onUpgrade", void 0);
			_defineProperty(this, "dbPromise", null);
			this.name = name;
			this.version = version;
			this.onUpgrade = onUpgrade;
		}
		openDb() {
			var _this = this;
			return _asyncToGenerator(function* () {
				if (_this.dbPromise) return _this.dbPromise;
				_this.dbPromise = new Promise((resolve, reject) => {
					const req = indexedDB.open(_this.name, _this.version);
					req.onupgradeneeded = (event) => {
						const db = req.result;
						const oldVersion = event.oldVersion || 0;
						const tx = req.transaction;
						try {
							_this.onUpgrade(db, oldVersion, tx);
						} catch (e) {
							console.error("IndexedDbClient upgrade failed:", e);
						}
					};
					req.onsuccess = () => resolve(req.result);
					req.onerror = () => {
						var _req$error;
						return reject(/* @__PURE__ */ new Error(`IndexedDB open failed: ${((_req$error = req.error) === null || _req$error === void 0 ? void 0 : _req$error.message) || req.error}`));
					};
				});
				return _this.dbPromise;
			})();
		}
		tx(storeName, mode, op) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				const db = yield _this2.openDb();
				return new Promise((resolve, reject) => {
					const transaction = db.transaction(storeName, mode);
					const st = transaction.objectStore(storeName);
					let opResult;
					let opError;
					transaction.oncomplete = () => resolve(opResult);
					transaction.onerror = () => {
						var _transaction$error;
						return reject(/* @__PURE__ */ new Error(`IDB transaction error on ${storeName}: ${((_transaction$error = transaction.error) === null || _transaction$error === void 0 ? void 0 : _transaction$error.message) || transaction.error}`));
					};
					transaction.onabort = () => {
						var _transaction$error2;
						return reject(/* @__PURE__ */ new Error(`IDB transaction aborted on ${storeName}: ${((_transaction$error2 = transaction.error) === null || _transaction$error2 === void 0 ? void 0 : _transaction$error2.message) || opError || "unknown"}`));
					};
					Promise.resolve().then(() => op(st, transaction)).then((res) => {
						opResult = res;
					}).catch((err) => {
						opError = err;
						try {
							transaction.abort();
						} catch (_unused) {}
					});
				});
			})();
		}
		getAll(store) {
			var _this3 = this;
			return _asyncToGenerator(function* () {
				return _this3.tx(store, "readonly", (st) => _this3.promisifyRequest(st.getAll(), store, "getAll").then((res) => res || []));
			})();
		}
		get(store, key) {
			var _this4 = this;
			return _asyncToGenerator(function* () {
				return _this4.tx(store, "readonly", (st) => _this4.promisifyRequest(st.get(key), store, `get(${String(key)})`).then((res) => res));
			})();
		}
		put(store, value) {
			var _this5 = this;
			return _asyncToGenerator(function* () {
				return _this5.tx(store, "readwrite", (st) => _this5.promisifyRequest(st.put(value), store, "put").then(() => void 0));
			})();
		}
		delete(store, key) {
			var _this6 = this;
			return _asyncToGenerator(function* () {
				return _this6.tx(store, "readwrite", (st) => _this6.promisifyRequest(st.delete(key), store, `delete(${String(key)})`).then(() => void 0));
			})();
		}
		clear(store) {
			var _this7 = this;
			return _asyncToGenerator(function* () {
				return _this7.tx(store, "readwrite", (st) => _this7.promisifyRequest(st.clear(), store, "clear").then(() => void 0));
			})();
		}
		putMany(store, values) {
			var _this8 = this;
			return _asyncToGenerator(function* () {
				return _this8.tx(store, "readwrite", function() {
					var _ref = _asyncToGenerator(function* (st) {
						for (const v of values) st.put(v);
					});
					return function(_x) {
						return _ref.apply(this, arguments);
					};
				}());
			})();
		}
		promisifyRequest(req, store, action) {
			return new Promise((resolve, reject) => {
				req.onsuccess = () => resolve(req.result);
				req.onerror = () => {
					var _req$error2;
					return reject(/* @__PURE__ */ new Error(`IDB ${action} error on ${store}: ${((_req$error2 = req.error) === null || _req$error2 === void 0 ? void 0 : _req$error2.message) || req.error}`));
				};
			});
		}
	};
	//#endregion
	//#region entrypoints/background/element-marker/element-marker-storage.ts
	init_asyncToGenerator();
	var DB_NAME = "element_marker_storage";
	var DB_VERSION = 1;
	var STORE = "markers";
	var idb = new IndexedDbClient(DB_NAME, DB_VERSION, (db, oldVersion) => {
		switch (oldVersion) {
			case 0: {
				const store = db.createObjectStore(STORE, { keyPath: "id" });
				store.createIndex("by_host", "host", { unique: false });
				store.createIndex("by_origin", "origin", { unique: false });
				store.createIndex("by_path", "path", { unique: false });
			}
		}
	});
	function normalizeUrl(raw) {
		try {
			const u = new URL(raw);
			return {
				url: raw,
				origin: u.origin,
				host: u.hostname,
				path: u.pathname
			};
		} catch (_unused) {
			return {
				url: raw,
				origin: "",
				host: "",
				path: ""
			};
		}
	}
	function now$1() {
		return Date.now();
	}
	function listAllMarkers() {
		return _listAllMarkers.apply(this, arguments);
	}
	function _listAllMarkers() {
		_listAllMarkers = _asyncToGenerator(function* () {
			return idb.getAll(STORE);
		});
		return _listAllMarkers.apply(this, arguments);
	}
	function listMarkersForUrl(_x) {
		return _listMarkersForUrl.apply(this, arguments);
	}
	function _listMarkersForUrl() {
		_listMarkersForUrl = _asyncToGenerator(function* (url) {
			const { origin, path, host } = normalizeUrl(url);
			return (yield idb.getAll(STORE)).filter((m) => {
				if (!m) return false;
				if (m.matchType === "exact") return m.origin === origin && m.path === path;
				if (m.matchType === "host") return !!m.host && m.host === host;
				return m.origin === origin && (m.path ? path.startsWith(m.path) : true);
			});
		});
		return _listMarkersForUrl.apply(this, arguments);
	}
	function saveMarker(_x2) {
		return _saveMarker.apply(this, arguments);
	}
	function _saveMarker() {
		_saveMarker = _asyncToGenerator(function* (req) {
			var _globalThis$crypto$ra, _globalThis$crypto, _globalThis$crypto$ra2;
			const { url: rawUrl, selector } = req;
			if (!rawUrl || !selector) throw new Error("url and selector are required");
			const { url, origin, host, path } = normalizeUrl(rawUrl);
			const ts = now$1();
			const marker = {
				id: req.id || ((_globalThis$crypto$ra = (_globalThis$crypto = globalThis.crypto) === null || _globalThis$crypto === void 0 || (_globalThis$crypto$ra2 = _globalThis$crypto.randomUUID) === null || _globalThis$crypto$ra2 === void 0 ? void 0 : _globalThis$crypto$ra2.call(_globalThis$crypto)) !== null && _globalThis$crypto$ra !== void 0 ? _globalThis$crypto$ra : `${ts}_${Math.random()}`),
				url,
				origin,
				host,
				path,
				matchType: req.matchType || "prefix",
				name: req.name || selector,
				selector,
				selectorType: req.selectorType || "css",
				listMode: req.listMode || false,
				action: req.action || "custom",
				createdAt: ts,
				updatedAt: ts
			};
			yield idb.put(STORE, marker);
			return marker;
		});
		return _saveMarker.apply(this, arguments);
	}
	function updateMarker(_x3) {
		return _updateMarker.apply(this, arguments);
	}
	function _updateMarker() {
		_updateMarker = _asyncToGenerator(function* (marker) {
			const existing = yield idb.get(STORE, marker.id);
			if (!existing) throw new Error("marker not found");
			const updated = _objectSpread2(_objectSpread2({}, marker), {}, {
				createdAt: existing.createdAt,
				updatedAt: now$1()
			});
			yield idb.put(STORE, updated);
		});
		return _updateMarker.apply(this, arguments);
	}
	function deleteMarker(_x4) {
		return _deleteMarker.apply(this, arguments);
	}
	function _deleteMarker() {
		_deleteMarker = _asyncToGenerator(function* (id) {
			yield idb.delete(STORE, id);
		});
		return _deleteMarker.apply(this, arguments);
	}
	//#endregion
	//#region entrypoints/background/tools/browser/read-page.ts
	init_defineProperty();
	init_asyncToGenerator();
	var ReadPageTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.READ_PAGE);
		}
		execute(args) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const { filter, depth, refId } = args || {};
				const focusRefId = typeof refId === "string" ? refId.trim() : "";
				if (refId !== void 0 && !focusRefId) return createErrorResponse(`${ERROR_MESSAGES.INVALID_PARAMETERS}: refId must be a non-empty string`);
				const requestedDepth = depth === void 0 ? void 0 : Number(depth);
				if (requestedDepth !== void 0 && (!Number.isInteger(requestedDepth) || requestedDepth < 0)) return createErrorResponse(`${ERROR_MESSAGES.INVALID_PARAMETERS}: depth must be a non-negative integer`);
				const userControlled = requestedDepth !== void 0 || !!focusRefId;
				try {
					var _resp$stats$processed, _resp$stats$included, _resp$stats$durationM;
					const standardTips = "If the specific element you need is missing from the returned data, use the 'screenshot' tool to capture the current viewport and confirm the element's on-screen coordinates. Also note: 'markedElements' are user-marked elements and have the highest priority when choosing targets.";
					const tab = (yield _this.tryGetTab(args === null || args === void 0 ? void 0 : args.tabId)) || (yield _this.getActiveTabOrThrowInWindow(args === null || args === void 0 ? void 0 : args.windowId));
					if (!tab.id) return createErrorResponse(ERROR_MESSAGES.TAB_NOT_FOUND + ": Active tab has no ID");
					const currentUrl = String(tab.url || "");
					const userMarkers = currentUrl ? yield listMarkersForUrl(currentUrl) : [];
					yield _this.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"], false, "ISOLATED", true);
					const resp = yield _this.sendMessageToTab(tab.id, {
						action: TOOL_MESSAGE_TYPES.GENERATE_ACCESSIBILITY_TREE,
						filter: filter || null,
						depth: requestedDepth,
						refId: focusRefId || void 0
					});
					const treeOk = resp && resp.success === true;
					const pageContent = resp && typeof resp.pageContent === "string" ? resp.pageContent : "";
					const stats = treeOk && (resp === null || resp === void 0 ? void 0 : resp.stats) ? {
						processed: (_resp$stats$processed = resp.stats.processed) !== null && _resp$stats$processed !== void 0 ? _resp$stats$processed : 0,
						included: (_resp$stats$included = resp.stats.included) !== null && _resp$stats$included !== void 0 ? _resp$stats$included : 0,
						durationMs: (_resp$stats$durationM = resp.stats.durationMs) !== null && _resp$stats$durationM !== void 0 ? _resp$stats$durationM : 0
					} : null;
					const lines = pageContent ? pageContent.split("\n").filter((l) => l.trim().length > 0).length : 0;
					const refCount = Array.isArray(resp === null || resp === void 0 ? void 0 : resp.refMap) ? resp.refMap.length : 0;
					const isSparse = !userControlled && lines < 10 && refCount < 3;
					const markedElements = userMarkers.map((m) => ({
						name: m.name,
						selector: m.selector,
						selectorType: m.selectorType || "css",
						urlMatch: {
							type: m.matchType,
							origin: m.origin,
							path: m.path
						},
						source: "marker",
						priority: "highest"
					}));
					const formatElementsAsPageContent = (elements) => {
						const out = [];
						for (const e of elements || []) {
							const type = typeof (e === null || e === void 0 ? void 0 : e.type) === "string" && e.type ? e.type : "element";
							const rawText = typeof (e === null || e === void 0 ? void 0 : e.text) === "string" ? e.text.trim() : "";
							const text = rawText.length > 0 ? ` "${rawText.replace(/\s+/g, " ").slice(0, 100).replace(/"/g, "\\\"")}"` : "";
							const selector = typeof (e === null || e === void 0 ? void 0 : e.selector) === "string" && e.selector ? ` selector="${e.selector}"` : "";
							const coords = (e === null || e === void 0 ? void 0 : e.coordinates) && Number.isFinite(e.coordinates.x) && Number.isFinite(e.coordinates.y) ? ` (x=${Math.round(e.coordinates.x)},y=${Math.round(e.coordinates.y)})` : "";
							out.push(`- ${type}${text}${selector}${coords}`);
							if (out.length >= 150) break;
						}
						return out.join("\n");
					};
					const basePayload = {
						success: true,
						filter: filter || "all",
						pageContent,
						tips: standardTips,
						viewport: treeOk ? resp.viewport : {
							width: null,
							height: null,
							dpr: null
						},
						stats: stats || {
							processed: 0,
							included: 0,
							durationMs: 0
						},
						refMapCount: refCount,
						sparse: treeOk ? isSparse : false,
						depth: requestedDepth !== null && requestedDepth !== void 0 ? requestedDepth : null,
						focus: focusRefId ? {
							refId: focusRefId,
							found: treeOk
						} : null,
						markedElements,
						elements: [],
						count: 0,
						fallbackUsed: false,
						fallbackSource: null,
						reason: null
					};
					if (treeOk && !isSparse) return {
						content: [{
							type: "text",
							text: JSON.stringify(basePayload)
						}],
						isError: false
					};
					if (focusRefId) return createErrorResponse((resp === null || resp === void 0 ? void 0 : resp.error) || `refId "${focusRefId}" not found or expired`);
					if (requestedDepth !== void 0) return createErrorResponse((resp === null || resp === void 0 ? void 0 : resp.error) || "Failed to generate accessibility tree");
					try {
						yield _this.injectContentScript(tab.id, ["inject-scripts/interactive-elements-helper.js"]);
						const fallback = yield _this.sendMessageToTab(tab.id, {
							action: TOOL_MESSAGE_TYPES.GET_INTERACTIVE_ELEMENTS,
							includeCoordinates: true
						});
						if (fallback && fallback.success && Array.isArray(fallback.elements)) {
							const limited = fallback.elements.slice(0, 150);
							const markerEls = userMarkers.map((m) => ({
								type: "marker",
								selector: m.selector,
								text: m.name,
								selectorType: m.selectorType || "css",
								isInteractive: true,
								source: "marker",
								priority: "highest"
							}));
							const seen = new Set(markerEls.map((e) => e.selector));
							const merged = [...markerEls, ...limited.filter((e) => !seen.has(e.selector))];
							basePayload.fallbackUsed = true;
							basePayload.fallbackSource = "get_interactive_elements";
							basePayload.reason = treeOk ? "sparse_tree" : (resp === null || resp === void 0 ? void 0 : resp.error) || "tree_failed";
							basePayload.elements = merged;
							basePayload.count = fallback.elements.length;
							if (!basePayload.pageContent) basePayload.pageContent = formatElementsAsPageContent(merged);
							return {
								content: [{
									type: "text",
									text: JSON.stringify(basePayload)
								}],
								isError: false
							};
						}
					} catch (fallbackErr) {
						console.warn("read_page fallback failed:", fallbackErr);
					}
					return createErrorResponse(treeOk ? "Accessibility tree is too sparse and fallback failed" : (resp === null || resp === void 0 ? void 0 : resp.error) || "Failed to generate accessibility tree and fallback failed");
				} catch (error) {
					console.error("Error in read page tool:", error);
					return createErrorResponse(`Error generating accessibility tree: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var readPageTool = new ReadPageTool();
	//#endregion
	//#region entrypoints/background/tools/browser/computer.ts
	init_cdp_session_manager();
	init_asyncToGenerator();
	init_defineProperty();
	var CDPHelper = class {
		static attach(tabId) {
			return _asyncToGenerator(function* () {
				yield cdpSessionManager.attach(tabId, "computer");
			})();
		}
		static detach(tabId) {
			return _asyncToGenerator(function* () {
				yield cdpSessionManager.detach(tabId, "computer");
			})();
		}
		static send(tabId, method, params) {
			return _asyncToGenerator(function* () {
				return yield cdpSessionManager.sendCommand(tabId, method, params);
			})();
		}
		static dispatchMouseEvent(tabId, opts) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const params = {
					type: opts.type,
					x: Math.round(opts.x),
					y: Math.round(opts.y),
					modifiers: opts.modifiers || 0
				};
				if (opts.type === "mousePressed" || opts.type === "mouseReleased" || opts.type === "mouseMoved") {
					params.button = opts.button || "none";
					if (opts.type === "mousePressed" || opts.type === "mouseReleased") params.clickCount = opts.clickCount || 1;
					params.buttons = opts.buttons !== void 0 ? opts.buttons : 0;
				}
				if (opts.type === "mouseWheel") {
					params.deltaX = opts.deltaX || 0;
					params.deltaY = opts.deltaY || 0;
				}
				yield _this.send(tabId, "Input.dispatchMouseEvent", params);
			})();
		}
		static insertText(tabId, text) {
			var _this2 = this;
			return _asyncToGenerator(function* () {
				yield _this2.send(tabId, "Input.insertText", { text });
			})();
		}
		static modifierMask(mods) {
			const map = {
				alt: 1,
				ctrl: 2,
				control: 2,
				meta: 4,
				cmd: 4,
				command: 4,
				win: 4,
				windows: 4,
				shift: 8
			};
			let mask = 0;
			for (const m of mods) mask |= map[m] || 0;
			return mask;
		}
		static resolveKeyDef(token) {
			const t = (token || "").toLowerCase();
			if (this.KEY_ALIASES[t]) return this.KEY_ALIASES[t];
			if (/^f([1-9]|1[0-2])$/.test(t)) return {
				key: t.toUpperCase(),
				code: t.toUpperCase()
			};
			if (t.length === 1) {
				const upper = t.toUpperCase();
				return {
					key: upper,
					code: `Key${upper}`,
					text: t
				};
			}
			return { key: token };
		}
		static dispatchSimpleKey(tabId, token) {
			var _this3 = this;
			return _asyncToGenerator(function* () {
				const def = _this3.resolveKeyDef(token);
				if (def.text && def.text.length === 1) {
					yield _this3.insertText(tabId, def.text);
					return;
				}
				yield _this3.send(tabId, "Input.dispatchKeyEvent", {
					type: "rawKeyDown",
					key: def.key,
					code: def.code
				});
				yield _this3.send(tabId, "Input.dispatchKeyEvent", {
					type: "keyUp",
					key: def.key,
					code: def.code
				});
			})();
		}
		static dispatchKeyChord(tabId, chord) {
			var _this4 = this;
			return _asyncToGenerator(function* () {
				const parts = chord.split("+");
				const modifiers = [];
				let keyToken = "";
				for (const pRaw of parts) {
					const p = pRaw.trim().toLowerCase();
					if ([
						"ctrl",
						"control",
						"alt",
						"shift",
						"cmd",
						"meta",
						"command",
						"win",
						"windows"
					].includes(p)) modifiers.push(p);
					else keyToken = pRaw.trim();
				}
				const mask = _this4.modifierMask(modifiers);
				const def = _this4.resolveKeyDef(keyToken);
				yield _this4.send(tabId, "Input.dispatchKeyEvent", {
					type: "rawKeyDown",
					key: def.key,
					code: def.code,
					text: def.text,
					modifiers: mask
				});
				yield _this4.send(tabId, "Input.dispatchKeyEvent", {
					type: "keyUp",
					key: def.key,
					code: def.code,
					modifiers: mask
				});
			})();
		}
	};
	_defineProperty(CDPHelper, "KEY_ALIASES", {
		enter: {
			key: "Enter",
			code: "Enter"
		},
		return: {
			key: "Enter",
			code: "Enter"
		},
		backspace: {
			key: "Backspace",
			code: "Backspace"
		},
		delete: {
			key: "Delete",
			code: "Delete"
		},
		tab: {
			key: "Tab",
			code: "Tab"
		},
		escape: {
			key: "Escape",
			code: "Escape"
		},
		esc: {
			key: "Escape",
			code: "Escape"
		},
		space: {
			key: " ",
			code: "Space",
			text: " "
		},
		pageup: {
			key: "PageUp",
			code: "PageUp"
		},
		pagedown: {
			key: "PageDown",
			code: "PageDown"
		},
		home: {
			key: "Home",
			code: "Home"
		},
		end: {
			key: "End",
			code: "End"
		},
		arrowup: {
			key: "ArrowUp",
			code: "ArrowUp"
		},
		arrowdown: {
			key: "ArrowDown",
			code: "ArrowDown"
		},
		arrowleft: {
			key: "ArrowLeft",
			code: "ArrowLeft"
		},
		arrowright: {
			key: "ArrowRight",
			code: "ArrowRight"
		}
	});
	var ComputerTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.COMPUTER);
		}
		execute(args) {
			var _this5 = this;
			return _asyncToGenerator(function* () {
				const params = args || {};
				if (!params.action) return createErrorResponse("Action parameter is required");
				try {
					const tab = (yield _this5.tryGetTab(args.tabId)) || (yield _this5.getActiveTabOrThrowInWindow(args.windowId));
					if (!tab.id) return createErrorResponse(ERROR_MESSAGES.TAB_NOT_FOUND + ": Active tab has no ID");
					const result = yield _this5.executeAction(params, tab);
					if (!result.isError && params.action !== "screenshot" && params.action !== "wait") {
						const actionType = _this5.mapActionToCapture(params.action);
						if (actionType) {
							const ctx = screenshotContextManager.getContext(tab.id);
							const toViewport = (c) => {
								if (!c) return void 0;
								if (!ctx) return {
									x: c.x,
									y: c.y
								};
								const scaled = scaleCoordinates(c.x, c.y, ctx);
								return {
									x: scaled.x,
									y: scaled.y
								};
							};
							const endCoords = toViewport(params.coordinates);
							const startCoords = toViewport(params.startCoordinates);
							yield _this5.triggerAutoCapture(tab.id, actionType, {
								coordinateSpace: "viewport",
								coordinates: endCoords,
								startCoordinates: startCoords,
								endCoordinates: actionType === "drag" ? endCoords : void 0,
								text: params.text,
								ref: params.ref
							});
						}
					}
					return result;
				} catch (error) {
					console.error("Error in computer tool:", error);
					return createErrorResponse(`Failed to execute action: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
		mapActionToCapture(action) {
			return {
				left_click: "click",
				right_click: "right_click",
				double_click: "double_click",
				triple_click: "triple_click",
				left_click_drag: "drag",
				scroll: "scroll",
				type: "type",
				key: "key",
				hover: "hover",
				fill: "fill",
				fill_form: "fill",
				resize_page: "other",
				scroll_to: "scroll",
				zoom: "other"
			}[action] || null;
		}
		executeAction(params, tab) {
			var _this6 = this;
			return _asyncToGenerator(function* () {
				if (!tab.id) return createErrorResponse(ERROR_MESSAGES.TAB_NOT_FOUND + ": Active tab has no ID");
				const project = (c) => {
					if (!c) return void 0;
					const ctx = screenshotContextManager.getContext(tab.id);
					if (!ctx) return c;
					const scaled = scaleCoordinates(c.x, c.y, ctx);
					return {
						x: scaled.x,
						y: scaled.y
					};
				};
				switch (params.action) {
					case "resize_page": {
						var _params$coordinates, _params$coordinates2, _params$width, _params$height;
						const width = Number(((_params$coordinates = params.coordinates) === null || _params$coordinates === void 0 ? void 0 : _params$coordinates.x) || params.text);
						const height = Number(((_params$coordinates2 = params.coordinates) === null || _params$coordinates2 === void 0 ? void 0 : _params$coordinates2.y) || params.value);
						const w = Number((_params$width = params.width) !== null && _params$width !== void 0 ? _params$width : width);
						const h = Number((_params$height = params.height) !== null && _params$height !== void 0 ? _params$height : height);
						if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) return createErrorResponse("Provide width and height for resize_page (positive numbers)");
						try {
							yield CDPHelper.attach(tab.id);
							try {
								yield CDPHelper.send(tab.id, "Emulation.setDeviceMetricsOverride", {
									width: Math.round(w),
									height: Math.round(h),
									deviceScaleFactor: 0,
									mobile: false,
									screenWidth: Math.round(w),
									screenHeight: Math.round(h)
								});
							} finally {
								yield CDPHelper.detach(tab.id);
							}
						} catch (e) {
							if (tab.windowId !== void 0) yield chrome.windows.update(tab.windowId, {
								width: Math.round(w),
								height: Math.round(h)
							});
							else return createErrorResponse(`Failed to resize via CDP and cannot determine windowId: ${e instanceof Error ? e.message : String(e)}`);
						}
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									success: true,
									action: "resize_page",
									width: w,
									height: h
								})
							}],
							isError: false
						};
					}
					case "hover": {
						let coord = void 0;
						let resolvedBy;
						try {
							if (params.ref) {
								yield _this6.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
								try {
									yield _this6.sendMessageToTab(tab.id, {
										action: "focusByRef",
										ref: params.ref
									});
								} catch (_unused) {}
								const resolved = yield _this6.sendMessageToTab(tab.id, {
									action: TOOL_MESSAGE_TYPES.RESOLVE_REF,
									ref: params.ref
								});
								if (resolved && resolved.success) {
									coord = project({
										x: resolved.center.x,
										y: resolved.center.y
									});
									resolvedBy = "ref";
								}
							} else if (params.selector) {
								yield _this6.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
								const selectorType = params.selectorType || "css";
								const ensured = yield _this6.sendMessageToTab(tab.id, {
									action: TOOL_MESSAGE_TYPES.ENSURE_REF_FOR_SELECTOR,
									selector: params.selector,
									isXPath: selectorType === "xpath"
								});
								if (ensured && ensured.success) {
									const resolvedRef = typeof ensured.ref === "string" ? ensured.ref : void 0;
									if (resolvedRef) {
										try {
											yield _this6.sendMessageToTab(tab.id, {
												action: "focusByRef",
												ref: resolvedRef
											});
										} catch (_unused2) {}
										const reResolved = yield _this6.sendMessageToTab(tab.id, {
											action: TOOL_MESSAGE_TYPES.RESOLVE_REF,
											ref: resolvedRef
										});
										if (reResolved && reResolved.success) coord = project({
											x: reResolved.center.x,
											y: reResolved.center.y
										});
										else coord = project({
											x: ensured.center.x,
											y: ensured.center.y
										});
									} else coord = project({
										x: ensured.center.x,
										y: ensured.center.y
									});
									resolvedBy = "selector";
								}
							} else if (params.coordinates) {
								coord = project(params.coordinates);
								resolvedBy = "coordinates";
							}
						} catch (e) {}
						if (!coord) return createErrorResponse("Provide ref or selector or coordinates for hover, or failed to resolve target");
						{
							const stale = (() => {
								if (!params.coordinates) return null;
								const getHostname = (url) => {
									try {
										return new URL(url).hostname;
									} catch (_unused3) {
										return "";
									}
								};
								const currentHostname = getHostname(tab.url || "");
								const ctx = screenshotContextManager.getContext(tab.id);
								const contextHostname = ctx === null || ctx === void 0 ? void 0 : ctx.hostname;
								if (contextHostname && contextHostname !== currentHostname) return createErrorResponse(`Security check failed: Domain changed since last screenshot (from ${contextHostname} to ${currentHostname}) during hover. Capture a new screenshot or use ref/selector.`);
								return null;
							})();
							if (stale) return stale;
						}
						try {
							yield CDPHelper.attach(tab.id);
							try {
								yield CDPHelper.dispatchMouseEvent(tab.id, {
									type: "mouseMoved",
									x: coord.x,
									y: coord.y,
									button: "none",
									buttons: 0
								});
							} finally {
								yield CDPHelper.detach(tab.id);
							}
							const holdMs = Math.max(0, Math.min(params.duration ? params.duration * 1e3 : 400, 5e3));
							if (holdMs > 0) yield new Promise((r) => setTimeout(r, holdMs));
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										action: "hover",
										coordinates: coord,
										resolvedBy,
										transport: "cdp"
									})
								}],
								isError: false
							};
						} catch (error) {
							console.warn("[ComputerTool] CDP hover failed, attempting DOM fallback", error);
							return yield _this6.domHoverFallback(tab.id, coord, resolvedBy, params.ref);
						}
					}
					case "left_click":
					case "right_click": {
						var _params$modifiers, _params$modifiers2, _params$modifiers3, _params$modifiers4;
						const modifiersMask = CDPHelper.modifierMask([
							((_params$modifiers = params.modifiers) === null || _params$modifiers === void 0 ? void 0 : _params$modifiers.altKey) ? "alt" : void 0,
							((_params$modifiers2 = params.modifiers) === null || _params$modifiers2 === void 0 ? void 0 : _params$modifiers2.ctrlKey) ? "ctrl" : void 0,
							((_params$modifiers3 = params.modifiers) === null || _params$modifiers3 === void 0 ? void 0 : _params$modifiers3.metaKey) ? "meta" : void 0,
							((_params$modifiers4 = params.modifiers) === null || _params$modifiers4 === void 0 ? void 0 : _params$modifiers4.shiftKey) ? "shift" : void 0
						].filter((v) => typeof v === "string"));
						if (params.ref) return yield clickTool.execute({
							ref: params.ref,
							waitForNavigation: false,
							timeout: TIMEOUTS.DEFAULT_WAIT * 5,
							button: params.action === "right_click" ? "right" : "left",
							modifiers: params.modifiers
						});
						if (params.selector) return yield clickTool.execute({
							selector: params.selector,
							selectorType: params.selectorType,
							frameId: params.frameId,
							waitForNavigation: false,
							timeout: TIMEOUTS.DEFAULT_WAIT * 5,
							button: params.action === "right_click" ? "right" : "left",
							modifiers: params.modifiers
						});
						if (!params.coordinates) return createErrorResponse("Provide ref, selector, or coordinates for click action");
						{
							const stale = (() => {
								const getHostname = (url) => {
									try {
										return new URL(url).hostname;
									} catch (_unused4) {
										return "";
									}
								};
								const currentHostname = getHostname(tab.url || "");
								const ctx = screenshotContextManager.getContext(tab.id);
								const contextHostname = ctx === null || ctx === void 0 ? void 0 : ctx.hostname;
								if (contextHostname && contextHostname !== currentHostname) return createErrorResponse(`Security check failed: Domain changed since last screenshot (from ${contextHostname} to ${currentHostname}) during ${params.action}. Capture a new screenshot or use ref/selector.`);
								return null;
							})();
							if (stale) return stale;
						}
						const coord = project(params.coordinates);
						const domResult = yield clickTool.execute({
							coordinates: coord,
							waitForNavigation: false,
							timeout: TIMEOUTS.DEFAULT_WAIT * 5,
							button: params.action === "right_click" ? "right" : "left",
							modifiers: params.modifiers
						});
						if (!domResult.isError) return domResult;
						try {
							yield CDPHelper.attach(tab.id);
							const button = params.action === "right_click" ? "right" : "left";
							const clickCount = 1;
							yield CDPHelper.dispatchMouseEvent(tab.id, {
								type: "mouseMoved",
								x: coord.x,
								y: coord.y,
								button: "none",
								buttons: 0,
								modifiers: modifiersMask
							});
							for (let i = 1; i <= clickCount; i++) {
								yield CDPHelper.dispatchMouseEvent(tab.id, {
									type: "mousePressed",
									x: coord.x,
									y: coord.y,
									button,
									buttons: button === "left" ? 1 : 2,
									clickCount: i,
									modifiers: modifiersMask
								});
								yield CDPHelper.dispatchMouseEvent(tab.id, {
									type: "mouseReleased",
									x: coord.x,
									y: coord.y,
									button,
									buttons: 0,
									clickCount: i,
									modifiers: modifiersMask
								});
							}
							yield CDPHelper.detach(tab.id);
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										action: params.action,
										coordinates: coord
									})
								}],
								isError: false
							};
						} catch (e) {
							yield CDPHelper.detach(tab.id);
							return createErrorResponse(`CDP click failed: ${e instanceof Error ? e.message : String(e)}`);
						}
					}
					case "double_click":
					case "triple_click": {
						var _params$modifiers5, _params$modifiers6, _params$modifiers7, _params$modifiers8;
						const modifiersMask = CDPHelper.modifierMask([
							((_params$modifiers5 = params.modifiers) === null || _params$modifiers5 === void 0 ? void 0 : _params$modifiers5.altKey) ? "alt" : void 0,
							((_params$modifiers6 = params.modifiers) === null || _params$modifiers6 === void 0 ? void 0 : _params$modifiers6.ctrlKey) ? "ctrl" : void 0,
							((_params$modifiers7 = params.modifiers) === null || _params$modifiers7 === void 0 ? void 0 : _params$modifiers7.metaKey) ? "meta" : void 0,
							((_params$modifiers8 = params.modifiers) === null || _params$modifiers8 === void 0 ? void 0 : _params$modifiers8.shiftKey) ? "shift" : void 0
						].filter((v) => typeof v === "string"));
						if (!params.coordinates && !params.ref && !params.selector) return createErrorResponse("Provide ref, selector, or coordinates for double/triple click");
						let coord = params.coordinates ? project(params.coordinates) : void 0;
						if (params.ref) try {
							yield _this6.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
							const resolved = yield _this6.sendMessageToTab(tab.id, {
								action: TOOL_MESSAGE_TYPES.RESOLVE_REF,
								ref: params.ref
							});
							if (resolved && resolved.success) coord = project({
								x: resolved.center.x,
								y: resolved.center.y
							});
						} catch (e) {}
						else if (params.selector) try {
							yield _this6.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
							const selectorType = params.selectorType || "css";
							const ensured = yield _this6.sendMessageToTab(tab.id, {
								action: TOOL_MESSAGE_TYPES.ENSURE_REF_FOR_SELECTOR,
								selector: params.selector,
								isXPath: selectorType === "xpath"
							}, params.frameId);
							if (ensured && ensured.success) coord = project({
								x: ensured.center.x,
								y: ensured.center.y
							});
						} catch (e) {}
						if (!coord) return createErrorResponse("Failed to resolve coordinates from ref/selector");
						{
							const stale = (() => {
								if (!params.coordinates) return null;
								const getHostname = (url) => {
									try {
										return new URL(url).hostname;
									} catch (_unused5) {
										return "";
									}
								};
								const currentHostname = getHostname(tab.url || "");
								const ctx = screenshotContextManager.getContext(tab.id);
								const contextHostname = ctx === null || ctx === void 0 ? void 0 : ctx.hostname;
								if (contextHostname && contextHostname !== currentHostname) return createErrorResponse(`Security check failed: Domain changed since last screenshot (from ${contextHostname} to ${currentHostname}) during ${params.action}. Capture a new screenshot or use ref/selector.`);
								return null;
							})();
							if (stale) return stale;
						}
						try {
							yield CDPHelper.attach(tab.id);
							const button = "left";
							const clickCount = params.action === "double_click" ? 2 : 3;
							yield CDPHelper.dispatchMouseEvent(tab.id, {
								type: "mouseMoved",
								x: coord.x,
								y: coord.y,
								button: "none",
								buttons: 0,
								modifiers: modifiersMask
							});
							for (let i = 1; i <= clickCount; i++) {
								yield CDPHelper.dispatchMouseEvent(tab.id, {
									type: "mousePressed",
									x: coord.x,
									y: coord.y,
									button,
									buttons: 1,
									clickCount: i,
									modifiers: modifiersMask
								});
								yield CDPHelper.dispatchMouseEvent(tab.id, {
									type: "mouseReleased",
									x: coord.x,
									y: coord.y,
									button,
									buttons: 0,
									clickCount: i,
									modifiers: modifiersMask
								});
							}
							yield CDPHelper.detach(tab.id);
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										action: params.action,
										coordinates: coord
									})
								}],
								isError: false
							};
						} catch (e) {
							yield CDPHelper.detach(tab.id);
							return createErrorResponse(`CDP ${params.action} failed: ${e instanceof Error ? e.message : String(e)}`);
						}
					}
					case "left_click_drag": {
						if (!params.startCoordinates && !params.startRef) return createErrorResponse("Provide startRef or startCoordinates for drag");
						if (!params.coordinates && !params.ref) return createErrorResponse("Provide ref or end coordinates for drag");
						let start = params.startCoordinates ? project(params.startCoordinates) : void 0;
						let end = params.coordinates ? project(params.coordinates) : void 0;
						{
							const stale = (() => {
								if (!params.startCoordinates && !params.coordinates) return null;
								const getHostname = (url) => {
									try {
										return new URL(url).hostname;
									} catch (_unused6) {
										return "";
									}
								};
								const currentHostname = getHostname(tab.url || "");
								const ctx = screenshotContextManager.getContext(tab.id);
								const contextHostname = ctx === null || ctx === void 0 ? void 0 : ctx.hostname;
								if (contextHostname && contextHostname !== currentHostname) return createErrorResponse(`Security check failed: Domain changed since last screenshot (from ${contextHostname} to ${currentHostname}) during left_click_drag. Capture a new screenshot or use ref/selector.`);
								return null;
							})();
							if (stale) return stale;
						}
						if (params.startRef || params.ref) yield _this6.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
						if (params.startRef) try {
							const resolved = yield _this6.sendMessageToTab(tab.id, {
								action: TOOL_MESSAGE_TYPES.RESOLVE_REF,
								ref: params.startRef
							});
							if (resolved && resolved.success) start = project({
								x: resolved.center.x,
								y: resolved.center.y
							});
						} catch (_unused7) {}
						if (params.ref) try {
							const resolved = yield _this6.sendMessageToTab(tab.id, {
								action: TOOL_MESSAGE_TYPES.RESOLVE_REF,
								ref: params.ref
							});
							if (resolved && resolved.success) end = project({
								x: resolved.center.x,
								y: resolved.center.y
							});
						} catch (_unused8) {}
						if (!start || !end) return createErrorResponse("Failed to resolve drag coordinates");
						try {
							yield CDPHelper.attach(tab.id);
							yield CDPHelper.dispatchMouseEvent(tab.id, {
								type: "mouseMoved",
								x: start.x,
								y: start.y,
								button: "none",
								buttons: 0
							});
							yield CDPHelper.dispatchMouseEvent(tab.id, {
								type: "mousePressed",
								x: start.x,
								y: start.y,
								button: "left",
								buttons: 1,
								clickCount: 1
							});
							yield CDPHelper.dispatchMouseEvent(tab.id, {
								type: "mouseMoved",
								x: end.x,
								y: end.y,
								button: "left",
								buttons: 1
							});
							yield CDPHelper.dispatchMouseEvent(tab.id, {
								type: "mouseReleased",
								x: end.x,
								y: end.y,
								button: "left",
								buttons: 0,
								clickCount: 1
							});
							yield CDPHelper.detach(tab.id);
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										action: "left_click_drag",
										start,
										end
									})
								}],
								isError: false
							};
						} catch (e) {
							yield CDPHelper.detach(tab.id);
							return createErrorResponse(`Drag failed: ${e instanceof Error ? e.message : String(e)}`);
						}
					}
					case "scroll": {
						if (!params.coordinates && !params.ref) return createErrorResponse("Provide ref or coordinates for scroll");
						let coord = params.coordinates ? project(params.coordinates) : void 0;
						if (params.ref) try {
							yield _this6.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
							const resolved = yield _this6.sendMessageToTab(tab.id, {
								action: TOOL_MESSAGE_TYPES.RESOLVE_REF,
								ref: params.ref
							});
							if (resolved && resolved.success) coord = project({
								x: resolved.center.x,
								y: resolved.center.y
							});
						} catch (_unused9) {}
						if (!coord) return createErrorResponse("Failed to resolve scroll coordinates");
						{
							const stale = (() => {
								if (!params.coordinates) return null;
								const getHostname = (url) => {
									try {
										return new URL(url).hostname;
									} catch (_unused10) {
										return "";
									}
								};
								const currentHostname = getHostname(tab.url || "");
								const ctx = screenshotContextManager.getContext(tab.id);
								const contextHostname = ctx === null || ctx === void 0 ? void 0 : ctx.hostname;
								if (contextHostname && contextHostname !== currentHostname) return createErrorResponse(`Security check failed: Domain changed since last screenshot (from ${contextHostname} to ${currentHostname}) during scroll. Capture a new screenshot or use ref/selector.`);
								return null;
							})();
							if (stale) return stale;
						}
						const direction = params.scrollDirection || "down";
						const amount = Math.max(1, Math.min(params.scrollAmount || 3, 10));
						const unit = 100;
						let deltaX = 0, deltaY = 0;
						if (direction === "up") deltaY = -amount * unit;
						if (direction === "down") deltaY = amount * unit;
						if (direction === "left") deltaX = -amount * unit;
						if (direction === "right") deltaX = amount * unit;
						try {
							yield CDPHelper.attach(tab.id);
							yield CDPHelper.dispatchMouseEvent(tab.id, {
								type: "mouseWheel",
								x: coord.x,
								y: coord.y,
								deltaX,
								deltaY
							});
							yield CDPHelper.detach(tab.id);
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										action: "scroll",
										coordinates: coord,
										deltaX,
										deltaY
									})
								}],
								isError: false
							};
						} catch (e) {
							yield CDPHelper.detach(tab.id);
							return createErrorResponse(`Scroll failed: ${e instanceof Error ? e.message : String(e)}`);
						}
					}
					case "type":
						if (!params.text) return createErrorResponse("Text parameter is required for type action");
						try {
							if (params.ref) yield clickTool.execute({
								ref: params.ref,
								waitForNavigation: false,
								timeout: TIMEOUTS.DEFAULT_WAIT * 5
							});
							yield CDPHelper.attach(tab.id);
							yield CDPHelper.insertText(tab.id, params.text);
							yield CDPHelper.detach(tab.id);
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										action: "type",
										length: params.text.length
									})
								}],
								isError: false
							};
						} catch (e) {
							yield CDPHelper.detach(tab.id);
							return yield keyboardTool.execute({
								keys: params.text.split("").join(","),
								delay: 0,
								selector: void 0
							});
						}
					case "fill":
						if (!params.ref && !params.selector) return createErrorResponse("Provide ref or selector and a value for fill");
						return yield fillTool.execute({
							selector: params.selector,
							selectorType: params.selectorType,
							ref: params.ref,
							value: params.value
						});
					case "fill_form": {
						const elements = params.elements;
						if (!Array.isArray(elements) || elements.length === 0) return createErrorResponse("elements must be a non-empty array for fill_form");
						const results = [];
						for (const item of elements) {
							if (!item || !item.ref) {
								results.push({
									ref: String((item === null || item === void 0 ? void 0 : item.ref) || ""),
									ok: false,
									error: "missing ref"
								});
								continue;
							}
							try {
								const ok = !(yield fillTool.execute({
									ref: item.ref,
									value: item.value
								})).isError;
								results.push({
									ref: item.ref,
									ok,
									error: ok ? void 0 : "failed"
								});
							} catch (e) {
								results.push({
									ref: item.ref,
									ok: false,
									error: String(e instanceof Error ? e.message : e)
								});
							}
						}
						const successCount = results.filter((r) => r.ok).length;
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									success: true,
									action: "fill_form",
									filled: successCount,
									total: results.length,
									results
								})
							}],
							isError: false
						};
					}
					case "key": {
						var _params$repeat;
						if (!params.text) return createErrorResponse("text is required for key action (e.g., \"Backspace Backspace Enter\" or \"cmd+a\")");
						const tokens = params.text.trim().split(/\s+/).filter(Boolean);
						const repeat = (_params$repeat = params.repeat) !== null && _params$repeat !== void 0 ? _params$repeat : 1;
						if (!Number.isInteger(repeat) || repeat < 1 || repeat > 100) return createErrorResponse("repeat must be an integer between 1 and 100 for key action");
						try {
							if (params.ref) yield clickTool.execute({
								ref: params.ref,
								waitForNavigation: false,
								timeout: TIMEOUTS.DEFAULT_WAIT * 5
							});
							yield CDPHelper.attach(tab.id);
							for (let i = 0; i < repeat; i++) for (const t of tokens) if (t.includes("+")) yield CDPHelper.dispatchKeyChord(tab.id, t);
							else yield CDPHelper.dispatchSimpleKey(tab.id, t);
							yield CDPHelper.detach(tab.id);
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										action: "key",
										keys: tokens,
										repeat
									})
								}],
								isError: false
							};
						} catch (e) {
							yield CDPHelper.detach(tab.id);
							const keysStr = tokens.join(",");
							const repeatedKeys = repeat === 1 ? keysStr : Array.from({ length: repeat }, () => keysStr).join(",");
							return yield keyboardTool.execute({ keys: repeatedKeys });
						}
					}
					case "wait": if (typeof params.text === "string" && params.text.trim().length > 0) try {
						yield _this6.injectContentScript(tab.id, ["inject-scripts/wait-helper.js"], false, "ISOLATED", true);
						const appear = params.appear !== false;
						const timeoutMs = Math.max(0, Math.min(params.timeout || 1e4, 12e4));
						const resp = yield _this6.sendMessageToTab(tab.id, {
							action: TOOL_MESSAGE_TYPES.WAIT_FOR_TEXT,
							text: params.text,
							appear,
							timeout: timeoutMs
						});
						if (!resp || resp.success !== true) return createErrorResponse(resp && resp.reason === "timeout" ? `wait_for timed out after ${timeoutMs}ms for text: ${params.text}` : `wait_for failed: ${resp && resp.error ? resp.error : "unknown error"}`);
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									success: true,
									action: "wait_for",
									appear,
									text: params.text,
									matched: resp.matched || null,
									tookMs: resp.tookMs
								})
							}],
							isError: false
						};
					} catch (e) {
						return createErrorResponse(`wait_for failed: ${e instanceof Error ? e.message : String(e)}`);
					}
					else {
						const seconds = Math.max(0, Math.min(params.duration || 0, 30));
						if (!seconds) return createErrorResponse("Duration parameter is required and must be > 0");
						yield new Promise((r) => setTimeout(r, seconds * 1e3));
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									success: true,
									action: "wait",
									duration: seconds
								})
							}],
							isError: false
						};
					}
					case "scroll_to":
						if (!params.ref) return createErrorResponse("ref is required for scroll_to action");
						try {
							yield _this6.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
							const resp = yield _this6.sendMessageToTab(tab.id, {
								action: "focusByRef",
								ref: params.ref
							});
							if (!resp || resp.success !== true) return createErrorResponse((resp === null || resp === void 0 ? void 0 : resp.error) || "scroll_to failed: element not found");
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										action: "scroll_to",
										ref: params.ref
									})
								}],
								isError: false
							};
						} catch (e) {
							return createErrorResponse(`scroll_to failed: ${e instanceof Error ? e.message : String(e)}`);
						}
					case "zoom": {
						const region = params.region;
						if (!region) return createErrorResponse("region is required for zoom action");
						const x0 = Number(region.x0);
						const y0 = Number(region.y0);
						const x1 = Number(region.x1);
						const y1 = Number(region.y1);
						if (![
							x0,
							y0,
							x1,
							y1
						].every(Number.isFinite)) return createErrorResponse("region must contain finite numbers (x0, y0, x1, y1)");
						if (x0 < 0 || y0 < 0 || x1 <= x0 || y1 <= y0) return createErrorResponse("Invalid region: require x0>=0, y0>=0 and x1>x0, y1>y0");
						const p0 = project({
							x: x0,
							y: y0
						});
						const p1 = project({
							x: x1,
							y: y1
						});
						const rx0 = Math.min(p0.x, p1.x);
						const ry0 = Math.min(p0.y, p1.y);
						const rx1 = Math.max(p0.x, p1.x);
						const ry1 = Math.max(p0.y, p1.y);
						const w = rx1 - rx0;
						const h = ry1 - ry0;
						if (w <= 0 || h <= 0) return createErrorResponse("Invalid region after projection");
						{
							const getHostname = (url) => {
								try {
									return new URL(url).hostname;
								} catch (_unused11) {
									return "";
								}
							};
							const ctx = screenshotContextManager.getContext(tab.id);
							const contextHostname = ctx === null || ctx === void 0 ? void 0 : ctx.hostname;
							const currentHostname = getHostname(tab.url || "");
							if (contextHostname && contextHostname !== currentHostname) return createErrorResponse(`Security check failed: Domain changed since last screenshot (from ${contextHostname} to ${currentHostname}) during zoom. Capture a new screenshot first.`);
						}
						try {
							yield CDPHelper.attach(tab.id);
							const metrics = yield CDPHelper.send(tab.id, "Page.getLayoutMetrics", {});
							const viewport = (metrics === null || metrics === void 0 ? void 0 : metrics.layoutViewport) || (metrics === null || metrics === void 0 ? void 0 : metrics.visualViewport) || {
								clientWidth: 800,
								clientHeight: 600,
								pageX: 0,
								pageY: 0
							};
							const vw = Math.round(Number(viewport.clientWidth || 800));
							const vh = Math.round(Number(viewport.clientHeight || 600));
							if (rx1 > vw || ry1 > vh) {
								yield CDPHelper.detach(tab.id);
								return createErrorResponse(`Region exceeds viewport boundaries (${vw}x${vh}). Choose a region within the visible viewport.`);
							}
							const pageX = Number(viewport.pageX || 0);
							const pageY = Number(viewport.pageY || 0);
							const shot = yield CDPHelper.send(tab.id, "Page.captureScreenshot", {
								format: "png",
								captureBeyondViewport: false,
								fromSurface: true,
								clip: {
									x: pageX + rx0,
									y: pageY + ry0,
									width: w,
									height: h,
									scale: 1
								}
							});
							yield CDPHelper.detach(tab.id);
							const base64Data = String((shot === null || shot === void 0 ? void 0 : shot.data) || "");
							if (!base64Data) return createErrorResponse("Failed to capture zoom screenshot via CDP");
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										action: "zoom",
										mimeType: "image/png",
										base64Data,
										region: {
											x0: rx0,
											y0: ry0,
											x1: rx1,
											y1: ry1
										}
									})
								}],
								isError: false
							};
						} catch (e) {
							yield CDPHelper.detach(tab.id);
							return createErrorResponse(`zoom failed: ${e instanceof Error ? e.message : String(e)}`);
						}
					}
					case "screenshot": return yield screenshotTool.execute({
						name: "computer",
						storeBase64: true,
						fullPage: false
					});
					default: return createErrorResponse(`Unsupported action: ${params.action}`);
				}
			})();
		}
		/**
		* DOM-based hover fallback when CDP is unavailable
		* Tries ref-based approach first (works with iframes), falls back to coordinates
		*/
		domHoverFallback(tabId, coord, resolvedBy, ref) {
			var _this7 = this;
			return _asyncToGenerator(function* () {
				if (ref) try {
					const resp = yield _this7.sendMessageToTab(tabId, {
						action: TOOL_MESSAGE_TYPES.DISPATCH_HOVER_FOR_REF,
						ref
					});
					if (resp === null || resp === void 0 ? void 0 : resp.success) return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								action: "hover",
								resolvedBy: "ref",
								transport: "dom-ref",
								target: resp.target
							})
						}],
						isError: false
					};
				} catch (error) {
					console.warn("[ComputerTool] DOM ref hover failed, falling back to coordinates", error);
				}
				if (!coord) return createErrorResponse("Hover fallback requires coordinates or ref");
				try {
					const [injection] = yield chrome.scripting.executeScript({
						target: { tabId },
						world: "MAIN",
						func: (point) => {
							var _target$textContent;
							const target = document.elementFromPoint(point.x, point.y);
							if (!target) return {
								success: false,
								error: "No element found at coordinates"
							};
							for (const type of [
								"mousemove",
								"mouseover",
								"mouseenter"
							]) target.dispatchEvent(new MouseEvent(type, {
								bubbles: true,
								cancelable: true,
								clientX: point.x,
								clientY: point.y,
								view: window
							}));
							return {
								success: true,
								target: {
									tagName: target.tagName,
									id: target.id,
									className: target.className,
									text: ((_target$textContent = target.textContent) === null || _target$textContent === void 0 || (_target$textContent = _target$textContent.trim()) === null || _target$textContent === void 0 ? void 0 : _target$textContent.slice(0, 100)) || ""
								}
							};
						},
						args: [coord]
					});
					const payload = injection === null || injection === void 0 ? void 0 : injection.result;
					if (!(payload === null || payload === void 0 ? void 0 : payload.success)) return createErrorResponse((payload === null || payload === void 0 ? void 0 : payload.error) || "DOM hover fallback failed");
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								action: "hover",
								coordinates: coord,
								resolvedBy,
								transport: "dom",
								target: payload.target
							})
						}],
						isError: false
					};
				} catch (error) {
					return createErrorResponse(`DOM hover fallback failed: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
		/**
		* Trigger GIF auto-capture after a successful action.
		* This is a no-op if auto-capture is not active.
		*/
		triggerAutoCapture(tabId, actionType, metadata) {
			return _asyncToGenerator(function* () {
				if (!isAutoCaptureActive(tabId)) return;
				try {
					yield captureFrameOnAction(tabId, _objectSpread2({ type: actionType }, metadata));
				} catch (error) {
					console.warn("[ComputerTool] Auto-capture failed:", error);
				}
			})();
		}
	};
	var computerTool = new ComputerTool();
	//#endregion
	//#region entrypoints/background/tools/browser/dialog.ts
	init_cdp_session_manager();
	init_defineProperty();
	init_asyncToGenerator();
	/**
	* Handle JavaScript dialogs (alert/confirm/prompt) via CDP Page.handleJavaScriptDialog
	*/
	var HandleDialogTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.HANDLE_DIALOG);
		}
		execute(args) {
			return _asyncToGenerator(function* () {
				const { action, promptText } = args || {};
				if (!action || action !== "accept" && action !== "dismiss") return createErrorResponse("action must be \"accept\" or \"dismiss\"");
				try {
					const [activeTab] = yield chrome.tabs.query({
						active: true,
						currentWindow: true
					});
					if (!(activeTab === null || activeTab === void 0 ? void 0 : activeTab.id)) return createErrorResponse("No active tab found");
					const tabId = activeTab.id;
					yield cdpSessionManager.withSession(tabId, "dialog", _asyncToGenerator(function* () {
						yield cdpSessionManager.sendCommand(tabId, "Page.enable");
						yield cdpSessionManager.sendCommand(tabId, "Page.handleJavaScriptDialog", {
							accept: action === "accept",
							promptText: action === "accept" ? promptText : void 0
						});
					}));
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								action,
								promptText: promptText || null
							})
						}],
						isError: false
					};
				} catch (error) {
					return createErrorResponse(`Failed to handle dialog: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
	};
	var handleDialogTool = new HandleDialogTool();
	//#endregion
	//#region entrypoints/background/tools/browser/download.ts
	init_defineProperty();
	init_asyncToGenerator();
	/**
	* Tool: wait for a download and return info
	*/
	var HandleDownloadTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.HANDLE_DOWNLOAD);
		}
		execute(args) {
			return _asyncToGenerator(function* () {
				var _args$timeoutMs;
				const filenameContains = String((args === null || args === void 0 ? void 0 : args.filenameContains) || "").trim();
				const waitForComplete = (args === null || args === void 0 ? void 0 : args.waitForComplete) !== false;
				const timeoutMs = Math.max(1e3, Math.min(Number((_args$timeoutMs = args === null || args === void 0 ? void 0 : args.timeoutMs) !== null && _args$timeoutMs !== void 0 ? _args$timeoutMs : 6e4), 3e5));
				try {
					const result = yield waitForDownload({
						filenameContains,
						waitForComplete,
						timeoutMs
					});
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								download: result
							})
						}],
						isError: false
					};
				} catch (e) {
					return createErrorResponse(`Handle download failed: ${(e === null || e === void 0 ? void 0 : e.message) || String(e)}`);
				}
			})();
		}
	};
	function waitForDownload(_x2) {
		return _waitForDownload.apply(this, arguments);
	}
	function _waitForDownload() {
		_waitForDownload = _asyncToGenerator(function* (opts) {
			const { filenameContains, waitForComplete, timeoutMs } = opts;
			return new Promise((resolve, reject) => {
				let timer = null;
				const onError = (err) => {
					cleanup();
					reject(err instanceof Error ? err : new Error(String(err)));
				};
				const cleanup = () => {
					try {
						if (timer) clearTimeout(timer);
					} catch (_unused) {}
					try {
						chrome.downloads.onCreated.removeListener(onCreated);
					} catch (_unused2) {}
					try {
						chrome.downloads.onChanged.removeListener(onChanged);
					} catch (_unused3) {}
				};
				const matches = (item) => {
					if (!filenameContains) return true;
					return ((item.filename || "").split(/[/\\]/).pop() || "").includes(filenameContains) || (item.url || "").includes(filenameContains);
				};
				const fulfill = function() {
					var _ref2 = _asyncToGenerator(function* (item) {
						try {
							var _ref, _out$fileSize;
							const [found] = yield chrome.downloads.search({ id: item.id });
							const out = found || item;
							cleanup();
							resolve({
								id: out.id,
								filename: out.filename,
								url: out.url,
								mime: out.mime || void 0,
								fileSize: (_ref = (_out$fileSize = out.fileSize) !== null && _out$fileSize !== void 0 ? _out$fileSize : out.totalBytes) !== null && _ref !== void 0 ? _ref : void 0,
								state: out.state,
								danger: out.danger,
								startTime: out.startTime,
								endTime: out.endTime || void 0,
								exists: out.exists
							});
							return;
						} catch (_unused4) {
							cleanup();
							resolve({
								id: item.id,
								filename: item.filename,
								url: item.url,
								state: item.state
							});
						}
					});
					return function fulfill(_x) {
						return _ref2.apply(this, arguments);
					};
				}();
				const onCreated = (item) => {
					try {
						if (!matches(item)) return;
						if (!waitForComplete) fulfill(item);
					} catch (_unused5) {}
				};
				const onChanged = (delta) => {
					try {
						if (!delta || typeof delta.id !== "number") return;
						chrome.downloads.search({ id: delta.id }).then((arr) => {
							const item = arr && arr[0];
							if (!item) return;
							if (!matches(item)) return;
							if (waitForComplete && item.state === "complete") fulfill(item);
						}).catch(() => {});
					} catch (_unused6) {}
				};
				chrome.downloads.onCreated.addListener(onCreated);
				chrome.downloads.onChanged.addListener(onChanged);
				timer = setTimeout(() => onError(/* @__PURE__ */ new Error("Download wait timed out")), timeoutMs);
				chrome.downloads.search({ state: waitForComplete ? "in_progress" : void 0 }).then((arr) => {
					const hit = (arr || []).find((d) => matches(d));
					if (hit && !waitForComplete) fulfill(hit);
				}).catch(() => {});
			});
		});
		return _waitForDownload.apply(this, arguments);
	}
	var handleDownloadTool = new HandleDownloadTool();
	//#endregion
	//#region \0@oxc-project+runtime@0.137.0/helpers/esm/objectWithoutPropertiesLoose.js
	function _objectWithoutPropertiesLoose(r, e) {
		if (null == r) return {};
		var t = {};
		for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
			if (e.includes(n)) continue;
			t[n] = r[n];
		}
		return t;
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.137.0/helpers/esm/objectWithoutProperties.js
	function _objectWithoutProperties(e, t) {
		if (null == e) return {};
		var o, r, i = _objectWithoutPropertiesLoose(e, t);
		if (Object.getOwnPropertySymbols) {
			var s = Object.getOwnPropertySymbols(e);
			for (r = 0; r < s.length; r++) o = s[r], t.includes(o) || {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
		}
		return i;
	}
	//#endregion
	//#region entrypoints/background/tools/browser/userscript.ts
	init_cdp_session_manager();
	init_asyncToGenerator();
	init_defineProperty();
	var _excluded = ["id"];
	var activeInjections = /* @__PURE__ */ new Map();
	function loadAllRecords() {
		return _loadAllRecords.apply(this, arguments);
	}
	function _loadAllRecords() {
		_loadAllRecords = _asyncToGenerator(function* () {
			return (yield chrome.storage.local.get([STORAGE_KEYS.USERSCRIPTS]))[STORAGE_KEYS.USERSCRIPTS] || {};
		});
		return _loadAllRecords.apply(this, arguments);
	}
	function saveAllRecords(_x) {
		return _saveAllRecords.apply(this, arguments);
	}
	function _saveAllRecords() {
		_saveAllRecords = _asyncToGenerator(function* (records) {
			yield chrome.storage.local.set({ [STORAGE_KEYS.USERSCRIPTS]: records });
		});
		return _saveAllRecords.apply(this, arguments);
	}
	function fnv1a(str) {
		let h = 2166136261;
		for (let i = 0; i < str.length; i++) {
			h ^= str.charCodeAt(i);
			h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
		}
		return (h >>> 0).toString(16);
	}
	function now() {
		return Date.now();
	}
	function computeSHA256(_x2) {
		return _computeSHA.apply(this, arguments);
	}
	function _computeSHA() {
		_computeSHA = _asyncToGenerator(function* (input) {
			const enc = new TextEncoder().encode(input);
			const digest = yield crypto.subtle.digest("SHA-256", enc);
			return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
		});
		return _computeSHA.apply(this, arguments);
	}
	function probeUnsafeEvalInMain(_x3) {
		return _probeUnsafeEvalInMain.apply(this, arguments);
	}
	function _probeUnsafeEvalInMain() {
		_probeUnsafeEvalInMain = _asyncToGenerator(function* (tabId) {
			try {
				const res = yield chrome.scripting.executeScript({
					target: {
						tabId,
						allFrames: false
					},
					world: ExecutionWorld.MAIN,
					func: () => {
						try {
							return !!new Function("return 1")();
						} catch (_unused) {
							return false;
						}
					}
				});
				return Array.isArray(res) && res[0] && res[0].result === true;
			} catch (_unused2) {
				return false;
			}
		});
		return _probeUnsafeEvalInMain.apply(this, arguments);
	}
	function parseUserscriptMeta(source) {
		const meta = {};
		const start = source.indexOf("==UserScript==");
		const end = source.indexOf("==/UserScript==");
		if (start !== -1 && end !== -1 && end > start) {
			const block = source.slice(start, end).split(/\r?\n/);
			for (const line of block) {
				const m = line.match(/@([\w-]+)\s+(.+)/);
				if (m) {
					const k = m[1].trim();
					const v = m[2].trim();
					if (!meta[k]) meta[k] = [];
					meta[k].push(v);
				}
			}
			return {
				meta,
				isTM: true
			};
		}
		return {
			meta: {},
			isTM: false
		};
	}
	function pick(arr) {
		return arr && arr.length > 0 ? arr[0] : void 0;
	}
	function deriveName(meta, fallback) {
		return pick(meta["name"]) || fallback;
	}
	function toBoolean(val, d) {
		return typeof val === "boolean" ? val : d;
	}
	function isLikelyCSS(source) {
		const trimmed = source.trim();
		if (trimmed.startsWith("/*") && trimmed.includes("==UserStyle")) return true;
		if (/^[.#\w\-\s*,:>+~\n\r{}();'"%!@/]+$/.test(trimmed)) {
			if (!/(function|=>|var\s|let\s|const\s|document\.|window\.|\beval\b|new\s+Function)/.test(trimmed)) {
				const colon = (trimmed.match(/:/g) || []).length;
				const brace = (trimmed.match(/[{}]/g) || []).length;
				return colon > 0 && brace >= 2;
			}
		}
		return false;
	}
	function normalizeMatches(matches, currentUrl) {
		if (matches && matches.length > 0) return matches;
		if (!currentUrl) return ["<all_urls>"];
		try {
			const u = new URL(currentUrl);
			const host = u.hostname;
			const base = host.startsWith("www.") ? host.slice(4) : host;
			return [`${u.protocol}//*.${base}/*`, `${u.protocol}//${host}/*`];
		} catch (_unused3) {
			return ["<all_urls>"];
		}
	}
	function matchUrl(patterns, url) {
		if (!url) return false;
		try {
			const u = new URL(url);
			for (const p of patterns) {
				if (p === "<all_urls>") return true;
				const m = p.match(/^(\*|https?:)\/\/([^/]+)\/(.*)$/);
				if (!m) continue;
				const proto = m[1];
				const host = m[2];
				const path = m[3];
				if (proto !== "*" && proto !== u.protocol.replace(":", "")) continue;
				if (!new RegExp("^" + host.split(".").map((h) => h === "*" ? "[^.]+" : h.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")).join("\\.") + "$").test(u.hostname)) continue;
				const pathRegex = new RegExp("^" + path.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + "$");
				const testPath = (u.pathname + (u.search || "") + (u.hash || "")).replace(/^\//, "");
				if (pathRegex.test(testPath)) return true;
			}
		} catch (_unused4) {
			return false;
		}
		return false;
	}
	function getActiveTab() {
		return _getActiveTab.apply(this, arguments);
	}
	function _getActiveTab() {
		_getActiveTab = _asyncToGenerator(function* () {
			return (yield chrome.tabs.query({
				active: true,
				currentWindow: true
			}))[0] || null;
		});
		return _getActiveTab.apply(this, arguments);
	}
	function insertCssToTab(_x4, _x5, _x6) {
		return _insertCssToTab.apply(this, arguments);
	}
	function _insertCssToTab() {
		_insertCssToTab = _asyncToGenerator(function* (tabId, css, allFrames) {
			yield chrome.scripting.insertCSS({
				target: {
					tabId,
					allFrames
				},
				css
			});
		});
		return _insertCssToTab.apply(this, arguments);
	}
	function removeCssFromTab(_x7, _x8, _x9) {
		return _removeCssFromTab.apply(this, arguments);
	}
	function _removeCssFromTab() {
		_removeCssFromTab = _asyncToGenerator(function* (tabId, css, allFrames) {
			try {
				yield chrome.scripting.removeCSS({
					target: {
						tabId,
						allFrames
					},
					css
				});
			} catch (e) {}
		});
		return _removeCssFromTab.apply(this, arguments);
	}
	function injectJsPersistent(_x10, _x11, _x12, _x13) {
		return _injectJsPersistent.apply(this, arguments);
	}
	function _injectJsPersistent() {
		_injectJsPersistent = _asyncToGenerator(function* (tabId, code, world, allFrames) {
			if (world === ExecutionWorld.MAIN) {
				yield chrome.scripting.executeScript({
					target: {
						tabId,
						allFrames
					},
					files: ["inject-scripts/inject-bridge.js"],
					world: ExecutionWorld.ISOLATED
				});
				const wrapped = `(() => {
      try {
        // Optional command API: window.__userscript_onCommand(action, payload)
        window.addEventListener('chrome-mcp:execute', (ev) => {
          const { action, payload, requestId } = ev.detail || {};
          try {
            let result;
            const handler = (window as any).__userscript_onCommand;
            if (typeof handler === 'function') {
              result = handler(action, payload);
            }
            window.dispatchEvent(new CustomEvent('chrome-mcp:response', { detail: { requestId, data: result } }));
          } catch (err) {
            window.dispatchEvent(new CustomEvent('chrome-mcp:response', { detail: { requestId, error: String(err && (err as any).message || err) } }));
          }
        });
        (new Function(${JSON.stringify(code)}))();
      } catch (e) {
        console.warn('Userscript MAIN injection error:', e);
      }
    })();`;
				yield chrome.scripting.executeScript({
					target: {
						tabId,
						allFrames
					},
					func: (src) => {
						try {
							new Function(src)();
						} catch (e) {
							console.warn("Userscript MAIN wrapper execution error:", e);
						}
					},
					args: [wrapped],
					world: ExecutionWorld.MAIN
				});
			} else yield chrome.scripting.executeScript({
				target: {
					tabId,
					allFrames
				},
				func: (userCode) => {
					try {
						const handlerName = "__userscript_onCommand__";
						chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
							if (!req || req.type !== "userscript:command") return;
							const { action, payload, scriptId } = req;
							try {
								const handler = globalThis[handlerName];
								let result;
								if (typeof handler === "function") result = handler(action, payload, scriptId);
								sendResponse({ data: result });
							} catch (err) {
								sendResponse({ error: String(err && err.message || err) });
							}
							return true;
						});
						new Function(userCode)();
					} catch (e) {
						console.warn("Userscript ISOLATED injection error:", e);
					}
				},
				args: [code],
				world: ExecutionWorld.ISOLATED
			});
		});
		return _injectJsPersistent.apply(this, arguments);
	}
	function setActiveInjection(tabId, id, inj) {
		let m = activeInjections.get(tabId);
		if (!m) {
			m = /* @__PURE__ */ new Map();
			activeInjections.set(tabId, m);
		}
		m.set(id, inj);
	}
	function clearActiveInjection(tabId, id) {
		const m = activeInjections.get(tabId);
		if (m) m.delete(id);
	}
	function reinjectForTab(_x14, _x15) {
		return _reinjectForTab.apply(this, arguments);
	}
	function _reinjectForTab() {
		_reinjectForTab = _asyncToGenerator(function* (tabId, url) {
			if ((yield chrome.storage.local.get([STORAGE_KEYS.USERSCRIPTS_DISABLED]))[STORAGE_KEYS.USERSCRIPTS_DISABLED]) return;
			const all = yield loadAllRecords();
			for (const rec of Object.values(all)) {
				if (!rec.enabled || !rec.persist) continue;
				if (!matchUrl(rec.matches, url)) continue;
				try {
					if (rec.sourceType === "CSS") {
						yield insertCssToTab(tabId, rec.script, rec.allFrames);
						setActiveInjection(tabId, rec.id, { kind: "css" });
					} else {
						if (rec.world === "MAIN") {
							if (!(yield probeUnsafeEvalInMain(tabId))) {
								rec.cspBlocked = true;
								yield injectJsPersistent(tabId, rec.script, "ISOLATED", rec.allFrames);
								setActiveInjection(tabId, rec.id, {
									kind: "js",
									world: "ISOLATED"
								});
								continue;
							}
						}
						yield injectJsPersistent(tabId, rec.script, rec.world, rec.allFrames);
						setActiveInjection(tabId, rec.id, {
							kind: "js",
							world: rec.world
						});
					}
				} catch (e) {
					console.warn("Reinject failed for tab", tabId, rec.id, e);
				}
			}
		});
		return _reinjectForTab.apply(this, arguments);
	}
	chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
		if (changeInfo.status === "complete") reinjectForTab(tabId, tab.url).catch(() => {});
	});
	chrome.webNavigation.onCommitted.addListener(function() {
		var _ref = _asyncToGenerator(function* (details) {
			if (details.frameId !== 0) return;
			const tab = yield chrome.tabs.get(details.tabId).catch(() => null);
			if (!tab) return;
			if ((yield chrome.storage.local.get([STORAGE_KEYS.USERSCRIPTS_DISABLED]))[STORAGE_KEYS.USERSCRIPTS_DISABLED]) return;
			const all = yield loadAllRecords();
			for (const rec of Object.values(all)) {
				if (!rec.enabled || !rec.persist || rec.runAt !== "document_start") continue;
				if (!matchUrl(rec.matches, tab.url)) continue;
				try {
					if (rec.sourceType === "CSS") yield insertCssToTab(details.tabId, rec.script, rec.allFrames);
					else yield injectJsPersistent(details.tabId, rec.script, rec.world, rec.allFrames);
				} catch (_unused5) {}
			}
		});
		return function(_x16) {
			return _ref.apply(this, arguments);
		};
	}());
	chrome.webNavigation.onDOMContentLoaded.addListener(function() {
		var _ref2 = _asyncToGenerator(function* (details) {
			if (details.frameId !== 0) return;
			const tab = yield chrome.tabs.get(details.tabId).catch(() => null);
			if (!tab) return;
			if ((yield chrome.storage.local.get([STORAGE_KEYS.USERSCRIPTS_DISABLED]))[STORAGE_KEYS.USERSCRIPTS_DISABLED]) return;
			const all = yield loadAllRecords();
			for (const rec of Object.values(all)) {
				if (!rec.enabled || !rec.persist || rec.runAt !== "document_end") continue;
				if (!matchUrl(rec.matches, tab.url)) continue;
				try {
					if (rec.sourceType === "CSS") yield insertCssToTab(details.tabId, rec.script, rec.allFrames);
					else yield injectJsPersistent(details.tabId, rec.script, rec.world, rec.allFrames);
				} catch (_unused6) {}
			}
		});
		return function(_x17) {
			return _ref2.apply(this, arguments);
		};
	}());
	var UserscriptTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.USERSCRIPT);
		}
		execute(params) {
			var _this = this;
			return _asyncToGenerator(function* () {
				try {
					const { action } = params;
					const args = params.args || {};
					switch (action) {
						case "create": return yield _this.create(args);
						case "list": return yield _this.list(args);
						case "get": return yield _this.get(args);
						case "enable": return yield _this.enable(args, true);
						case "disable": return yield _this.enable(args, false);
						case "update": return yield _this.update(args);
						case "remove": return yield _this.remove(args);
						case "send_command": return yield _this.sendCommand(args);
						case "export": return yield _this.exportAll();
						default: return createErrorResponse(`Unknown action: ${String(action)}`);
					}
				} catch (error) {
					console.error("Userscript tool error:", error);
					return createErrorResponse(`Userscript error: ${error instanceof Error ? error.message : String(error)}`);
				}
			})();
		}
		create(args) {
			return _asyncToGenerator(function* () {
				var _all$id, _all$id2, _all$id3, _all$id4, _all$id$allFrames, _all$id5;
				const active = yield getActiveTab();
				if (!active || !active.id) return createErrorResponse("No active tab found");
				const currentUrl = active.url;
				const emergency = (yield chrome.storage.local.get([STORAGE_KEYS.USERSCRIPTS_DISABLED]))[STORAGE_KEYS.USERSCRIPTS_DISABLED];
				const { meta, isTM } = parseUserscriptMeta(args.script);
				const name = args.name || deriveName(meta, void 0);
				const description = args.description || pick(meta["description"]);
				const matches = normalizeMatches(args.matches || meta["match"] || meta["include"], currentUrl);
				const excludes = args.excludes || meta["exclude"] || [];
				const runAt = (args.runAt && args.runAt !== "auto" ? args.runAt : pick(meta["run-at"])) || "document_idle";
				const requestedWorld = (args.world && args.world !== "auto" ? args.world : pick(meta["inject-into"])) || "ISOLATED";
				const allFrames = toBoolean(args.allFrames, true);
				const persist = toBoolean(args.persist, true);
				const dnrFallback = toBoolean(args.dnrFallback, true);
				const mode = args.mode || "auto";
				const sourceType = isTM ? "TM" : mode === "css" || isLikelyCSS(args.script) ? "CSS" : "JS";
				const sha256 = yield computeSHA256(args.script).catch(() => void 0);
				const id = `us_${fnv1a((name || "") + "|" + args.script)}`;
				const record = {
					id,
					name,
					description,
					script: args.script,
					sourceType,
					matches,
					excludes,
					runAt,
					world: requestedWorld === "MAIN" ? "MAIN" : "ISOLATED",
					allFrames,
					persist,
					dnrFallback,
					tags: args.tags,
					enabled: true,
					createdAt: now(),
					updatedAt: now(),
					applyCount: 0,
					sha256
				};
				const all = yield loadAllRecords();
				if (record.persist) {
					all[id] = record;
					yield saveAllRecords(all);
				}
				let applied = false;
				const fallbacks = [];
				let cspBlocked = false;
				const t0 = performance.now();
				try {
					if (mode === "once") {
						yield cdpSessionManager.withSession(active.id, "userscript_once", _asyncToGenerator(function* () {
							var _result$result;
							const expression = `(function(){try{return (function(){${record.script}\n})()}catch(e){return {__error:String(e&&e.message||e)}}})()`;
							const result = yield cdpSessionManager.sendCommand(active.id, "Runtime.evaluate", {
								expression,
								returnByValue: true,
								awaitPromise: true
							});
							if (result === null || result === void 0 || (_result$result = result.result) === null || _result$result === void 0 || (_result$result = _result$result.value) === null || _result$result === void 0 ? void 0 : _result$result.__error) throw new Error(result.result.value.__error);
						}));
						applied = true;
					} else if (sourceType === "CSS") {
						yield insertCssToTab(active.id, record.script, record.allFrames);
						setActiveInjection(active.id, id, { kind: "css" });
						applied = true;
					} else {
						if (record.world === "MAIN") {
							if (!(yield probeUnsafeEvalInMain(active.id))) {
								cspBlocked = true;
								fallbacks.push("MAIN->ISOLATED");
								yield injectJsPersistent(active.id, record.script, "ISOLATED", record.allFrames);
								setActiveInjection(active.id, id, {
									kind: "js",
									world: "ISOLATED"
								});
								applied = true;
							}
						}
						if (!applied) {
							yield injectJsPersistent(active.id, record.script, record.world, record.allFrames);
							setActiveInjection(active.id, id, {
								kind: "js",
								world: record.world
							});
							applied = true;
						}
					}
				} catch (e) {
					if (record.persist) {
						all[id].lastError = e instanceof Error ? e.message : String(e);
						all[id].cspBlocked = cspBlocked;
						yield saveAllRecords(all);
					}
				}
				const result = {
					id,
					status: record.persist && ((_all$id = all[id]) === null || _all$id === void 0 ? void 0 : _all$id.lastError) ? "queued" : applied ? "applied" : "queued",
					strategy: {
						kind: mode === "once" ? "once_cdp" : sourceType === "CSS" ? "insertCSS" : `persistent_${(record.persist ? ((_all$id2 = all[id]) === null || _all$id2 === void 0 ? void 0 : _all$id2.world) || record.world : record.world).toLowerCase()}`,
						runAt: record.persist ? ((_all$id3 = all[id]) === null || _all$id3 === void 0 ? void 0 : _all$id3.runAt) || record.runAt : record.runAt,
						world: record.persist ? ((_all$id4 = all[id]) === null || _all$id4 === void 0 ? void 0 : _all$id4.world) || record.world : record.world,
						allFrames: record.persist ? (_all$id$allFrames = (_all$id5 = all[id]) === null || _all$id5 === void 0 ? void 0 : _all$id5.allFrames) !== null && _all$id$allFrames !== void 0 ? _all$id$allFrames : record.allFrames : record.allFrames,
						fallbacksTried: fallbacks,
						cspBlocked
					},
					warnings: emergency ? ["USERSCRIPTS_DISABLED is ON, injection skipped"] : [],
					metrics: { injectMs: Math.round(performance.now() - t0) }
				};
				return {
					content: [{
						type: "text",
						text: JSON.stringify(result)
					}],
					isError: false
				};
			})();
		}
		list(args) {
			return _asyncToGenerator(function* () {
				const all = yield loadAllRecords();
				const q = (args && args.query ? String(args.query).toLowerCase() : "").trim();
				const status = args && args.status ? String(args.status) : "";
				const domain = args && args.domain ? String(args.domain) : "";
				const items = Object.values(all).filter((r) => status ? status === "enabled" ? r.enabled : !r.enabled : true).filter((r) => domain ? matchUrl(r.matches, `https://${domain}/`) : true).filter((r) => q ? (r.name || "").toLowerCase().includes(q) || (r.description || "").toLowerCase().includes(q) : true).map((r) => ({
					id: r.id,
					name: r.name,
					status: r.enabled ? "enabled" : "disabled",
					sourceType: r.sourceType,
					matches: r.matches,
					world: r.world,
					runAt: r.runAt,
					tags: r.tags || [],
					lastError: r.lastError,
					updatedAt: r.updatedAt,
					applyCount: r.applyCount || 0,
					lastAppliedAt: r.lastAppliedAt || null
				}));
				return {
					content: [{
						type: "text",
						text: JSON.stringify({
							ok: true,
							items
						})
					}],
					isError: false
				};
			})();
		}
		get(args) {
			return _asyncToGenerator(function* () {
				const { id } = args || {};
				if (!id) return createErrorResponse("id is required");
				const rec = (yield loadAllRecords())[id];
				if (!rec) return createErrorResponse("userscript not found");
				return {
					content: [{
						type: "text",
						text: JSON.stringify({
							ok: true,
							record: rec
						})
					}],
					isError: false
				};
			})();
		}
		enable(args, enabled) {
			return _asyncToGenerator(function* () {
				const { id } = args || {};
				if (!id) return createErrorResponse("id is required");
				const all = yield loadAllRecords();
				const rec = all[id];
				if (!rec) return createErrorResponse("userscript not found");
				rec.enabled = enabled;
				rec.updatedAt = now();
				yield saveAllRecords(all);
				return {
					content: [{
						type: "text",
						text: JSON.stringify({ ok: true })
					}],
					isError: false
				};
			})();
		}
		update(args) {
			return _asyncToGenerator(function* () {
				const { id } = args, rest = _objectWithoutProperties(args, _excluded);
				if (!id) return createErrorResponse("id is required");
				const all = yield loadAllRecords();
				const rec = all[id];
				if (!rec) return createErrorResponse("userscript not found");
				if (rest.name !== void 0) rec.name = rest.name;
				if (rest.description !== void 0) rec.description = rest.description;
				if (rest.matches) rec.matches = rest.matches;
				if (rest.excludes) rec.excludes = rest.excludes;
				if (rest.runAt && rest.runAt !== "auto") rec.runAt = rest.runAt;
				if (rest.world && rest.world !== "auto") rec.world = rest.world;
				if (typeof rest.allFrames === "boolean") rec.allFrames = rest.allFrames;
				if (typeof rest.persist === "boolean") rec.persist = rest.persist;
				if (typeof rest.dnrFallback === "boolean") rec.dnrFallback = rest.dnrFallback;
				if (rest.tags) rec.tags = rest.tags;
				if (typeof rest.script === "string") rec.script = rest.script;
				rec.updatedAt = now();
				yield saveAllRecords(all);
				return {
					content: [{
						type: "text",
						text: JSON.stringify({ ok: true })
					}],
					isError: false
				};
			})();
		}
		remove(args) {
			return _asyncToGenerator(function* () {
				const { id } = args || {};
				if (!id) return createErrorResponse("id is required");
				const all = yield loadAllRecords();
				const rec = all[id];
				if (!rec) return createErrorResponse("userscript not found");
				delete all[id];
				yield saveAllRecords(all);
				const active = yield getActiveTab();
				if (active && active.id) try {
					if (rec.sourceType === "CSS") yield removeCssFromTab(active.id, rec.script, rec.allFrames);
					else chrome.tabs.sendMessage(active.id, { type: "chrome-mcp:cleanup" }).catch(() => {});
					clearActiveInjection(active.id, rec.id);
				} catch (err) {
					console.warn("Userscript cleanup failed:", err);
				}
				return {
					content: [{
						type: "text",
						text: JSON.stringify({ ok: true })
					}],
					isError: false
				};
			})();
		}
		sendCommand(args) {
			return _asyncToGenerator(function* () {
				const { id, payload, tabId } = args || {};
				if (!id) return createErrorResponse("id is required");
				const tab = tabId ? yield chrome.tabs.get(tabId).catch(() => null) : yield getActiveTab();
				if (!tab || !tab.id) return createErrorResponse("No active tab found");
				const rec = (yield loadAllRecords())[id];
				if (!rec) return createErrorResponse("userscript not found");
				try {
					if (rec.world === "MAIN") {
						const result = yield chrome.tabs.sendMessage(tab.id, {
							action: "userscript:command",
							payload,
							targetWorld: "MAIN"
						});
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									ok: true,
									result
								})
							}],
							isError: false
						};
					} else {
						const result = yield chrome.tabs.sendMessage(tab.id, {
							type: "userscript:command",
							action: "userscript:command",
							payload,
							scriptId: id
						});
						return {
							content: [{
								type: "text",
								text: JSON.stringify({
									ok: true,
									result
								})
							}],
							isError: false
						};
					}
				} catch (e) {
					return createErrorResponse(`send_command failed: ${e instanceof Error ? e.message : String(e)}`);
				}
			})();
		}
		exportAll() {
			return _asyncToGenerator(function* () {
				const all = yield loadAllRecords();
				return {
					content: [{
						type: "text",
						text: JSON.stringify({
							ok: true,
							data: all
						})
					}],
					isError: false
				};
			})();
		}
	};
	var userscriptTool = new UserscriptTool();
	//#endregion
	//#region entrypoints/background/tools/browser/performance.ts
	init_cdp_session_manager();
	init_asyncToGenerator();
	init_defineProperty();
	var sessions = /* @__PURE__ */ new Map();
	var LAST_RESULTS = /* @__PURE__ */ new Map();
	function tracingCategories() {
		return [
			"-*",
			"blink.console",
			"blink.user_timing",
			"devtools.timeline",
			"disabled-by-default-devtools.screenshot",
			"disabled-by-default-devtools.timeline",
			"disabled-by-default-devtools.timeline.invalidationTracking",
			"disabled-by-default-devtools.timeline.frame",
			"disabled-by-default-devtools.timeline.stack",
			"disabled-by-default-v8.cpu_profiler",
			"disabled-by-default-v8.cpu_profiler.hires",
			"latencyInfo",
			"loading",
			"disabled-by-default-lighthouse",
			"v8.execute",
			"v8"
		];
	}
	function enablePerformanceMetrics(_x) {
		return _enablePerformanceMetrics.apply(this, arguments);
	}
	function _enablePerformanceMetrics() {
		_enablePerformanceMetrics = _asyncToGenerator(function* (tabId) {
			try {
				yield cdpSessionManager.sendCommand(tabId, "Performance.enable");
				const result = yield cdpSessionManager.sendCommand(tabId, "Performance.getMetrics");
				yield cdpSessionManager.sendCommand(tabId, "Performance.disable");
				const map = {};
				for (const m of result.metrics || []) map[m.name] = m.value;
				return map;
			} catch (e) {
				return {};
			}
		});
		return _enablePerformanceMetrics.apply(this, arguments);
	}
	function saveTraceToDownloads(_x2) {
		return _saveTraceToDownloads.apply(this, arguments);
	}
	function _saveTraceToDownloads() {
		_saveTraceToDownloads = _asyncToGenerator(function* (json, filenamePrefix = "performance_trace") {
			try {
				const filename = `${filenamePrefix}_${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.json`;
				const dataUrl = `data:application/json;base64,${btoa(unescape(encodeURIComponent(json)))}`;
				const downloadId = yield chrome.downloads.download({
					url: dataUrl,
					filename,
					saveAs: false
				});
				try {
					yield new Promise((r) => setTimeout(r, 120));
					const [item] = yield chrome.downloads.search({ id: downloadId });
					return {
						downloadId,
						filename,
						fullPath: item === null || item === void 0 ? void 0 : item.filename
					};
				} catch (_unused) {
					return {
						downloadId,
						filename
					};
				}
			} catch (_unused2) {
				return {};
			}
		});
		return _saveTraceToDownloads.apply(this, arguments);
	}
	function saveTraceToNativeTemp(_x3) {
		return _saveTraceToNativeTemp.apply(this, arguments);
	}
	function _saveTraceToNativeTemp() {
		_saveTraceToNativeTemp = _asyncToGenerator(function* (json, filenamePrefix = "performance_trace") {
			try {
				const filename = `${filenamePrefix}_${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.json`;
				const base64 = btoa(unescape(encodeURIComponent(json)));
				const requestId = `trace-temp-${Date.now()}-${Math.random().toString(36).slice(2)}`;
				const timeoutMs = 3e4;
				const resp = yield new Promise((resolve, reject) => {
					const timer = setTimeout(() => {
						chrome.runtime.onMessage.removeListener(listener);
						reject(/* @__PURE__ */ new Error("Native temp save timed out"));
					}, timeoutMs);
					const listener = (message) => {
						if (message && message.type === "file_operation_response" && message.responseToRequestId === requestId) {
							clearTimeout(timer);
							chrome.runtime.onMessage.removeListener(listener);
							resolve(message.payload);
						}
					};
					chrome.runtime.onMessage.addListener(listener);
					chrome.runtime.sendMessage({
						type: "forward_to_native",
						message: {
							type: "file_operation",
							requestId,
							payload: {
								action: "prepareFile",
								base64Data: base64,
								fileName: filename
							}
						}
					}).catch((err) => {
						clearTimeout(timer);
						chrome.runtime.onMessage.removeListener(listener);
						reject(err);
					});
				});
				if (resp && resp.success && resp.filePath) return {
					filename,
					fullPath: resp.filePath
				};
			} catch (_unused3) {}
		});
		return _saveTraceToNativeTemp.apply(this, arguments);
	}
	function cleanupNativeTempFile(_x4) {
		return _cleanupNativeTempFile.apply(this, arguments);
	}
	function _cleanupNativeTempFile() {
		_cleanupNativeTempFile = _asyncToGenerator(function* (filePath) {
			if (!filePath) return;
			try {
				const requestId = `trace-clean-${Date.now()}-${Math.random().toString(36).slice(2)}`;
				const timeoutMs = 1e4;
				yield new Promise((resolve) => {
					const timer = setTimeout(() => {
						chrome.runtime.onMessage.removeListener(listener);
						resolve();
					}, timeoutMs);
					const listener = (message) => {
						if (message && message.type === "file_operation_response" && message.responseToRequestId === requestId) {
							clearTimeout(timer);
							chrome.runtime.onMessage.removeListener(listener);
							resolve();
						}
					};
					chrome.runtime.onMessage.addListener(listener);
					chrome.runtime.sendMessage({
						type: "forward_to_native",
						message: {
							type: "file_operation",
							requestId,
							payload: {
								action: "cleanupFile",
								filePath
							}
						}
					}).catch(() => {
						clearTimeout(timer);
						chrome.runtime.onMessage.removeListener(listener);
						resolve();
					});
				});
			} catch (_unused4) {}
		});
		return _cleanupNativeTempFile.apply(this, arguments);
	}
	function getOrCreateStopPromise(session) {
		if (session.stopPromise) return session.stopPromise;
		session.stopPromise = new Promise((resolve) => {
			session.stopResolver = resolve;
		});
		return session.stopPromise;
	}
	/**
	* Start performance trace
	*/
	var PerformanceStartTraceTool = class extends BaseBrowserToolExecutor {
		constructor(..._args) {
			super(..._args);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.PERFORMANCE_START_TRACE);
		}
		execute(args) {
			return _asyncToGenerator(function* () {
				const { reload = false, autoStop = false, durationMs = 5e3 } = args || {};
				try {
					const [activeTab] = yield chrome.tabs.query({
						active: true,
						currentWindow: true
					});
					if (!(activeTab === null || activeTab === void 0 ? void 0 : activeTab.id)) return createErrorResponse("No active tab found");
					const tabId = activeTab.id;
					const existed = sessions.get(tabId);
					if (existed === null || existed === void 0 ? void 0 : existed.recording) return {
						content: [{
							type: "text",
							text: "Error: a performance trace is already running."
						}],
						isError: false
					};
					yield cdpSessionManager.attach(tabId, "performance");
					const state = {
						recording: true,
						events: [],
						startedAt: Date.now(),
						pageUrl: activeTab.url || "",
						listener: (source, method, params) => {
							if (source.tabId !== tabId) return;
							if (method === "Tracing.dataCollected" && (params === null || params === void 0 ? void 0 : params.value)) try {
								state.events.push(...params.value);
							} catch (_unused5) {}
							else if (method === "Tracing.tracingComplete") {
								var _state$stopResolver;
								state.recording = false;
								(_state$stopResolver = state.stopResolver) === null || _state$stopResolver === void 0 || _state$stopResolver.call(state, { completed: true });
							}
						}
					};
					chrome.debugger.onEvent.addListener(state.listener);
					sessions.set(tabId, state);
					const cats = tracingCategories().join(",");
					yield cdpSessionManager.sendCommand(tabId, "Tracing.start", {
						categories: cats,
						options: "record-as-much-as-possible",
						transferMode: "ReportEvents"
					});
					if (reload) try {
						yield cdpSessionManager.sendCommand(tabId, "Page.reload", { ignoreCache: true });
					} catch (_unused6) {}
					if (autoStop) setTimeout(_asyncToGenerator(function* () {
						try {
							yield cdpSessionManager.sendCommand(tabId, "Tracing.end");
						} catch (_unused7) {}
					}), Math.max(1e3, Math.min(durationMs, 6e4)));
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: "Performance trace is recording. Use performance_stop_trace to stop it.",
								reload,
								autoStop
							})
						}],
						isError: false
					};
				} catch (e) {
					return createErrorResponse(`Failed to start performance trace: ${(e === null || e === void 0 ? void 0 : e.message) || e}`);
				}
			})();
		}
	};
	/**
	* Stop performance trace
	*/
	var PerformanceStopTraceTool = class extends BaseBrowserToolExecutor {
		constructor(..._args2) {
			super(..._args2);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.PERFORMANCE_STOP_TRACE);
		}
		execute(args) {
			return _asyncToGenerator(function* () {
				const { saveToDownloads = true, filenamePrefix } = args || {};
				try {
					const [activeTab] = yield chrome.tabs.query({
						active: true,
						currentWindow: true
					});
					if (!(activeTab === null || activeTab === void 0 ? void 0 : activeTab.id)) return createErrorResponse("No active tab found");
					const tabId = activeTab.id;
					const session = sessions.get(tabId);
					if (!session) return {
						content: [{
							type: "text",
							text: "No performance trace session found for the current tab."
						}],
						isError: false
					};
					let stopResult = { completed: false };
					if (session.recording) {
						yield cdpSessionManager.sendCommand(tabId, "Tracing.end");
						yield getOrCreateStopPromise(session);
						stopResult = yield session.stopPromise;
					} else stopResult = { completed: true };
					const metrics = yield enablePerformanceMetrics(tabId);
					try {
						chrome.debugger.onEvent.removeListener(session.listener);
					} catch (_unused8) {}
					try {
						yield cdpSessionManager.detach(tabId, "performance");
					} catch (_unused9) {}
					const endedAt = Date.now();
					const trace = { traceEvents: session.events };
					const json = JSON.stringify(trace);
					let saved;
					if (saveToDownloads) saved = yield saveTraceToDownloads(json, filenamePrefix || "performance_trace");
					else {
						const tempSaved = yield saveTraceToNativeTemp(json, filenamePrefix || "performance_trace");
						if (tempSaved) saved = _objectSpread2({}, tempSaved);
					}
					LAST_RESULTS.set(tabId, {
						events: session.events,
						startedAt: session.startedAt,
						endedAt,
						tabUrl: session.pageUrl || "",
						saved,
						metrics
					});
					sessions.delete(tabId);
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								message: "The performance trace has been stopped.",
								eventCount: session.events.length,
								saved,
								metrics,
								startedAt: session.startedAt,
								endedAt,
								durationMs: endedAt - session.startedAt,
								url: session.pageUrl || "",
								tracingCompleted: (stopResult === null || stopResult === void 0 ? void 0 : stopResult.completed) === true
							})
						}],
						isError: false
					};
				} catch (e) {
					return createErrorResponse(`Failed to stop performance trace: ${(e === null || e === void 0 ? void 0 : e.message) || e}`);
				}
			})();
		}
	};
	/**
	* Analyze last trace (lightweight)
	* Note: Deep insights require DevTools front-end trace engine on the native side; this is a
	* pragmatic first step returning basic metrics and a quick event histogram.
	*/
	var PerformanceAnalyzeInsightTool = class extends BaseBrowserToolExecutor {
		constructor(..._args3) {
			super(..._args3);
			_defineProperty(this, "name", TOOL_NAMES.BROWSER.PERFORMANCE_ANALYZE_INSIGHT);
		}
		execute(args) {
			return _asyncToGenerator(function* () {
				const { insightName } = args || {};
				try {
					const [activeTab] = yield chrome.tabs.query({
						active: true,
						currentWindow: true
					});
					if (!(activeTab === null || activeTab === void 0 ? void 0 : activeTab.id)) return createErrorResponse("No active tab found");
					const tabId = activeTab.id;
					const result = LAST_RESULTS.get(tabId);
					if (!result) return {
						content: [{
							type: "text",
							text: "No recorded traces found. Start and stop a performance trace first."
						}],
						isError: false
					};
					const fullPath = result.saved && result.saved.fullPath || void 0;
					if (fullPath) try {
						var _args$timeoutMs;
						const requestId = `trace-analyze-${Date.now()}-${Math.random().toString(36).slice(2)}`;
						const timeoutMs = Math.max(1e4, Math.min((_args$timeoutMs = args === null || args === void 0 ? void 0 : args.timeoutMs) !== null && _args$timeoutMs !== void 0 ? _args$timeoutMs : 6e4, 3e5));
						const resp = yield new Promise((resolve, reject) => {
							const timer = setTimeout(() => {
								chrome.runtime.onMessage.removeListener(listener);
								reject(/* @__PURE__ */ new Error("Native trace analysis timed out"));
							}, timeoutMs);
							const listener = (message) => {
								if (message && message.type === "file_operation_response" && message.responseToRequestId === requestId) {
									clearTimeout(timer);
									chrome.runtime.onMessage.removeListener(listener);
									resolve(message.payload);
								}
							};
							chrome.runtime.onMessage.addListener(listener);
							chrome.runtime.sendMessage({
								type: "forward_to_native",
								message: {
									type: "file_operation",
									requestId,
									payload: {
										action: "analyzeTrace",
										traceFilePath: fullPath,
										insightName
									}
								}
							}).catch((err) => {
								clearTimeout(timer);
								chrome.runtime.onMessage.removeListener(listener);
								reject(err);
							});
						});
						if (resp && resp.success) {
							yield cleanupNativeTempFile(fullPath);
							return {
								content: [{
									type: "text",
									text: JSON.stringify({
										success: true,
										url: result.tabUrl,
										startedAt: result.startedAt,
										endedAt: result.endedAt,
										durationMs: result.endedAt - result.startedAt,
										metrics: result.metrics || {},
										saved: result.saved,
										summary: resp.summary,
										insight: resp.insight
									})
								}],
								isError: false
							};
						}
					} catch (e) {}
					const counts = /* @__PURE__ */ new Map();
					for (const ev of result.events.slice(0, 1e5)) {
						const n = typeof (ev === null || ev === void 0 ? void 0 : ev.name) === "string" ? ev.name : "unknown";
						counts.set(n, (counts.get(n) || 0) + 1);
					}
					const top = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 20).map(([name, count]) => ({
						name,
						count
					}));
					return {
						content: [{
							type: "text",
							text: JSON.stringify({
								success: true,
								info: "Lightweight analysis (no saved file path). Native-side deep analysis unavailable.",
								requestedInsight: insightName || null,
								url: result.tabUrl,
								startedAt: result.startedAt,
								endedAt: result.endedAt,
								durationMs: result.endedAt - result.startedAt,
								metrics: result.metrics || {},
								topEventNames: top,
								saved: result.saved
							})
						}],
						isError: false
					};
				} catch (e) {
					return createErrorResponse(`Failed to analyze trace: ${(e === null || e === void 0 ? void 0 : e.message) || e}`);
				}
			})();
		}
	};
	var performanceStartTraceTool = new PerformanceStartTraceTool();
	var performanceStopTraceTool = new PerformanceStopTraceTool();
	var performanceAnalyzeInsightTool = new PerformanceAnalyzeInsightTool();
	//#endregion
	//#region entrypoints/background/tools/browser/index.ts
	var browser_exports = /* @__PURE__ */ __exportAll({
		bookmarkAddTool: () => bookmarkAddTool,
		bookmarkDeleteTool: () => bookmarkDeleteTool,
		bookmarkSearchTool: () => bookmarkSearchTool,
		clickTool: () => clickTool,
		closeTabsTool: () => closeTabsTool,
		computerTool: () => computerTool,
		consoleTool: () => consoleTool,
		elementPickerTool: () => elementPickerTool,
		fileUploadTool: () => fileUploadTool,
		fillTool: () => fillTool,
		getInteractiveElementsTool: () => getInteractiveElementsTool,
		gifRecorderTool: () => gifRecorderTool,
		handleDialogTool: () => handleDialogTool,
		handleDownloadTool: () => handleDownloadTool,
		historyTool: () => historyTool,
		injectScriptTool: () => injectScriptTool,
		javascriptTool: () => javascriptTool,
		keyboardTool: () => keyboardTool,
		navigateTool: () => navigateTool,
		networkCaptureStartTool: () => networkCaptureStartTool,
		networkCaptureStopTool: () => networkCaptureStopTool,
		networkCaptureTool: () => networkCaptureTool,
		networkDebuggerStartTool: () => networkDebuggerStartTool,
		networkDebuggerStopTool: () => networkDebuggerStopTool,
		networkRequestTool: () => networkRequestTool,
		performanceAnalyzeInsightTool: () => performanceAnalyzeInsightTool,
		performanceStartTraceTool: () => performanceStartTraceTool,
		performanceStopTraceTool: () => performanceStopTraceTool,
		readPageTool: () => readPageTool,
		screenshotTool: () => screenshotTool,
		sendCommandToInjectScriptTool: () => sendCommandToInjectScriptTool,
		switchTabTool: () => switchTabTool,
		userscriptTool: () => userscriptTool,
		webFetcherTool: () => webFetcherTool,
		windowTool: () => windowTool
	});
	//#endregion
	//#region entrypoints/background/tools/index.ts
	init_asyncToGenerator();
	var tools = _objectSpread2({}, browser_exports);
	var toolsMap = new Map(Object.values(tools).map((tool) => [tool.name, tool]));
	/**
	* Handle tool execution
	*/
	var handleCallTool = function() {
		var _ref = _asyncToGenerator(function* (param) {
			const tool = toolsMap.get(param.name);
			if (!tool) return createErrorResponse(`Tool ${param.name} not found`);
			try {
				return yield tool.execute(param.args);
			} catch (error) {
				console.error(`Tool execution failed for ${param.name}:`, error);
				return createErrorResponse(error instanceof Error ? error.message : ERROR_MESSAGES.TOOL_EXECUTION_FAILED);
			}
		});
		return function handleCallTool(_x) {
			return _ref.apply(this, arguments);
		};
	}();
	//#endregion
	//#region entrypoints/background/keepalive-manager.ts
	/**
	* @fileoverview Keepalive Manager
	* @description Global singleton service for managing Service Worker keepalive.
	*
	* Uses chrome.alarms API to keep the service worker alive.
	*/
	var LOG_PREFIX$4 = "[KeepaliveManager]";
	var ALARM_NAME = "sw-keepalive";
	var keepaliveTags = /* @__PURE__ */ new Set();
	function ensureAlarm() {
		if (keepaliveTags.size === 0) {
			chrome.alarms.create(ALARM_NAME, { periodInMinutes: .45 });
			console.debug(`${LOG_PREFIX$4} Alarm started`);
		}
	}
	function maybeStopAlarm() {
		if (keepaliveTags.size === 0) {
			chrome.alarms.clear(ALARM_NAME);
			console.debug(`${LOG_PREFIX$4} Alarm stopped`);
		}
	}
	/**
	* Acquire a keepalive reference with a tag.
	*
	* @param tag - Identifier for the reference (e.g., 'native-host')
	* @returns A release function to call when keepalive is no longer needed
	*/
	function acquireKeepalive(tag) {
		keepaliveTags.add(tag);
		ensureAlarm();
		console.debug(`${LOG_PREFIX$4} Acquired keepalive for tag: ${tag}`);
		return () => {
			keepaliveTags.delete(tag);
			maybeStopAlarm();
			console.debug(`${LOG_PREFIX$4} Released keepalive for tag: ${tag}`);
		};
	}
	//#endregion
	//#region entrypoints/background/native-host.ts
	init_asyncToGenerator();
	var LOG_PREFIX$3 = "[NativeHost]";
	var nativePort = null;
	var HOST_NAME = NATIVE_HOST.NAME;
	var RECONNECT_BASE_DELAY_MS = 500;
	var RECONNECT_MAX_DELAY_MS = 6e4;
	var RECONNECT_MAX_FAST_ATTEMPTS = 8;
	var RECONNECT_COOLDOWN_DELAY_MS = 5 * 6e4;
	var keepaliveRelease = null;
	var autoConnectEnabled = true;
	var autoConnectLoaded = false;
	var ensurePromise = null;
	var reconnectTimer = null;
	var reconnectAttempts = 0;
	var manualDisconnect = false;
	var currentServerStatus = {
		isRunning: false,
		lastUpdated: Date.now()
	};
	/**
	* Save server status to chrome.storage
	*/
	function saveServerStatus(_x) {
		return _saveServerStatus.apply(this, arguments);
	}
	function _saveServerStatus() {
		_saveServerStatus = _asyncToGenerator(function* (status) {
			try {
				yield chrome.storage.local.set({ [STORAGE_KEYS.SERVER_STATUS]: status });
			} catch (error) {
				console.error(ERROR_MESSAGES.SERVER_STATUS_SAVE_FAILED, error);
			}
		});
		return _saveServerStatus.apply(this, arguments);
	}
	/**
	* Load server status from chrome.storage
	*/
	function loadServerStatus() {
		return _loadServerStatus.apply(this, arguments);
	}
	function _loadServerStatus() {
		_loadServerStatus = _asyncToGenerator(function* () {
			try {
				const result = yield chrome.storage.local.get([STORAGE_KEYS.SERVER_STATUS]);
				if (result[STORAGE_KEYS.SERVER_STATUS]) return result[STORAGE_KEYS.SERVER_STATUS];
			} catch (error) {
				console.error(ERROR_MESSAGES.SERVER_STATUS_LOAD_FAILED, error);
			}
			return {
				isRunning: false,
				lastUpdated: Date.now()
			};
		});
		return _loadServerStatus.apply(this, arguments);
	}
	/**
	* Broadcast server status change to all listeners
	*/
	function broadcastServerStatusChange(status) {
		chrome.runtime.sendMessage({
			type: BACKGROUND_MESSAGE_TYPES.SERVER_STATUS_CHANGED,
			payload: status
		}).catch(() => {});
	}
	/**
	* Normalize a port value to a valid port number or null.
	*/
	function normalizePort$1(value) {
		const n = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
		if (!Number.isFinite(n)) return null;
		const port = Math.floor(n);
		if (port <= 0 || port > 65535) return null;
		return port;
	}
	/**
	* Add jitter to a delay value to avoid thundering herd.
	*/
	function withJitter(ms) {
		const ratio = .7 + Math.random() * .6;
		return Math.max(0, Math.round(ms * ratio));
	}
	/**
	* Calculate reconnect delay based on attempt number.
	* Uses exponential backoff with jitter, then switches to cooldown interval.
	*/
	function getReconnectDelayMs(attempt) {
		if (attempt >= RECONNECT_MAX_FAST_ATTEMPTS) return withJitter(RECONNECT_COOLDOWN_DELAY_MS);
		return withJitter(Math.min(RECONNECT_BASE_DELAY_MS * Math.pow(2, attempt), RECONNECT_MAX_DELAY_MS));
	}
	/**
	* Clear the reconnect timer if active.
	*/
	function clearReconnectTimer() {
		if (!reconnectTimer) return;
		clearTimeout(reconnectTimer);
		reconnectTimer = null;
	}
	/**
	* Reset reconnect state after successful connection.
	*/
	function resetReconnectState() {
		reconnectAttempts = 0;
		clearReconnectTimer();
	}
	/**
	* Sync keepalive hold based on autoConnectEnabled state.
	* When auto-connect is enabled, we hold a keepalive reference to keep SW alive.
	*/
	function syncKeepaliveHold() {
		if (autoConnectEnabled) {
			if (!keepaliveRelease) {
				keepaliveRelease = acquireKeepalive("native-host");
				console.debug(`${LOG_PREFIX$3} Acquired keepalive`);
			}
			return;
		}
		if (keepaliveRelease) {
			try {
				keepaliveRelease();
				console.debug(`${LOG_PREFIX$3} Released keepalive`);
			} catch (_unused) {}
			keepaliveRelease = null;
		}
	}
	/**
	* Load the nativeAutoConnectEnabled setting from storage.
	*/
	function loadNativeAutoConnectEnabled() {
		return _loadNativeAutoConnectEnabled.apply(this, arguments);
	}
	function _loadNativeAutoConnectEnabled() {
		_loadNativeAutoConnectEnabled = _asyncToGenerator(function* () {
			try {
				const raw = (yield chrome.storage.local.get([STORAGE_KEYS.NATIVE_AUTO_CONNECT_ENABLED]))[STORAGE_KEYS.NATIVE_AUTO_CONNECT_ENABLED];
				if (typeof raw === "boolean") return raw;
			} catch (error) {
				console.warn(`${LOG_PREFIX$3} Failed to load nativeAutoConnectEnabled`, error);
			}
			return true;
		});
		return _loadNativeAutoConnectEnabled.apply(this, arguments);
	}
	/**
	* Set the nativeAutoConnectEnabled setting and persist to storage.
	*/
	function setNativeAutoConnectEnabled(_x2) {
		return _setNativeAutoConnectEnabled.apply(this, arguments);
	}
	function _setNativeAutoConnectEnabled() {
		_setNativeAutoConnectEnabled = _asyncToGenerator(function* (enabled) {
			autoConnectEnabled = enabled;
			autoConnectLoaded = true;
			try {
				yield chrome.storage.local.set({ [STORAGE_KEYS.NATIVE_AUTO_CONNECT_ENABLED]: enabled });
				console.debug(`${LOG_PREFIX$3} Set nativeAutoConnectEnabled=${enabled}`);
			} catch (error) {
				console.warn(`${LOG_PREFIX$3} Failed to persist nativeAutoConnectEnabled`, error);
			}
			syncKeepaliveHold();
		});
		return _setNativeAutoConnectEnabled.apply(this, arguments);
	}
	/**
	* Get the preferred port for connecting to native server.
	* Priority: explicit override > user preference > last known port > default
	*/
	function getPreferredPort(_x3) {
		return _getPreferredPort.apply(this, arguments);
	}
	function _getPreferredPort() {
		_getPreferredPort = _asyncToGenerator(function* (override) {
			const explicit = normalizePort$1(override);
			if (explicit) return explicit;
			try {
				const result = yield chrome.storage.local.get([STORAGE_KEYS.NATIVE_SERVER_PORT, STORAGE_KEYS.SERVER_STATUS]);
				const userPort = normalizePort$1(result[STORAGE_KEYS.NATIVE_SERVER_PORT]);
				if (userPort) return userPort;
				const status = result[STORAGE_KEYS.SERVER_STATUS];
				const statusPort = normalizePort$1(status === null || status === void 0 ? void 0 : status.port);
				if (statusPort) return statusPort;
			} catch (error) {
				console.warn(`${LOG_PREFIX$3} Failed to read preferred port`, error);
			}
			const inMemoryPort = normalizePort$1(currentServerStatus.port);
			if (inMemoryPort) return inMemoryPort;
			return NATIVE_HOST.DEFAULT_PORT;
		});
		return _getPreferredPort.apply(this, arguments);
	}
	/**
	* Schedule a reconnect attempt with exponential backoff.
	*/
	function scheduleReconnect(reason) {
		if (nativePort) return;
		if (manualDisconnect) return;
		if (!autoConnectEnabled) return;
		if (reconnectTimer) return;
		const delay = getReconnectDelayMs(reconnectAttempts);
		console.debug(`${LOG_PREFIX$3} Reconnect scheduled in ${delay}ms (attempt=${reconnectAttempts}, reason=${reason})`);
		reconnectTimer = setTimeout(() => {
			reconnectTimer = null;
			if (nativePort) return;
			if (manualDisconnect || !autoConnectEnabled) return;
			reconnectAttempts += 1;
			ensureNativeConnected(`reconnect:${reason}`).catch(() => {});
		}, delay);
	}
	/**
	* Mark server as stopped and broadcast the change.
	*/
	function markServerStopped(_x4) {
		return _markServerStopped.apply(this, arguments);
	}
	function _markServerStopped() {
		_markServerStopped = _asyncToGenerator(function* (reason) {
			currentServerStatus = {
				isRunning: false,
				port: currentServerStatus.port,
				lastUpdated: Date.now()
			};
			try {
				yield saveServerStatus(currentServerStatus);
			} catch (_unused2) {}
			broadcastServerStatusChange(currentServerStatus);
			console.debug(`${LOG_PREFIX$3} Server marked stopped (${reason})`);
		});
		return _markServerStopped.apply(this, arguments);
	}
	/**
	* Ensure native connection is established.
	* This is the main entry point for auto-connect logic.
	*
	* @param trigger - Description of what triggered this call (for logging)
	* @param portOverride - Optional explicit port to use
	* @returns Whether the connection is now established
	*/
	function ensureNativeConnected(_x5, _x6) {
		return _ensureNativeConnected.apply(this, arguments);
	}
	function _ensureNativeConnected() {
		_ensureNativeConnected = _asyncToGenerator(function* (trigger, portOverride) {
			if (ensurePromise) return ensurePromise;
			ensurePromise = _asyncToGenerator(function* () {
				if (!autoConnectLoaded) {
					autoConnectEnabled = yield loadNativeAutoConnectEnabled();
					autoConnectLoaded = true;
					syncKeepaliveHold();
				}
				if (!autoConnectEnabled) {
					console.debug(`${LOG_PREFIX$3} Auto-connect disabled, skipping ensure (trigger=${trigger})`);
					return false;
				}
				syncKeepaliveHold();
				if (nativePort) {
					console.debug(`${LOG_PREFIX$3} Already connected (trigger=${trigger})`);
					return true;
				}
				const port = yield getPreferredPort(portOverride);
				console.debug(`${LOG_PREFIX$3} Attempting connection on port ${port} (trigger=${trigger})`);
				if (!connectNativeHost(port)) {
					console.warn(`${LOG_PREFIX$3} Connection failed (trigger=${trigger})`);
					scheduleReconnect(`connect_failed:${trigger}`);
					return false;
				}
				console.debug(`${LOG_PREFIX$3} Connection initiated successfully (trigger=${trigger})`);
				return true;
			})().finally(() => {
				ensurePromise = null;
			});
			return ensurePromise;
		});
		return _ensureNativeConnected.apply(this, arguments);
	}
	/**
	* Connect to the native messaging host
	* @returns Whether the connection was initiated successfully
	*/
	function connectNativeHost(port = NATIVE_HOST.DEFAULT_PORT) {
		if (nativePort) return true;
		try {
			nativePort = chrome.runtime.connectNative(HOST_NAME);
			nativePort.onMessage.addListener(function() {
				var _ref = _asyncToGenerator(function* (message) {
					if (message.type === NativeMessageType.PROCESS_DATA && message.requestId) {
						const requestId = message.requestId;
						const requestPayload = message.payload;
						nativePort === null || nativePort === void 0 || nativePort.postMessage({
							responseToRequestId: requestId,
							payload: {
								status: "success",
								message: SUCCESS_MESSAGES.TOOL_EXECUTED,
								data: requestPayload
							}
						});
					} else if (message.type === NativeMessageType.CALL_TOOL && message.requestId) {
						const requestId = message.requestId;
						try {
							const result = yield handleCallTool(message.payload);
							nativePort === null || nativePort === void 0 || nativePort.postMessage({
								responseToRequestId: requestId,
								payload: {
									status: "success",
									message: SUCCESS_MESSAGES.TOOL_EXECUTED,
									data: result
								}
							});
						} catch (error) {
							nativePort === null || nativePort === void 0 || nativePort.postMessage({
								responseToRequestId: requestId,
								payload: {
									status: "error",
									message: ERROR_MESSAGES.TOOL_EXECUTION_FAILED,
									error: error instanceof Error ? error.message : String(error)
								}
							});
						}
					} else if (message.type === NativeMessageType.SERVER_STARTED) {
						var _message$payload;
						const port = (_message$payload = message.payload) === null || _message$payload === void 0 ? void 0 : _message$payload.port;
						currentServerStatus = {
							isRunning: true,
							port,
							lastUpdated: Date.now()
						};
						yield saveServerStatus(currentServerStatus);
						broadcastServerStatusChange(currentServerStatus);
						resetReconnectState();
						console.log(`${SUCCESS_MESSAGES.SERVER_STARTED} on port ${port}`);
					} else if (message.type === NativeMessageType.SERVER_STOPPED) {
						currentServerStatus = {
							isRunning: false,
							port: currentServerStatus.port,
							lastUpdated: Date.now()
						};
						yield saveServerStatus(currentServerStatus);
						broadcastServerStatusChange(currentServerStatus);
						console.log(SUCCESS_MESSAGES.SERVER_STOPPED);
					} else if (message.type === NativeMessageType.ERROR_FROM_NATIVE_HOST) {
						var _message$payload2;
						console.error("Error from native host:", ((_message$payload2 = message.payload) === null || _message$payload2 === void 0 ? void 0 : _message$payload2.message) || "Unknown error");
					} else if (message.type === "file_operation_response") chrome.runtime.sendMessage(message).catch(() => {});
				});
				return function(_x7) {
					return _ref.apply(this, arguments);
				};
			}());
			nativePort.onDisconnect.addListener(() => {
				console.warn(ERROR_MESSAGES.NATIVE_DISCONNECTED, chrome.runtime.lastError);
				nativePort = null;
				markServerStopped("native_port_disconnected");
				if (manualDisconnect) {
					manualDisconnect = false;
					return;
				}
				if (!autoConnectEnabled) return;
				scheduleReconnect("native_port_disconnected");
			});
			nativePort.postMessage({
				type: NativeMessageType.START,
				payload: { port }
			});
			return true;
		} catch (error) {
			console.warn(ERROR_MESSAGES.NATIVE_CONNECTION_FAILED, error);
			nativePort = null;
			return false;
		}
	}
	/**
	* Initialize native host listeners and load initial state
	*/
	var initNativeHostListener = () => {
		loadServerStatus().then((status) => {
			currentServerStatus = status;
		}).catch((error) => {
			console.error(ERROR_MESSAGES.SERVER_STATUS_LOAD_FAILED, error);
		});
		ensureNativeConnected("sw_startup").catch(() => {});
		chrome.runtime.onStartup.addListener(() => {
			ensureNativeConnected("onStartup").catch(() => {});
		});
		chrome.runtime.onInstalled.addListener(() => {
			ensureNativeConnected("onInstalled").catch(() => {});
		});
		chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
			if (message && message.type === "call_tool" && message.name) {
				handleCallTool({
					name: message.name,
					args: message.args
				}).then((res) => sendResponse({
					success: true,
					result: res
				})).catch((err) => sendResponse({
					success: false,
					error: err instanceof Error ? err.message : String(err)
				}));
				return true;
			}
			const msgType = typeof message === "string" ? message : message === null || message === void 0 ? void 0 : message.type;
			if (msgType === NativeMessageType.ENSURE_NATIVE) {
				ensureNativeConnected("ui_ensure", typeof message === "object" ? message.port : void 0).then((connected) => {
					sendResponse({
						success: true,
						connected,
						autoConnectEnabled
					});
				}).catch((e) => {
					sendResponse({
						success: false,
						connected: nativePort !== null,
						error: String(e)
					});
				});
				return true;
			}
			if (msgType === NativeMessageType.CONNECT_NATIVE) {
				const normalized = normalizePort$1(typeof message === "object" ? message.port : void 0);
				_asyncToGenerator(function* () {
					yield setNativeAutoConnectEnabled(true);
					if (normalized) try {
						yield chrome.storage.local.set({ [STORAGE_KEYS.NATIVE_SERVER_PORT]: normalized });
					} catch (_unused3) {}
					return ensureNativeConnected("ui_connect", normalized !== null && normalized !== void 0 ? normalized : void 0);
				})().then((connected) => {
					sendResponse({
						success: true,
						connected
					});
				}).catch((e) => {
					sendResponse({
						success: false,
						connected: nativePort !== null,
						error: String(e)
					});
				});
				return true;
			}
			if (msgType === NativeMessageType.PING_NATIVE) {
				sendResponse({
					connected: nativePort !== null,
					autoConnectEnabled
				});
				return true;
			}
			if (msgType === NativeMessageType.DISCONNECT_NATIVE) {
				_asyncToGenerator(function* () {
					yield setNativeAutoConnectEnabled(false);
					clearReconnectTimer();
					reconnectAttempts = 0;
					syncKeepaliveHold();
					if (nativePort) {
						manualDisconnect = true;
						try {
							nativePort.disconnect();
						} catch (_unused4) {}
						nativePort = null;
					}
					yield markServerStopped("manual_disconnect");
				})().then(() => {
					sendResponse({ success: true });
				}).catch((e) => {
					sendResponse({
						success: false,
						error: String(e)
					});
				});
				return true;
			}
			if (message.type === BACKGROUND_MESSAGE_TYPES.GET_SERVER_STATUS) {
				sendResponse({
					success: true,
					serverStatus: currentServerStatus,
					connected: nativePort !== null
				});
				return true;
			}
			if (message.type === BACKGROUND_MESSAGE_TYPES.REFRESH_SERVER_STATUS) {
				loadServerStatus().then((storedStatus) => {
					currentServerStatus = storedStatus;
					sendResponse({
						success: true,
						serverStatus: currentServerStatus,
						connected: nativePort !== null
					});
				}).catch((error) => {
					console.error(ERROR_MESSAGES.SERVER_STATUS_LOAD_FAILED, error);
					sendResponse({
						success: false,
						error: ERROR_MESSAGES.SERVER_STATUS_LOAD_FAILED,
						serverStatus: currentServerStatus,
						connected: nativePort !== null
					});
				});
				return true;
			}
			if (message.type === "forward_to_native" && message.message) {
				if (nativePort) {
					nativePort.postMessage(message.message);
					sendResponse({ success: true });
				} else sendResponse({
					success: false,
					error: "Native host not connected"
				});
				return true;
			}
		});
	};
	//#endregion
	//#region entrypoints/background/storage-manager.ts
	init_asyncToGenerator();
	/**
	* Get storage statistics
	*/
	function handleGetStorageStats() {
		return _handleGetStorageStats.apply(this, arguments);
	}
	function _handleGetStorageStats() {
		_handleGetStorageStats = _asyncToGenerator(function* () {
			return {
				success: true,
				stats: {
					indexedPages: 0,
					totalDocuments: 0,
					totalTabs: 0,
					indexSize: 0,
					isInitialized: false
				}
			};
		});
		return _handleGetStorageStats.apply(this, arguments);
	}
	/**
	* Clear all data
	*/
	function handleClearAllData() {
		return _handleClearAllData.apply(this, arguments);
	}
	function _handleClearAllData() {
		_handleClearAllData = _asyncToGenerator(function* () {
			try {
				try {
					yield chrome.storage.local.remove([
						"vectorDatabaseStats",
						"lastCleanupTime",
						"contentIndexerStats"
					]);
					console.log("Storage: Chrome storage data cleared successfully");
				} catch (storageError) {
					console.warn("Background: Failed to clear chrome storage data:", storageError);
				}
				return { success: true };
			} catch (error) {
				console.error("Background: Failed to clear all data:", error);
				return {
					success: false,
					error: error.message
				};
			}
		});
		return _handleClearAllData.apply(this, arguments);
	}
	/**
	* Initialize storage manager module message listeners
	*/
	var initStorageManagerListener = () => {
		chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
			if (message.type === BACKGROUND_MESSAGE_TYPES.GET_STORAGE_STATS) {
				handleGetStorageStats().then((result) => sendResponse(result)).catch((error) => sendResponse({
					success: false,
					error: error.message
				}));
				return true;
			} else if (message.type === BACKGROUND_MESSAGE_TYPES.CLEAR_ALL_DATA) {
				handleClearAllData().then((result) => sendResponse(result)).catch((error) => sendResponse({
					success: false,
					error: error.message
				}));
				return true;
			}
		});
	};
	//#endregion
	//#region entrypoints/background/element-marker/index.ts
	init_asyncToGenerator();
	var CONTEXT_MENU_ID$1 = "element_marker_mark";
	/**
	* Extract error message from MCP tool result
	*/
	function extractToolError(result) {
		if (!result) return void 0;
		if (Array.isArray(result.content)) {
			for (const item of result.content) if (item === null || item === void 0 ? void 0 : item.text) try {
				const parsed = JSON.parse(item.text);
				if (parsed === null || parsed === void 0 ? void 0 : parsed.error) return parsed.error;
				if (parsed === null || parsed === void 0 ? void 0 : parsed.message) return parsed.message;
			} catch (_unused) {
				return item.text;
			}
		}
		return result.error || (result.isError ? "unknown tool error" : void 0);
	}
	function ensureContextMenu$1() {
		return _ensureContextMenu$1.apply(this, arguments);
	}
	function _ensureContextMenu$1() {
		_ensureContextMenu$1 = _asyncToGenerator(function* () {
			try {
				var _chrome$contextMenus;
				if (!((_chrome$contextMenus = chrome.contextMenus) === null || _chrome$contextMenus === void 0 ? void 0 : _chrome$contextMenus.create)) return;
				try {
					yield chrome.contextMenus.remove(CONTEXT_MENU_ID$1);
				} catch (_unused2) {}
				yield chrome.contextMenus.create({
					id: CONTEXT_MENU_ID$1,
					title: "Mark Element",
					contexts: ["all"]
				});
			} catch (e) {
				console.warn("ElementMarker: ensureContextMenu failed:", e);
			}
		});
		return _ensureContextMenu$1.apply(this, arguments);
	}
	/**
	* Check if element-marker.js is already injected in the tab
	* Uses a short timeout to avoid hanging on unresponsive tabs
	*/
	function isMarkerInjected(_x) {
		return _isMarkerInjected.apply(this, arguments);
	}
	function _isMarkerInjected() {
		_isMarkerInjected = _asyncToGenerator(function* (tabId) {
			try {
				const response = yield Promise.race([chrome.tabs.sendMessage(tabId, { action: "element_marker_ping" }), new Promise((resolve) => setTimeout(() => resolve(null), 300))]);
				return (response === null || response === void 0 ? void 0 : response.status) === "pong";
			} catch (_unused3) {
				return false;
			}
		});
		return _isMarkerInjected.apply(this, arguments);
	}
	/**
	* Inject element-marker.js into the tab if not already injected
	*/
	function injectMarkerHelper(_x2) {
		return _injectMarkerHelper.apply(this, arguments);
	}
	function _injectMarkerHelper() {
		_injectMarkerHelper = _asyncToGenerator(function* (tabId) {
			if (!(yield isMarkerInjected(tabId))) try {
				yield chrome.scripting.executeScript({
					target: {
						tabId,
						allFrames: true
					},
					files: ["inject-scripts/element-marker.js"],
					world: "ISOLATED"
				});
			} catch (e) {
				console.warn("ElementMarker: script injection failed:", e);
			}
			try {
				yield chrome.tabs.sendMessage(tabId, { action: "element_marker_start" });
			} catch (e) {
				console.warn("ElementMarker: start overlay failed:", e);
			}
		});
		return _injectMarkerHelper.apply(this, arguments);
	}
	function initElementMarkerListeners() {
		var _chrome$contextMenus2;
		ensureContextMenu$1().catch(() => {});
		chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
			try {
				switch (message === null || message === void 0 ? void 0 : message.type) {
					case BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_START: {
						const tabId = message.tabId;
						if (typeof tabId !== "number") {
							sendResponse({
								success: false,
								error: "invalid tabId"
							});
							return true;
						}
						injectMarkerHelper(tabId).then(() => sendResponse({ success: true })).catch((e) => sendResponse({
							success: false,
							error: (e === null || e === void 0 ? void 0 : e.message) || String(e)
						}));
						return true;
					}
					case BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_LIST_ALL:
						listAllMarkers().then((markers) => sendResponse({
							success: true,
							markers
						})).catch((e) => sendResponse({
							success: false,
							error: (e === null || e === void 0 ? void 0 : e.message) || String(e)
						}));
						return true;
					case BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_LIST_FOR_URL:
						listMarkersForUrl(String(message.url || "")).then((markers) => sendResponse({
							success: true,
							markers
						})).catch((e) => sendResponse({
							success: false,
							error: (e === null || e === void 0 ? void 0 : e.message) || String(e)
						}));
						return true;
					case BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_SAVE: {
						const req = message.marker;
						saveMarker(req).then((marker) => sendResponse({
							success: true,
							marker
						})).catch((e) => sendResponse({
							success: false,
							error: (e === null || e === void 0 ? void 0 : e.message) || String(e)
						}));
						return true;
					}
					case BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_UPDATE: {
						const marker = message.marker;
						updateMarker(marker).then(() => sendResponse({ success: true })).catch((e) => sendResponse({
							success: false,
							error: (e === null || e === void 0 ? void 0 : e.message) || String(e)
						}));
						return true;
					}
					case BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_DELETE: {
						const id = String(message.id || "");
						if (!id) {
							sendResponse({
								success: false,
								error: "invalid id"
							});
							return true;
						}
						deleteMarker(id).then(() => sendResponse({ success: true })).catch((e) => sendResponse({
							success: false,
							error: (e === null || e === void 0 ? void 0 : e.message) || String(e)
						}));
						return true;
					}
					case BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_VALIDATE:
						_asyncToGenerator(function* () {
							const req = message;
							req.waitForNavigation = message.waitForNavigation;
							req.timeoutMs = message.timeoutMs;
							req.scrollDirection = message.scrollDirection;
							req.scrollAmount = message.scrollAmount;
							const selector = String(req.selector || "").trim();
							const selectorType = req.selectorType || "css";
							const action = req.action;
							if (!selector) return sendResponse({
								success: false,
								error: "selector is required"
							});
							const tab = (yield chrome.tabs.query({
								active: true,
								currentWindow: true
							}))[0];
							if (!(tab === null || tab === void 0 ? void 0 : tab.id)) return sendResponse({
								success: false,
								error: "active tab not found"
							});
							try {
								yield chrome.scripting.executeScript({
									target: {
										tabId: tab.id,
										allFrames: true
									},
									files: ["inject-scripts/accessibility-tree-helper.js"],
									world: "ISOLATED"
								});
							} catch (_unused4) {}
							let ensured;
							try {
								ensured = yield chrome.tabs.sendMessage(tab.id, {
									action: "ensureRefForSelector",
									selector,
									isXPath: selectorType === "xpath",
									allowMultiple: !!req.listMode
								});
							} catch (e) {
								return sendResponse({
									success: false,
									error: String(e instanceof Error ? e.message : e)
								});
							}
							if (!ensured || !ensured.success || !ensured.ref) return sendResponse({
								success: false,
								error: (ensured === null || ensured === void 0 ? void 0 : ensured.error) || "failed to resolve selector"
							});
							const base = {
								success: true,
								resolved: true,
								ref: ensured.ref,
								center: ensured.center
							};
							let coords = void 0;
							if (req.coordinates && typeof req.coordinates.x === "number" && typeof req.coordinates.y === "number") coords = {
								x: Math.round(req.coordinates.x),
								y: Math.round(req.coordinates.y)
							};
							else if (req.relativeTo === "element" && ensured.center && (typeof req.offsetX === "number" || typeof req.offsetY === "number")) {
								const dx = Number.isFinite(req.offsetX) ? req.offsetX : 0;
								const dy = Number.isFinite(req.offsetY) ? req.offsetY : 0;
								coords = {
									x: ensured.center.x + dx,
									y: ensured.center.y + dy
								};
							}
							try {
								switch (action) {
									case "hover": {
										const r = yield computerTool.execute(coords ? {
											action: "hover",
											coordinates: coords
										} : {
											action: "hover",
											ref: ensured.ref
										});
										const error = r.isError ? extractToolError(r) : void 0;
										base.tool = {
											name: "computer.hover",
											ok: !r.isError,
											error
										};
										break;
									}
									case "left_click": {
										const r = yield clickTool.execute(_objectSpread2(_objectSpread2({}, coords ? { coordinates: coords } : { ref: ensured.ref }), {}, {
											waitForNavigation: !!req.waitForNavigation,
											timeout: Number.isFinite(req.timeoutMs) ? req.timeoutMs : 3e3,
											button: req.button || "left",
											modifiers: req.modifiers || {}
										}));
										const error = r.isError ? extractToolError(r) : void 0;
										base.tool = {
											name: "interaction.click",
											ok: !r.isError,
											error
										};
										break;
									}
									case "double_click": {
										const r = yield clickTool.execute(_objectSpread2(_objectSpread2({}, coords ? { coordinates: coords } : { ref: ensured.ref }), {}, {
											double: true,
											waitForNavigation: !!req.waitForNavigation,
											timeout: Number.isFinite(req.timeoutMs) ? req.timeoutMs : 3e3,
											button: req.button || "left",
											modifiers: req.modifiers || {}
										}));
										const error = r.isError ? extractToolError(r) : void 0;
										base.tool = {
											name: "interaction.click(double)",
											ok: !r.isError,
											error
										};
										break;
									}
									case "right_click": {
										const r = yield clickTool.execute(_objectSpread2(_objectSpread2({}, coords ? { coordinates: coords } : { ref: ensured.ref }), {}, {
											waitForNavigation: !!req.waitForNavigation,
											timeout: Number.isFinite(req.timeoutMs) ? req.timeoutMs : 3e3,
											button: "right",
											modifiers: req.modifiers || {}
										}));
										const error = r.isError ? extractToolError(r) : void 0;
										base.tool = {
											name: "interaction.click(right)",
											ok: !r.isError,
											error
										};
										break;
									}
									case "scroll": {
										const direction = req.scrollDirection || "down";
										const amount = Number.isFinite(req.scrollAmount) ? Number(req.scrollAmount) : 300;
										const payload = coords ? {
											action: "scroll",
											scrollDirection: direction,
											scrollAmount: amount,
											coordinates: coords
										} : {
											action: "scroll",
											scrollDirection: direction,
											scrollAmount: amount,
											ref: ensured.ref
										};
										const r = yield computerTool.execute(payload);
										const error = r.isError ? extractToolError(r) : void 0;
										base.tool = {
											name: "computer.scroll",
											ok: !r.isError,
											error
										};
										break;
									}
									case "type_text": {
										const text = String(req.text || "");
										const r = yield computerTool.execute({
											action: "type",
											ref: ensured.ref,
											text
										});
										const error = r.isError ? extractToolError(r) : void 0;
										base.tool = {
											name: "computer.type",
											ok: !r.isError,
											error
										};
										break;
									}
									case "press_keys": {
										const keys = String(req.keys || "");
										try {
											yield clickTool.execute({
												ref: ensured.ref,
												waitForNavigation: false,
												timeout: 2e3
											});
										} catch (_unused5) {}
										const r = yield keyboardTool.execute({
											keys,
											delay: 0
										});
										const error = r.isError ? extractToolError(r) : void 0;
										base.tool = {
											name: "keyboard.simulate",
											ok: !r.isError,
											error
										};
										break;
									}
									default: base.tool = {
										name: "noop",
										ok: true
									};
								}
							} catch (e) {
								console.warn("[ElementMarker] Validation failed before tool execution", e);
								base.tool = {
									name: "unknown",
									ok: false,
									error: String(e instanceof Error ? e.message : e)
								};
							}
							if (base.tool && base.tool.ok === false) console.warn("[ElementMarker] Tool validation failure", {
								action,
								toolName: base.tool.name,
								error: base.tool.error,
								selector,
								selectorType
							});
							return sendResponse(base);
						})();
						return true;
					case BACKGROUND_MESSAGE_TYPES.RR_REFRESH_TRIGGERS:
					case BACKGROUND_MESSAGE_TYPES.RR_SAVE_TRIGGER:
					case BACKGROUND_MESSAGE_TYPES.RR_DELETE_TRIGGER:
						setTimeout(() => ensureContextMenu$1().catch(() => {}), 300);
						break;
				}
			} catch (e) {
				sendResponse({
					success: false,
					error: (e === null || e === void 0 ? void 0 : e.message) || String(e)
				});
			}
			return false;
		});
		if ((_chrome$contextMenus2 = chrome.contextMenus) === null || _chrome$contextMenus2 === void 0 || (_chrome$contextMenus2 = _chrome$contextMenus2.onClicked) === null || _chrome$contextMenus2 === void 0 ? void 0 : _chrome$contextMenus2.addListener) chrome.contextMenus.onClicked.addListener(function() {
			var _ref = _asyncToGenerator(function* (info, tab) {
				try {
					if (info.menuItemId === CONTEXT_MENU_ID$1 && (tab === null || tab === void 0 ? void 0 : tab.id)) yield injectMarkerHelper(tab.id);
				} catch (e) {
					console.warn("ElementMarker: context menu click failed:", e);
				}
			});
			return function(_x3, _x4) {
				return _ref.apply(this, arguments);
			};
		}());
	}
	//#endregion
	//#region common/web-editor-types.ts
	/**
	* Action types for web editor V2 messages
	*
	* IMPORTANT: V2 uses versioned action names (suffix _v2) to avoid
	* conflicts with V1 when both scripts might be injected in the same tab.
	* This prevents double-response race conditions.
	*
	* V1 uses: web_editor_ping, web_editor_toggle, etc.
	* V2 uses: web_editor_ping_v2, web_editor_toggle_v2, etc.
	*/
	var WEB_EDITOR_V2_ACTIONS = {
		/** Check if V2 editor is injected and get status */
		PING: "web_editor_ping_v2",
		/** Toggle V2 editor on/off */
		TOGGLE: "web_editor_toggle_v2",
		/** Start V2 editor */
		START: "web_editor_start_v2",
		/** Stop V2 editor */
		STOP: "web_editor_stop_v2",
		/** Highlight an element (from sidepanel hover) */
		HIGHLIGHT_ELEMENT: "web_editor_highlight_element_v2",
		/** Revert an element to its original state (Phase 2 - Selective Undo) */
		REVERT_ELEMENT: "web_editor_revert_element_v2",
		/** Clear selection (from sidepanel after send) */
		CLEAR_SELECTION: "web_editor_clear_selection_v2"
	};
	//#endregion
	//#region entrypoints/background/utils/sidepanel.ts
	init_asyncToGenerator();
	/**
	* Sidepanel Utilities
	*
	* Shared helpers for opening and managing the Chrome sidepanel from background modules.
	* Used by web-editor, quick-panel, and other modules that need to trigger sidepanel navigation.
	*/
	/**
	* Best-effort open the sidepanel with AgentChat tab selected.
	*
	* @param tabId - Tab ID to associate with sidepanel
	* @param windowId - Optional window ID for fallback when tab-level open fails
	* @param sessionId - Optional session ID to navigate directly to chat view (deep-link)
	*
	* @remarks
	* This function is intentionally resilient - it will not throw on failures.
	* Sidepanel availability varies across Chrome versions and contexts.
	*/
	function openAgentChatSidepanel(_x, _x2, _x3) {
		return _openAgentChatSidepanel.apply(this, arguments);
	}
	function _openAgentChatSidepanel() {
		_openAgentChatSidepanel = _asyncToGenerator(function* (tabId, windowId, sessionId) {
			try {
				let path = "sidepanel.html?tab=agent-chat";
				if (sessionId) path += `&view=chat&sessionId=${encodeURIComponent(sessionId)}`;
				const sidePanel = chrome.sidePanel;
				if (sidePanel === null || sidePanel === void 0 ? void 0 : sidePanel.setOptions) yield sidePanel.setOptions({
					tabId,
					path,
					enabled: true
				});
				if (sidePanel === null || sidePanel === void 0 ? void 0 : sidePanel.open) try {
					yield sidePanel.open({ tabId });
				} catch (_unused) {
					if (typeof windowId === "number") yield sidePanel.open({ windowId });
				}
			} catch (_unused2) {}
		});
		return _openAgentChatSidepanel.apply(this, arguments);
	}
	//#endregion
	//#region entrypoints/background/web-editor/index.ts
	init_asyncToGenerator();
	var CONTEXT_MENU_ID = "web_editor_toggle";
	var COMMAND_KEY$1 = "toggle_web_editor";
	var DEFAULT_NATIVE_SERVER_PORT = 12306;
	/** Storage key prefix for TX change session data (per-tab isolation) */
	var WEB_EDITOR_TX_CHANGED_SESSION_KEY_PREFIX = "web-editor-v2-tx-changed-";
	var WEB_EDITOR_SELECTION_SESSION_KEY_PREFIX = "web-editor-v2-selection-";
	/** Storage key prefix for excluded element keys (per-tab isolation, managed by sidepanel) */
	var WEB_EDITOR_EXCLUDED_KEYS_SESSION_KEY_PREFIX = "web-editor-v2-excluded-keys-";
	/** Storage key for AgentChat selected session ID */
	var STORAGE_KEY_SELECTED_SESSION$1 = "agent-selected-session-id";
	var executionStatusCache = /* @__PURE__ */ new Map();
	var STATUS_CACHE_TTL = 300 * 1e3;
	function cleanupExpiredStatuses() {
		const now = Date.now();
		for (const [key, entry] of executionStatusCache) if (now - entry.updatedAt > STATUS_CACHE_TTL) executionStatusCache.delete(key);
	}
	function setExecutionStatus(requestId, status, message, result) {
		executionStatusCache.set(requestId, {
			status,
			message,
			updatedAt: Date.now(),
			result
		});
		if (executionStatusCache.size > 100) cleanupExpiredStatuses();
	}
	function getExecutionStatus(requestId) {
		return executionStatusCache.get(requestId);
	}
	var sseConnections = /* @__PURE__ */ new Map();
	/**
	* Start SSE subscription for a session to receive status updates
	*/
	function subscribeToSessionStatus(_x, _x2, _x3) {
		return _subscribeToSessionStatus.apply(this, arguments);
	}
	function _subscribeToSessionStatus() {
		_subscribeToSessionStatus = _asyncToGenerator(function* (sessionId, requestId, port) {
			const existing = sseConnections.get(sessionId);
			if (existing) {
				existing.abort.abort();
				sseConnections.delete(sessionId);
			}
			const abortController = new AbortController();
			sseConnections.set(sessionId, {
				abort: abortController,
				lastRequestId: requestId
			});
			setExecutionStatus(requestId, "starting", "Connecting to Agent...");
			const sseUrl = `http://127.0.0.1:${port}/agent/chat/${encodeURIComponent(sessionId)}/stream`;
			try {
				const response = yield fetch(sseUrl, {
					method: "GET",
					headers: { Accept: "text/event-stream" },
					signal: abortController.signal
				});
				if (!response.ok || !response.body) {
					setExecutionStatus(requestId, "running", "Agent processing...");
					return;
				}
				const reader = response.body.getReader();
				const decoder = new TextDecoder();
				let buffer = "";
				setExecutionStatus(requestId, "running", "Agent processing...");
				while (true) {
					var _lines$pop;
					const { done, value } = yield reader.read();
					if (done) break;
					buffer += decoder.decode(value, { stream: true });
					const lines = buffer.split("\n");
					buffer = (_lines$pop = lines.pop()) !== null && _lines$pop !== void 0 ? _lines$pop : "";
					for (const line of lines) if (line.startsWith("data:")) try {
						handleSseEvent(requestId, JSON.parse(line.slice(5).trim()));
					} catch (_unused) {}
				}
			} catch (err) {
				if (err instanceof Error && err.name === "AbortError") return;
				const cached = getExecutionStatus(requestId);
				if (cached && ![
					"completed",
					"failed",
					"cancelled"
				].includes(cached.status)) setExecutionStatus(requestId, "running", "Agent processing (connection lost)...");
			} finally {
				sseConnections.delete(sessionId);
			}
		});
		return _subscribeToSessionStatus.apply(this, arguments);
	}
	/**
	* Handle SSE event from Agent stream
	*/
	function handleSseEvent(requestId, event) {
		if (!event || typeof event !== "object") return;
		const e = event;
		const type = e.type;
		const data = e.data;
		const eventRequestId = data === null || data === void 0 ? void 0 : data.requestId;
		if (eventRequestId && eventRequestId !== requestId) return;
		if (type === "status" && data) {
			const status = data.status;
			const message = data.message;
			let mappedStatus = status;
			if (status === "ready") mappedStatus = "running";
			if (status === "error") mappedStatus = "failed";
			setExecutionStatus(requestId, mappedStatus, message);
		} else if (type === "message" && data) {
			const cached = getExecutionStatus(requestId);
			if (cached && cached.status === "starting") setExecutionStatus(requestId, "running", "Agent is working...");
			const role = data.role;
			const isFinal = data.isFinal;
			if (role === "assistant" && isFinal) {
				const content = data.content;
				setExecutionStatus(requestId, "completed", "Completed", {
					success: true,
					summary: content === null || content === void 0 ? void 0 : content.slice(0, 200)
				});
			}
		} else if (type === "error") {
			const errorMsg = e.error || "Unknown error";
			setExecutionStatus(requestId, "failed", errorMsg, {
				success: false,
				error: errorMsg
			});
		}
	}
	/** Script path for v2 (WXT unlisted script output) */
	var V2_SCRIPT_PATH = "web-editor-v2.js";
	/** Script path for Phase 7 props agent (MAIN world) */
	var PROPS_AGENT_SCRIPT_PATH = "inject-scripts/props-agent.js";
	function normalizeString$1(value) {
		return typeof value === "string" ? value : "";
	}
	function normalizeStringArray(value) {
		if (!Array.isArray(value)) return [];
		return value.map((item) => normalizeString$1(item)).filter(Boolean);
	}
	function normalizeStyleMap(value) {
		if (!value || typeof value !== "object") return void 0;
		const out = {};
		for (const [k, v] of Object.entries(value)) {
			const key = normalizeString$1(k).trim();
			const val = normalizeString$1(v).trim();
			if (!key || !val) continue;
			out[key] = val;
		}
		return Object.keys(out).length ? out : void 0;
	}
	function normalizeStyleMapAllowEmpty(value) {
		if (!value || typeof value !== "object") return void 0;
		const out = {};
		for (const [k, v] of Object.entries(value)) {
			const key = normalizeString$1(k).trim();
			if (!key) continue;
			out[key] = normalizeString$1(v).trim();
		}
		return Object.keys(out).length ? out : void 0;
	}
	function normalizeDebugSource(value) {
		if (!value || typeof value !== "object") return void 0;
		const obj = value;
		const file = normalizeString$1(obj.file).trim();
		if (!file) return void 0;
		const source = { file };
		const line = Number(obj.line);
		if (Number.isFinite(line) && line > 0) source.line = line;
		const column = Number(obj.column);
		if (Number.isFinite(column) && column >= 0) source.column = column;
		const componentName = normalizeString$1(obj.componentName).trim();
		if (componentName) source.componentName = componentName;
		return source;
	}
	function normalizeOperation(value) {
		if (!value || typeof value !== "object") return void 0;
		const obj = value;
		if (obj.type !== "update_style") return void 0;
		const before = normalizeStyleMapAllowEmpty(obj.before);
		const after = normalizeStyleMapAllowEmpty(obj.after);
		const removed = normalizeStringArray(obj.removed);
		if (!before && !after && removed.length === 0) return void 0;
		return {
			type: "update_style",
			before: before !== null && before !== void 0 ? before : {},
			after: after !== null && after !== void 0 ? after : {},
			removed
		};
	}
	function normalizeApplyPayload(raw) {
		const obj = raw && typeof raw === "object" ? raw : {};
		const pageUrl = normalizeString$1(obj.pageUrl).trim();
		const targetFile = normalizeString$1(obj.targetFile).trim() || void 0;
		const techStackHint = normalizeStringArray(obj.techStackHint);
		const fingerprintRaw = obj.fingerprint && typeof obj.fingerprint === "object" ? obj.fingerprint : {};
		const fingerprint = {
			tag: normalizeString$1(fingerprintRaw.tag).trim() || "unknown",
			id: normalizeString$1(fingerprintRaw.id).trim() || void 0,
			classes: normalizeStringArray(fingerprintRaw.classes),
			text: normalizeString$1(fingerprintRaw.text).trim() || void 0
		};
		const instructionRaw = obj.instruction && typeof obj.instruction === "object" ? obj.instruction : {};
		const type = normalizeString$1(instructionRaw.type).trim();
		if (type !== "update_text" && type !== "update_style") throw new Error("Invalid instruction.type");
		const instruction = {
			type,
			description: normalizeString$1(instructionRaw.description).trim() || "",
			text: normalizeString$1(instructionRaw.text).trim() || void 0,
			style: normalizeStyleMap(instructionRaw.style)
		};
		if (!pageUrl) throw new Error("pageUrl is required");
		if (!instruction.description) throw new Error("instruction.description is required");
		const selectorCandidates = normalizeStringArray(obj.selectorCandidates);
		const debugSource = normalizeDebugSource(obj.debugSource);
		const operation = normalizeOperation(obj.operation);
		return {
			pageUrl,
			targetFile,
			fingerprint,
			techStackHint: techStackHint.length ? techStackHint : void 0,
			instruction,
			selectorCandidates: selectorCandidates.length ? selectorCandidates : void 0,
			debugSource,
			operation
		};
	}
	/**
	* Normalize and validate batch apply payload.
	* Runtime validation for WebEditorApplyBatchPayload.
	*/
	function normalizeApplyBatchPayload(raw) {
		const obj = raw && typeof raw === "object" ? raw : {};
		const tabIdRaw = Number(obj.tabId);
		return {
			tabId: Number.isFinite(tabIdRaw) && tabIdRaw > 0 ? tabIdRaw : 0,
			elements: Array.isArray(obj.elements) ? obj.elements : [],
			excludedKeys: Array.isArray(obj.excludedKeys) ? obj.excludedKeys.map((k) => normalizeString$1(k).trim()).filter((k) => Boolean(k)) : [],
			pageUrl: normalizeString$1(obj.pageUrl).trim() || void 0
		};
	}
	/**
	* Build a batch prompt for multiple element changes.
	* Designed for AgentChat integration to apply multiple visual edits at once.
	*/
	function buildAgentPromptBatch(elements, pageUrl) {
		const lines = [];
		lines.push("You are a senior frontend engineer working in a local codebase.");
		lines.push("Goal: persist a batch of visual edits from the browser into the source code with minimal changes.");
		lines.push("");
		lines.push(`Page URL: ${pageUrl}`);
		lines.push("");
		lines.push("## Batch Changes");
		lines.push(`Total elements: ${elements.length}`);
		lines.push("");
		lines.push("For each element, prefer \"source\" (file/line/component) when available; otherwise use selectors/fingerprint to locate it.");
		lines.push("");
		elements.forEach((element, index) => {
			var _element$debugSource, _element$locator, _element$locator2, _element$locator3, _element$locator4, _element$locator5;
			const title = element.fullLabel || element.label || element.elementKey;
			lines.push(`### ${index + 1}. ${title}`);
			lines.push(`- elementKey: ${element.elementKey}`);
			lines.push(`- change type: ${element.type}`);
			const ds = (_element$debugSource = element.debugSource) !== null && _element$debugSource !== void 0 ? _element$debugSource : (_element$locator = element.locator) === null || _element$locator === void 0 ? void 0 : _element$locator.debugSource;
			if (ds === null || ds === void 0 ? void 0 : ds.file) {
				const loc = ds.line ? `${ds.file}:${ds.line}${ds.column ? `:${ds.column}` : ""}` : ds.file;
				lines.push(`- source: ${loc}${ds.componentName ? ` (${ds.componentName})` : ""}`);
			}
			if ((_element$locator2 = element.locator) === null || _element$locator2 === void 0 || (_element$locator2 = _element$locator2.selectors) === null || _element$locator2 === void 0 ? void 0 : _element$locator2.length) {
				lines.push("- selectors:");
				for (const sel of element.locator.selectors.slice(0, 5)) lines.push(`  - ${sel}`);
			}
			if ((_element$locator3 = element.locator) === null || _element$locator3 === void 0 ? void 0 : _element$locator3.fingerprint) lines.push(`- fingerprint: ${element.locator.fingerprint}`);
			if (Array.isArray((_element$locator4 = element.locator) === null || _element$locator4 === void 0 ? void 0 : _element$locator4.path) && element.locator.path.length > 0) lines.push(`- path: ${JSON.stringify(element.locator.path)}`);
			if ((_element$locator5 = element.locator) === null || _element$locator5 === void 0 || (_element$locator5 = _element$locator5.shadowHostChain) === null || _element$locator5 === void 0 ? void 0 : _element$locator5.length) lines.push(`- shadowHostChain: ${JSON.stringify(element.locator.shadowHostChain)}`);
			lines.push("");
			const net = element.netEffect;
			lines.push("#### Net Effect (apply these final values)");
			if (net.textChange) {
				lines.push("##### Text");
				lines.push(`- before: ${JSON.stringify(net.textChange.before)}`);
				lines.push(`- after: ${JSON.stringify(net.textChange.after)}`);
				lines.push("");
			}
			if (net.classChanges) {
				lines.push("##### Classes");
				lines.push(`- before: ${net.classChanges.before.join(" ")}`);
				lines.push(`- after: ${net.classChanges.after.join(" ")}`);
				lines.push("");
			}
			if (net.styleChanges) {
				var _net$styleChanges$bef, _net$styleChanges$aft;
				lines.push("##### Styles (before → after)");
				const before = (_net$styleChanges$bef = net.styleChanges.before) !== null && _net$styleChanges$bef !== void 0 ? _net$styleChanges$bef : {};
				const after = (_net$styleChanges$aft = net.styleChanges.after) !== null && _net$styleChanges$aft !== void 0 ? _net$styleChanges$aft : {};
				const allKeys = /* @__PURE__ */ new Set([...Object.keys(before), ...Object.keys(after)]);
				for (const key of Array.from(allKeys).sort()) {
					var _before$key;
					const beforeVal = (_before$key = before[key]) !== null && _before$key !== void 0 ? _before$key : "(unset)";
					const afterRaw = Object.prototype.hasOwnProperty.call(after, key) ? after[key] : "(unset)";
					const afterVal = afterRaw === "" ? "(removed)" : afterRaw;
					if (beforeVal !== afterVal) lines.push(`- ${key}: "${beforeVal}" → "${afterVal}"`);
				}
				lines.push("");
			}
			if (!net.textChange && !net.classChanges && !net.styleChanges) {
				lines.push("- No net effect details available; use locator hints to inspect the element in code.");
				lines.push("");
			}
		});
		lines.push("## How to Apply");
		lines.push("1. Use \"source\" when available to go directly to the component file.");
		lines.push("2. Otherwise, use selectors/fingerprint/path to locate the element in the codebase.");
		lines.push("3. Apply the net effect with minimal changes and correct styling conventions.");
		lines.push("4. Avoid generated/bundled outputs; update source files only.");
		lines.push("");
		lines.push("## Constraints");
		lines.push("- Make the smallest safe edit possible for each element");
		lines.push("- If Tailwind/CSS Modules/styled-components are used, update the correct styling source");
		lines.push("- Do not change unrelated behavior or formatting");
		lines.push("");
		lines.push("## Output\nApply all the changes in the repo, then reply with a short summary of what file(s) you modified and the exact changes made.");
		return lines.join("\n");
	}
	function buildAgentPrompt(payload) {
		var _payload$fingerprint$, _payload$selectorCand, _payload$techStackHin, _payload$techStackHin2, _payload$techStackHin3, _payload$techStackHin4;
		const lines = [];
		lines.push("You are a senior frontend engineer working in a local codebase.");
		lines.push("Goal: persist a visual edit from the browser into the source code with minimal changes.");
		lines.push("");
		lines.push(`Page URL: ${payload.pageUrl}`);
		lines.push("");
		const ds = payload.debugSource;
		if (ds === null || ds === void 0 ? void 0 : ds.file) {
			lines.push("## Source Location (from React/Vue debug info)");
			const loc = ds.line ? `${ds.file}:${ds.line}${ds.column ? `:${ds.column}` : ""}` : ds.file;
			lines.push(`- file: ${loc}`);
			if (ds.componentName) lines.push(`- component: ${ds.componentName}`);
			lines.push("");
			lines.push("This is high-confidence source location extracted from framework debug info.");
			lines.push("Start your search here. Only fall back to fingerprint if this file is invalid.");
			lines.push("");
		} else if (payload.targetFile) {
			lines.push(`## Target File (best-effort): ${payload.targetFile}`);
			lines.push("If this path is invalid or points to node_modules, fall back to fingerprint search.");
			lines.push("");
		}
		lines.push("## Element Fingerprint");
		lines.push(`- tag: ${payload.fingerprint.tag}`);
		if (payload.fingerprint.id) lines.push(`- id: ${payload.fingerprint.id}`);
		if ((_payload$fingerprint$ = payload.fingerprint.classes) === null || _payload$fingerprint$ === void 0 ? void 0 : _payload$fingerprint$.length) lines.push(`- classes: ${payload.fingerprint.classes.join(" ")}`);
		if (payload.fingerprint.text) lines.push(`- text: ${payload.fingerprint.text}`);
		lines.push("");
		if ((_payload$selectorCand = payload.selectorCandidates) === null || _payload$selectorCand === void 0 ? void 0 : _payload$selectorCand.length) {
			lines.push("## CSS Selectors (ordered by specificity)");
			for (const sel of payload.selectorCandidates.slice(0, 5)) lines.push(`- ${sel}`);
			lines.push("");
			lines.push("Use these selectors to grep the codebase if file location is unavailable.");
			lines.push("");
		}
		if ((_payload$techStackHin = payload.techStackHint) === null || _payload$techStackHin === void 0 ? void 0 : _payload$techStackHin.length) {
			lines.push(`## Tech Stack: ${payload.techStackHint.join(", ")}`);
			lines.push("");
		}
		lines.push("## Requested Change");
		lines.push(`- type: ${payload.instruction.type}`);
		lines.push(`- description: ${payload.instruction.description}`);
		if (payload.instruction.type === "update_text" && payload.instruction.text !== void 0) lines.push(`- new text: ${JSON.stringify(payload.instruction.text)}`);
		if (payload.instruction.type === "update_style") {
			const op = payload.operation;
			if (op && (Object.keys(op.before).length > 0 || Object.keys(op.after).length > 0)) {
				lines.push("");
				lines.push("### Style Changes (before → after)");
				const allKeys = /* @__PURE__ */ new Set([...Object.keys(op.before), ...Object.keys(op.after)]);
				for (const key of allKeys) {
					var _op$before$key, _op$after$key;
					const before = (_op$before$key = op.before[key]) !== null && _op$before$key !== void 0 ? _op$before$key : "(unset)";
					const after = (_op$after$key = op.after[key]) !== null && _op$after$key !== void 0 ? _op$after$key : "(removed)";
					if (before !== after) lines.push(`  ${key}: "${before}" → "${after}"`);
				}
				if (op.removed.length > 0) lines.push(`  [Removed]: ${op.removed.join(", ")}`);
			} else if (payload.instruction.style) lines.push(`- style map: ${JSON.stringify(payload.instruction.style, null, 2)}`);
		}
		lines.push("");
		lines.push("## How to Apply");
		if (ds === null || ds === void 0 ? void 0 : ds.file) {
			var _payload$fingerprint$2;
			lines.push(`1. Open ${ds.file}${ds.line ? ` around line ${ds.line}` : ""}`);
			if (ds.componentName) lines.push(`2. Locate the "${ds.componentName}" component definition`);
			lines.push(`3. Find the element matching tag="${payload.fingerprint.tag}"${((_payload$fingerprint$2 = payload.fingerprint.classes) === null || _payload$fingerprint$2 === void 0 ? void 0 : _payload$fingerprint$2.length) ? ` with classes including "${payload.fingerprint.classes[0]}"` : ""}`);
			lines.push("4. Apply the requested style/text change");
		} else if (payload.targetFile) {
			lines.push(`1. Open ${payload.targetFile}`);
			lines.push("2. Search for the element by matching fingerprint (tag, classes, text)");
			lines.push("3. If not found, use repo-wide search with selectors or class names");
			lines.push("4. Apply the requested change");
		} else {
			var _payload$selectorCand2;
			lines.push("1. Use repo-wide search (rg) with class names or text from fingerprint");
			if ((_payload$selectorCand2 = payload.selectorCandidates) === null || _payload$selectorCand2 === void 0 ? void 0 : _payload$selectorCand2.length) lines.push(`2. Try searching for: "${payload.selectorCandidates[0]}"`);
			lines.push("3. Locate the component/template containing this element");
			lines.push("4. Apply the requested change");
		}
		lines.push("");
		lines.push("## Constraints");
		lines.push("- Make the smallest safe edit possible");
		if ((_payload$techStackHin2 = payload.techStackHint) === null || _payload$techStackHin2 === void 0 ? void 0 : _payload$techStackHin2.includes("Tailwind")) lines.push("- Tailwind detected: prefer updating className over inline styles");
		if (((_payload$techStackHin3 = payload.techStackHint) === null || _payload$techStackHin3 === void 0 ? void 0 : _payload$techStackHin3.includes("React")) || ((_payload$techStackHin4 = payload.techStackHint) === null || _payload$techStackHin4 === void 0 ? void 0 : _payload$techStackHin4.includes("Vue"))) lines.push("- Update the component source, not generated/bundled code");
		lines.push("- If CSS Modules or styled-components are used, update the correct styling source");
		lines.push("- Do not change unrelated behavior or formatting");
		lines.push("");
		lines.push("## Output\nApply the change in the repo, then reply with a short summary of what file(s) you modified and the exact change made.");
		return lines.join("\n");
	}
	function ensureContextMenu() {
		return _ensureContextMenu.apply(this, arguments);
	}
	function _ensureContextMenu() {
		_ensureContextMenu = _asyncToGenerator(function* () {
			try {
				var _chrome$contextMenus;
				if (!((_chrome$contextMenus = chrome.contextMenus) === null || _chrome$contextMenus === void 0 ? void 0 : _chrome$contextMenus.create)) return;
				try {
					yield chrome.contextMenus.remove(CONTEXT_MENU_ID);
				} catch (_unused2) {}
				yield chrome.contextMenus.create({
					id: CONTEXT_MENU_ID,
					title: "Toggle Web Editor",
					contexts: ["all"]
				});
			} catch (error) {
				console.warn("[WebEditor] Failed to ensure context menu:", error);
			}
		});
		return _ensureContextMenu.apply(this, arguments);
	}
	/**
	* Get the appropriate action constants based on version
	*/
	function getActions() {
		return WEB_EDITOR_V2_ACTIONS;
	}
	/**
	* Ensure the web editor script is injected into the tab
	* Supports both v1 (legacy) and v2 (new) versions
	*
	* V1 and V2 use different action names to avoid conflicts:
	* - V1: web_editor_ping, web_editor_toggle, etc.
	* - V2: web_editor_ping_v2, web_editor_toggle_v2, etc.
	*/
	function ensureEditorInjected(_x4) {
		return _ensureEditorInjected.apply(this, arguments);
	}
	function _ensureEditorInjected() {
		_ensureEditorInjected = _asyncToGenerator(function* (tabId) {
			const scriptPath = V2_SCRIPT_PATH;
			const logPrefix = "[WebEditorV2]";
			const actions = getActions();
			try {
				const pong = yield chrome.tabs.sendMessage(tabId, { action: actions.PING }, { frameId: 0 });
				if ((pong === null || pong === void 0 ? void 0 : pong.status) === "pong") return;
			} catch (_unused3) {}
			try {
				yield chrome.scripting.executeScript({
					target: { tabId },
					files: [scriptPath],
					world: "ISOLATED"
				});
				console.log(`${logPrefix} Script injected successfully`);
			} catch (error) {
				console.warn(`${logPrefix} Failed to inject editor script:`, error);
			}
		});
		return _ensureEditorInjected.apply(this, arguments);
	}
	/**
	* Inject props agent into MAIN world for Phase 7 Props editing
	* Only inject for v2 editor
	*/
	function ensurePropsAgentInjected(_x5) {
		return _ensurePropsAgentInjected.apply(this, arguments);
	}
	function _ensurePropsAgentInjected() {
		_ensurePropsAgentInjected = _asyncToGenerator(function* (tabId) {
			try {
				yield chrome.scripting.executeScript({
					target: { tabId },
					files: [PROPS_AGENT_SCRIPT_PATH],
					world: "MAIN"
				});
			} catch (error) {
				console.warn("[WebEditorV2] Failed to inject props agent:", error);
			}
		});
		return _ensurePropsAgentInjected.apply(this, arguments);
	}
	/**
	* Send cleanup event to props agent
	*/
	function sendPropsAgentCleanup(_x6) {
		return _sendPropsAgentCleanup.apply(this, arguments);
	}
	function _sendPropsAgentCleanup() {
		_sendPropsAgentCleanup = _asyncToGenerator(function* (tabId) {
			try {
				yield chrome.scripting.executeScript({
					target: { tabId },
					func: () => {
						try {
							window.dispatchEvent(new CustomEvent("web-editor-props:cleanup"));
						} catch (_unused4) {}
					},
					world: "ISOLATED"
				});
			} catch (error) {
				console.warn("[WebEditorV2] Failed to send props agent cleanup:", error);
			}
		});
		return _sendPropsAgentCleanup.apply(this, arguments);
	}
	/**
	* Content script ID prefix for early injection (document_start).
	* Registered scripts persist across sessions and survive browser restarts.
	*/
	var PROPS_AGENT_EARLY_INJECTION_ID_PREFIX = "mcp_we_props_early";
	/**
	* Sanitize a string for use in content script ID
	* Only allows alphanumeric, underscore, and hyphen
	*/
	function sanitizeContentScriptId(input) {
		return String(input !== null && input !== void 0 ? input : "").toLowerCase().replace(/[^a-z0-9_-]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 80) || "site";
	}
	/**
	* Build match patterns from tab URL for early injection.
	* Returns patterns for the specific host only (not all URLs).
	*/
	function buildEarlyInjectionPatterns(tabUrl) {
		let url;
		try {
			url = new URL(tabUrl);
		} catch (_unused5) {
			throw new Error("Invalid tab URL");
		}
		if (url.protocol !== "http:" && url.protocol !== "https:") throw new Error(`Early injection only supports http/https pages (got ${url.protocol})`);
		const host = url.hostname.trim();
		if (!host) throw new Error("Unable to derive host from tab URL");
		return {
			host,
			matches: [`*://${host}/*`]
		};
	}
	/**
	* Register props agent for early injection (document_start, MAIN world).
	* This allows capturing React DevTools hook before React initializes.
	*
	* The registration is per-host and persists across sessions.
	*/
	function registerPropsAgentEarlyInjection(_x7) {
		return _registerPropsAgentEarlyInjection.apply(this, arguments);
	}
	function _registerPropsAgentEarlyInjection() {
		_registerPropsAgentEarlyInjection = _asyncToGenerator(function* (tabUrl) {
			const { host, matches } = buildEarlyInjectionPatterns(tabUrl);
			const id = `${PROPS_AGENT_EARLY_INJECTION_ID_PREFIX}_${sanitizeContentScriptId(host)}`;
			let alreadyRegistered = false;
			try {
				alreadyRegistered = (yield chrome.scripting.getRegisteredContentScripts({ ids: [id] })).some((s) => s.id === id);
			} catch (_unused6) {
				alreadyRegistered = false;
			}
			if (!alreadyRegistered) {
				yield chrome.scripting.registerContentScripts([{
					id,
					js: [PROPS_AGENT_SCRIPT_PATH],
					matches,
					runAt: "document_start",
					world: "MAIN",
					allFrames: false,
					persistAcrossSessions: true
				}]);
				console.log(`[WebEditorV2] Registered early injection for ${host}`);
			}
			return {
				id,
				host,
				matches,
				alreadyRegistered
			};
		});
		return _registerPropsAgentEarlyInjection.apply(this, arguments);
	}
	function toggleEditorInTab(_x8) {
		return _toggleEditorInTab.apply(this, arguments);
	}
	function _toggleEditorInTab() {
		_toggleEditorInTab = _asyncToGenerator(function* (tabId) {
			yield ensureEditorInjected(tabId);
			const logPrefix = "[WebEditorV2]";
			const actions = getActions();
			try {
				const resp = yield chrome.tabs.sendMessage(tabId, { action: actions.TOGGLE }, { frameId: 0 });
				const active = typeof (resp === null || resp === void 0 ? void 0 : resp.active) === "boolean" ? resp.active : void 0;
				if (active === true) yield ensurePropsAgentInjected(tabId);
				else if (active === false) yield sendPropsAgentCleanup(tabId);
				return { active };
			} catch (error) {
				console.warn(`${logPrefix} Failed to toggle editor in tab:`, error);
				return {};
			}
		});
		return _toggleEditorInTab.apply(this, arguments);
	}
	function getActiveTabId$1() {
		return _getActiveTabId$1.apply(this, arguments);
	}
	function _getActiveTabId$1() {
		_getActiveTabId$1 = _asyncToGenerator(function* () {
			try {
				var _tabs$;
				const tabs = yield chrome.tabs.query({
					active: true,
					currentWindow: true
				});
				const tabId = tabs === null || tabs === void 0 || (_tabs$ = tabs[0]) === null || _tabs$ === void 0 ? void 0 : _tabs$.id;
				return typeof tabId === "number" ? tabId : null;
			} catch (_unused7) {
				return null;
			}
		});
		return _getActiveTabId$1.apply(this, arguments);
	}
	function initWebEditorListeners() {
		var _chrome$contextMenus2;
		ensureContextMenu().catch(() => {});
		chrome.tabs.onRemoved.addListener((tabId) => {
			try {
				const keys = [
					`${WEB_EDITOR_TX_CHANGED_SESSION_KEY_PREFIX}${tabId}`,
					`${WEB_EDITOR_SELECTION_SESSION_KEY_PREFIX}${tabId}`,
					`${WEB_EDITOR_EXCLUDED_KEYS_SESSION_KEY_PREFIX}${tabId}`
				];
				chrome.storage.session.remove(keys).catch(() => {});
			} catch (_unused8) {}
		});
		if ((_chrome$contextMenus2 = chrome.contextMenus) === null || _chrome$contextMenus2 === void 0 || (_chrome$contextMenus2 = _chrome$contextMenus2.onClicked) === null || _chrome$contextMenus2 === void 0 ? void 0 : _chrome$contextMenus2.addListener) chrome.contextMenus.onClicked.addListener(function() {
			var _ref = _asyncToGenerator(function* (info, tab) {
				try {
					if (info.menuItemId !== CONTEXT_MENU_ID) return;
					const tabId = tab === null || tab === void 0 ? void 0 : tab.id;
					if (typeof tabId !== "number") return;
					yield toggleEditorInTab(tabId);
				} catch (_unused9) {}
			});
			return function(_x9, _x10) {
				return _ref.apply(this, arguments);
			};
		}());
		chrome.commands.onCommand.addListener(function() {
			var _ref2 = _asyncToGenerator(function* (command) {
				try {
					if (command !== COMMAND_KEY$1) return;
					const tabId = yield getActiveTabId$1();
					if (typeof tabId !== "number") return;
					yield toggleEditorInTab(tabId);
				} catch (_unused10) {}
			});
			return function(_x11) {
				return _ref2.apply(this, arguments);
			};
		}());
		chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
			try {
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_PROPS_REGISTER_EARLY_INJECTION) {
					_asyncToGenerator(function* () {
						const senderTab = _sender === null || _sender === void 0 ? void 0 : _sender.tab;
						const senderTabId = senderTab === null || senderTab === void 0 ? void 0 : senderTab.id;
						const senderTabUrl = senderTab === null || senderTab === void 0 ? void 0 : senderTab.url;
						if (typeof senderTabId !== "number" || typeof senderTabUrl !== "string") return sendResponse({
							success: false,
							error: "Sender tab information is required"
						});
						try {
							sendResponse(_objectSpread2({ success: true }, yield registerPropsAgentEarlyInjection(senderTabUrl)));
							yield new Promise((resolve) => setTimeout(resolve, 50));
							try {
								yield chrome.tabs.reload(senderTabId);
							} catch (_unused11) {}
						} catch (err) {
							sendResponse({
								success: false,
								error: err instanceof Error ? err.message : String(err)
							});
						}
					})();
					return true;
				}
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_OPEN_SOURCE) {
					_asyncToGenerator(function* () {
						try {
							const payload = message.payload;
							const debugSource = payload === null || payload === void 0 ? void 0 : payload.debugSource;
							if (!debugSource || typeof debugSource !== "object") return sendResponse({
								success: false,
								error: "debugSource is required"
							});
							const rec = debugSource;
							const file = typeof rec.file === "string" ? rec.file.trim() : "";
							if (!file) return sendResponse({
								success: false,
								error: "debugSource.file is required"
							});
							const stored = yield chrome.storage.local.get(["nativeServerPort", "agent-selected-project-id"]);
							const portRaw = stored.nativeServerPort;
							const port = Number.isFinite(Number(portRaw)) ? Number(portRaw) : DEFAULT_NATIVE_SERVER_PORT;
							const projectId = stored["agent-selected-project-id"];
							if (!projectId || typeof projectId !== "string") return sendResponse({
								success: false,
								error: "No project selected. Please select a project in AgentChat first."
							});
							const lineRaw = Number(rec.line);
							const columnRaw = Number(rec.column);
							const line = Number.isFinite(lineRaw) && lineRaw > 0 ? lineRaw : void 0;
							const column = Number.isFinite(columnRaw) && columnRaw > 0 ? columnRaw : void 0;
							const openResp = yield fetch(`http://127.0.0.1:${port}/agent/projects/${encodeURIComponent(projectId)}/open-file`, {
								method: "POST",
								headers: { "Content-Type": "application/json" },
								body: JSON.stringify({
									filePath: file,
									line,
									column
								})
							});
							let result;
							try {
								result = yield openResp.json();
							} catch (_unused12) {
								result = {
									success: false,
									error: (yield openResp.text().catch(() => "")) || `HTTP ${openResp.status}`
								};
							}
							sendResponse(result);
						} catch (err) {
							sendResponse({
								success: false,
								error: err instanceof Error ? err.message : String(err)
							});
						}
					})();
					return true;
				}
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_TOGGLE) {
					getActiveTabId$1().then(function() {
						var _ref3 = _asyncToGenerator(function* (tabId) {
							if (typeof tabId !== "number") return sendResponse({ success: false });
							sendResponse(_objectSpread2({ success: true }, yield toggleEditorInTab(tabId)));
						});
						return function(_x12) {
							return _ref3.apply(this, arguments);
						};
					}()).catch(() => sendResponse({ success: false }));
					return true;
				}
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_TX_CHANGED) {
					_asyncToGenerator(function* () {
						var _sender$tab;
						const senderTabId = _sender === null || _sender === void 0 || (_sender$tab = _sender.tab) === null || _sender$tab === void 0 ? void 0 : _sender$tab.id;
						if (typeof senderTabId !== "number") {
							sendResponse({
								success: false,
								error: "Sender tabId is required"
							});
							return;
						}
						const rawPayload = message.payload;
						if (!rawPayload || typeof rawPayload !== "object") {
							sendResponse({
								success: false,
								error: "Invalid payload"
							});
							return;
						}
						const payload = _objectSpread2(_objectSpread2({}, rawPayload), {}, { tabId: senderTabId });
						const storageKey = `${WEB_EDITOR_TX_CHANGED_SESSION_KEY_PREFIX}${senderTabId}`;
						if (payload.action === "clear") {
							const excludedKey = `${WEB_EDITOR_EXCLUDED_KEYS_SESSION_KEY_PREFIX}${senderTabId}`;
							yield chrome.storage.session.remove([storageKey, excludedKey]);
						} else yield chrome.storage.session.set({ [storageKey]: payload });
						chrome.runtime.sendMessage({
							type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_TX_CHANGED,
							payload
						}).catch(() => {});
						sendResponse({ success: true });
					})().catch((error) => {
						sendResponse({
							success: false,
							error: String(error instanceof Error ? error.message : error)
						});
					});
					return true;
				}
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_SELECTION_CHANGED) {
					_asyncToGenerator(function* () {
						var _sender$tab2;
						const senderTabId = _sender === null || _sender === void 0 || (_sender$tab2 = _sender.tab) === null || _sender$tab2 === void 0 ? void 0 : _sender$tab2.id;
						if (typeof senderTabId !== "number") {
							sendResponse({
								success: false,
								error: "Sender tabId is required"
							});
							return;
						}
						const rawPayload = message.payload;
						if (!rawPayload || typeof rawPayload !== "object") {
							sendResponse({
								success: false,
								error: "Invalid payload"
							});
							return;
						}
						const payload = _objectSpread2(_objectSpread2({}, rawPayload), {}, { tabId: senderTabId });
						const storageKey = `${WEB_EDITOR_SELECTION_SESSION_KEY_PREFIX}${senderTabId}`;
						if (payload.selected === null) yield chrome.storage.session.remove(storageKey);
						else yield chrome.storage.session.set({ [storageKey]: payload });
						chrome.runtime.sendMessage({
							type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_SELECTION_CHANGED,
							payload
						}).catch(() => {});
						sendResponse({ success: true });
					})().catch((error) => {
						sendResponse({
							success: false,
							error: String(error instanceof Error ? error.message : error)
						});
					});
					return true;
				}
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_CLEAR_SELECTION) {
					_asyncToGenerator(function* () {
						const payload = message.payload;
						const targetTabId = payload === null || payload === void 0 ? void 0 : payload.tabId;
						if (typeof targetTabId !== "number" || targetTabId <= 0) {
							sendResponse({
								success: false,
								error: "Invalid tabId"
							});
							return;
						}
						try {
							yield chrome.tabs.sendMessage(targetTabId, { action: WEB_EDITOR_V2_ACTIONS.CLEAR_SELECTION });
							sendResponse({ success: true });
						} catch (error) {
							sendResponse({
								success: false,
								error: error instanceof Error ? error.message : "Failed to send to tab"
							});
						}
					})().catch((error) => {
						sendResponse({
							success: false,
							error: String(error instanceof Error ? error.message : error)
						});
					});
					return true;
				}
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_APPLY_BATCH) {
					const payload = normalizeApplyBatchPayload(message.payload);
					_asyncToGenerator(function* () {
						var _sender$tab3, _sender$tab4, _sender$tab5;
						const senderTabId = _sender === null || _sender === void 0 || (_sender$tab3 = _sender.tab) === null || _sender$tab3 === void 0 ? void 0 : _sender$tab3.id;
						const senderWindowId = _sender === null || _sender === void 0 || (_sender$tab4 = _sender.tab) === null || _sender$tab4 === void 0 ? void 0 : _sender$tab4.windowId;
						const stored = yield chrome.storage.local.get(["nativeServerPort", STORAGE_KEY_SELECTED_SESSION$1]);
						const portRaw = stored === null || stored === void 0 ? void 0 : stored.nativeServerPort;
						const port = Number.isFinite(Number(portRaw)) ? Number(portRaw) : DEFAULT_NATIVE_SERVER_PORT;
						const sessionId = normalizeString$1(stored === null || stored === void 0 ? void 0 : stored[STORAGE_KEY_SELECTED_SESSION$1]).trim();
						if (typeof senderTabId === "number") openAgentChatSidepanel(senderTabId, senderWindowId, sessionId || void 0).catch(() => {});
						if (!sessionId) {
							sendResponse({
								success: false,
								error: "No Agent session selected. Please select or create a session in AgentChat, then try Apply again."
							});
							return;
						}
						const hydratedPayload = typeof senderTabId === "number" ? _objectSpread2(_objectSpread2({}, payload), {}, { tabId: senderTabId }) : payload;
						let sessionExcludedKeys = [];
						if (typeof senderTabId === "number") {
							const excludedSessionKey = `${WEB_EDITOR_EXCLUDED_KEYS_SESSION_KEY_PREFIX}${senderTabId}`;
							try {
								var _chrome$storage;
								if ((_chrome$storage = chrome.storage) === null || _chrome$storage === void 0 || (_chrome$storage = _chrome$storage.session) === null || _chrome$storage === void 0 ? void 0 : _chrome$storage.get) {
									const stored = yield chrome.storage.session.get(excludedSessionKey);
									const raw = stored === null || stored === void 0 ? void 0 : stored[excludedSessionKey];
									sessionExcludedKeys = Array.isArray(raw) ? raw.map((k) => normalizeString$1(k).trim()).filter(Boolean) : [];
								}
							} catch (_unused13) {}
						}
						const excluded = /* @__PURE__ */ new Set([...hydratedPayload.excludedKeys, ...sessionExcludedKeys]);
						const elements = hydratedPayload.elements.filter((e) => !excluded.has(e.elementKey));
						if (elements.length === 0) {
							sendResponse({
								success: false,
								error: "No elements selected to apply."
							});
							return;
						}
						const pageUrl = normalizeString$1(hydratedPayload.pageUrl).trim() || normalizeString$1(_sender === null || _sender === void 0 || (_sender$tab5 = _sender.tab) === null || _sender$tab5 === void 0 ? void 0 : _sender$tab5.url).trim() || "unknown";
						const instruction = buildAgentPromptBatch(elements, pageUrl);
						const url = `http://127.0.0.1:${port}/agent/chat/${encodeURIComponent(sessionId)}/act`;
						const elementLabels = elements.slice(0, 5).map((e) => e.label);
						const resp = yield fetch(url, {
							method: "POST",
							headers: { "Content-Type": "application/json" },
							body: JSON.stringify({
								instruction,
								dbSessionId: sessionId,
								displayText: `Apply ${elements.length} change${elements.length === 1 ? "" : "s"}`,
								clientMeta: {
									kind: "web_editor_apply_batch",
									pageUrl,
									elementCount: elements.length,
									elementLabels
								}
							})
						});
						if (!resp.ok) {
							sendResponse({
								success: false,
								error: (yield resp.text().catch(() => "")) || `HTTP ${resp.status}`
							});
							return;
						}
						const json = yield resp.json().catch(() => ({}));
						const requestId = json === null || json === void 0 ? void 0 : json.requestId;
						if (requestId) subscribeToSessionStatus(sessionId, requestId, port).catch(() => {});
						sendResponse({
							success: true,
							requestId,
							sessionId
						});
					})().catch((error) => {
						sendResponse({
							success: false,
							error: String(error instanceof Error ? error.message : error)
						});
					});
					return true;
				}
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_HIGHLIGHT_ELEMENT) {
					const payload = message.payload;
					_asyncToGenerator(function* () {
						const tabId = payload === null || payload === void 0 ? void 0 : payload.tabId;
						if (typeof tabId !== "number" || !Number.isFinite(tabId) || tabId <= 0) {
							sendResponse({
								success: false,
								error: "Invalid tabId"
							});
							return;
						}
						const mode = payload === null || payload === void 0 ? void 0 : payload.mode;
						if (mode !== "hover" && mode !== "clear") {
							sendResponse({
								success: false,
								error: "Invalid mode"
							});
							return;
						}
						if (mode === "clear") {
							try {
								sendResponse({
									success: true,
									response: yield chrome.tabs.sendMessage(tabId, {
										action: WEB_EDITOR_V2_ACTIONS.HIGHLIGHT_ELEMENT,
										mode: "clear"
									})
								});
							} catch (error) {
								sendResponse({
									success: false,
									error: String(error instanceof Error ? error.message : error)
								});
							}
							return;
						}
						const locator = payload === null || payload === void 0 ? void 0 : payload.locator;
						if (!locator || typeof locator !== "object") {
							sendResponse({
								success: false,
								error: "Invalid locator"
							});
							return;
						}
						const primarySelector = (Array.isArray(locator.selectors) ? locator.selectors : []).find((s) => typeof s === "string" && s.trim().length > 0);
						if (!primarySelector) {
							sendResponse({
								success: false,
								error: "No valid selector in locator"
							});
							return;
						}
						try {
							sendResponse({
								success: true,
								response: yield chrome.tabs.sendMessage(tabId, {
									action: WEB_EDITOR_V2_ACTIONS.HIGHLIGHT_ELEMENT,
									locator,
									selector: primarySelector,
									mode,
									elementKey: payload.elementKey
								})
							});
						} catch (error) {
							sendResponse({
								success: false,
								error: String(error instanceof Error ? error.message : error)
							});
						}
					})().catch((error) => {
						sendResponse({
							success: false,
							error: String(error instanceof Error ? error.message : error)
						});
					});
					return true;
				}
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_REVERT_ELEMENT) {
					const payload = message.payload;
					_asyncToGenerator(function* () {
						const tabId = payload === null || payload === void 0 ? void 0 : payload.tabId;
						if (typeof tabId !== "number" || !Number.isFinite(tabId) || tabId <= 0) {
							sendResponse({
								success: false,
								error: "Invalid tabId"
							});
							return;
						}
						const elementKey = payload === null || payload === void 0 ? void 0 : payload.elementKey;
						if (typeof elementKey !== "string" || !elementKey.trim()) {
							sendResponse({
								success: false,
								error: "Invalid elementKey"
							});
							return;
						}
						try {
							sendResponse(_objectSpread2({ success: true }, yield chrome.tabs.sendMessage(tabId, {
								action: WEB_EDITOR_V2_ACTIONS.REVERT_ELEMENT,
								elementKey
							}, { frameId: 0 })));
						} catch (error) {
							sendResponse({
								success: false,
								error: String(error instanceof Error ? error.message : error)
							});
						}
					})().catch((error) => {
						sendResponse({
							success: false,
							error: String(error instanceof Error ? error.message : error)
						});
					});
					return true;
				}
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_APPLY) {
					const payload = normalizeApplyPayload(message.payload);
					_asyncToGenerator(function* () {
						var _sender$tab6;
						const senderTabId = _sender === null || _sender === void 0 || (_sender$tab6 = _sender.tab) === null || _sender$tab6 === void 0 ? void 0 : _sender$tab6.id;
						const sessionId = typeof senderTabId === "number" ? `web-editor-${senderTabId}` : "web-editor";
						const stored = yield chrome.storage.local.get(["nativeServerPort", "agent-selected-project-id"]);
						const portRaw = stored === null || stored === void 0 ? void 0 : stored.nativeServerPort;
						const port = Number.isFinite(Number(portRaw)) ? Number(portRaw) : DEFAULT_NATIVE_SERVER_PORT;
						const projectId = normalizeString$1(stored === null || stored === void 0 ? void 0 : stored["agent-selected-project-id"]).trim() || "";
						if (!projectId) return sendResponse({
							success: false,
							error: "No Agent project selected. Open Side Panel → Agent Assistant and select/create a project first."
						});
						const instruction = buildAgentPrompt(payload);
						const url = `http://127.0.0.1:${port}/agent/chat/${encodeURIComponent(sessionId)}/act`;
						const resp = yield fetch(url, {
							method: "POST",
							headers: { "Content-Type": "application/json" },
							body: JSON.stringify({
								instruction,
								projectId
							})
						});
						if (!resp.ok) return sendResponse({
							success: false,
							error: (yield resp.text().catch(() => "")) || `HTTP ${resp.status}`
						});
						const json = yield resp.json().catch(() => ({}));
						const requestId = json === null || json === void 0 ? void 0 : json.requestId;
						if (requestId) subscribeToSessionStatus(sessionId, requestId, port).catch(() => {});
						return sendResponse({
							success: true,
							requestId,
							sessionId
						});
					})().catch((error) => {
						sendResponse({
							success: false,
							error: String(error instanceof Error ? error.message : error)
						});
					});
					return true;
				}
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_STATUS_QUERY) {
					const { requestId } = message;
					if (!requestId || typeof requestId !== "string") {
						sendResponse({
							success: false,
							error: "requestId is required"
						});
						return false;
					}
					const entry = getExecutionStatus(requestId);
					if (!entry) sendResponse({
						success: true,
						status: "pending",
						message: "Waiting for status..."
					});
					else sendResponse({
						success: true,
						status: entry.status,
						message: entry.message,
						result: entry.result
					});
					return false;
				}
				if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_CANCEL_EXECUTION) {
					const payload = message.payload;
					_asyncToGenerator(function* () {
						var _payload$sessionId, _payload$requestId;
						const sessionId = payload === null || payload === void 0 || (_payload$sessionId = payload.sessionId) === null || _payload$sessionId === void 0 ? void 0 : _payload$sessionId.trim();
						const requestId = payload === null || payload === void 0 || (_payload$requestId = payload.requestId) === null || _payload$requestId === void 0 ? void 0 : _payload$requestId.trim();
						if (!sessionId) {
							sendResponse({
								success: false,
								error: "sessionId is required"
							});
							return;
						}
						if (!requestId) {
							sendResponse({
								success: false,
								error: "requestId is required"
							});
							return;
						}
						const port = (yield chrome.storage.local.get(["nativeServerPort"])).nativeServerPort || DEFAULT_NATIVE_SERVER_PORT;
						try {
							const cancelUrl = `http://127.0.0.1:${port}/agent/chat/${encodeURIComponent(sessionId)}/cancel/${encodeURIComponent(requestId)}`;
							const response = yield fetch(cancelUrl, { method: "DELETE" });
							if (!response.ok) {
								sendResponse({
									success: false,
									error: yield response.text().catch(() => `HTTP ${response.status}`)
								});
								return;
							}
							setExecutionStatus(requestId, "cancelled", "Execution cancelled by user");
							const sseConnection = sseConnections.get(sessionId);
							if (sseConnection && sseConnection.lastRequestId === requestId) {
								sseConnection.abort.abort();
								sseConnections.delete(sessionId);
							}
							sendResponse({ success: true });
						} catch (error) {
							sendResponse({
								success: false,
								error: String(error instanceof Error ? error.message : error)
							});
						}
					})().catch((error) => {
						sendResponse({
							success: false,
							error: String(error instanceof Error ? error.message : error)
						});
					});
					return true;
				}
			} catch (error) {
				sendResponse({
					success: false,
					error: String(error instanceof Error ? error.message : error)
				});
			}
			return false;
		});
	}
	//#endregion
	//#region entrypoints/background/quick-panel/agent-handler.ts
	init_asyncToGenerator();
	var LOG_PREFIX$2 = "[QuickPanelAgent]";
	var KEEPALIVE_TAG = "quick-panel-ai";
	/** Storage key for AgentChat selected session ID (owned by sidepanel composables) */
	var STORAGE_KEY_SELECTED_SESSION = "agent-selected-session-id";
	/** Timeout for initial SSE connection establishment */
	var SSE_CONNECT_TIMEOUT_MS = 3e3;
	/** Safety timeout for entire request lifecycle (15 minutes) */
	var REQUEST_TIMEOUT_MS = 900 * 1e3;
	/** Flag indicating SSE connection timed out but we should continue */
	var SSE_TIMEOUT = Symbol("SSE_TIMEOUT");
	/** Active streaming requests indexed by requestId */
	var activeRequests = /* @__PURE__ */ new Map();
	/** Initialization flag to prevent duplicate listeners */
	var initialized$1 = false;
	function normalizeString(value) {
		return typeof value === "string" ? value : "";
	}
	function normalizePort(value) {
		const num = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
		if (!Number.isFinite(num)) return null;
		const port = Math.floor(num);
		if (port <= 0 || port > 65535) return null;
		return port;
	}
	function createRequestId() {
		try {
			var _crypto, _crypto$randomUUID;
			const id = (_crypto = crypto) === null || _crypto === void 0 || (_crypto$randomUUID = _crypto.randomUUID) === null || _crypto$randomUUID === void 0 ? void 0 : _crypto$randomUUID.call(_crypto);
			if (id) return id;
		} catch (_unused) {}
		return `req_${Date.now()}_${Math.random().toString(16).slice(2)}`;
	}
	function sleep(ms) {
		return new Promise((resolve) => setTimeout(resolve, ms));
	}
	function isTerminalStatus(status) {
		return status === "completed" || status === "error" || status === "cancelled";
	}
	function createErrorEvent(sessionId, requestId, error) {
		return {
			type: "error",
			error: error || "Unknown error",
			data: {
				sessionId,
				requestId
			}
		};
	}
	function createCancelledStatusEvent(sessionId, requestId, message) {
		return {
			type: "status",
			data: {
				sessionId,
				status: "cancelled",
				requestId,
				message: message || "Cancelled by user"
			}
		};
	}
	/**
	* Forward a RealtimeEvent to the Quick Panel in the originating tab.
	* Handles receiver unavailability gracefully by cleaning up the request.
	*/
	function forwardEventToQuickPanel(request, event) {
		const message = {
			action: TOOL_MESSAGE_TYPES.QUICK_PANEL_AI_EVENT,
			requestId: request.requestId,
			sessionId: request.sessionId,
			event
		};
		const sendOptions = typeof request.frameId === "number" ? { frameId: request.frameId } : void 0;
		(sendOptions ? chrome.tabs.sendMessage(request.tabId, message, sendOptions) : chrome.tabs.sendMessage(request.tabId, message)).catch((err) => {
			const msg = err instanceof Error ? err.message : String(err);
			if (msg.includes("Receiving end does not exist") || msg.includes("No tab with id") || msg.includes("The message port closed")) cleanupRequest(request.requestId, "receiver_unavailable");
		});
	}
	/**
	* Clean up an active request and release all associated resources.
	* Idempotent - safe to call multiple times.
	*/
	function cleanupRequest(requestId, reason) {
		const request = activeRequests.get(requestId);
		if (!request) return;
		activeRequests.delete(requestId);
		try {
			clearTimeout(request.timeoutId);
		} catch (_unused2) {}
		try {
			request.abortController.abort();
		} catch (_unused3) {}
		try {
			request.releaseKeepalive();
		} catch (_unused4) {}
		console.debug(`${LOG_PREFIX$2} Cleaned up request ${requestId} (${reason})`);
	}
	/**
	* Validate that the selected session exists on the native server.
	* Returns false if the session is invalid or server is unreachable.
	*/
	function validateSession(_x, _x2) {
		return _validateSession.apply(this, arguments);
	}
	function _validateSession() {
		_validateSession = _asyncToGenerator(function* (port, sessionId) {
			const url = `http://127.0.0.1:${port}/agent/sessions/${encodeURIComponent(sessionId)}`;
			try {
				return (yield fetch(url)).ok;
			} catch (_unused5) {
				return false;
			}
		});
		return _validateSession.apply(this, arguments);
	}
	/**
	* Determine if a RealtimeEvent should be forwarded for a specific requestId.
	*
	* Events without requestId (connected, heartbeat) are session-level signals
	* and are not forwarded to avoid confusion with request-specific events.
	*/
	function shouldForwardEvent(event, requestId) {
		switch (event.type) {
			case "message":
				var _event$data;
				return ((_event$data = event.data) === null || _event$data === void 0 ? void 0 : _event$data.requestId) === requestId;
			case "status":
				var _event$data2;
				return ((_event$data2 = event.data) === null || _event$data2 === void 0 ? void 0 : _event$data2.requestId) === requestId;
			case "usage":
				var _event$data3;
				return ((_event$data3 = event.data) === null || _event$data3 === void 0 ? void 0 : _event$data3.requestId) === requestId;
			case "error":
				var _event$data4;
				return ((_event$data4 = event.data) === null || _event$data4 === void 0 ? void 0 : _event$data4.requestId) === requestId;
			case "connected":
			case "heartbeat": return false;
			default: return false;
		}
	}
	/**
	* Create an SSE subscription for the request's session.
	*
	* The subscription:
	* 1. Connects to the session's /stream endpoint
	* 2. Filters events by requestId
	* 3. Forwards matching events to Quick Panel
	* 4. Triggers cleanup on terminal status
	*
	* @returns SseSubscription with ready promise that resolves to:
	*   - true: SSE connected successfully
	*   - false: SSE failed (request was cleaned up, don't send /act)
	*/
	function createSseSubscription(request) {
		let readySettled = false;
		let readyResolve;
		const ready = new Promise((resolve) => {
			readyResolve = resolve;
		});
		const settleReady = (connected) => {
			if (readySettled) return;
			readySettled = true;
			readyResolve(connected);
		};
		return {
			ready,
			done: _asyncToGenerator(function* () {
				const sseUrl = `http://127.0.0.1:${request.port}/agent/chat/${encodeURIComponent(request.sessionId)}/stream`;
				try {
					const response = yield fetch(sseUrl, {
						method: "GET",
						headers: { Accept: "text/event-stream" },
						signal: request.abortController.signal
					});
					if (!response.ok || !response.body) throw new Error(`SSE stream unavailable (HTTP ${response.status})`);
					settleReady(true);
					const reader = response.body.getReader();
					const decoder = new TextDecoder();
					let buffer = "";
					while (true) {
						var _lines$pop;
						const { done, value } = yield reader.read();
						if (done) break;
						buffer += decoder.decode(value, { stream: true });
						const lines = buffer.split("\n");
						buffer = (_lines$pop = lines.pop()) !== null && _lines$pop !== void 0 ? _lines$pop : "";
						for (const line of lines) {
							if (!line.startsWith("data:")) continue;
							const raw = line.slice(5).trim();
							if (!raw) continue;
							try {
								var _event$data5;
								const event = JSON.parse(raw);
								if (!shouldForwardEvent(event, request.requestId)) continue;
								forwardEventToQuickPanel(request, event);
								if (event.type === "status" && ((_event$data5 = event.data) === null || _event$data5 === void 0 ? void 0 : _event$data5.requestId) === request.requestId) {
									if (isTerminalStatus(event.data.status)) {
										cleanupRequest(request.requestId, `terminal_status:${event.data.status}`);
										return;
									}
								}
							} catch (_unused6) {}
						}
					}
				} catch (err) {
					if (err instanceof Error && err.name === "AbortError") {
						settleReady(false);
						return;
					}
					if (activeRequests.has(request.requestId)) {
						const msg = err instanceof Error ? err.message : String(err);
						forwardEventToQuickPanel(request, createErrorEvent(request.sessionId, request.requestId, msg));
						cleanupRequest(request.requestId, "sse_error");
					}
					settleReady(false);
				}
			})()
		};
	}
	/**
	* Send the act request to native-server.
	* The server will emit events via SSE which are already being subscribed.
	*
	* @param request - Active request context
	* @throws Error if request was cancelled/aborted or HTTP request fails
	*/
	function postActRequest(_x3) {
		return _postActRequest.apply(this, arguments);
	}
	function _postActRequest() {
		_postActRequest = _asyncToGenerator(function* (request) {
			if (request.abortController.signal.aborted) throw new Error("Request was cancelled");
			const url = `http://127.0.0.1:${request.port}/agent/chat/${encodeURIComponent(request.sessionId)}/act`;
			const payload = {
				instruction: request.instruction,
				dbSessionId: request.sessionId,
				requestId: request.requestId
			};
			const response = yield fetch(url, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(payload),
				signal: request.abortController.signal
			});
			if (!response.ok) {
				const text = yield response.text().catch(() => "");
				throw new Error(text || `HTTP ${response.status}`);
			}
		});
		return _postActRequest.apply(this, arguments);
	}
	/**
	* Cancel an active request on the native-server.
	*/
	function cancelRequestOnServer(_x4, _x5, _x6) {
		return _cancelRequestOnServer.apply(this, arguments);
	}
	function _cancelRequestOnServer() {
		_cancelRequestOnServer = _asyncToGenerator(function* (port, sessionId, requestId) {
			const url = `http://127.0.0.1:${port}/agent/chat/${encodeURIComponent(sessionId)}/cancel/${encodeURIComponent(requestId)}`;
			try {
				yield fetch(url, { method: "DELETE" });
			} catch (_unused7) {}
		});
		return _cancelRequestOnServer.apply(this, arguments);
	}
	/**
	* Check if the request is still active and not cancelled.
	* Used as a guard before each async operation to handle race conditions.
	*/
	function isRequestStillActive(request) {
		return activeRequests.has(request.requestId) && !request.abortController.signal.aborted;
	}
	/**
	* Main orchestration function for starting a Quick Panel AI request.
	*
	* Flow:
	* 1. Ensure native server is running
	* 2. Validate session exists
	* 3. Open sidepanel (best-effort)
	* 4. Start SSE subscription (wait for connection)
	* 5. Fire act request
	* 6. Let SSE handle event forwarding and cleanup
	*
	* @remarks
	* Guards are placed after each async operation to handle cancellation races.
	*/
	function startRequest(_x7) {
		return _startRequest.apply(this, arguments);
	}
	function _startRequest() {
		_startRequest = _asyncToGenerator(function* (request) {
			try {
				yield chrome.runtime.sendMessage({ type: NativeMessageType.ENSURE_NATIVE }).catch(() => null);
				if (!isRequestStillActive(request)) return;
				const sessionValid = yield validateSession(request.port, request.sessionId);
				if (!isRequestStillActive(request)) return;
				if (!sessionValid) {
					forwardEventToQuickPanel(request, createErrorEvent(request.sessionId, request.requestId, "Selected Agent session is not available. Please open AgentChat and select a valid session."));
					openAgentChatSidepanel(request.tabId, request.windowId).catch(() => {});
					cleanupRequest(request.requestId, "session_invalid");
					return;
				}
				openAgentChatSidepanel(request.tabId, request.windowId, request.sessionId).catch(() => {});
				const sse = createSseSubscription(request);
				const sseResult = yield Promise.race([sse.ready, sleep(SSE_CONNECT_TIMEOUT_MS).then(() => SSE_TIMEOUT)]);
				if (!isRequestStillActive(request)) return;
				if (sseResult === false) {
					console.debug(`${LOG_PREFIX$2} SSE failed for ${request.requestId}, not sending /act`);
					return;
				}
				if (sseResult === SSE_TIMEOUT) console.warn(`${LOG_PREFIX$2} SSE connection timed out for ${request.requestId}, proceeding anyway`);
				yield postActRequest(request);
				sse.done;
			} catch (err) {
				if (err instanceof Error && err.name === "AbortError") return;
				if (!activeRequests.has(request.requestId)) return;
				const msg = err instanceof Error ? err.message : String(err);
				forwardEventToQuickPanel(request, createErrorEvent(request.sessionId, request.requestId, msg));
				cleanupRequest(request.requestId, "start_failed");
			}
		});
		return _startRequest.apply(this, arguments);
	}
	/**
	* Handle QUICK_PANEL_SEND_TO_AI message.
	* Creates a new streaming request and starts the orchestration flow.
	*/
	function handleSendToAI(_x8, _x9) {
		return _handleSendToAI.apply(this, arguments);
	}
	function _handleSendToAI() {
		_handleSendToAI = _asyncToGenerator(function* (message, sender) {
			var _sender$tab, _sender$tab2, _message$payload, _normalizePort;
			const tabId = sender === null || sender === void 0 || (_sender$tab = sender.tab) === null || _sender$tab === void 0 ? void 0 : _sender$tab.id;
			const windowId = sender === null || sender === void 0 || (_sender$tab2 = sender.tab) === null || _sender$tab2 === void 0 ? void 0 : _sender$tab2.windowId;
			const frameId = typeof (sender === null || sender === void 0 ? void 0 : sender.frameId) === "number" ? sender.frameId : void 0;
			if (typeof tabId !== "number") return {
				success: false,
				error: "Quick Panel request must originate from a tab."
			};
			const instruction = normalizeString(message === null || message === void 0 || (_message$payload = message.payload) === null || _message$payload === void 0 ? void 0 : _message$payload.instruction).trim();
			if (!instruction) return {
				success: false,
				error: "instruction is required"
			};
			const stored = yield chrome.storage.local.get([STORAGE_KEYS.NATIVE_SERVER_PORT, STORAGE_KEY_SELECTED_SESSION]);
			const port = (_normalizePort = normalizePort(stored === null || stored === void 0 ? void 0 : stored[STORAGE_KEYS.NATIVE_SERVER_PORT])) !== null && _normalizePort !== void 0 ? _normalizePort : NATIVE_HOST.DEFAULT_PORT;
			const sessionId = normalizeString(stored === null || stored === void 0 ? void 0 : stored[STORAGE_KEY_SELECTED_SESSION]).trim();
			if (!sessionId) {
				openAgentChatSidepanel(tabId, windowId).catch(() => {});
				return {
					success: false,
					error: "No Agent session selected. Please open AgentChat, select or create a session, then try again."
				};
			}
			const requestId = createRequestId();
			const releaseKeepalive = acquireKeepalive(KEEPALIVE_TAG);
			const abortController = new AbortController();
			const timeoutId = setTimeout(() => {
				const activeRequest = activeRequests.get(requestId);
				if (!activeRequest) return;
				forwardEventToQuickPanel(activeRequest, createErrorEvent(activeRequest.sessionId, activeRequest.requestId, "Quick Panel stream timed out. Please continue in AgentChat sidepanel."));
				cleanupRequest(requestId, "timeout");
			}, REQUEST_TIMEOUT_MS);
			const request = {
				requestId,
				sessionId,
				instruction,
				tabId,
				windowId: typeof windowId === "number" ? windowId : void 0,
				frameId,
				port,
				createdAt: Date.now(),
				abortController,
				releaseKeepalive,
				timeoutId
			};
			activeRequests.set(requestId, request);
			startRequest(request);
			return {
				success: true,
				requestId,
				sessionId
			};
		});
		return _handleSendToAI.apply(this, arguments);
	}
	/**
	* Handle QUICK_PANEL_CANCEL_AI message.
	* Cancels an active request both locally and on the server.
	*/
	function handleCancelAI(_x10, _x11) {
		return _handleCancelAI.apply(this, arguments);
	}
	function _handleCancelAI() {
		_handleCancelAI = _asyncToGenerator(function* (message, sender) {
			var _sender$tab3, _message$payload2, _message$payload3;
			const tabId = sender === null || sender === void 0 || (_sender$tab3 = sender.tab) === null || _sender$tab3 === void 0 ? void 0 : _sender$tab3.id;
			const frameId = typeof (sender === null || sender === void 0 ? void 0 : sender.frameId) === "number" ? sender.frameId : void 0;
			if (typeof tabId !== "number") return {
				success: false,
				error: "Cancel request must originate from a tab."
			};
			const requestId = normalizeString(message === null || message === void 0 || (_message$payload2 = message.payload) === null || _message$payload2 === void 0 ? void 0 : _message$payload2.requestId).trim();
			const fallbackSessionId = normalizeString(message === null || message === void 0 || (_message$payload3 = message.payload) === null || _message$payload3 === void 0 ? void 0 : _message$payload3.sessionId).trim();
			if (!requestId) return {
				success: false,
				error: "requestId is required"
			};
			const activeRequest = activeRequests.get(requestId);
			const sessionId = (activeRequest === null || activeRequest === void 0 ? void 0 : activeRequest.sessionId) || fallbackSessionId;
			if (!sessionId) return {
				success: false,
				error: "Unknown sessionId for this request. Please cancel from AgentChat sidepanel."
			};
			if (activeRequest) try {
				activeRequest.abortController.abort();
			} catch (_unused8) {}
			let port = activeRequest === null || activeRequest === void 0 ? void 0 : activeRequest.port;
			if (!port) {
				var _normalizePort2;
				const stored = yield chrome.storage.local.get([STORAGE_KEYS.NATIVE_SERVER_PORT]);
				port = (_normalizePort2 = normalizePort(stored === null || stored === void 0 ? void 0 : stored[STORAGE_KEYS.NATIVE_SERVER_PORT])) !== null && _normalizePort2 !== void 0 ? _normalizePort2 : NATIVE_HOST.DEFAULT_PORT;
			}
			cancelRequestOnServer(port, sessionId, requestId);
			const cancelledEvent = createCancelledStatusEvent(sessionId, requestId);
			const eventMessage = {
				action: TOOL_MESSAGE_TYPES.QUICK_PANEL_AI_EVENT,
				requestId,
				sessionId,
				event: cancelledEvent
			};
			const sendOptions = typeof frameId === "number" ? { frameId } : void 0;
			(sendOptions ? chrome.tabs.sendMessage(tabId, eventMessage, sendOptions) : chrome.tabs.sendMessage(tabId, eventMessage)).catch(() => {}).finally(() => {
				cleanupRequest(requestId, "cancelled_by_user");
			});
			return { success: true };
		});
		return _handleCancelAI.apply(this, arguments);
	}
	/**
	* Initialize the Quick Panel Agent Handler.
	* Sets up message listeners and tab cleanup handlers.
	*/
	function initQuickPanelAgentHandler() {
		if (initialized$1) return;
		initialized$1 = true;
		chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
			if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.QUICK_PANEL_SEND_TO_AI) {
				handleSendToAI(message, sender).then(sendResponse).catch((err) => {
					sendResponse({
						success: false,
						error: (err instanceof Error ? err.message : String(err)) || "Unknown error"
					});
				});
				return true;
			}
			if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.QUICK_PANEL_CANCEL_AI) {
				handleCancelAI(message, sender).then(sendResponse).catch((err) => {
					sendResponse({
						success: false,
						error: (err instanceof Error ? err.message : String(err)) || "Unknown error"
					});
				});
				return true;
			}
			return false;
		});
		chrome.tabs.onRemoved.addListener((tabId) => {
			for (const [requestId, request] of activeRequests) if (request.tabId === tabId) cleanupRequest(requestId, "tab_removed");
		});
		console.debug(`${LOG_PREFIX$2} Initialized`);
	}
	//#endregion
	//#region entrypoints/background/quick-panel/commands.ts
	init_asyncToGenerator();
	/**
	* Quick Panel Commands Handler
	*
	* Handles keyboard shortcuts for Quick Panel functionality.
	* Listens for the 'toggle_quick_panel' command and sends toggle message
	* to the content script in the active tab.
	*/
	var COMMAND_KEY = "toggle_quick_panel";
	var LOG_PREFIX$1 = "[QuickPanelCommands]";
	/**
	* Get the ID of the currently active tab
	*/
	function getActiveTabId() {
		return _getActiveTabId.apply(this, arguments);
	}
	function _getActiveTabId() {
		_getActiveTabId = _asyncToGenerator(function* () {
			try {
				var _tab$id;
				const [tab] = yield chrome.tabs.query({
					active: true,
					currentWindow: true
				});
				return (_tab$id = tab === null || tab === void 0 ? void 0 : tab.id) !== null && _tab$id !== void 0 ? _tab$id : null;
			} catch (err) {
				console.warn(`${LOG_PREFIX$1} Failed to get active tab:`, err);
				return null;
			}
		});
		return _getActiveTabId.apply(this, arguments);
	}
	/**
	* Check if a tab can receive content scripts
	*/
	function isValidTabUrl(url) {
		if (!url) return false;
		return ![
			"chrome://",
			"chrome-extension://",
			"edge://",
			"about:",
			"moz-extension://",
			"devtools://",
			"view-source:",
			"data:"
		].some((prefix) => url.startsWith(prefix));
	}
	/**
	* Toggle Quick Panel in the active tab
	*/
	function toggleQuickPanelInActiveTab() {
		return _toggleQuickPanelInActiveTab.apply(this, arguments);
	}
	function _toggleQuickPanelInActiveTab() {
		_toggleQuickPanelInActiveTab = _asyncToGenerator(function* () {
			const tabId = yield getActiveTabId();
			if (tabId === null) {
				console.warn(`${LOG_PREFIX$1} No active tab found`);
				return;
			}
			try {
				const tab = yield chrome.tabs.get(tabId);
				if (!isValidTabUrl(tab.url)) {
					console.warn(`${LOG_PREFIX$1} Cannot inject into tab URL: ${tab.url}`);
					return;
				}
			} catch (err) {
				console.warn(`${LOG_PREFIX$1} Failed to get tab info:`, err);
				return;
			}
			try {
				const response = yield chrome.tabs.sendMessage(tabId, { action: "toggle_quick_panel" });
				if (response === null || response === void 0 ? void 0 : response.success) console.log(`${LOG_PREFIX$1} Quick Panel toggled, visible: ${response.visible}`);
				else console.warn(`${LOG_PREFIX$1} Toggle failed:`, response === null || response === void 0 ? void 0 : response.error);
			} catch (err) {
				console.warn(`${LOG_PREFIX$1} Failed to send toggle message (content script may not be loaded):`, err);
			}
		});
		return _toggleQuickPanelInActiveTab.apply(this, arguments);
	}
	/**
	* Initialize Quick Panel keyboard command listener
	*/
	function initQuickPanelCommands() {
		console.log(`${LOG_PREFIX$1} initQuickPanelCommands called`);
		chrome.commands.onCommand.addListener(function() {
			var _ref = _asyncToGenerator(function* (command) {
				console.log(`${LOG_PREFIX$1} onCommand received:`, command);
				if (command !== COMMAND_KEY) {
					console.log(`${LOG_PREFIX$1} Command not matched, expected:`, COMMAND_KEY);
					return;
				}
				console.log(`${LOG_PREFIX$1} Command matched, calling toggleQuickPanelInActiveTab...`);
				try {
					yield toggleQuickPanelInActiveTab();
					console.log(`${LOG_PREFIX$1} toggleQuickPanelInActiveTab completed`);
				} catch (err) {
					console.error(`${LOG_PREFIX$1} Command handler error:`, err);
				}
			});
			return function(_x) {
				return _ref.apply(this, arguments);
			};
		}());
		console.log(`${LOG_PREFIX$1} Command listener registered for: ${COMMAND_KEY}`);
	}
	//#endregion
	//#region entrypoints/background/quick-panel/tabs-handler.ts
	/**
	* Quick Panel Tabs Handler
	*
	* Background service worker bridge for Quick Panel (content script) to:
	* - Enumerate tabs for search suggestions
	* - Activate a selected tab
	* - Close a tab
	*
	* Note: Content scripts cannot access chrome.tabs.* directly.
	*/
	init_asyncToGenerator();
	var LOG_PREFIX = "[QuickPanelTabs]";
	function isValidTabId(value) {
		return typeof value === "number" && Number.isFinite(value) && value > 0;
	}
	function isValidWindowId(value) {
		return typeof value === "number" && Number.isFinite(value) && value > 0;
	}
	function normalizeBoolean(value) {
		return value === true;
	}
	function getLastAccessed(tab) {
		const value = tab.lastAccessed;
		return typeof value === "number" && Number.isFinite(value) ? value : void 0;
	}
	function safeErrorMessage(err) {
		if (err instanceof Error) return err.message || String(err);
		return String(err);
	}
	/**
	* Convert a chrome.tabs.Tab to our summary format.
	* Returns null if tab is invalid.
	*/
	function toTabSummary(tab) {
		var _tab$title, _tab$url, _tab$favIconUrl, _tab$mutedInfo;
		if (!isValidTabId(tab.id)) return null;
		const windowId = isValidWindowId(tab.windowId) ? tab.windowId : null;
		if (windowId === null) return null;
		return {
			tabId: tab.id,
			windowId,
			title: (_tab$title = tab.title) !== null && _tab$title !== void 0 ? _tab$title : "",
			url: (_tab$url = tab.url) !== null && _tab$url !== void 0 ? _tab$url : "",
			favIconUrl: (_tab$favIconUrl = tab.favIconUrl) !== null && _tab$favIconUrl !== void 0 ? _tab$favIconUrl : void 0,
			active: normalizeBoolean(tab.active),
			pinned: normalizeBoolean(tab.pinned),
			audible: normalizeBoolean(tab.audible),
			muted: normalizeBoolean((_tab$mutedInfo = tab.mutedInfo) === null || _tab$mutedInfo === void 0 ? void 0 : _tab$mutedInfo.muted),
			index: typeof tab.index === "number" && Number.isFinite(tab.index) ? tab.index : 0,
			lastAccessed: getLastAccessed(tab)
		};
	}
	function handleTabsQuery(_x, _x2) {
		return _handleTabsQuery.apply(this, arguments);
	}
	function _handleTabsQuery() {
		_handleTabsQuery = _asyncToGenerator(function* (message, sender) {
			try {
				var _message$payload$incl, _message$payload, _sender$tab, _sender$tab2;
				const includeAllWindows = (_message$payload$incl = (_message$payload = message.payload) === null || _message$payload === void 0 ? void 0 : _message$payload.includeAllWindows) !== null && _message$payload$incl !== void 0 ? _message$payload$incl : true;
				const currentWindowId = isValidWindowId((_sender$tab = sender.tab) === null || _sender$tab === void 0 ? void 0 : _sender$tab.windowId) ? sender.tab.windowId : null;
				const currentTabId = isValidTabId((_sender$tab2 = sender.tab) === null || _sender$tab2 === void 0 ? void 0 : _sender$tab2.id) ? sender.tab.id : null;
				if (!includeAllWindows && currentWindowId === null) return {
					success: false,
					error: "Invalid request: sender tab context required for window-scoped queries"
				};
				const queryInfo = includeAllWindows ? {} : { windowId: currentWindowId };
				const tabs = yield chrome.tabs.query(queryInfo);
				const summaries = [];
				for (const tab of tabs) {
					const summary = toTabSummary(tab);
					if (summary) summaries.push(summary);
				}
				return {
					success: true,
					tabs: summaries,
					currentTabId,
					currentWindowId
				};
			} catch (err) {
				console.warn(`${LOG_PREFIX} Error querying tabs:`, err);
				return {
					success: false,
					error: safeErrorMessage(err) || "Failed to query tabs"
				};
			}
		});
		return _handleTabsQuery.apply(this, arguments);
	}
	function handleActivateTab(_x3) {
		return _handleActivateTab.apply(this, arguments);
	}
	function _handleActivateTab() {
		_handleActivateTab = _asyncToGenerator(function* (message) {
			try {
				var _message$payload2, _message$payload3;
				const tabId = (_message$payload2 = message.payload) === null || _message$payload2 === void 0 ? void 0 : _message$payload2.tabId;
				const windowId = (_message$payload3 = message.payload) === null || _message$payload3 === void 0 ? void 0 : _message$payload3.windowId;
				if (!isValidTabId(tabId)) return {
					success: false,
					error: "Invalid tabId"
				};
				if (isValidWindowId(windowId)) try {
					yield chrome.windows.update(windowId, { focused: true });
				} catch (_unused) {}
				yield chrome.tabs.update(tabId, { active: true });
				return { success: true };
			} catch (err) {
				console.warn(`${LOG_PREFIX} Error activating tab:`, err);
				return {
					success: false,
					error: safeErrorMessage(err) || "Failed to activate tab"
				};
			}
		});
		return _handleActivateTab.apply(this, arguments);
	}
	function handleCloseTab(_x4) {
		return _handleCloseTab.apply(this, arguments);
	}
	function _handleCloseTab() {
		_handleCloseTab = _asyncToGenerator(function* (message) {
			try {
				var _message$payload4;
				const tabId = (_message$payload4 = message.payload) === null || _message$payload4 === void 0 ? void 0 : _message$payload4.tabId;
				if (!isValidTabId(tabId)) return {
					success: false,
					error: "Invalid tabId"
				};
				yield chrome.tabs.remove(tabId);
				return { success: true };
			} catch (err) {
				console.warn(`${LOG_PREFIX} Error closing tab:`, err);
				return {
					success: false,
					error: safeErrorMessage(err) || "Failed to close tab"
				};
			}
		});
		return _handleCloseTab.apply(this, arguments);
	}
	var initialized = false;
	/**
	* Initialize the Quick Panel Tabs handler.
	* Safe to call multiple times - subsequent calls are no-ops.
	*/
	function initQuickPanelTabsHandler() {
		if (initialized) return;
		initialized = true;
		chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
			if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.QUICK_PANEL_TABS_QUERY) {
				handleTabsQuery(message, sender).then(sendResponse);
				return true;
			}
			if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.QUICK_PANEL_TAB_ACTIVATE) {
				handleActivateTab(message).then(sendResponse);
				return true;
			}
			if ((message === null || message === void 0 ? void 0 : message.type) === BACKGROUND_MESSAGE_TYPES.QUICK_PANEL_TAB_CLOSE) {
				handleCloseTab(message).then(sendResponse);
				return true;
			}
			return false;
		});
		console.debug(`${LOG_PREFIX} Initialized`);
	}
	//#endregion
	//#region entrypoints/background/index.ts
	/**
	* Background script entry point
	* Initializes all background services and listeners
	*/
	var background_default = defineBackground(() => {
		initNativeHostListener();
		initStorageManagerListener();
		initElementMarkerListeners();
		initWebEditorListeners();
		initQuickPanelAgentHandler();
		initQuickPanelTabsHandler();
		initQuickPanelCommands();
	});
	//#endregion
	//#region node_modules/@wxt-dev/browser/src/index.mjs
	var _globalThis$browser;
	((_globalThis$browser = globalThis.browser) === null || _globalThis$browser === void 0 || (_globalThis$browser = _globalThis$browser.runtime) === null || _globalThis$browser === void 0 ? void 0 : _globalThis$browser.id) ? globalThis.browser : globalThis.chrome;
	//#endregion
	//#region node_modules/@webext-core/match-patterns/lib/index.js
	var _MatchPattern = class {
		constructor(matchPattern) {
			if (matchPattern === "<all_urls>") {
				this.isAllUrls = true;
				this.protocolMatches = [..._MatchPattern.PROTOCOLS];
				this.hostnameMatch = "*";
				this.pathnameMatch = "*";
			} else {
				const groups = /(.*):\/\/(.*?)(\/.*)/.exec(matchPattern);
				if (groups == null) throw new InvalidMatchPattern(matchPattern, "Incorrect format");
				const [_, protocol, hostname, pathname] = groups;
				validateProtocol(matchPattern, protocol);
				validateHostname(matchPattern, hostname);
				this.protocolMatches = protocol === "*" ? ["http", "https"] : [protocol];
				this.hostnameMatch = hostname;
				this.pathnameMatch = pathname;
			}
		}
		includes(url) {
			if (this.isAllUrls) return true;
			const u = typeof url === "string" ? new URL(url) : url instanceof Location ? new URL(url.href) : url;
			return !!this.protocolMatches.find((protocol) => {
				if (protocol === "http") return this.isHttpMatch(u);
				if (protocol === "https") return this.isHttpsMatch(u);
				if (protocol === "file") return this.isFileMatch(u);
				if (protocol === "ftp") return this.isFtpMatch(u);
				if (protocol === "urn") return this.isUrnMatch(u);
			});
		}
		isHttpMatch(url) {
			return url.protocol === "http:" && this.isHostPathMatch(url);
		}
		isHttpsMatch(url) {
			return url.protocol === "https:" && this.isHostPathMatch(url);
		}
		isHostPathMatch(url) {
			if (!this.hostnameMatch || !this.pathnameMatch) return false;
			const hostnameMatchRegexs = [this.convertPatternToRegex(this.hostnameMatch), this.convertPatternToRegex(this.hostnameMatch.replace(/^\*\./, ""))];
			const pathnameMatchRegex = this.convertPatternToRegex(this.pathnameMatch);
			return !!hostnameMatchRegexs.find((regex) => regex.test(url.hostname)) && pathnameMatchRegex.test(url.pathname);
		}
		isFileMatch(url) {
			throw Error("Not implemented: file:// pattern matching. Open a PR to add support");
		}
		isFtpMatch(url) {
			throw Error("Not implemented: ftp:// pattern matching. Open a PR to add support");
		}
		isUrnMatch(url) {
			throw Error("Not implemented: urn:// pattern matching. Open a PR to add support");
		}
		convertPatternToRegex(pattern) {
			const starsReplaced = this.escapeForRegex(pattern).replace(/\\\*/g, ".*");
			return RegExp(`^${starsReplaced}$`);
		}
		escapeForRegex(string) {
			return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
		}
	};
	var MatchPattern = _MatchPattern;
	MatchPattern.PROTOCOLS = [
		"http",
		"https",
		"file",
		"ftp",
		"urn"
	];
	var InvalidMatchPattern = class extends Error {
		constructor(matchPattern, reason) {
			super(`Invalid match pattern "${matchPattern}": ${reason}`);
		}
	};
	function validateProtocol(matchPattern, protocol) {
		if (!MatchPattern.PROTOCOLS.includes(protocol) && protocol !== "*") throw new InvalidMatchPattern(matchPattern, `${protocol} not a valid protocol (${MatchPattern.PROTOCOLS.join(", ")})`);
	}
	function validateHostname(matchPattern, hostname) {
		if (hostname.includes(":")) throw new InvalidMatchPattern(matchPattern, `Hostname cannot include a port`);
		if (hostname.includes("*") && hostname.length > 1 && !hostname.startsWith("*.")) throw new InvalidMatchPattern(matchPattern, `If using a wildcard (*), it must go at the start of the hostname`);
	}
	//#endregion
	//#region \0virtual:wxt-background-entrypoint?C:/Users/gajja/Documents/data-science/Gakrcli/packages/chrome-extension/entrypoints/background/index.ts
	/** Wrapper around `console` with a "[wxt]" prefix */
	var logger = {
		debug: (...args) => ([...args], void 0),
		log: (...args) => ([...args], void 0),
		warn: (...args) => ([...args], void 0),
		error: (...args) => ([...args], void 0)
	};
	var result;
	try {
		result = background_default.main();
		if (result instanceof Promise) console.warn("The background's main() function return a promise, but it must be synchronous");
	} catch (err) {
		logger.error("The background crashed on startup!");
		throw err;
	}
	//#endregion
	return result;
})();
